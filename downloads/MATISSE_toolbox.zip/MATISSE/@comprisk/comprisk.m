classdef comprisk
    % COMPRISK comprisk objects contain competing risks data.
    %
    % competing risks data generalize survival data to settings where more
    % than one event type can occur: The status indicator can take on
    % 2 or more values depending on the type of event that occurred at the
    % exit time.
    %
    % MATISSE can compute multiple decrement lifetables and cause-specific
    % hazard functions.
    %
    % See also comprisk/comprisk, survival.

    properties

        time(:, 1) {mustBeMatrix} = [];             % time to event
        status(:, 1) {mustBeMatrix} = [];           % event type or censored
        fullname (1, :) {mustBeTextScalar} = '';    % a scientific name for the data
        values (1, :) {mustBeNumeric} = [];         % event types, 0 for censored observations
        labels (1, :) {mustBeText} = {''};          % corresponding event type labels
        time_units (1, :) {mustBeTextScalar} = '';  % e.g. 'years'

    end

    methods

        function S = comprisk(varargin)
            % COMPRISK competing risks data.
            %
            % S = comprisk(...
            %      'time', vector, ...
            %      'status', vector of integers, ...
            %      'fullname', 'string', ...
            %      'values', [0, 1, 2, ..., K], ...
            %      'labels', {'non-event label', 'event 1', ... 'event K'}, ...
            %      'time_units', 'string')
            %
            % * always code non-event aka censored observations by 0
            % * time and status are both set to missing if either value is missing
            %
            % See also survival.

            if nargin == 0
                % Contents of an empty comprisk
                S.time = [];
                S.status = [];
                S.fullname = '';
                S.values = [];
                S.labels = {''};
                S.time_units = '';

                return
            end

            if isa(varargin{1}, 'comprisk')
                S = varargin{1};
                return
            end

            % Contents of an empty survival
            S.time = [];
            S.status = [];
            S.fullname = '';
            S.values = [];
            S.labels = {''};
            S.time_units = '';

            N = numel(varargin);

            if N == 0
                return
            end

            %%%
            % whittle the arguments
            %%%
            lArgin = varargin;
            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};

                if ~ischar(propi)
                    error('A property must be specified using a string.')
                end

                switch lower(propi)


                    case 'time'
                        if ismatrix(vali) && isreal(vali)
                            if ~(any(vali(:) < 0))
                                S.time = vali(:);
                            else
                                error('time values must be non-negative')
                            end
                        else
                            error('time values must be numeric')
                        end

                    case 'status'
                        if ismatrix(vali) && isreal(vali)
                            if all(eq(rem(vali, 1), 0) | isnan(vali))
                                % the + coerces logical to double
                                S.status = +vali(:);
                            else
                                error('status values must be integers including 0')
                            end
                        else
                            error('status values must integers including 0')
                        end

                    case 'fullname'
                        if ischar(vali)
                            S.fullname = vali;
                        else
                            error('fullname must be a string')
                        end

                    case 'values'
                        % first see if this is a real vector
                        if ~(isreal(vali) && isnumeric(vali))
                            error('values must be vector')
                        end
                        if any(vali < 0)
                            error('values must be >= 0')
                        end
                        if any(rem(vali, 1)~=0)
                            error('values must be integers')
                        end

                        if ~ismember(0, vali)
                            error('values must include 0')
                        end

                        S.values = vali(:)';

                    case 'labels'
                        if ~iscellstr(vali) %#ok<ISCLSTR>
                            error('labels must be a cellstr')
                        else
                            if lt(numel(vali), 2)
                                error('you must specify at least two labels')
                            else
                                S.labels = vali;
                            end

                        end

                    case 'time_units'
                        if ischar(vali)
                            S.time_units = vali;
                        else
                            error('time_units must be a string')
                        end
                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('the last property has no matching value');
                end

            end

            % time and status must have the same length
            n_t = size(S.time, 1);
            n_s = size(S.status, 1);
            if ~eq(n_t, n_s)
                error('time and status data must have the same length')
            end

            % status and labels must have the same length
            n_l = numel(S.labels);
            n_v = numel(S.values);
            if ~eq(n_l, n_v)
                error(' number of values and labels must be equal')
            end

            % status data can include only values
            if ~(all(ismember(S.status, S.values) | isnan(S.status)))
                error('undefined status data')
            end

            % force the sequence of values to be integers from 1 to K
            % this makes many things easier downstream
            [TMP1, TMP2] = sort(S.values);
            TMP3 = S.labels(TMP2);
            S.values = TMP1;
            S.labels = TMP3;

            if isempty(S.fullname)
                S.fullname = 'competing risks data';
            end

            if isempty(S.time_units)
                S.time_units = 'time';
            end

            % A record is entirely missing if any value is missing
            miss = isnan(S.time) | isnan(S.status);
            S.time(miss) = NaN;
            S.status(miss) = NaN;

        end

        function r = end(g, k, ~)
            % END end method for comprisk objects.

            switch k
                case 1
                    r = size(g, 1);
                case 2
                    r = size(g, 2);
                otherwise
            end

        end

        function B = isempty(S)
            % ISEMPTY isempty for comprisk objects.
            %
            % B = ISEMPTY(S)
            %
            % See also length, size, isnan.

            B = isempty(S.time);

        end

        function B = isnan(S)
            % ISNAN isnan for comprisk objects. 
            %
            % B = ISNAN(S)
            %
            % See also isempty.

            B = isnan(S.time);

        end

        function L = length(S)
            % LENGTH length of a comprisk object.
            %
            % L = LENGTH(S)
            %
            % See also size, isempty.

            L = size(S.time, 1);

        end

        function varargout = size(S, varargin)
            % SIZE size of a comprisk object.
            %
            % [R, C] = SIZE(S)
            % R = SIZE(S, 1)
            % C = SIZE(S, 2)
            %
            % Number of rows R and columns C of S.time.
            %
            % See also length, isempty.

            switch nargin
                case 1
                    switch nargout
                        case {0, 1}
                            varargout{1} = [size(S.time, 1), size(S.time, 2)];
                        case 2
                            varargout{1} = size(S.time, 1);
                            varargout{2} = size(S.time, 2);
                        otherwise
                            error('too many outputs')
                    end

                case 2
                    d = varargin{1};
                    switch nargout
                        case {0, 1}
                            varargout{1} = size(S.time, d(1));
                        case 2
                            varargout{1} = size(S.time, d(1));
                            varargout{2} = size(S.time, d(2));
                        otherwise
                            error('too many outputs')
                    end
            end

        end

        function G = subsasgn(X, S, V)
            % SUBSASGN subscripted assignment for comprisk objects.

            if length(S) > 1
                DEPTH = numel(S);
                error('index expression has depth %g, cannot be > 1', DEPTH)
            end

            switch S.type

                case '.'

                    switch S.subs


                        case 'fullname'
                            G = X;
                            G.fullname = V;
                        case 'labels'
                            G = X;
                            G.labels = V;
                        case 'time_units'
                            G = X;
                            G.time_units = V;


                        otherwise

                            warning(['assignment of ' S.subs ' is undefined'])
                    end

                case '()'
                    warning('parantheses indexing is undefined')

                case '{}'
                    warning('brace indexing is undefined')

                otherwise

            end

        end

        function U = subsref(R, S)
            % SUBSREF subscripted referencing for a comprisk object.

            if length(S) > 1

                DEPTH = numel(S);
                for d = 1:DEPTH
                    if d == 1
                        U = subsref(R, S(1));
                    else
                        U = subsref(U, S(d));
                    end
                end

            else

                switch S.type

                    case '.'

                        switch S.subs

                            case 'time'
                                U = R.time;
                            case 'status'
                                U = R.status;
                            case 'fullname'
                                U = R.fullname;
                            case 'values'
                                U = R.values;
                            case 'labels'
                                U = R.labels;
                            case 'time_units'
                                U = R.event_label;
                            otherwise

                        end

                    case '()'
                        if isa(S.subs{1}, 'boolean')
                            S.subs = find(S.subs{1}.data == 1);
                            S.subs = {S.subs};
                        elseif isa(S.subs{1}, 'logical')
                            S.subs = S.subs{1};
                            S.subs = {S.subs};
                        elseif isa(S.subs{1}, 'numeric')

                            % let MATLAB handle any errors
                        end
                        NI = numel(S.subs);
                        switch NI
                            case {0, 1}
                                SUBS = cell(1, 2);
                                SUBS{1} = S.subs{1};
                                SUBS{2} = ':';
                            case 2
                                SUBS = S.subs;
                            otherwise

                        end

                        TIME = R.time(SUBS{1}(:), SUBS{2});
                        STATUS = R.status(SUBS{1}(:), SUBS{2});
                        U = comprisk(...
                            'time', TIME, ...
                            'status', STATUS, ...
                            'fullname', R.fullname, ...
                            'values', R.values, ...
                            'labels', R.labels, ...
                            'time_units', R.time_units);

                    case '{}'

                        % do nothing
                        U = R;
                end

            end

        end

        function disp(S)
            % DISP command window disp of a comprisk object.

            if isempty(S)
                disp('empty comprisk')
                return
            end

            disp(['<strong>' S.fullname '</strong>'])
            disp(' ')

            dta = [S.time, S.status];
            nt = size(S, 1);
            bad = isnan(dta(:, 1));
            nm = sum(bad);
            data = dta(~bad, :);

            if isempty(data)
                return
            end

            fu = sum(data(:, 1));
            ev = nnz(data(:, 2));
            sl = S.labels;
            % unique also sorts
            sv = S.values;
            nv = numel(sv) - 1;
            txt = [...
                '<strong>' num2str(nt - nm) '</strong> non-missing cases with ' ...
                '<strong>' num2str(fu, '%20.2f') '</strong> time units of ''' S.time_units ''', '  ...
                '<strong>' num2str(nv) '</strong> event classes, and '...
                '<strong>' num2str(ev) '</strong> total events.'];
            disp(txt)

            eventTable = histcounts(data(:, 2), [sv sv(end)+1]);
            crudeTable = eventTable/fu;

            T = tbl(...
                'data', [sv', eventTable', crudeTable'], ...
                'fullname', '', ...
                'row_labels', sl, ...
                'col_labels', {'Value', 'Events', 'Crude Rate'}, ...
                'labels', {'Outcomes', ''});
            disp(T)

        end

        function varargout = mdl(varargin)
            % MDL multiple decrement lifetable of a comprisk object.
            %
            % MDL(S)
            % [M, P] = MDL(S, go(...))
            %
            % * M - intermediate calculations
            % * P - plotted data
            %
            % See also hsp.

            switch nargin
                case 1
                    S = varargin{1};
                    K = numel(S.values);
                    PVP = ego('class', 'comprisk', 'method', 'mdl');
                    PVP.LineColor = 1:K;

                case 2
                    S = varargin{1};
                    K = numel(S.values);
                    PVP = mascara(K, varargin{2});

                otherwise
                    error('too many inputs')
            end

            M = MDLCORE(S);
            P = preprocess(M, S, PVP.Alpha);

            if PVP.Plot

                MDLPLOT(P, PVP);

            end

            switch nargout
                case 0
                case 1
                    varargout{1} = M;
                case 2
                    varargout{1} = M;
                    varargout{2} = P;
                otherwise
                    error('too many outputs')
            end

        end

        function H = hsp(S, varargin)
            % HSP B-spline hazard function estimation for each event type in a comprisk object.
            %
            % H = HSP(S, 'Order', <values>, 'Segments', <values>, 'boot', <value>, 'Alpha', <value>)
            %
            % 'Order'    - a scalar or sequence of non-negative integers
            %              1 - step function
            %              2 - piecewise linear
            %              3 - piecewise quadratic
            %              4 - piecewise cubic
            %              ...
            %
            % 'Segments' - a scalar or sequence of positive integers
            %              1 - 1 segment
            %              2 - 2 segments split at the median
            %              3 - 3 segments split at the tertiles
            %              ...
            %
            % 'boot'     - scalar, number of bootstrap relications (100 default)
            %
            % 'Alpha'    - scalar between 0 and 1 (default 0.05), confidence level
            %
            % * one hazard function per cause
            % * knots at quantiles of the observed event times by cause.
            %
            % See also mdl, plato.

            K = numel(S.values) - 1;
            Y = cell(1, K);
            H = cell(1, K);
            B = cell(1, K);

            for i = 1:K
                Y{i} = survival(...
                    'time', S.time, ...
                    'status', S.status == i, ...
                    'fullname', S.labels{i+1}, ...
                    'labels', {'AE-Free', S.labels{i+1}}, ...
                    'time_units', S.time_units);
                B{i} = knots(Y{i}, varargin{:});

            end

            parfor i = 1:K
                H{i} = hsp(B{i}.S, ...
                    'Order', B{i}.Order, ...
                    'Segments', B{i}.Segments, ...
                    'boot', B{i}.boot, ...
                    'Alpha', B{i}.Alpha);
                H{i}.parent = 'comprisk/hsp';
            end

        end

    end



end

