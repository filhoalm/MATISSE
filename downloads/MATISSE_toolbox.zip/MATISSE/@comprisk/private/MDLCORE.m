function M = MDLCORE(S)
% MDLCORE Multiple decrement lifetable.

M = struct(...
    'cumulativeIncidence', [], ...
    'cumulativeIncidenceMax', [], ...
    'cumulativeIncidenceMaxSE', [], ...
    'multipleDecrementTable', [], ...
    'standardError', [], ...
    'timeFrame', []);

[time, index] = sort(S.time);
status = S.status(index);

INC = ~isnan(time) & ~isnan(status);
data = [time(INC) status(INC)];

if isempty(data)
    return
end

sv = S.values;

censorIndex = (data(:, 2) == 0);
dataNonCensored = data(~censorIndex, :);
dataCensored = data(censorIndex, :);

t = unique(dataNonCensored(:, 1));

% number of causes
k = length(sv) - 1;
% number of unique failure times
r = length(t);
% number of subjects at risk at time==0
n = size(data, 1);

%%%
% build MDLTable:
% column  1       - time
% column  2       - n
% columns 3:(2+k) - number of events of type k and time j
% column  3+k     - all causes
% column  4+k     - number censored censored
%%%

MDLTable = zeros(r, 4 + k);

%%%
% unique sorted observed failure times
%%%
MDLTable(:, 1) = t(:);

%%%
% number of events of each type over time by cause
%%%
for i = 1:k
    % extract time values associated with cause i
    INC = dataNonCensored(:, 2) == sv(i + 1);
    % count events of cause i that occurred at each failure time
    ti = dataNonCensored(INC);
    % nothing to do if no events of this type
    if ~isempty(ti)
        temp = histcounts(ti, [0; t]);
        % coersion to column is necessary when ti has length 1
        temp = temp(:);
        MDLTable(:, 2 + i) = temp;
        MDLTable(:, 3 + k) = MDLTable(:, 3 + k) + temp;
    end
end

%%%
% prepend MDLTable with a row for time==0
%%%
MDLTable = [zeros(1, 4 + k); MDLTable];
% fill in the value for n at time 0
MDLTable(1, 2) = n;

%%%
% number censored between event times
%%%

% nothing to do if no events censored
if ~isempty(dataCensored)
    % coersion to column is necessary when dataCensored has length 1
    temp = histcounts(dataCensored(:, 1), [0;t;Inf]);
    temp = temp(:); %temp = temp(1:end-1);
    MDLTable(:, 4 + k) = temp;
end

%%%
% calculate number at risk over time for time > 0
%%%
for i = 2:(r+1)
    MDLTable(i, 2) = MDLTable(i - 1, 2) - MDLTable(i - 1, 3 + k) - MDLTable(i - 1, 4 + k);
end

%%%
% The multiple decrement MDLTable is now complete.
% It has r+1 rows, corresponding to times 0, t(1), t(2), ..., t(r),
% and 4 + k columns, as defined above.
%%%

%%%
% hazard rates (r+1) x k
%%%
hazardRates = MDLTable(:, 3:(2 + k)) ./ (MDLTable(:, 2)*ones(1, k));

%%%
% KM estimate of probability of surviving all causes (r+1) x 1
%%%
KMestimate = cumprod(1 - (MDLTable(:, 3 + k) ./ MDLTable(:, 2)));

%%%
% Cumulative Incidence for each cause
%%%
% first for times t(0), t(1), ..., t(r)
cumulativeIncidence = cumsum( hazardRates .* ([0;KMestimate(1:end-1, 1)] * ones(1, k) ) );

%%%
% Variance-Covariance matrix for each observed time for each cause, r x r x k
%%%
VC = zeros(r, r, k);
% VC0 = zeros(r, r, k);
cumVar = zeros(r, k);
% r==0 iff there are no non-censored cases
if r>0
    for i = 1:k

        %%%
        % VC matrix
        %%%

        % VCi = zeros(r, r);

        % expression for hazard at t(j) times survivorship to t(j-1)
        hS = hazardRates(2:end, i).* KMestimate(1:end-1, 1);
        % D is number of events of all types, Di number of events of type i,
        % N number at risk, at time t(0), t(1), ..., t(r)
        D = MDLTable(:, 3 + k);
        Di = MDLTable(:, 2 + i);
        N = MDLTable(:, 2);
        % covariance adjustment term 1
        term1 = -1 ./ N(2:end, 1);
        % covariance adjustment term 2, with fix-up to avoid division-by-zero warnings when N==D
        term2 = cumsum( D ./ (N.*( N - D + (N==D) )) );
        % sums to time t(j-1)
        term2 = term2(1:end-1, 1);
        % covariance adjustment term 3, with fix-up to avoid division-by-zero warnings when Di==0
        term3 = (Di~=0).*(N - Di) ./ (Di .* N + (Di==0));
        term3 = term3(2:end, 1);

        %%%
        % VC matrix using vectorized code
        %%%
        FACTOR1 = hS * hS';
        FACTOR2 = (term1 + term2) * ones(1, r);
        FACTOR3 = diag(term2 + term3);
        VC(:, :, i) = FACTOR1.*( FACTOR3 + triu(FACTOR2, +1) + tril(FACTOR2', -1) );

        %%%
        % variance of Cumulative Incidence with vectorized code
        %%%
        temp = cumsum(VC(:,:,i), 1);
        temp = cumsum(temp, 2);
        var1 = diag(temp);
        cumVar(:, i) = max(0, var1);

    end
end

standardError = [zeros(1, k); sqrt(cumVar)];
cumulativeIncidenceMax = cumulativeIncidence(end, :);
cumulativeIncidenceMaxSE = standardError(end,:);

% delete 'all causes' column from the output
multipleDecrementTable = MDLTable(:,[1:(2 + k) (4 + k)]);

timeFrame = [0 multipleDecrementTable(end, 1) time(end, 1)];
% Patch an inconvenient NaN value. 02 Sep 09
if isnan(timeFrame(3))
    timeFrame(3) = max(time, [], 'omitnan');
end

M = struct(...
    'cumulativeIncidence', cumulativeIncidence, ...
    'cumulativeIncidenceMax', cumulativeIncidenceMax, ...
    'cumulativeIncidenceMaxSE', cumulativeIncidenceMaxSE, ...
    'multipleDecrementTable', multipleDecrementTable, ...
    'standardError', standardError, ...
    'timeFrame', timeFrame);

end