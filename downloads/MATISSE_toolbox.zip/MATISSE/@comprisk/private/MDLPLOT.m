function hndl = MDLPLOT(P, PVP)
% Plot the cumulative incidence of the competing risks.

% same approach as in KMPLOT

K = size(P, 2);
hndl = cell(1, K);
htxt = cell(1, K);

for i = 1:K

    DATAi = P{i}{2};

    % do NOT add labels and legend within this loop

    PVP0 = PVP;
    PVP0.LineColor = PVP.LineColor(i);
    PVP0.Legend = 0;
    PVP0.labels = [0 0 0];

    hi = pcurve(DATAi, PVP0);

    hndl{i} = hi(1);
    htxt{i} = P{i}{1}.fullname;

end

% NOW we add labels and legend
if PVP.Legend
    legend([hndl{:}], htxt{:}, 'FontSize', PVP.FontSize(1))
end

if PVP.labels(1)
    xlabel(P{1}{1}.labels{1}, 'FontSize', PVP.FontSize(1))

    if PVP.labels(2)
        ylabel('Probability', 'FontSize', PVP.FontSize(2))
    end
end

