function P = preprocess(M, S, Alpha)
% Prepare MDLCORE outputs for presentation.

K = size(M.cumulativeIncidence, 2);
t = M.multipleDecrementTable(:, 1);
N = size(t, 1);
JN2 = 2:1:N;
JN0 = 1:1:N-1;
z = norminv(1 - Alpha/2);
 
P = cell(1, K);
for i = 1:K
   yi = M.cumulativeIncidence(:, i);
   si = M.standardError(:, i);
   li = max(0, yi - z*si);
   hi = min(1, yi + z*si);
   ci = [li, hi];
   % tbl in pcurve format / labels for adverse event types start in position 2
   DATAi = tbl(...
       'data', [t, yi, ci], ...
       'fullname', S.labels{1 + i}, ...
       'col_labels', {S.time_units, 'CumInc', 'Lo', 'Hi'}, ...
       'labels', {S.time_units, S.labels{1 + i}});

   % data doubling for the stair plots / differs from KM because a 0 is
   % always included in t
   Si.x = [0; t(kron(JN2, [1 1]))]';
   Si.y = [yi(kron(JN0, [1 1]))', yi(N)];
   Si.l = [li(kron(JN0, [1 1]))', li(N)];
   Si.h = [hi(kron(JN0, [1 1]))', hi(N)];
   Si.s = [Si.x', Si.y', Si.l', Si.h'];
   % ? if an event occurs at t(end) repeat l and h from t(end-1)
   if isnan(Si.l(end))
       Si.s(end, 3:4) = Si.s(end-1, 3:4);
   end

  P{i} = {DATAi, Si.s};

end

end
