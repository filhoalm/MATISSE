function S = PANKO(varargin)
% PANKO construct a panel of kernel operators

T = INPUTS(varargin{:});

S = nullS;

N = numel(T.shape);

y = T.y;
x = T.x;
k = T.k;
k2 = T.k2;
shape = T.shape;
CalculateInverse = T.CalculateInverse;
CalculateSVD = T.CalculateSVD;
ylabel = T.ylabel;
xlabel = T.xlabel;

parfor n = 1:N
    S(n) = kernel('y', y, 'x', x, 'k', k(n), 'k2', k2(n), ...
        'shape', shape{n}, ...
        'inverse', CalculateInverse, 'svd', CalculateSVD);
    % hack to put the labels back in
    S(n).ylabel = ylabel;
    S(n).xlabel = xlabel;
end

end

%%%
% Helper Functions
%%%

function S = INPUTS(varargin)
% Helper. Process input variables and property-value pairs.

% default values
S = struct(...
    'fullname', '', ...
    'y', 1, ...
    'ylabel', 'y', ...
    'R', 1, ...
    'y0', NaN, ...
    'x', 1, ...
    'xlabel', 'x', ...
    'C', 1, ...
    'x0', NaN, ...
    'Delta', NaN, ...
    'shape', '', ...
    'shapeAbbr', '', ...
    'NumberAnnuliInGrid', NaN, ...
    'A1', NaN, ...
    'N1', NaN, ...
    'A2', NaN, ...
    'N2', NaN, ...
    'A3', NaN, ...
    'N3', NaN, ...
    'kMax', NaN, ...
    'k2', NaN, ...
    'k', 3, ...
    'equalk', NaN, ...
    'Lambda', NaN, ...
    'LambdaOuter', NaN, ...
    'LambdaInner', NaN, ...
    'EuclidD2', NaN, ...
    'K', NaN, ...
    'CalculateInverse', 0, ...
    'Rank', NaN, ...
    'Cond', NaN, ...
    'iK', [], ...
    'CalculateSVD', 1, ...
    'U', NaN, ...
    'L', NaN, ...
    'V', NaN);
S.shape = {'boxcar'}; % coerce to cellstr
S.shapeAbbr = {'box'};
lArgin = varargin(1:end);
Nl = numel(lArgin);

if eq(Nl, 1)
    error('a property has no matching value');
end


while Nl >= 1
    if eq(Nl, 1)
        error('a property has no matching value');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('A property must be specified using a string.')
    end

    switch lower(propi)

        case 'x'
            switch class(vali)
                case 'double'
                    x = vali(:);
                    S.xlabel = 'x';
                case 'continuous'
                    x = vali.data;
                    S.xlabel = vali.fullname;
                case 'tbl'
                    x = vali.data(:);
                    S.xlabel = vali.fullname;
                otherwise
                    error('x must be double, continuous, or tbl')
            end

            S.C = length(x);
            % x must be a non-decreasing evenly-spaced sequence
            if ~issorted(x)
                error('x must be a non-decreasing sequence')
            end
            if S.C > 1
                Deltax = uniquetol(diff(x), 1E-10);
                if length(Deltax)~=1
                    error('x must be an evenly-spaced sequence')
                end
            else
                Deltax = 1;
            end

            S.x0 = x(1);
            S.x = x(:)';

        case 'y'
            switch class(vali)
                case 'double'
                    y = vali(:);
                    S.ylabel = 'y';
                case 'continuous'
                    y = vali.data;
                    S.ylabel = vali.fullname;
                case 'tbl'
                    y = vali.data(:);
                    S.ylabel = vali.fullname;
                otherwise
                    error('y must be double, continuous, or tbl')
            end

            S.R = length(y);

            % y must be a non-decreasing evenly-spaced sequence
            if ~issorted(y)
                error('y must be a non-decreasing sequence')
            end
            if S.R > 1
                Deltay = uniquetol(diff(y));
                if length(Deltay)~=1
                    error('y must be an evenly-spaced sequence')
                end
            else
                Deltay = 1;
            end

            S.y0 = y(1);
            S.y = y(:)';

        case 'shape'
            vals = {'epanechnikov', 'boxcar', 'triangle', 'triweight'};

            if ischar(vali)
                if size(vali, 1)>1
                    error('shape values must be strings, not a character matrix')
                end
                s = strcmpi(vali, vals);
                if ~any(s)
                    error('unrecognized shape')
                end
                S.shape = {lower(vali)};

                Abbr = {'Epan', 'box', 'trg', 'triwt'};
                S.shapeAbbr = Abbr{s};

            elseif iscellstr(vali) %#ok<ISCLSTR>

                [s, I] = ismember(vali, vals);
                if ~all(s)
                    error('unrecognized shape')
                end
                S.shape = lower(vali);
                Abbr = {'Epan', 'box', 'trg', 'triwt'};
                S.shapeAbbr = Abbr(I);

            end

        case 'k'
            % first see if this is a real vector
            if ~(isreal(vali) && isnumeric(vali))
                error('k must be a scalar or vector')
            end
            if any(vali <= 0)
                error('k values must be > 0')
            end
            if any(rem(vali, 2)~=1)
                error('k values must be odd integers')
            end
            S.k = vali(:)';

        case 'k2'
            % first see if this is a real vector
            if ~(isreal(vali) && isnumeric(vali))
                error('k2 must be a scalar or vector')
            end
            if any(vali <= 0)
                error('k2 values must be > 0')
            end
            if any(rem(vali, 2)~=1)
                error('k2 values must be odd integers')
            end
            S.k2 = vali(:)';

        case 'inv'
            if ~isscalar(vali)
                error('inv must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('inv must be 0 or 1')
            end
            S.CalculateInverse = vali;

        case 'svd'
            if ~isscalar(vali)
                error('svd must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('svd must be 0 or 1')
            end
            S.CalculateSVD = vali;

        otherwise

    end
end

% fill in k2 value if necessary
if isnan(S.k2)
    S.k2 = S.k;
end
if (eq(numel(S.k2), 1) && numel(S.k)>1)
    S.k2 = S.k2*ones(1, numel(S.k));
end
if (eq(numel(S.k), 1) && numel(S.k2)>1)
    S.k = S.k*ones(1,numel(S.k2));
end

% remove any duplicate combinations of k2-k
TMP = unique([S.k' S.k2'], 'rows');
S.k = TMP(:, 1)';
S.k2 = TMP(:, 2)';

% Check that S.C and S.R are >= 3, & Deltax and Deltay are equal
if S.C < 3
    error('you must have 3 or more x-values')
end
if S.R < 3
    error('you must have 3 or more y-values')
end

if ~(abs(Deltax - Deltay) <= 1E-6)
    error('increments along the x- and y-axes must be equal')
else
    S.Delta = Deltax;
end

% Remove (k,k2) pairs if either k or k2 is too large
INC = (S.R >= S.k & S.C >= S.k) & (S.R >= S.k2 & S.C >= S.k2);
S.k = S.k(INC);
S.k2 = S.k2(INC);

if isempty(INC)
    error('all of the bandwidths are too large')
end

% Calculate number of annuli in the grid.
S.NumberAnnuliInGrid = ceil(min(S.C, S.R)/2);

% S.kMax is the maximum span in terms of indices.
S.kMax = 2*S.NumberAnnuliInGrid - 1;

% Indices of outer annulus of the grid
S.A1 = [...
    1: 1: S.R, ...                                  % first column
    (S.R + 1) : S.R : ((S.C - 2)*S.R + 1), ...      % inside of first row
    ((S.C - 1)*S.R + 1) : 1 : S.R*S.C, ...          % last column
    (S.C - 1)*S.R : -S.R : 2*S.R];                  % inside of last row (in reverse)
S.N1 = length(S.A1);

% Indices of second outermost annulus of the grid.
% 4 cases: 3 x 3, 3 x >3, >3 x 3, >3 x >3
d = 1*(S.C > 3) + 2*(S.R > 3);

switch d

    case 0
        % 3 x 3
        S.A2 = 5;

    case 1
        % 3 x >3
        S.A2 = (2*S.R - 1) : S.R : ((S.C - 2)*S.R + 2);

    case 2
        % >3 x 3
        S.A2 = (S.R + 2) : 1 : (2*S.R - 1);

    case 3
        % >3 x >3
        S.A2 = [...
            (S.R + 2) : 1 : (2*S.R - 1), ...
            (2*S.R + 2) : S.R : ((S.C - 3)*S.R + 2), ...
            ((S.C - 2)*S.R + 2) : 1 : ((S.C - 1)*S.R - 1), ...
            ((S.C - 2)*S.R - 1) : -S.R : (3*S.R - 1)];

end
S.N2 = length(S.A2);

S.A3 = setdiff(1 : 1: S.R*S.C, [S.A1, S.A2]);
S.N3 = length(S.A3);

%%%
% Modifications for parfor
%%%
nk = numel(S.k);
ns = numel(S.shape);
S.k = repmat(S.k, 1, ns);
S.k2 = repmat(S.k2, 1, ns);
S.shape = S.shape(kron(1:ns, ones(1, nk)));
S.shapeabbr = S.shapeAbbr(kron(1:ns, ones(1, nk)));

% * S.k and S.k2 are the spans in terms of indices.
% * S.lambdaInner and S.LambdaOuter are the spans in terms of index values.
% * To find the corresponding spans in terms of the original units,
%   multiply the index span values by S.Delta

if ~all(S.k == S.k2)
    S.equalk = 0;
    S.LambdaInner = (S.k+1)/2;
    S.LambdaOuter = (S.k2+1)/2;
    S.Lambda = NaN;
else
    S.equalk = 1;
    S.LambdaInner = NaN;
    S.LambdaOuter = NaN;
    S.Lambda = (S.k+1)/2;
end

% If S.CalculateInverse is true, force S.CalculateSVD to be true, becuase
% the SVD is the best way to calculate the inverse
if S.CalculateInverse
    S.CalculateSVD = 1;
end

end

function S = nullS
% default values
S = struct(...
    'fullname', '', ...
    'y', 1, ...
    'ylabel', 'y', ...
    'R', 1, ...
    'y0', NaN, ...
    'x', 1, ...
    'xlabel', 'x', ...
    'C', 1, ...
    'x0', NaN, ...
    'Delta', NaN, ...
    'shape', 'boxcar', ...
    'shapeAbbr', 'box', ...
    'NumberAnnuliInGrid', NaN, ...
    'A1', NaN, ...
    'N1', NaN, ...
    'A2', NaN, ...
    'N2', NaN, ...
    'A3', NaN, ...
    'N3', NaN, ...
    'kMax', NaN, ...
    'k2', NaN, ...
    'k', 3, ...
    'equalk', NaN, ...
    'Lambda', NaN, ...
    'LambdaOuter', NaN, ...
    'LambdaInner', NaN, ...
    'EuclidD2', NaN, ...
    'K', NaN, ...
    'CalculateInverse', 0, ...
    'Rank', NaN, ...
    'Cond', NaN, ...
    'iK', [], ...
    'CalculateSVD', 1, ...
    'U', NaN, ...
    'L', NaN, ...
    'V', NaN);
end



