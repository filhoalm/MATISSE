classdef panko
    % PANKO panko objects contain a panel of bivariate kernel operators.
    % 
    % PANKO kernels are defined over a rectangular grid of square
    % cells using:
    %
    %  * a shape function 
    %      - 'boxcar', 'triangle', 'epanechnikov', 'triweight' 
    %  * a bandwidth k1
    %      - for interior cell 2-away from the margins
    %  * a bandwidth k2
    %      - for edge cells and their immediate neighbors
    % 
    % PANKO kernels are low-pass denoisers for functional data ascertained
    % over a bivariate grid. PANKO kernels generalize K-point moving
    % averages of time series.
    %
    % PANKO objects are used by the sift method.
    % 
    % See https://pubmed.ncbi.nlm.nih.gov/37621099/ for details.
    %
    % See also sift, panko/panko, kernel, matrix/contrasts.

    properties

        kernels struct = struct;   % A Px1 structure array of kernel operators and related quantities

    end

    methods

        function P = panko(varargin)
            % PANKO Construct a PANnel of Kernel Operators.
            %
            % P = PANKO(...)
            %
            % 'y'     - R equally-spaced values along the y-axis (rows)
            % 'x'     - C equally-spaced values along the x-axis (cols)
            % 'k'     - spans for interior cells: Nk odd integers >= 3 (default)
            % 'k2'    - spans for exterior cells:
            %            * scalar, or Nk odd integers >= 3 (default 'k')
            % 'shape' - string, or length Ns cellstr, containing:
            %            * 'boxcar' (default), 'epanechnikov', 'triangle', 'triweight'
            % 'svd'   - compute SVD, 0 (false) or 1 (true, default)
            % 'inv'   - compute inv, 0 (false, default) or 1 (true, also sets 'svd' to 1)
            %
            % Notes:
            %
            %    *  Spacing along the y and x axes must be the same
            %    *  R and C must be >= 3
            %    *  R and C must be >= all values of 'k' and 'k2'.
            %
            %  P is a 1 x Ns * Nk structure array of kernel operators.
            % 
            % See also kernel, plot, pcolor, tile.

            if nargin == 0
                % contents of an empty panko object
                return
            end

            if isa(varargin{1}, 'panko')
                P = varargin{1};
                return
            end

            % Contents of an empty panko object
            P.kernels = struct(...
                'fullname', '', ...       
                'y', 1, ...
                'ylabel', 'y', ...
                'R', 1, ...
                'y0', NaN, ...
                'x', 1, ...
                'xlabel', 'x', ...
                'C', 1, ...
                'x0', NaN, ...
                'Delta', NaN, ...
                'shape', 'boxcar', ...
                'shapeAbbr', 'box', ...
                'NumberAnnuliInGrid', NaN, ...
                'A1', NaN, ...
                'N1', NaN, ...
                'A2', NaN, ...
                'N2', NaN, ...
                'A3', NaN, ...
                'N3', NaN, ...
                'kMax', NaN, ...
                'k2', NaN, ...
                'k', 3, ...
                'equalk', NaN, ...
                'Lambda', NaN, ...
                'LambdaOuter', NaN, ...
                'LambdaInner', NaN, ...
                'EuclidD2', NaN, ...
                'K', NaN, ...
                'CalculateInverse', 0, ...
                'Rank', NaN, ...
                'Cond', NaN, ...
                'iK', [], ...
                'CalculateSVD', 1, ...
                'U', NaN, ...
                'L', NaN, ...
                'V', NaN);

            N = numel(varargin);

            if N == 0
                return
            end

            % construct the panel . . .
            P.kernels = PANKO(varargin{:});

        end

        %%%
        % Visualization methods
        %%%

        function pcolor(P, varargin)
            % PCOLOR Heat map of a kernel operator in a panko object.
            %
            % PCOLOR(P)
            % PCOLOR(P, col)
            % PCOLOR(P, col, go(...))
            %
            % PCOLOR plot of P.kernels(col).K.
            %
            % See also plot, tile.

            defaultPVP = ego('class', 'panko', 'method', 'pcolor');
            switch nargin
                case 1
                    col = 1;
                    PVP = defaultPVP;
                case 2
                    col = varargin{1};
                    PVP = defaultPVP;
                case 3
                    col = varargin{1};
                    PVP = varargin{2};
                otherwise
                    error('too many inputs')
            end

            G = size(P.kernels, 2);
            if ~ismember(col, 1:G)
                error(['col must lie between 1 and ' num2str(G)])
            end

            P = P.kernels(col);

            T = tbl(...
                'data', P.K, ...
                'fullname', P.fullname, ...
                'row_labels', {''}, ...
                'col_labels', {''}, ...
                'labels', {'', ''});

            pcolor(T, PVP)
            set(gca, 'XTick', [], 'YTick', [])

        end

        function tile(P, varargin)
            % TILE Tile plot of a kernel operator in a panko object.
            %
            % TILE(P)
            % TILE(P, col)
            % TILE(P, col, go(...))
            %
            % TILE plot of P.kernels(col).K.
            %
            % See also plot, pcolor.

            defaultPVP = ego('class', 'panko', 'method', 'tile');
            switch nargin
                case 1
                    col = 1;
                    PVP = defaultPVP;
                case 2
                    col = varargin{1};
                    PVP = defaultPVP;
                case 3
                    col = varargin{1};
                    PVP = varargin{2};
                otherwise
                    error('too many inputs')
            end

            G = size(P.kernels, 2);
            if ~ismember(col, 1:G)
                error(['col must lie between 1 and ' num2str(G)])
            end

            P = P.kernels(col);

            PVP.m = numel(unique(P.K(:)));
            PVP.nColors = 54;

            T = tbl(...
                'data', P.K, ...
                'fullname', P.fullname, ...
                'row_labels', {''}, ...
                'col_labels', {''}, ...
                'labels', {'', ''});

            tile(T, PVP)
            set(gca, 'XTick', [], 'YTick', [])

        end

        function plot(P, varargin)
            % PLOT Plot singular values of kernels in a panko object.
            %
            % plot(P)
            % plot(P, cols)
            % plot(P, cols, go(...))
            %
            % P must be instantiated with 'svd' equal to 1 (true)
            %
            % See also pcolor, tile.

            G = size(P.kernels, 2);
            defaultPVP = ego('class', 'panko', 'method', 'plot');
            defaultPVP.LineColor = 1:G;

            switch nargin
                case 1
                    col = 1:G;
                    PVP = defaultPVP;
                case 2
                    col = varargin{1};
                    PVP = defaultPVP;
                case 3
                    col = varargin{1};
                    PVP = varargin{2};
                otherwise
                    error('too many inputs')
            end

            col = unique(sort(col));
            if ~all(ismember(col, 1:G))
                error(['col values must lie between 1 and ' num2str(G)])
            end

            if P.kernels(1).CalculateSVD
                l = tbl(...
                    'data', [P.kernels(col).L], ...
                    'fullname', 'Singular Values', ...
                    'col_labels', {P.kernels(col).fullname}, ...
                    'labels', {'Index', 'kernel'});

                plot(matrix('data', l), PVP)

            else

                disp(['no singular values to plot: ''svd'' option for ' inputname(1) ' was 0 (false)'])
            
            end

        end


        % end methods
    end
    % end classdef
end