classdef tbl
    % TBL tbl objects contain a numeric matrix and metadata.
    %
    % * TBL objects should never be confused with MATLAB's table class!
    %
    % A TBL object is a lightweight container used by MATISSE to
    % automatically add meaningful labels to text and graphic outputs.
    %
    % See also tbl/tbl, matrix.

    properties

        data (:, :) {mustBeMatrix} = [];            % An R x C numeric array
        fullname (1, :) {mustBeTextScalar} = '';    % scientific name for the array
        labels (1, 2) {mustBeText} = {'', ''};      % cell array of 2 strings declaring a name for the rows and columns
        row_labels (1, :) {mustBeText} =  {''};     % cell array of strings containing R row labels
        col_labels (1, :) {mustBeText} = {''};      % cell array of strings containing C column labels

    end

    methods

        %%%
        % housekeeping
        %%%

        function T = tbl(varargin)
            % TBL tbl objects contain a numeric matrix and metadata.
            %
            % T = TBL('data', <RxC numeric matrix>, ...
            %         'fullname', 'string', ...
            %         'labels', {'rows', 'columns')
            %         'row_labels', {'r 1, 'r 2', ..., 'r R'}
            %         'col_labels', {'c 1', c 2', ..., 'c R'}
            %
            % See also matrix.

            if nargin == 0
                % Contents of an empty tbl
                T.data = [];
                T.fullname = '';
                T.labels = {'', ''};
                T.row_labels = {''};
                T.col_labels = {''};
                return
            end

            if isa(varargin{1}, 'tbl')
                T = varargin{1};
                return
            end

            % Contents of an empty tbl
            T.data = [];
            T.fullname = '';
            T.labels = {'', ''};
            T.row_labels = {''};
            T.col_labels = {''};

            N = numel(varargin);

            if N == 0
                return
            end

            %%%
            % whittle the arguments
            %%%
            lArgin = varargin;

            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};

                if ~ischar(propi)
                    error('A property must be specified using a string.')
                end

                switch lower(propi)

                    case 'data'
                        if ismatrix(vali)
                            if isa(vali, 'tbl')
                                T.data = vali.data;
                            elseif isa(vali, 'matrix')
                                T.data = vali.data.data;
                            else
                                T.data = vali;
                            end
                        else
                            error('tbl data must be a matrix')
                        end

                    case 'fullname'
                        if ischar(vali)
                            T.fullname = vali;
                        else
                            error('fullname must be a string')
                        end

                    case 'labels'
                        if ~iscellstr(vali) %#ok<ISCLSTR>
                            error('labels must be a cellstr')
                        elseif numel(vali) ~= 2
                            error('labels must be a 1x2 cellstr')
                        else
                            T.labels = vali;
                        end

                    case 'row_labels'
                        if ~iscellstr(vali) %#ok<ISCLSTR>
                            error('row_labels must be a cellstr')
                        else
                            T.row_labels = vali;
                        end

                    case 'col_labels'
                        if ~iscellstr(vali) %#ok<ISCLSTR>
                            error('col_labels must be a cellstr')
                        else
                            T.col_labels = vali;
                        end

                    otherwise

                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('The last property has no matching value.');
                end

            end

            %%%
            % size validations
            %%%
            [R, C] = size(T.data);

            r = numel(T.row_labels);
            if ~ismember(r, [1 R])
                error('wrong number of row_labels')
            end
            if r==1 && R>1 && ~isempty(T.row_labels{1})
                error('wrong number of row_labels')
            end

            c = numel(T.col_labels);
            if ~ismember(c, [1 C])
                error('wrong number of col_labels')
            end
            if c==1 && C>1 && ~isempty(T.col_labels{1})
                error('wrong number of col_labels')
            end

        end

        function U = subsref(T, S)
            % SUBSREF Subscripted referencing for tbl objects.

            if length(S) > 1

                DEPTH = numel(S);
                for d = 1:DEPTH
                    if d == 1
                        U = subsref(T, S(1));
                    else
                        % q = numArgumentsFromSubscript(U, S(d), ...
                        %     matlab.mixin.util.IndexingContext.Statement);
                        % if q > 1
                        %     warning('Only one output was captured')
                        % end
                        U = subsref(U, S(d));
                    end
                end

            else

                switch S.type

                    case '.'

                        switch S.subs

                            case 'data'
                                U = T.data;
                            case 'fullname'
                                U = T.fullname;
                            case 'labels'
                                U = T.labels;
                            case 'row_labels'
                                U = T.row_labels;
                            case 'col_labels'
                                U = T.col_labels;

                            otherwise

                        end

                    case '()'
                        [R, C] = size(T);
                        % if S.subs{1} is a boolean, replace with indices
                        if isa(S.subs{1}, 'boolean')
                            S.subs{1} = find(S.subs{1}.data == 1);
                        elseif isa(S.subs{1}, 'logical')
                            S.subs{1} = S.subs{1};
                        elseif isa(S.subs{1}, 'char')
                            S.subs{1} = 1:R;
                        else
                            % let MATLAB hande any errors
                        end

                        if eq(numel(S.subs), 2)
                            if isa(S.subs{2}, 'boolean')
                                S.subs{2} = find(S.subs{2}.data == 1);
                            elseif isa(S.subs{2}, 'logical')
                                S.subs{2} = S.subs{2};
                            elseif isa(S.subs{2}, 'char')
                                S.subs{2} = 1:C;
                            else
                                % let MATLAB handle any errors
                            end
                        end

                        %%%
                        % coerce logical indices to numeric indices
                        %%%
                        JR = (1:R)';
                        JC = (1:C)';
                        if isa(S.subs{1}, 'logical')
                            S.subs{1} = JR(S.subs{1});
                        end
                        if eq(numel(S.subs), 2)
                            if isa(S.subs{2}, 'logical')
                                S.subs{2} = JC(S.subs{2});
                            end
                        end

                        SUBS = S.subs;

                        if eq(numel(S.subs), 2)
                            DATA = T.data(SUBS{1}(:), SUBS{2}(:));
                        else
                            TMP = T.data(SUBS{1});
                            DATA = reshape(TMP, R, C);
                            SUBS{end+1} = 1:C;
                        end

                        rl = T.row_labels;
                        NR = numel(rl);
                        if eq(NR, 1) && isempty(rl{1})
                            U_rl = {''};
                        else
                            U_rl = rl(SUBS{1}(:)');
                        end

                        cl = T.col_labels;
                        NC = numel(cl);
                        if eq(NC, 1) && isempty(cl{1})
                            U_cl = {''};
                        else
                            U_cl = cl(SUBS{2}(:)');
                        end

                        U = tbl('data', DATA, ...
                            'fullname', T.fullname, ...
                            'labels', T.labels, ...
                            'row_labels', U_rl, ...
                            'col_labels', U_cl);

                    case '{}'

                        % do nothing
                        U = T;

                end

            end

        end

        function G = subsasgn(T, S, V)
            % SUBSASGN Subscripted assignment for tbl objects.

            if length(S) > 1
                error('Index expression has depth %g, cannot be > 1', length(S))
            end

            G = T;

            switch S.type

                case '.'

                    switch S.subs
                        case 'tbl'
                            [R, C] = size(G.data);
                            [r, c] = size(V.data);
                            if eq(r, R) && eq(c, C)
                                G.data = V.data;
                            else
                                error('value has wrong size')
                            end

                        case 'data'
                            [R, C] = size(G.data);
                            [r, c] = size(V);
                            if eq(r, R) && eq(c, C)
                                G.data = V;
                            else
                                error('value has wrong size')
                            end

                        case 'fullname'
                            G.fullname = V;

                        case 'labels'
                            G.labels = V;

                        case 'row_labels'
                            %%%
                            % Three cases
                            %
                            % [1]: {''} to {'t1', 't2', ..., 'tR'}
                            % [2]: {'t1', 't2', ..., 'tR'} to {''}
                            % [3]: {'t1', ..., rR} to {'t1*', ..., 'tR*'}
                            %%%

                            R = size(G.data, 1);
                            r = numel(G.row_labels);
                            N = numel(V);

                            if eq(r, 1) && isempty(G.row_labels{1}) && eq(N, R) %[1]
                                G.row_labels = V;
                            elseif eq(r, R) && iscell(V)
                                if isempty(V{1})
                                    G.row_labels = {''}; % [2]
                                else
                                    if eq(N, R)
                                        G.row_labels = V; % [3]
                                    else
                                        error('value must have length %g', R)
                                    end
                                end
                            else
                                error('value must be a cellstr')
                            end

                        case 'col_labels'
                            %%%
                            % Three cases
                            %
                            % [1]: {''} to {'t1', 't2', ..., 'tC'}
                            % [2]: {'t1', 't2', ..., 'tC'} to {''}
                            % [3]: {'t1', ..., rC} to {'t1*', ..., 'tC*'}
                            %%%
                            C = size(G.data, 2);
                            c = numel(G.col_labels);
                            N = numel(V);

                            if eq(c, 1) && isempty(G.col_labels{1}) && eq(N, C) %[1]
                                G.col_labels = V;
                            elseif eq(c, C) && iscell(V)
                                if isempty(V{1})
                                    G.col_labels = {''}; % [2]
                                else
                                    if eq(N, C)
                                        G.col_labels = V; % [3]
                                    else
                                        error('value must have length %g', C)
                                    end
                                end
                            else
                                error('value must be a cellstr')
                            end

                        otherwise
                    end

                case '()'
                    warning('parentheses indexing is undefined')

                case '{}'
                    warning('brace indexing is undefined')

                otherwise

            end

        end

        function r = end(g, k, ~)
            % END end method for tbl objects.

            switch k
                case 1
                    r = size(g, 1);
                case 2
                    r = size(g, 2);
                otherwise
            end

        end

        function S = isempty(T)
            % ISEMPTY Deterine whether a tbl object is empty.
            %
            % S = isempty(T)
            %
            % S is logical true or false.
            %
            % See also size, numel.

            S = isempty(T.data);
        end

        % function N = numel(T)
        %     % TBL/NUMEL Number of cells in a tbl object
        %     %
        %     % N = NUMEL(T)
        %     %
        %     % See also size, isempty.
        %
        %     N = size(T.data, 1) * size(T.data, 2);
        % end

        function varargout = size(T, varargin)
            % SIZE Size of a tbl object.
            %
            % [R, C] = SIZE(T)
            % R = SIZE(T, 1)
            % C = SIZE(T, 2)
            %
            % Number of rows R and columns C of T.
            %
            % See also isempty, numel.

            switch nargin
                case 1
                    switch nargout
                        case {0, 1}
                            varargout{1} = [size(T.data, 1), size(T.data, 2)];
                        case 2
                            varargout{1} = size(T.data, 1);
                            varargout{2} = size(T.data, 2);
                        otherwise
                            error('too many outputs')
                    end

                case 2
                    d = varargin{1};
                    switch nargout
                        case {0, 1}
                            varargout{1} = size(T.data, d(1));
                        case 2
                            varargout{1} = size(T.data, d(1));
                            varargout{2} = size(T.data, d(2));
                        otherwise
                            error('too many outputs')
                    end
            end
        end

        function varargout = disp(T, varargin)
            % DISP Command window disp of a tbl object.
            %
            % DISP(T)
            % s = DISP(T)
            % ... = DISP(T, 'precision', prec, 'width', width, 'N', N, 'chromacode', flag)
            %
            % Property-value pairs:
            %
            % 'precision'  - number of digits to the right of the decimal place (default 5)
            % 'width'      - spacing between columns (default 8)
            % 'N'          - maximum number of rows to display (default 500)
            % 'chromacode' - 0 (don't display chromacodes, default) or 1
            %
            % See also:

            switch nargout
                case 0
                    DISP(T, varargin{:})
                case 1
                    varargout{1} = DISP(T, varargin{:});
                otherwise
                    error('disp produces a single output')
            end

        end

        function varargout = tbl2table(T)
            % TBL2TABLE Convert a tbl object to a table object.
            %
            % M = tbl2table(T)
            %
            % * Chromacodes (if any) are stripped out.
            % * The column names of T must be unique.
            % * The rowlabels of M include the row numbers.

            [nRows, nCols] = size(T);

            rl = T.row_labels;
            cl = T.col_labels;
            fn = T.fullname;
            if numel(rl) == nRows && ~isempty(rl{1})
                rl = strrep(...
                    replaceBetween(rl, '\color[rgb]{', '}', ''), ...
                    '\color[rgb]{}', '');
            else
                % Need to construct them
                rl = cellstr(num2str((1:nRows)'))';
            end
            if numel(cl) == nCols
                cl = strrep(...
                    replaceBetween(cl, '\color[rgb]{', '}', ''), ...
                    '\color[rgb]{}', '');
            else
                % Need to construct them
                cl = cellstr(num2str((1:nCols)'))';
            end
            if ~isempty(fn)
                fn = strrep(...
                    replaceBetween(fn, '\color[rgb]{', '}', ''), ...
                    '\color[rgb]{}', '');
            else
                fn = 'Data';
            end

            if ismember(fn, cl)
                % duplicate dimension and variable name - not allowed
                fn = [fn, ' (tbl)'];
            end

            % considering our use cases, we force the RowNames to be unique
            for i = 1:nRows
                if isempty(rl{i})
                    rl{i} = ['row ' num2str(i)];
                else
                    rl{i} = ['[' num2str(i) '] ', rl{i}];
                end
            end

            % up to user to start with unique column names
            for j = 1:nCols
                if isempty(cl{j})
                    cl{j} = ['col ' num2str(j)];
                end
            end

            M = array2table(T.data, 'VariableNames', cl, 'RowNames', rl, ...
                'DimensionNames', {fn, ' '});

            switch nargout
                case 0
                case 1
                    varargout{1} = M;
                otherwise
                    error('tbl2table produces a single output')
            end
        end

        %%%
        % concatenation and transposition
        %%%

        function T = horzcat(varargin)
            % HORZCAT Horizontally join tbl objects with equal numbers of rows.
            %
            % C = [A, B]
            % C = horzcat(A1, A2, A3, A4, ...)
            %
            % See also vertcat.

            T = HORZCAT(varargin{:});
        end

        function T = vertcat(varargin)
            % VERTCAT Vertically join tbl objects with equal numbers of columns.
            %
            % C = [A; B]
            % B = vertcat(A1, A2, A3, A4, ...)
            %
            % The number of columns and the corresponding column labels must be
            % identical.
            %
            % See also horzcat.

            T = VERTCAT(varargin{:});
        end

        function B = ctranspose(A)
            % CTRANSPOSE Transpose a tbl object.
            %
            % B = A'
            % B = ctranspose(A)
            %
            % The data are transposed and row and column labels are interchanged.

            B = tbl(...
                'data', A.data', ...
                'fullname', A.fullname, ...
                'labels', {A.labels{2}, A.labels{1}}, ...
                'row_labels', A.col_labels, ...
                'col_labels', A.row_labels);
        end

        function V = vec(T)
            % VEC Stack the columns of a tbl object.
            %
            % V = vec(T)
            %
            % The data are stacked column on column.

            vdat = T.data(:);
            [R, C] = size(T);

            if isempty(T.col_labels{1}) && eq(numel(T.col_labels), 1)
                cl = cellstr(num2str((1:C)'))';
            else
                cl = T.col_labels;
            end

            if isempty(T.row_labels{1}) && eq(numel(T.row_labels), 1)
                rl = cellstr(num2str((1:R)'));
            else
                rl = T.row_labels;
            end

            TMP1 = repmat(rl, 1, C);
            TMP2 =reshape(repmat(cl, R, 1), 1, R*C);
            TMP3 = ['(' str('data', TMP1(:)) ' , ' str('data', TMP2) ')'];

            V = tbl(...
                'data', vdat, ...
                'fullname', T.fullname, ...
                'labels', {[T.labels{1} ' , ' T.labels{2}], ''}, ...
                'row_labels', TMP3.data, ...
                'col_labels', {''});

        end


        function D = diagonals(T)
            % DIAGONALS Diagonals of a tbl object.
            %
            % D = diagonals(T)
            %
            % Diagonals are ordered from lower left to upper right, so data elements
            % r/c 1 2 3 4
            %  1  a b c d
            %  2  e f g h
            %  3  i j k l
            %
            % are rearranged to produce
            %
            % r/d 1 2 3 4 5 6
            %  1  . . a b c d
            %  2  . e f g h .
            %  3  i j k l . .
            %
            % The columns of D are labelled by the corresponding diagonal of T.
            %
            % See also matrix/diagonals.

            D = DIAGONALS(T);

        end

        %%%
        % unary operators
        %%%

        function F = abs(T)
            % ABS Absolute value of data values in a tbl object.
            %
            % F = abs(T)
            %
            % See also log, log2, log10, exp.

            F = tbl(...
                'data', abs(T.data), ...
                'fullname', ['abs(' T.fullname ')'], ...
                'labels', {['abs(' T.labels{1} ')'], T.labels{2}}, ...
                'row_labels', T.row_labels, ...
                'col_labels', T.col_labels);
        end

        function F = log(T)
            % LOG Natural log of data values in a tbl object.
            %
            % F = log(T)
            %
            % Negative values in T are set to NaNs in F.
            %
            % See also abs, log2, log10, exp, pc.

            DATA = T.data;
            DATA(DATA < 0) = NaN;
            DATA = log(DATA);

            F = tbl(...
                'data', DATA, ...
                'fullname', ['log(' T.fullname ')'], ...
                'labels', {['log(' T.labels{1} ')'], T.labels{2}}, ...
                'row_labels', T.row_labels, ...
                'col_labels', T.col_labels);
        end

        function F = log2(T)
            % LOG2 log2 of data values in a tbl object.
            %
            % F = log2(T)
            %
            % Negative values in T are set to NaNs in F.
            %
            % See also abs, log, log10, exp, pc.

            DATA = T.data;
            DATA(DATA < 0) = NaN;
            DATA = log2(DATA);

            F = tbl(...
                'data', DATA, ...
                'fullname', ['log2(' T.fullname ')'], ...
                'labels', {['log2(' T.labels{1} ')'], T.labels{2}}, ...
                'row_labels', T.row_labels, ...
                'col_labels', T.col_labels);
        end

        function F = log10(T)
            % LOG10 Base 10 logarithm of data values in a tbl object.
            %
            % F = log10(T)
            %
            % Negative values in T are set to NaNs in F.
            %
            % See also abs, log, log2, exp, pc.

            DATA = T.data;
            DATA(DATA < 0) = NaN;
            DATA = log10(DATA);

            F = tbl(...
                'data', DATA, ...
                'fullname', ['log10(' T.fullname ')'], ...
                'labels', {['log10(' T.labels{1} ')'], T.labels{2}}, ...
                'row_labels', T.row_labels, ...
                'col_labels', T.col_labels);
        end

        function F = exp(T)
            % EXP Exponentiate data values in a tbl object.
            %
            % F = exp(T)
            %
            % See also abs, log, log2, log10, pc.

            F = tbl(...
                'data', exp(T.data), ...
                'fullname', ['exp(' T.fullname ')'], ...
                'labels', {['exp(' T.labels{1} ')'], T.labels{2}}, ...
                'row_labels', T.row_labels, ...
                'col_labels', T.col_labels);
        end

        function F = pc(T)
            % PC Percent Change rescaling of values in a tbl object.
            %
            % F = pc(T)
            %
            % pc = 100 * (exp(T) - 1)
            %
            % See also abs, log, log2, log10, exp.

            F = tbl(...
                'data', 100 * ( exp(T.data) - 1 ), ...
                'fullname', ['pc(' T.fullname ')'], ...
                'labels', {['pc(' T.labels{1} ')'], T.labels{2}}, ...
                'row_labels', T.row_labels, ...
                'col_labels', T.col_labels);
        end

        %%%
        % binary operators
        %%%

        function s = eq(v, w)
            % EQ EQ method for tbl data.
            %
            % S = PLUS(V, W)
            % S = V + W
            %
            % * EQ is defined for tbl vs tbl, tbl vs double, and tbl vs scalar.
            % * If both V and W are tbl, the labels in S inherit from V.
            %
            % See also minus, min, max, times, rdivide.

            s = EQ(v, w);

        end

        function s = plus(v, w)
            % PLUS Elementwise addition of tbl data.
            %
            % S = PLUS(V, W)
            % S = V + W
            %
            % * PLUS is defined for tbl + tb, tbl + double, and tbl + scalar.
            % * If both V and W are tbl, the labels in S inherit from V.
            %
            % See also minus, min, max, times, rdivide.

            s = PLUS(v, w);

        end

        function s = minus(v, w)
            % MINUS Elementwise subtraction of tbl data.
            %
            % S = MINUS(V, W)
            % S = V - W
            %
            % * MINUS is defined for tbl - tbl, tbl - double, and tbl - scalar.
            % * If both V and W are tbl, the labels in S inherit from V.
            %
            % See also plus, min, max, times, rdivide.

            s = MINUS(v, w);

        end

        function s = max(v, w)
            % MAX Elementwise maxima of tbl data.
            %
            % S = MAX(V, W)
            %
            % * MAX is defined for tbl vs tbl, tbl vs double, and tbl vs scalar.
            % * If both V and W are tbl, the labels in S inherit from V.
            %
            % See also min, plus, minus, times, rdivide.

            s = MAX(v, w);

        end

        function s = min(v, w)
            % MIN Elementwise minima of tbl data.
            %
            % S = MIN(V, W)
            %
            % * MIN is defined for tbl vs tbl, tbl vs double, and tbl vs scalar.
            % * If both V and W are tbl, the labels in S are inherited from V.
            %
            % See also max, plus, minus, times, rdivide.

            s = MIN(v, w);

        end

        function s = times(v, w)
            % TIMES Elementwise multiplication of tbl data.
            %
            % S = TIMES(V, W)
            % S = V .* W
            %
            % * TIMES is defined for tbl .* tbl, tbl .* double, and tbl .* scalar.
            % * If both V and W are tbl, the labels in S inherit from V.
            %
            % See also rdivide, plus, minus, min, max.

            s = TIMES(v, w);

        end

        function s = rdivide(v, w)
            % RDIVIDE Elementwise division of tbl data.
            %
            % S = RDIVIDE(V, W)
            % S = V ./ W
            %
            % * RDIVIDE is defined for tbl ./ tbl, tbl ./ double, and tbl ./ scalar.
            % * If both V and W are tbl, the labels in S inherit from V.
            %
            % See also times, plus, minus, min, max.

            s = RDIVIDE(v, w);

        end

        %%%
        % visualization
        %%%

        function pcolor(T, varargin)
            % PCOLOR Heat map of data in a tbl object.
            %
            % PCOLOR(T)
            % PCOLOR(T, go(...))
            %
            % * NaN, -Inf, and +Inf values have no color
            %
            % See also tile, hexmap, bubbles, surf, bar3, go.

            switch nargin
                case 1
                    PVP = ego('class', 'tbl', 'method', 'pcolor');
                case 2
                    PVP = varargin{1};
                otherwise
                    error('too many inputs')
            end

            PCOLOR(T, PVP)

        end

        function tile(T, varargin)
            % TILE HeaT map of dIscrete vaLuEs in a tbl object.
            %
            % TILE(T)
            % TILE(T, go(...))
            %
            % * NaN, +Inf and -Inf values are set to -Inf
            %
            % See also pcolor, hexmap, bubbles, surf, bar3, go.

            switch nargin
                case 1
                    PVP = ego('class', 'tbl', 'method', 'tile');
                case 2
                    PVP = varargin{1};
                otherwise
                    error('too many inputs')
            end

            TILE(T, PVP)

        end

        function hexmap(T, varargin)
            % HEXMAP Heat map of data in a tbl object using hexagonal tiles.
            %
            % HEXMAP(T)
            % HEXMAP(T, go(...))
            %
            % * NaN, -Inf, and +Inf values have no color
            % * set 'orientation' to 'vertical' to put the pointy sides up
            %
            % See also pcolor, tile, bubbles, surf, bar3, go.

            switch nargin
                case 1
                    PVP = ego('class', 'tbl', 'method', 'hexmap');
                case 2
                    PVP = varargin{1};
                otherwise
                    error('too many inputs')
            end

            HEXMAP(T, PVP)

        end

        function bubbles(T, varargin)
            % BUBBLES Grid of tbl values displayed using bubbles.
            %
            % BUBBLES(T)
            % BUBBLES(T, go(...))
            %
            % * NaN, -Inf, and +Inf values have radius 0
            % * numeric values are added when 'text' is 1
            % * 'scaling' is necessarily 'range'
            %
            % See also pcolor, tile, hexmap, surf, bar3, go.

            switch nargin
                case 1
                    PVP = ego('class', 'tbl', 'method', 'bubbles');
                case 2
                    PVP = varargin{1};
                otherwise
                    error('too many inputs')
            end

            BUBBLES(T, PVP)

        end

        function surf(T, varargin)
            % SURF Surface plot of data in a tbl object.
            %
            % SURF(T)
            % SURF(T, go(...))
            %
            % * NaN, -Inf, and +Inf values have no color
            % * 'YLim' controls the Z-axis limits
            %
            % See also pcolor, tile, hexmap, bubbles, bar3, go, depth.

            switch nargin
                case 1
                    PVP = ego('class', 'tbl', 'method', 'surf');
                case 2
                    PVP = varargin{1};
                otherwise
                    error('too many inputs')
            end

            SURF(T, PVP)

        end

        function bar3(T, varargin)
            % BAR3 bar3 plot of data in a tbl object.
            %
            % BAR3(T)
            % BAR3(T, go(...))
            %
            % * NaN, -Inf, and +Inf values have no color
            %
            % See also go, pcolor, tile, hexmap, bubbles, surf.

            switch nargin
                case 1
                    PVP = ego('class', 'tbl', 'method', 'bar3');
                case 2
                    PVP = varargin{1};
                otherwise
                    error('too many inputs')
            end

            BAR3(T, PVP)

        end


        % end methods
    end

    % end classdef
end


