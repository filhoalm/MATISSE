function s = MAX(v, w)
% TBL/MAX Elementwise maxima of tbl data

if isa(v, 'numeric')
    if isscalar(v) && isreal(v)
        % catch expressions like x+3
        V = tbl('data', v, 'fullname', num2str(v));
    else
        V = tbl('data', v, 'fullname', 'numeric');
    end
else
    V = tbl(v);
end

if isa(w, 'numeric')
    if isscalar(w) && isreal(w)
        W = tbl('data', w, 'fullname', num2str(w));
    else
        W = tbl('data', w, 'fullname', 'numeric');
    end
else
    W = tbl(w);
end

% both 1 x 1 (0), both R x C (1), one 1 x 1, one R x C (2), otherwise error (3)
[RV, CV] = size(V.data);
[RW, CW] = size(W.data);
cl = ...
    0*(RV==RW && RV==1 && CV==CW && CV==1) + ...
    1*(RV==RW && RV>1 && CV==CW && CV>1) + ...
    2*( xor((RV==1)&&(CV==1) , (RW==1)&&(CW==1) )) + ...
    3*(RV~=RW || CV~=CW);

if cl==3
    error('tbl:max', 'sizes are not compatible.')
end

% v is a tbl and w not (1), or w is a tbl and v not (2), or both are tbl (3)
ml = ...
    1*(isa(v, 'tbl') && ~isa(w, 'tbl')) + ...
    2*(~isa(v, 'tbl') && isa(w, 'tbl')) + ...
    3*(isa(v, 'tbl') && isa(w, 'tbl'));
fn = FullName(V.fullname, W.fullname);

switch ml
    case {1, 3}
        % (1) v is tbl and w is not. use metadata from v.
        % (3) v is tbl and w is tbl. use metadata from v.
        data = max(V.data, W.data, "includemissing");
        s = tbl(...
            'data', data, ...
            'fullname', fn, ...
            'labels', V.labels, ...
            'row_labels', V.row_labels, ...
            'col_labels', V.col_labels);

    case 2
        % w is tbl and v is not. use metadata from w.
        data = max(V.data, W.data, "includemissing");
        s = tbl('data', data, ...
            'fullname', fn, ...
            'labels', W.labels, ...
            'row_labels', W.row_labels, ...
            'col_labels', W.col_labels);
end

function fn = FullName(s1, s2)
% Helper.

% Rule:
% If there is any space in s1 enclose s1 in parantheses.
% If there is any space in s2 enclose s2 in parentheses.

if any(isspace(s1))
    s1 = ['( ' s1 ' )'];
end
if any(isspace(s2))
    s2 = ['( ' s2 ' )'];
end

fn = ['max(' s1 ', ', s2 ')'];

