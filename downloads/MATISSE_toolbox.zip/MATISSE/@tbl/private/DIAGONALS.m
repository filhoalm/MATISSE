function D = DIAGONALS(T)
% TBL/DIAGONALS Diagonals of a tbl.

% This is the crucial step we need to get the ordering we want - diagonals
% running from the lower left to the upper right
Tt = T';

[R, C] = size(Tt);
K = R + C - 1;
DATA = NaN(C, K);

for i = 1:R
    for j = 1:C

        k = i - j + C;

        DATA(j, k) =  Tt.data(i, j);

    end
end

cl = cellstr(char(num2str((1:K)')));

D = tbl(...
    'data', DATA, ...
    'fullname', T.fullname, ...
    'labels', {T.labels{1}, ['(' T.labels{2} ' - ' T.labels{1} ')']}, ...
    'row_labels', T.row_labels, ...
    'col_labels', cl);

end