function SURF(T, PVP)
% TBL/SURF surface plot of data in a tbl object.

if isempty(T), return, end

%%%
% preprocess
%%%
[T, DATA, climValues, BadValuesFlag] = preprocess_tbl_data(T, PVP, 'surf');

%%%
% surface plot
%%%
ax = gca;

surf(ax, DATA, 'FaceAlpha', PVP.FaceAlpha, 'EdgeAlpha', PVP.EdgeAlpha)

shading(ax, PVP.shading)
set(ax, 'color', PVP.clarinet(PVP.AxisColor, :))
ax.XAxis.FontSize = PVP.FontSize(1);
ax.YAxis.FontSize = PVP.FontSize(2);

%%%
% colormap and colorbar
%%%
switch PVP.colormap
    case 'clarinet'
        MAP = clarinet('ncolors', min(54, PVP.nColors), 'startColor', 1);
        colormap(ax, MAP);
    otherwise
        map = eval([PVP.colormap '('  num2str(PVP.nColors)  ')']);
        MAP = colormap(ax, map);
end


% -Inf, +Inf, and NaN -> -Inf (smallest) -> grey
if eq(PVP.omitnan, 1) && BadValuesFlag
    MAP = [0.95 0.95 0.95; MAP];
end
if PVP.reversemap
    colormap(ax, MAP(end:-1:1, :));
end

clim(climValues)

if isempty(PVP.YLim)
    ZL = [min(T.data(:), [], 'omitmissing'), max(T.data(:), [], 'omitmissing')];
else
    ZL = PVP.YLim;
end

set(gca, 'ZLim', ZL)

if ~isempty(PVP.colorbar)
    colorbar(PVP.colorbar, 'FontSize', PVP.FontSize(2))
end

%%%
% add grid, row and column labels to the axis
%%%
set(ax, 'YTick', 0.5+(1:1:size(T, 1)), 'YTickLabel', [],  ...
    'XAxisLocation', 'top', 'XTick', 0.5+(1:1:size(T, 2)), ...
    'XTickLabel', [])

if PVP.Grid
    [X1, Y1] = meshgrid(1:1:(size(T, 2) + 2), ...
        1:1:(size(T, 1) + 2));

    [X2, Y2] = meshgrid(1:1:(size(T, 1) + 2), ...
        1:1:(size(T, 2) + 2));

    line(X1, Y1, 'Color', PVP.clarinet(PVP.GridColor, :), 'LineWidth', PVP.GridWidth)
    line(Y2, X2, 'Color', PVP.clarinet(PVP.GridColor, :), 'LineWidth', PVP.GridWidth)

end

axis equal

if ~isempty(PVP.Depth)
    DAR = [1 1 1/PVP.Depth];
else
    d0 = min(size(T));
    r0 = range(climValues);
    PVP.Depth = d0/r0;
    DAR = [1 1 1/PVP.Depth];
end

% this tightens the x, y, and z axes
axis tight
% this sets the Z-axis limits you want, and the overall DAR
set(gca, ...
    'ZLim', ZL, ...
    'DataAspectRatio', DAR, ...
    'Box', 'on', 'BoxStyle', 'full')

if PVP.Grid
    set(ax, 'XGrid', 'on', 'YGrid', 'on', 'ZGrid', 'on')
else
    set(ax, 'XGrid', 'off', 'YGrid', 'off', 'ZGrid', 'off')
end

if PVP.labels(1)
    % rows aka y
    set(ax, 'YTickLabel', T.row_labels)
    ylabel(T.labels{1})
end

if PVP.labels(2)
    % cols aka x
    set(ax, 'XTickLabel', T.col_labels, 'XTickLabelRotation', 90)
    xlabel(T.labels{2})
end

if PVP.labels(3)
    title(T.fullname, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
end