function varargout = DISP(T, varargin)
% TBL/DISP Command window DISP of a tbl object

% anything to display?
if isempty(T.data)
    disp('empty tbl')
    if nargout > 0
        disp('empty tbl')
        varargout{1} = {};
    end
    return
end

% validate the inputs
DATA = INPUTS(T, varargin{1:end});

% are we truncating the display of rows?
if isfinite(DATA.N)
    DATA.T = DATA.T(1:DATA.N, :);
end

% replace observed T with pre-processed T
T = DATA.T;

rowlabels = T.row_labels;
if isempty(char(rowlabels))
    rowlabels = {};
end

collabels = T.col_labels;
if isempty(char(collabels))
    collabels = {};
end

[n, p] = size(T.data);

fullname = T.fullname;

if DATA.chromacode == 0
    if ~isempty(collabels)
        collabels = strrep(...
            replaceBetween(collabels, '\color[rgb]{', '}', ''), ...
            '\color[rgb]{}', '');
        collabels = strrep(collabels, '\bf', '');
        collabels = strrep(collabels, '\it', '');

    end
    if ~isempty(rowlabels)
        rowlabels = strrep(...
            replaceBetween(rowlabels, '\color[rgb]{', '}', ''), ...
            '\color[rgb]{}', '');
        rowlabels = strrep(rowlabels, '\bf', '');
        rowlabels = strrep(rowlabels, '\it', '');

    end
    if ~isempty(fullname)
        fullname = strrep(...
            replaceBetween(fullname, '\color[rgb]{', '}', ''), ...
            '\color[rgb]{}', '');
        fullname = strrep(fullname, '\bf', '');
        fullname = strrep(fullname, '\it', '');
    end
end

% Format the column labels.
if ~isempty(collabels)

    clabs = char(collabels(:)');
    clabs = strjust(clabs, 'right');
    % add blanks at the beginning of the lines
    clabs = [blanks(size(clabs,1))',clabs];
    width0 = size(clabs, 2);
    width1 = max(width0, DATA.width);
    if width1 > width0
        ws = blanks(width1 - width0);
    else
        ws = '';
    end

    clabs = [kron(ws, ones(size(clabs,1),1)), clabs];
    clabs = reshape(clabs', 1, numel(clabs));

else

    width1 = DATA.width;
    clabs = [];

end

% format the row labels
if ~isempty(rowlabels)

    % Fix-up in case there are '' elements in the row labels.
    rowlabels = char(rowlabels(:)');
    rlabs = char(rowlabels);
    if ~isempty(clabs)
        if isempty(T.labels{2})
            rlabs = char(' ', rlabs);
        else
            if isempty(T.labels{1})
                rlabs = char(T.labels{2}, rlabs);
            else
                rlabs = char([T.labels{1}, ' by ', T.labels{2}], rlabs);
            end
        end

        rlabs(:,end+1) = ' ';
    end

else
    rlabs = [];
end

% format has at least 18 columns for numbers and one space after each
fmtstr = ['%' num2str(width1) '.' num2str(DATA.prec) 'g'];
fmt = [];
for i = 1:p
    fmt = [fmt, fmtstr]; %#ok<*AGROW>
end
fmt = [fmt, '\n'];

if issparse(T.data)
    s0 = sprintf(fmt, full(T.data'));
else
    s0 = sprintf(fmt, T.data');
end

% Here is the key hack
ls0 = numel(s0);
rs0 = ls0/n;
if rem(rs0, 1) == 0
    s = reshape(s0, rs0, n)';
    % Discard the extra linefeed.
    s = s(:,1:end-1);
    s = [rlabs,[clabs;s]];
else
    error('tbl:disp', 'width and prec are not compatible')
end

if nargout==0
    disp(['<strong>' fullname '</strong>'])
    disp(s)
    disp(' ')
else
    varargout{1} = char(fullname, s, ' ');
end

%%%%%%%

function DATA = INPUTS(T, varargin)
% inputs, helper function

DATA.T = [];
DATA.prec = [];
DATA.width = [];
DATA.N = Inf;
DATA.chromacode = 0;

% Loop over property/value pairs.
lArgin = varargin(1:end);
lN = numel(lArgin);
if eq(lN, 1)
    error('You need to specify at least one property/value pair.');
end
while lN >= 2
    methodi = lArgin{1};
    vali = lArgin{2};

    lArgin = lArgin(3:end);
    lN = numel(lArgin);

    switch lower(methodi)

        case {'prec', 'precision'}
            if ~isnumeric(vali)
                error('prec must be an integer')
            end
            % catch a bunch of stupid errors
            if ~isscalar(vali)
                error('prec must be a scalar')
            end
            % catch a bunch of stupid errors without comment
            prec = fix(abs(vali(1)));
            DATA.prec = min(prec, 10);

        case 'width'
            % first see if this is a real scalar
            if ~isscalar(vali)
                error('width must be a positive integer');
            end
            if vali<0
                error('width must be a positive integer')
            end
            DATA.width = round(vali);

        case 'n'
            % first see if this is a real scalar
            if ~isscalar(vali)
                error('N must be a positive integer');
            end
            if vali <= 0
                error('N must be a positive integer')
            end
            % truncate at number of rows
            DATA.N = min(size(T, 1), round(vali));

        case 'chromacode'
            % first see if this is a real scalar
            if ~isscalar(vali)
                error('chromacode must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('chromacode must be 0 or 1')
            end
            DATA.width = round(vali);

        otherwise

    end

end

e1 = +(~isempty(DATA.width));
e2 = +(~isempty(DATA.prec));
spec = 1 + e1 + 2*e2;
switch spec
    case 1
        % default
        DATA.width = 8;
        DATA.prec = 5;
    case 2
        % have width need prec
        DATA.prec = DATA.width - 1;
    case 3
        % have prec need width
        DATA.width = DATA.prec + 1;
    case 4
        % have both
end

% increase width to accomodate space and prec
DATA.width = DATA.width + DATA.prec + 1;

R = size(T.data, 1);
if R > DATA.N
    S.type = '()';
    S.subs{1} = 1:DATA.N;
    S.subs{2} = ':';
    DATA.T = subsref(T, S);
else
    DATA.T = T;
end

