function TILE(T, PVP)
% TILE HeaT map of dIscrete vaLuEs in a matrix or tbl.

if isempty(T), return, end

%%%
% preprocess
%%%
[T, DATA, ~, BadValuesFlag] = preprocess_tbl_data(T, PVP, 'tile');

T.data = DATA;

v = uniquetol(full(T.data(:)), 1E-8);
nv = numel(v);
% b contains the index to the color associated with the unique values of T
[~, b] = ismembertol(full(T.data), v, 1E-8);

TILEDATA = b;

ax = gca;
image(ax, TILEDATA, 'CDataMapping', 'scaled');
%%%
% set colormap and colorbar
%%%
switch PVP.colormap
    case 'clarinet'
        MAP = clarinet('ncolors', min(nv, 54));
        colormap(ax, MAP);
    otherwise
        map = eval([PVP.colormap '(' num2str(nv) ')']);
        MAP = colormap(ax, map);
end

clim([1-0.5 nv+0.5])

% -Inf, +Inf, and NaN -> -Inf (smallest) -> grey
if eq(PVP.omitnan, 1) && BadValuesFlag
    MAP = [0.95 0.95 0.95; MAP(1:nv-1, :)];
end

if PVP.reversemap
    MAP = MAP(nv:-1:1, :);
end

% axis ij
set(ax, 'DataAspectRatio', [1 1 1], 'ColorMap', MAP)
ax.XAxis.FontSize = PVP.FontSize(1);
ax.YAxis.FontSize = PVP.FontSize(2);

% fancy colorbar
if ~isempty(PVP.colorbar)

    hc = colorbar(PVP.colorbar, 'FontSize', min(PVP.FontSize(1:2)));

    if nv <= 54

        hc.Ticks = 1:1:nv;
        tl = cell(1, nv);
        vl = 0:1:nv;
        vl(1) = 1;
        vl(end) = nv;
        nl = numel(vl);
        for i = 1:nl
            tl{vl(i)} = num2str(v(vl(i)), '%7.4g');
        end

        if PVP.omitzero
            tl{1} = '0/NaN';
        end
        hc.TickLabels = tl;

    else

        % start with the default ticks
        ticks = hc.Ticks;
        ticks = unique([1 ticks nv]);
        nl = numel(ticks);
        tl = cell(1, nl);
        for i = 1:5:nl
            tl{i} = num2str(v(ticks(i)), '%7.4g');
        end

        hc.Ticks = ticks;
        hc.TickLabels = tl;

    end

    hc.TickDirection = 'out';

end

%%%
% add grid, row and column labels to the axis: set y-axis direction
%%%

set(ax, 'YTick', 1:1:size(T,1), 'YTickLabel', [],  ...
    'XAxisLocation', 'top', 'XTick', 1:1:size(T,2), ...
    'XTickLabel', [], 'TickDir', 'out', ...
    'YDir', PVP.YDir)

if PVP.Grid
    [X1, Y1] = meshgrid(-0.5 + 1:1:(size(T, 2) + 1), ...
        -0.5 + 1:1:(size(T, 1) + 1));

    [X2, Y2] = meshgrid(-0.5 + 1:1:(size(T, 1) + 1), ...
        -0.5 + 1:1:(size(T, 2) + 1));

    line(X1, Y1, 'Color', PVP.clarinet(PVP.GridColor, :), 'LineWidth', PVP.GridWidth)
    line(Y2, X2, 'Color', PVP.clarinet(PVP.GridColor, :), 'LineWidth', PVP.GridWidth)
end


if PVP.labels(1)
    % rows aka y
    set(ax, 'YTickLabel', T.row_labels)
    ylabel(ax, T.labels{1})
end

if PVP.labels(2)
    % cols aka x
    set(ax, 'XTickLabel', T.col_labels, 'XTickLabelRotation', 90)
    xlabel(ax, T.labels{2})
end

if PVP.labels(3)
    title(ax, T.fullname, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
end

end
