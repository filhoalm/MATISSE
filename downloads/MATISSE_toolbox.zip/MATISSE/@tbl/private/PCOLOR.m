function PCOLOR(T0, PVP)
% TBL/PCOLOR heat map of data in a tbl object.

if isempty(T0), return, end

%%%
% preprocess
%%%
[T, DATA, climValues, ~] = preprocess_tbl_data(T0, PVP, 'pcolor');

%%%
% heat map / pcolor plot
%%%
ax = gca;

pcolor(ax, DATA, 'FaceAlpha', PVP.FaceAlpha, 'EdgeAlpha', PVP.EdgeAlpha);
shading(ax, PVP.shading)
set(ax, 'color', PVP.clarinet(PVP.AxisColor, :))
ax.XAxis.FontSize = PVP.FontSize(1);
ax.YAxis.FontSize = PVP.FontSize(2);

%%%
% colormap and colorbar
%%%
switch PVP.colormap
    case 'clarinet'
        MAP = clarinet('ncolors', min(54, PVP.nColors), ...
            'startColor', PVP.LineColor(1));
        colormap(ax, MAP);
    otherwise
        map = eval([PVP.colormap '('  num2str(PVP.nColors)  ')']);
        MAP = colormap(ax, map);
end

if PVP.reversemap
    colormap(ax, MAP(end:-1:1, :))
end

if ~isempty(PVP.colorbar)
    colorbar(PVP.colorbar, 'FontSize', PVP.FontSize(2))
end

if strcmp(PVP.axis, 'equal')
    set(gca, 'DataAspectRatio', [1 1 1])
end

clim(climValues)

%%%
% add grid, row and column labels to the axis
%%%
set(ax, 'YTick', 0.5+(1:1:size(T, 1)), 'YTickLabel', [],  ...
    'XAxisLocation', 'top', 'XTick', 0.5+(1:1:size(T, 2)), ...
    'XTickLabel', [])

if PVP.Grid
    [X1, Y1] = meshgrid(1:1:(size(T, 2) + 2), ...
        1:1:(size(T, 1) + 2));

    [X2, Y2] = meshgrid(1:1:(size(T, 1) + 2), ...
        1:1:(size(T, 2) + 2));

    line(X1, Y1, 'Color', PVP.clarinet(PVP.GridColor, :), 'LineWidth', PVP.GridWidth)
    line(Y2, X2, 'Color', PVP.clarinet(PVP.GridColor, :), 'LineWidth', PVP.GridWidth)
end

if PVP.labels(1)
    % rows aka y
    set(ax, 'YTickLabel', T.row_labels)
    ylabel(T.labels{1})
end

if PVP.labels(2)
    % cols aka x
    set(ax, 'XTickLabel', T.col_labels, 'XTickLabelRotation', 90)
    xlabel(T.labels{2})
end

if PVP.labels(3)
    title(T.fullname, ...
        'FontSize', PVP.FontSize(3), ...
        'FontWeight', 'normal', ...
        'VerticalAlignment', 'bottom')
end

end