function BUBBLES(T, PVP)
% BUBBLES map tbl values by bubble size and color.

if isempty(T), return, end

%%%
% preprocess
%%%
[T, DATA, climValues, BadValuesFlag] = preprocess_tbl_data(T, PVP, 'bubbles');

[R, C] = size(T);
RC = R * C;
YT = (1:1:R)';
XT = (1:1:C)';

Y = kron(YT, ones(1, C));
X = kron(ones(R, 1), XT');
y = Y(:);
x = X(:);

ax = gca;

%%%
% set colormap and colorbar
%%%
switch PVP.colormap
    case 'clarinet'
        MAP = clarinet('ncolors', min(54, PVP.nColors), ...
            'startColor', PVP.startColor);
        colormap(ax, MAP);
    otherwise
        map = eval([PVP.colormap '('  num2str(PVP.nColors)  ')']);
        MAP = colormap(ax, map);
end

% -Inf, +Inf, and NaN -> -Inf (smallest) -> grey
if (eq(PVP.omitzero, 1) || eq(PVP.omitnan, 1)) && BadValuesFlag
    MAP = [0.95 0.95 0.95; MAP];
end
nv = size(MAP, 1);

%%%
% all our bubbles are values between 0 and 1
%%%
clim([0 1])
if ~isempty(PVP.colorbar)
    colorbar(PVP.colorbar, 'FontSize', min(PVP.FontSize(1:2)))
end

%%%
% add a grid to define the squares we need - each circle is placed within
% an enclosing square -  and then hide it or not depending on the
% 'Grid' property-value.
%%%

set(ax, 'YTick', 0.5+(1:1:R), 'YTickLabel', [],  ...
    'XAxisLocation', 'top', 'XTick', 0.5+(1:1:C), ...
    'XTickLabel', [])

[X1, Y1] = meshgrid(-0.5 + 1:1:(C + 1), ...
    -0.5 + 1:1:(R + 1));

[X2, Y2] = meshgrid(-0.5 + 1:1:(R + 1), ...
    -0.5 + 1:1:(C + 1));

if PVP.Grid
    line(X1, Y1, 'Color', PVP.clarinet(PVP.GridColor, :), 'LineWidth', PVP.GridWidth);
    line(Y2, X2, 'Color', PVP.clarinet(PVP.GridColor, :), 'LineWidth', PVP.GridWidth);
else
    ac = get(ax, 'Color');
    line(X1, Y1, 'Color', ac, 'LineWidth', 0.5);
    line(Y2, X2, 'Color', ac, 'LineWidth', 0.5);
end

%%%
% draw the bubbles
%%%
% Use fewer points (quicker) when C is moderately large
if RC >= 20
    DELTA = 20;
else
    DELTA = 50;
end
th = (0:pi/DELTA:2*pi)';
thL = numel(th);
vrad = 1 - (abs(climValues(2)) - abs(DATA(:)))./abs(climValues(2));
vcol = (DATA(:) - climValues(1))./(climValues(2) - climValues(1));
LOC0 = floor((nv-2)*vcol) + 2;
BAD = ~isfinite(LOC0);
LOC = LOC0;
LOC(BAD) = 1;

if PVP.reversemap
    MAP = MAP(end:-1:1, :);
end
% one patch per column
xunit = kron(cos(th), ones(1, RC)).*kron(ones(thL, 1), 0.5*sqrt(vrad')) + ...
    kron(ones(thL, 1), x');
yunit = kron(sin(th), ones(1, RC)).*kron(ones(thL, 1), 0.5*sqrt(vrad')) + ...
    kron(ones(thL, 1), y');

cmp = zeros(1, RC, 3);
for rc = 1:RC
    cmp(1, rc, 1:3) = MAP(LOC(rc), :);
end

patch(xunit, yunit, cmp, ...
    'FaceAlpha', PVP.FaceAlpha, ...
    'EdgeAlpha', PVP.EdgeAlpha, ...
    'LineWidth', PVP.LineWidth);
l = line(xunit, yunit, 'LineWidth', PVP.LineWidth);

for rc = 1:RC
    l(rc).Color = MAP(LOC(rc), :);
end

%%%
% add text
%%%
if PVP.Text
    [X3, Y3] = meshgrid(1:1:C, 1:1:R);
    txt = cellstr(num2str(T.data(:), PVP.formatSpec));
    text(X3(:), Y3(:), txt, 'FontSize', PVP.FontSize(1), ...
        'HorizontalAlignment', 'center')
end

set(ax, 'DataAspectRatio', [1 1 1])

%%%
% add row and column labels and title to the axis
%%%

set(ax, 'TickDir', 'out', 'TickLength', [0.01 0.01], ...
    'XTick', XT, ...
    'XTickLabel', [], ...
    'YTick', YT, ...
    'YTickLabel', [], ...
    'XTickLabelRotation', -90, ...
    'box', 'off', ...
    'YDir', PVP.YDir)

ax.XAxis.FontSize = PVP.FontSize(1);
ax.YAxis.FontSize = PVP.FontSize(2);
axis(ax, 'tight')

if PVP.labels(1)
    % rows aka y
    set(ax, 'YTickLabel', T.row_labels)
    ylabel(T.labels{1})
end

if PVP.labels(2)
    % cols aka x
    set(ax, 'XTickLabel', T.col_labels)
    xlabel(T.labels{2})
end

if PVP.labels(3)
    title(T.fullname, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
end

end

