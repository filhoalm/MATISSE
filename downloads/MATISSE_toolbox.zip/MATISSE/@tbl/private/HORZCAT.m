function T = HORZCAT(varargin)
% TBL/HORZCAT Horizontally concatenate tbl objects with the same number of rows

switch nargin
    case 1
        T = varargin{1};

    case 2
        v = varargin{1};
        w = varargin{2};

        %%%
        % join two tables along the rows
        %%%
        T = RJOIN(v, w);

    otherwise
        v = varargin{1};
        q = varargin{nargin};
        for i = nargin-1:-1:2
            w = varargin{i};
            q = horzcat(w, q); %#ok<AGROW>
        end
        T = horzcat(v, q);
end

end

%%%%%%%%%%%%%%%%
function T = RJOIN(A, B)
% helper function joins two tbl objects along the rows

rA = size(A, 1);
rB = size(B, 1);

if rA~=rB
    error('number of rows of the input tbl objects must all be the same')
end

if ~isa(A, 'tbl') 
    clA = cell(1, size(A, 2));
    for i = 1:size(A, 2)
        clA{i} = '';
    end

    A = tbl('data', A, ...
        'fullname', 'numeric', ...
        'row_labels', B.row_labels, ...
        'col_labels', clA, ...
        'labels', {B.labels{1}, 'numeric'});

end

if ~isa(B, 'tbl') 
    clB = cell(1, size(B, 2));
    for i = 1:size(B, 2)
        clB{i} = '';
    end

    B = tbl('data', B, ...
        'fullname', 'numeric', ...
        'row_labels', A.row_labels, ...
        'col_labels', clB, ...
        'labels', {A.labels{1}, 'numeric'});

end

%%%
% resolve empty labels for A or B
%%%
if (eq(numel(A.col_labels), 1) && isempty(A.col_labels{1}))
clA = cell(1, size(A, 2));
    for i = 1:size(A, 2)
        clA{i} = '';
    end
else
    clA = A.col_labels;
end

if (eq(numel(B.col_labels), 1) && isempty(B.col_labels{1}))
clB = cell(1, size(B, 2));
    for i = 1:size(B, 2)
        clB{i} = '';
    end
else
    clB = B.col_labels;
end

T = tbl(...
    'data', [A.data, B.data], ...
    'fullname', ['[' A.fullname ', ' B.fullname ']'], ...
    'row_labels', A.row_labels, ...
    'col_labels', [clA, clB], ...
    'labels', {A.labels{1}, ''});  % 03 April 2026

end