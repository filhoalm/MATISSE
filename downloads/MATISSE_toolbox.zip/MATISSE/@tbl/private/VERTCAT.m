function T = VERTCAT(varargin)
% TBL/VERTCAT Vertically concatenate tbl objects

switch nargin
    case 1
        T = varargin{1};

    case 2
        v = varargin{1};
        w = varargin{2};

        %%%
        % join two tables along the columns
        %%%
        T = CJOIN(v, w);

    otherwise

        v = varargin{1};
        q = varargin{nargin};
        for i = nargin-1:-1:2
            w = varargin{i};
            q = vertcat(w, q); %#ok<AGROW>
        end
        T = vertcat(v, q);

end

end

%%%%%%%%%%%%%%%%
function T = CJOIN(A, B)
% helper function joins two tbl objects along the columns

cA = size(A, 2);
cB = size(B, 2);

if cA~=cB
    error('number of columns of the input tbl objects must all be the same')
end

if ~isa(A, 'tbl')
    rlA = cell(1, size(A, 1));
    for i = 1:size(A, 1)
        rlA{i} = '';
    end

    A = tbl('data', A, ...
        'fullname', 'numeric', ...
        'row_labels', rlA, ...
        'col_labels', B.col_labels, ...
        'labels', {'numeric', B.labels{2}});
end

if ~isa(B, 'tbl')
    rlB = cell(1, size(B, 1));
    for i = 1:size(B, 1)
        rlB{i} = '';
    end

    B = tbl('data', B, ...
        'fullname', 'numeric', ...
        'row_labels', rlB, ...
        'col_labels', A.col_labels, ...
        'labels', {'numeric', A.labels{2}});
end

T = tbl(...
    'data', [A.data; B.data], ...
    'fullname', ['[' A.fullname ', ' B.fullname ']'], ...
    'row_labels', [A.row_labels, B.row_labels], ...
    'col_labels', A.col_labels, ...
    'labels', A.labels);

end