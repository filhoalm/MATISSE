function [T, DATA, climValues, BadValuesFlag] = preprocess_tbl_data(T, PVP, PlotMethod)
% preprocess data for PCOLOR, SURF, ...

BadValuesFlag = 0;
BadValuesFiller = NaN;

switch PlotMethod
    case 'pcolor'
        BadValuesFiller = NaN;
        scaling = PVP.Scaling;

    case 'surf'
        BadValuesFiller = NaN;
        scaling = PVP.Scaling;

    case 'bar3'
        BadValuesFiller = NaN;
        scaling = PVP.Scaling;

    case 'tile'
        BadValuesFiller = -Inf;
        scaling = PVP.Scaling;

    case 'bubbles'
        BadValuesFiller = -Inf;
        scaling = 'range';

    case 'hexmap'
        BadValuesFiller = -Inf;
        scaling = PVP.Scaling;

    otherwise
end

DATA = T.data;
if any(~isfinite(DATA(:)))
    DATA(~isfinite(DATA)) = BadValuesFiller;
    BadValuesFlag = 1;
end

if eq(PVP.omitzero, 1)
    DATA(DATA == 0) = BadValuesFiller;
    BadValuesFlag = 1;
end

if strcmpi(scaling, 'range')
    TMP = DATA(isfinite(DATA));
    [S, L] = bounds(TMP, 'all', 'omitnan');
    
    DATA = (DATA - S)./(L - S);
    % smallest value is 0 and it would have no size
    % give it some size!
    [B, ia] = unique(DATA(:));
    Z = eq(DATA, 0);
    DATA(Z) = B(ia(2))/2;

end

if strcmpi(PVP.YDir, 'normal')
    DATA = DATA(end:-1:1, :);
    T.row_labels = T.row_labels(end:-1:1);
end

switch PlotMethod
    case {'pcolor', 'surf'}
        % need to add duplicate last row and last column
        DATA = [ DATA; DATA(end,:)];
        DATA = [ DATA, DATA(:,end)];
       
    case {'hexmap', 'tile', 'bubbles', 'bar3'}

    otherwise
end

%%%
% set colormap axis limits
%%%
z = DATA(:);
z(~isfinite(z)) = [];
% z could be empty or a scalar - code should work
if ischar(PVP.clim)
    switch PVP.clim

        case 'tight'
            climValues = [min(z) max(z)];

        case 'symmetric'
            if min(z)<0 && max(z)>0
                climValues = [-max(abs([min(z) max(z)])) +max(abs([min(z) max(z)]))];
            else
                climValues = [min(z) max(z)];
            end

        case '95%'
            climValues = quantile(z, [0.025 0.975]);
            if eq(climValues(1), climValues(2))
                m = mean(T.data(:), 'omitnan');
                climValues = [m-1, m+1];
            end

        case '90%'
            climValues = quantile(z, [0.05 0.95]);
            if eq(climValues(1), climValues(2))
                m = mean(T.data(:), 'omitnan');
                climValues = [m-1, m+1];
            end

    end
else
    climValues = PVP.clim;
end

if all(isnan(climValues(:))) || isempty(climValues)
    climValues = [0 1];
elseif eq(climValues(1), climValues(2))
    climValues = climValues + [-0.5 +0.5];
else
    % we use calculated climValues
end

end