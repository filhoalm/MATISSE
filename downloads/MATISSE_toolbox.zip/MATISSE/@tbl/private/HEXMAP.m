function HEXMAP(T, PVP)
% TBL/HEXMAP heat map of data in a tbl using hexagonal tiles.

if isempty(T), return, end

%%%
% preprocess
%%%
[T, DATA, climValues, BadValuesFlag] = preprocess_tbl_data(T, PVP, 'hexmap');

[R, C] = size(T);
RC = R * C;
r = 1;

ax = gca;

%%%
% draw hexagonal tiles
%%%
switch PVP.orientation

    case 'horizontal'

        dx = r*cos(pi/3);
        dy = r*sin(pi/3);
        y0 = -(r+2*dy);
        x0 = -(r+1*dx);
        X = x0 + (1:(r+dx):(r+dx)*C);
        x = kron(ones(R, 1), X);
        % ys is dy for odd cols, 0 for even cols
        YS = +((-1).^(0:C-1) == 1) * dy;
        ys = repmat(YS, R, 1);
        Y = y0 + ((1:(2*dy):(2*dy*R)));
        y = kron(Y', ones(1, C));
        h = Type1Hexagons(x, y+ys, r);

    case 'vertical'

        dx = r*cos(pi/6);
        x0 = 0;
        y0 = -r;
        X = x0 + (0:(2*dx):(2*dx)*(C-1));
        x = kron(ones(R, 1), X);
        XS = (dx)*(0:1:R-1);
        xs = repmat(XS', 1, C);
        Y = y0 + (0:r*(1+sin(pi/6)):(r*(1+sin(pi/6)))*(R-1))';
        y =  kron(Y, ones(1, C));
        h = Type2Hexagons(x-xs, y, r);

end

%%%
% set colormap and colorbar
%%%
switch PVP.colormap
    case 'clarinet'
        MAP = clarinet('ncolors', min(54, PVP.nColors), ...
            'startColor', PVP.startColor);
        colormap(ax, MAP);
    otherwise
        map = eval([PVP.colormap '('  num2str(PVP.nColors)  ')']);
        MAP = colormap(ax, map);
end

% -Inf, +Inf, and NaN -> -Inf (smallest) -> grey
nv = size(MAP, 1);
if (eq(PVP.omitzero, 1) || eq(PVP.omitnan, 1)) && BadValuesFlag
    MAP = [0.95 0.95 0.95; MAP(1:nv-1, :)];
end

% every hexagon needs to be mapped, including infinite values and values
% below or above the designated range
vcl = (DATA(:) - climValues(1))./range(climValues);

LOC = floor((nv-1)*vcl) + 1;
BAD = ~isfinite(LOC);

LOC(BAD) = 1;
BelowLL = vcl < 0 & ~BAD;

LOC(BelowLL) = 2;
AboveUL = vcl > 1 & ~BAD;
LOC(AboveUL) = nv - 1;

if PVP.reversemap
    colormap(ax, MAP(end:-1:1, :))
else
    colormap(ax, MAP)
end

clim(climValues)

if ~isempty(PVP.colorbar)
    colorbar(PVP.colorbar, 'FontSize', min(PVP.FontSize(1:2)))
end

set(ax, 'DataAspectRatio', [1 1 1])

cmp = zeros(1, RC, 3);
for rc = 1:RC
    cmp(1, rc, 1:3) = MAP(LOC(rc), :);
end

patch(h.x, h.y, cmp, ...
    'FaceAlpha', PVP.FaceAlpha, ...
    'EdgeAlpha', PVP.EdgeAlpha, ...
    'LineWidth', PVP.LineWidth, ...
    'EdgeColor', PVP.clarinet(PVP.GridColor, :));

%%%
% add row and column labels to the axis
%%%

switch PVP.orientation

    case 'horizontal'

        DELTA = cos(pi/6);
        XT = uniquetol(h.centroid(1,:), 1E-5);
        YT = uniquetol(h.centroid(2,:), 1E-5);
        YT = DELTA + YT(1:2:end);
        
        set(ax, 'TickDir', 'out', 'TickLength', [0.01 0.01], ...
            'XTick', XT, ...
            'XTickLabel', [], ...
            'YTick', YT, ...
            'YTickLabel', [], ...
            'XTickLabelRotation', -60, ...
            'box', 'off', ...
            'YDir', PVP.YDir)
        ax.XAxis.FontSize = PVP.FontSize(1);
        ax.YAxis.FontSize = PVP.FontSize(2);
        axis(ax, 'tight')

    case 'vertical'
        XT = uniquetol(h.centroid(1,:), 1E-5);
        YT = uniquetol(h.centroid(2,:), 1E-5);
        XT = cos(pi/6) + XT(2:2:end);
        
        set(ax, 'TickDir', 'out', 'TickLength', [0.01 0.01], ...
            'XTick', XT, ...
            'XTickLabel', [], ...
            'YTick', YT, ...
            'YTickLabel', [], ...
            'XTickLabelRotation', -60, ...
            'box', 'off', ...
            'YDir', PVP.YDir)
        ax.XAxis.FontSize = PVP.FontSize(1);
        ax.YAxis.FontSize = PVP.FontSize(2);axis(ax, 'tight')

end

if PVP.labels(1)
    % rows aka y
    set(ax, 'YTickLabel', T.row_labels)
    xlabel(T.labels{2})
end

if PVP.labels(2)
    % cols aka x
    set(ax, 'XTickLabel', T.col_labels)
    ylabel(T.labels{1})
end

if PVP.labels(3)
    title(T.fullname, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
end

end

% helper function

function h1 = Type1Hexagons(x, y, r)
% Numerical construction of Type 1 hexagons
x = x(:)';
y = y(:)';
N = numel(x);
r = r(:)';
if eq(numel(r), 1)
    r = repmat(r, 1, N);
end

dx = r*cos(pi/3);
dy = r*sin(pi/3);
h1 = struct('x', [], 'y', [], 'centroid', []);
h1.x = [x; x+r; x+r+dx;    x+r;      x; x-dx; x];
h1.y = [y;   y;   y+dy; y+2*dy; y+2*dy; y+dy; y];
h1.centroid = [x+r/2; y+dy];

end

function h2 = Type2Hexagons(x, y, r)
% Numerical construction of Type 2 hexagons
x = x(:)';
y = y(:)';
N = numel(x);
r = r(:)';
if eq(numel(r), 1)
    r = repmat(r, 1, N);
end

dx = r*cos(pi/6);
dy = r*sin(pi/6);
h2 = struct('x', [], 'y', [], 'centroid', []);
h2.x = [x; x+dx;   x+dx;        x;   x-dx; x-dx; x];
h2.y = [y; y+dy; y+dy+r; y+2*dy+r; y+dy+r; y+dy; y];
h2.centroid = [x; y+dy+r/2];

end
