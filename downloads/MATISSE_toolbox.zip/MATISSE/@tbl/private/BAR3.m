function BAR3(T, PVP)
% BAR3 for tbl objects

if isempty(T), return, end

%%%
% preprocess
%%%
[T, DATA, climValues, BadValuesFlag] = preprocess_tbl_data(T, PVP, 'bar3');

clim(climValues)

[R, C] = size(DATA);

%%%
% bar3 plot
%%%
H = bar3(DATA);

ax = gca;
set(ax, 'XDir', 'reverse')


set(H, 'EdgeAlpha', PVP.EdgeAlpha)

MASK = logical([...
    0 1 1 0 0 0 ...
    1 1 1 1 1 0 ...
    1 1 1 1 1 0 ...
    0 1 1 0 0 0]);
S.type = '()'; S.subs = {MASK};

for k = 1:length(H)
    zdata = H(k).ZData;
    H(k).CData = zdata;


    %%%
    % We want to make bars of height 0 disappear.
    % There is one surface object per column.
    % For each surface object, there is one bar per row.
    % Each bar is described by 6 sides that are ordered consecutively.
    %
    % The size of each surface object's XData, YData, and ZData is 6*R x 4
    % Each of the R sets of 6 rows has the following pattern:
    %
    %     NaN   x   x NaN
    %       x   x   x   x
    %       x   x   x   x
    %     NaN   x   x NaN
    %     NaN   x   x NaN
    %     NaN NaN NaN NaN
    %
    % The cost of this refinement is it is slow.
    % This is controlled by PVP.omitzero
    %%%
    if PVP.omitzero

        for c = 1:C

            for r = 1:R
                bcr = (r-1)*6 + 1 : (r-1)*6 + 6;

                method = 2; % have to figure out which method is most efficient

                switch method
                    case 1
                        TMP = H(k).ZData(bcr, :);
                        if sum(TMP(:), 'omitnan') == 0
                            H(k).CData(bcr, :) = NaN;
                        end

                    case 2
                        TMP = H(k).ZData(bcr, :);
                        if ~any(TMP(MASK))
                            H(k).CData(bcr, :) = NaN;
                        end

                    case 3
                        if ~any(subsref(H(k).CData(bcr, :), S))
                            H(k).CData(bcr, :) = NaN;
                        end

                end

            end


        end
    end

end

%%%
% colormap and colorbar
%%%

switch PVP.colormap
    case 'clarinet'
        MAP = clarinet('ncolors', min(54, PVP.nColors));
        colormap(ax, MAP);
    otherwise
        map = eval([PVP.colormap '('  num2str(PVP.nColors)  ')']);
        MAP = colormap(ax, map);
end

% -Inf, +Inf, and NaN -> -Inf (smallest) -> grey
if eq(PVP.omitnan, 1) && BadValuesFlag
    MAP = [0.95 0.95 0.95; MAP];
end
if PVP.reversemap
    colormap(ax, MAP(end:-1:1, :));
end

clim(climValues)
ZL = [min(T.data(:), [], 'omitmissing'), max(T.data(:), [], 'omitmissing')];
if eq(0, ZL(2) - ZL(1))
    ZL = [ZL(1) - 1, ZL(2) + 1];
end
set(ax, 'ZLim', ZL)

ax.XAxis.FontSize = PVP.FontSize(1);
ax.YAxis.FontSize = PVP.FontSize(2);

if ~isempty(PVP.colorbar)
    colorbar(PVP.colorbar, 'FontSize', PVP.FontSize(2))
end

DAR = get(ax, 'DataAspectRatio');
a = DAR(1);
b = DAR(2);

if ~isempty(PVP.Depth)

    set(ax, ...
        'ZLim', ZL, ...
        'DataAspectRatio', [a b 1./PVP.Depth], ...
        'Box', 'on', 'BoxStyle', 'full')

else

    set(ax, 'ZLim', ZL, ...
        'Box', 'on', 'BoxStyle', 'full')

end

if PVP.Grid
    set(ax, 'XGrid', 'on', 'YGrid', 'on', 'ZGrid', 'on')
else
    set(ax, 'XGrid', 'off', 'YGrid', 'off', 'ZGrid', 'off')
end

if PVP.labels(1)
    % rows aka y
    set(ax, 'YTick', 1:R, 'YTickLabel', T.row_labels, ...
        'YTickLabelRotation', -90)
    ylabel(T.labels{1})
end

if PVP.labels(2)
    % cols aka x
    set(ax, 'XTick', 1:C, 'XTickLabel', T.col_labels, ...
        'XTickLabelRotation', -90)
    xlabel(T.labels{2})
end

if PVP.labels(3)
    title(T.fullname, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
end

axis tight

end

