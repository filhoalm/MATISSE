classdef survival
    % SURVIVAL survival objects contain survival data.
    %
    % Do not confuse a SURVIVAL object with MATLAB's survival method for
    % outputs from the coxphfit function!
    % 
    % Survival data describe times until the occurrence of an event. The
    % observations may be subject to right censoring and left truncation.
    % Hence, survival data includes an entry time, an exit time, and a
    % status indicator: 1 if an event occurred at the exit time, 0
    % otherwise.
    %
    % MATISSE can estimate hazard functions using B-splines. See
    % https://pubmed.ncbi.nlm.nih.gov/7548706/ for details.
    %
    % See also survival/survival, comprisk.

    properties

        entry(:, 1) {mustBeMatrix} = [];            % entry times
        time(:, 1) {mustBeMatrix} = [];             % exit times
        status(:, 1) {mustBeMatrix} = [];           % status indicator
        fullname (1, :) {mustBeTextScalar} = '';    % a scientific name for the data
        labels (1, 2) {mustBeText} = {'', ''};      % {'non-event label', 'event label'}
        time_units (1, :) {mustBeTextScalar} = '';  % string, e.g. 'years'

    end

    methods

        function S = survival(varargin)
            % SURVIVAL time-to-event data with right censoring and left truncation.
            %
            % S = survival(...
            %        'entry', scalar or vector, ...
            %        'time', vector, ...
            %        'status', vector of 0's and 1's, ...
            %        'fullname', 'string', ...
            %        'labels', {'non-event label', 'event label'}, ...
            %        'time_units', 'string')
            %
            % * 'entry'  - default values are 0 for all observations
            %              always entry < time
            % * 'time'   - always time > entry & time > 0
            % * 'status' - always 0 == non-event, 1 == event
            %
            % * entry, time, and status are all set to missing if any
            %   value is missing
            %
            % See also comprisk.

            if nargin == 0
                % Contents of an empty survival
                S.entry = [];
                S.time = [];
                S.status = [];
                S.fullname = '';
                S.labels = {'', ''};
                S.time_units = '';

                return
            end

            if isa(varargin{1}, 'survival')
                S = varargin{1};
                return
            end

            % Contents of an empty survival
            S.entry = [];
            S.time = [];
            S.status = [];
            S.fullname = '';
            S.labels = {''};
            S.time_units = '';

            N = numel(varargin);

            if N == 0
                return
            end

            %%%
            % whittle the arguments
            %%%
            lArgin = varargin;
            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};

                if ~ischar(propi)
                    error('A property must be specified using a string.')
                end

                switch lower(propi)

                    case 'entry'
                        if ismatrix(vali) && isreal(vali)
                            if ~(any(vali(:) < 0))
                                S.entry = vali(:);
                            else
                                error('entry values must be non-negative')
                            end
                        else
                            error('entry values must be numeric')
                        end

                    case 'time'
                        if ismatrix(vali) && isreal(vali)
                            if ~(any(vali(:) < 0))
                                S.time = vali(:);
                            else
                                error('time values must be non-negative')
                            end
                        else
                            error('time values must be numeric')
                        end

                    case 'status'
                        if ismatrix(vali) && isreal(vali)
                            if all((eq(vali, 0) | eq(vali, 1) | isnan(vali)))
                                % the + coerces logical to double
                                S.status = +vali(:);
                            else
                                error('status values must be 0 or 1')
                            end
                        else
                            error('status values must be 0 or 1')
                        end

                    case 'fullname'
                        if ischar(vali)
                            S.fullname = vali;
                        else
                            error('fullname must be a string')
                        end

                    case 'labels'
                        if ~iscellstr(vali) %#ok<ISCLSTR>
                            error('labels must be a cellstr')
                        else
                            if ne(numel(vali), 2)
                                error('you must specify two status labels')
                            else
                                S.labels = vali;
                            end

                        end

                    case 'time_units'
                        if ischar(vali)
                            S.time_units = vali;
                        else
                            error('time_units must be a string')
                        end
                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('the last property has no matching value');
                end

            end

            % time and status values must have the same length
            n_t = size(S.time, 1);
            n_s = size(S.status, 1);
            if ~eq(n_t, n_s)
                error('time and status data must have the same length')
            end

            % resolve entry values
            if isempty(S.entry)
                S.entry = zeros(n_t, 1);
            elseif isscalar(S.entry)
                S.entry = repmat(S.entry, n_t, 1);
            end

            n_e = size(S.entry, 1);
            if ~eq(n_t, n_e)
                error('time and entry values must have the same length')
            end

            if any(S.entry >= S.time)
                error('entry values must be stricty less than time values')
            end

            if isempty(S.fullname)
                S.fullname = 'survival data';
            end

            if isempty(S.labels{1})
                S.labels{1} = 'censored';
            end

            if isempty(S.labels{2})
                S.labels{2} = 'event';
            end

            if isempty(S.time_units)
                S.time_units = 'units';
            end

            % A record is entirely missing if any value is missing
            miss = isnan(S.entry)| isnan(S.time) | isnan(S.status);
            S.entry(miss) = NaN;
            S.time(miss) = NaN;
            S.status(miss) = NaN;


        end

        function r = end(g, k, ~)
            % END end method for survival objects.

            switch k
                case 1
                    r = size(g, 1);
                case 2
                    r = size(g, 2);
                otherwise
            end

        end

        function B = isempty(S)
            % ISEMPTY isempty for survival objects.
            %
            % B = ISEMPTY(S)
            %
            % See also isnan.

            B = isempty(S.time);

        end

        function B = isnan(S)
            % ISNAN isnan for survival objects.
            %
            % B = ISNAN(S)
            %
            % See also isempty.

            B = isnan(S.time);

        end

        function L = length(S)
            % LENGTH length of a survival object.
            %
            % L = LENGTH(S)
            %
            % See also size, isempty.

            L = size(S.time, 1);

        end

        function varargout = size(S, varargin)
            % SIZE size of a survival object.
            %
            % [R, C] = size(S)
            % R = size(S, 1)
            % C = size(S, 2)
            %
            % Number of rows R and columns C of S.time.
            %
            % See also length, isempty.

            switch nargin
                case 1
                    switch nargout
                        case {0, 1}
                            varargout{1} = [size(S.time, 1), size(S.time, 2)];
                        case 2
                            varargout{1} = size(S.time, 1);
                            varargout{2} = size(S.time, 2);
                        otherwise
                            error('too many outputs')
                    end

                case 2
                    d = varargin{1};
                    switch nargout
                        case {0, 1}
                            varargout{1} = size(S.time, d(1));
                        case 2
                            varargout{1} = size(S.time, d(1));
                            varargout{2} = size(S.time, d(2));
                        otherwise
                            error('too many outputs')
                    end
            end

        end

        function G = subsasgn(X, S, V)
            % SUBSASGN subscripted assignment for survival objects.

            if length(S) > 1
                DEPTH = numel(S);
                error('index expression has depth %g, cannot be > 1', DEPTH)
            end

            switch S.type

                case '.'

                    switch S.subs
                        case 'entry'
                            G = survival('entry', V, ...
                                'time', X.time, ...
                                'status', X.status, ...
                                'fullname', X.fullname, ...
                                'labels', X.labels, ...
                                'time_units', X.time_units);
                        case 'time'
                            G = survival('entry', X.entry, ...
                                'time', V, ...
                                'status', X.status, ...
                                'fullname', X.fullname, ...
                                'labels', X.labels, ...
                                'time_units', X.time_units);
                        case 'status'
                            G = survival('entry', X.entry, ...
                                'time', X.time, ...
                                'status', V, ...
                                'fullname', X.fullname, ...
                                'labels', X.labels, ...
                                'time_units', X.time_units);
                        case 'fullname'
                            G = X;
                            G.fullname = V;
                        case 'labels'
                            G = X;
                            G.labels = V;
                        case 'time_units'
                            G = X;
                            G.time_units = V;


                        otherwise

                    end

                case '()'
                    warning('parantheses indexing is undefined')

                case '{}'
                    warning('brace indexing is undefined')

                otherwise

            end

        end

        function U = subsref(R, S)
            % SUBSREF subscripted referencing for survival objects.

            if length(S) > 1

                DEPTH = numel(S);
                for d = 1:DEPTH
                    if d == 1
                        U = subsref(R, S(1));
                    else
                        U = subsref(U, S(d));
                    end
                end

            else

                switch S.type

                    case '.'

                        switch S.subs

                            case 'entry'
                                U = R.entry;
                            case 'time'
                                U = R.time;
                            case 'status'
                                U = R.status;
                            case 'fullname'
                                U = R.fullname;
                            case 'labels'
                                U = R.labels;
                            case 'time_units'
                                U = R.time_units;
                            otherwise

                        end

                    case '()'
                        if isa(S.subs{1}, 'boolean')
                            S.subs = find(S.subs{1}.data == 1);
                            S.subs = {S.subs};
                        elseif isa(S.subs{1}, 'logical')
                            S.subs = S.subs{1};
                            S.subs = {S.subs};
                        elseif isa(S.subs{1}, 'numeric')

                            % let MATLAB handle any errors
                        end
                        NI = numel(S.subs);
                        switch NI
                            case {0, 1}
                                SUBS = cell(1, 2);
                                SUBS{1} = S.subs{1};
                                SUBS{2} = ':';
                            case 2
                                SUBS = S.subs;
                            otherwise

                        end

                        ENTRY = R.entry(SUBS{1}(:), SUBS{2});
                        TIME = R.time(SUBS{1}(:), SUBS{2});
                        STATUS = R.status(SUBS{1}(:), SUBS{2});
                        U = survival('entry', ENTRY, ...
                            'time', TIME, ...
                            'status', STATUS, ...
                            'fullname', R.fullname, ...
                            'labels', R.labels, ...
                            'time_units', R.time_units);

                    case '{}'

                        % do nothing
                        U = R;
                end

            end

        end

        function W = window(S, varargin)
            % WINDOW extract follow-up within a time window.
            %
            % W = WINDOW(S, 'lower', L, 'upper', U)
            %
            % Construct a counting process at time L that includes
            % follow-up and events from time L through time U.
            %
            % Observations that exit follow-up at or before time L, or
            % enter follow-up after time U have missing data in W.
            %
            % Example: Split S into three follow-up periods, (0 4], (4 8], and (8 Inf):
            %
            %      W1 = window(S, 'upper', 4)
            %      W2 = window(S, 'lower', 4, 'upper', 8)
            %      W3 = window(S, 'lower', 8)
            
            W = WINDOW(S, varargin{:});

        end

        function disp(v)
            % DISP command window disp of a survival object.
            if isempty(v)
                disp('empty rates object')
                return
            end

            disp(['<strong>' v.fullname '</strong>'])
            disp(' ')

            dta = [v.entry, v.time, v.status];
            nt = size(v, 1);
            inc = isnan(v.time);
            nm = sum(inc);
            dta = dta(~inc, :);
            disp([num2str(nt) ' observations, ' num2str(nm) ' missing.']);

            if ~isempty(dta)
                E = sum(v.status, 'omitnan');
                O = sum(v.time - v.entry, 'omitnan');
                disp(['<strong>' num2str(E, '%15.0f') '</strong> ' v.labels{2} ...
                    ' events in <strong>' num2str(O, '%20.2f') '</strong> time units of ''' v.time_units '''.'])
            end

        end


        function varargout = km(varargin)
            % KM Kaplan-Meir survival curve for survival objects.
            %
            % K = KM(S1, S2, ..., Sn, go(...))
            %
            % S1, S2, ..., Sn are survival objects.
            %
            % K{1} contains the lifetable of S1, K{2} of S2, ..., K{n} of Sn.
            %
            % See also hsp.

            Q = numel(varargin);
            if isa(varargin{Q}, 'struct')
                N = Q - 1;
                pvp = varargin{Q};
            else
                N = Q;
                pvp = ego('class', 'survival', 'method', 'km');
                pvp.LineColor = 1:N;
            end

            % Expand pvp to accomodate all N curves
            PVP = mascara(N, pvp);

            for i = 1:N
                if ~isa(varargin{i}, 'survival')
                    error(['argument ' num2str(i) ' is not a survival object'])
                end
            end

            h = cell(1, N);
            K = cell(1, N);
            l = cell(1, N);
            for n = 1:N

                % Draw the curves one at a time - cherry pick the
                % PVP values we need for each curve

                %%%
                % expunge missing values, if any
                %%%
                Sn = varargin{n};
                INC = ~isnan(Sn);
                s.type = '()';
                s.subs = {INC};
                Sn0 = subsref(Sn, s);

                K{n} = KMCORE(Sn0, PVP.Alpha);

                if PVP.Plot

                    pvp = PVP;
                    pvp.LineColor = PVP.LineColor(n);
                    pvp.LineWidth = PVP.LineWidth(n);
                    pvp.CI = PVP.CI(n);

                    % KMPLOT will never add labels or a legend
                    % we will do so after this loop
                    h{n} = KMPLOT(K{n}, pvp);
                    l{n} = varargin{n}.fullname;

                end

            end

            if PVP.Legend
                legend([h{:}], l{:}, 'FontSize', PVP.FontSize(1))
            end
            if PVP.labels(1)
                xlabel(varargin{1}.time_units, 'FontSize', PVP.FontSize(1))
            end
            if PVP.labels(2)
                ylabel('Event-Free Probability', 'FontSize', PVP.FontSize(2))
            end

            set(gca, 'XGrid', PVP.Grid, 'YGrid', PVP.Grid)

            switch nargout
                case 0
                case 1
                    varargout{1} = K;
                otherwise
                    error('too many outputs')
            end

        end

        function B = knots(S, varargin)
            % KNOTS knots for hazard function estimation using B-splines.
            %
            % B = KNOTS(S, ...)
            %
            % 'Order'    - a scalar or sequence of non-negative integers
            %              1 - step function
            %              2 - piecewise linear
            %              3 - piecewise quadratic
            %              4 - piecewise cubic
            %              ...
            %
            % 'Segments' - a scalar or sequence of positive integers
            %              1 - 1 segment
            %              2 - 2 segments split at the median
            %              3 - 3 segments split at the tertiles
            %              ...
            %
            % 'boot'     - scalar, number of bootstrap relications (100 default)
            %
            % 'Alpha'    - scalar between 0 and 1 (default 0.05), confidence level
            %
            % * The knots are placed at quantiles of the observed event times.
            %
            % See also hsp, spcol.

            B = KNOTS(S, varargin{:});

        end

        function H = hsp(S, varargin)
            % HSP B-spline hazard function estimation for a survival object.
            %
            % H = HSP(S, 'Order', <values>, 'Segments', <values>, 'boot', <value>, 'Alpha', <value>)
            %
            % 'Order'    - a scalar or sequence of non-negative integers
            %              1 - step function
            %              2 - piecewise linear
            %              3 - piecewise quadratic
            %              4 - piecewise cubic
            %              ...
            %
            % 'Segments' - a scalar or sequence of positive integers
            %              1 - 1 segment
            %              2 - 2 segments split at the median
            %              3 - 3 segments split at the tertiles
            %              ...
            %
            % 'boot'     - scalar, number of bootstrap relications (100 default)
            %
            % 'Alpha'    - scalar between 0 and 1 (default 0.05), confidence level
            %
            % * knots are placed at quantiles of the observed event times
            %
            % * model selection uses bias-corrected AIC with sample size
            %   set to the ** observed number of events **
            %
            % See also km, knots, plato.

            H = HSP(S, varargin{:});

        end


    end

end
