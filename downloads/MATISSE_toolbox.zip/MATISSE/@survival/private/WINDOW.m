function W = WINDOW(S, varargin)
% window follow-up in a survival object.

if isempty(S)
    W = S;
    return
end

INPUTS = options(S, varargin{:});

% extract entry, exit, and status data from T
TE = continuous('data', S.entry, 'fullname', 'TE');
TX = continuous('data', S.time, 'fullname', 'TX');
TS = boolean('data', S.status, 'fullname', 'TS');

% exclude cases that enter after U or exit before L
EXC = TE >= INPUTS.U | TX <= INPUTS.L;

% calculate entry, exit, and status data for W
WE = max(TE, INPUTS.L) - INPUTS.L;
WX = min(TX, INPUTS.U) - INPUTS.L;
WS = TS & (TX < INPUTS.U);

% set missing W cases to NaN
WE(EXC) = NaN;
WX(EXC) = NaN;
WS(EXC) = NaN;

% package the windowed f/y

if INPUTS.L > 0
    wtu = [S.time_units ' from ' num2str(INPUTS.L)];
else
    wtu = S.time_units;
end

fn = [S.fullname ' in (' num2str(INPUTS.L) ', ' num2str(INPUTS.U) ']'];

W = survival(...
    'entry', WE.data, ...
    'time', WX.data, ...
    'status', WS.data, ...
    'fullname', fn, ...
    'labels', S.labels, ...
    'time_units', wtu); 

end

%%%

function INPUTS = options(S, varargin)
% helper function

INPUTS = struct('L', [], 'U', []);

% error out on situations we don't want to bother with
if isempty(S)
    error('survival variable has no data')
end
if all(isnan(S))
    error('all observations are missing')
end

% default values
INPUTS.L = 0;
INPUTS.U = Inf;

lArgin = varargin;
nlA = numel(varargin);
if eq(nlA, 1)
    error('a property has no value')
end

while ge(nlA, 2)

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('property must be specified in a string')
    end

    switch lower(propi)

        case 'lower'
            if ~(isscalar(vali) && isreal(vali))
                error('lower must be a real scalar')
            else
                if vali < 0
                    error('lower must be non-negative')
                else
                    INPUTS.L = vali;
                end
            end

        case 'upper'
            if ~(isscalar(vali) && isreal(vali))
                error('upper must be a real scalar')
            else
                if vali < 0
                    error('upper must be non-negative')
                else
                    INPUTS.U = vali;
                end
            end

        otherwise

    end

    lArgin = lArgin(3:end);
    nlA = numel(lArgin);
end

% L must be less than or equal to U 

if INPUTS.U <= INPUTS.L
    error('lower limit must be strictly less than upper limit')
end

% Set bounds on U:
%
% * It is inconvenient to have Inf as the upper limit
% * It is inelegant to have U exceed the largest observed f/u time

if eq(INPUTS.U, Inf) || gt(INPUTS.U, max(S.time))
    INPUTS.U = max(S.time);
end

end