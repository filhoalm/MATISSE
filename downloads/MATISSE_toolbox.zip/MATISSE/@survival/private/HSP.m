function F = HSP(varargin)
% Hazard function estimation using B-splines.

F = struct('parent', '', 'AIC', [], 'H', [], 'B', []);

B = knots(varargin{:});

% setup
n = size(B.S, 1);
nEvents = sum(B.S.status, 'omitmissing');

M = length(B.knots);
N = length(B.evalTimes);
hf = NaN(N, M);
Sf = NaN(N, M);
data = NaN(M, 4);

% model selection, no bootstrapping at this stage
for m = 1:M

    Hm = hspcore(B.S, B.Order(m), B.knots{m}, B.evalTimes, 0, 0.05);

    hf(:, m) = Hm.h.data(:, 2);
    Sf(:, m) = Hm.S.data(:, 2);
    mdf = numel(Hm.coefficients(1, :));
    % edf = mdf + (mdf^2 + mdf)/(n - mdf - 1);
    edf = mdf + (mdf^2 + mdf)/max(0, (nEvents - mdf - 1));

    % disp([edf, edfe])
    % aic = Hm.m2loglik + 2*edf;
    aic = Hm.m2loglik + 2*edf;
    data(m, :) = [mdf edf Hm.m2loglik aic];

end

% identify the best model
[~, rnk ] = sort(data(:, 4));
[~, irnk] = ismember((1:M)', rnk);
DELTA = data(:, 4) - data(rnk(1), 4);
DATA = [B.Order' B.Segments' irnk data DELTA];
AIC = tbl(...
    'data', DATA(rnk, :), ...
    'fullname', 'AICc', ...
    'col_labels', ...
    {'Order', 'Segments', 'rank', 'mdf', 'edf', 'm2loglik', 'AICc', 'DELTA'});

% all in on the best model - with variance calculations if boot > 0
H = hspcore(B.S, B.Order(rnk(1)), B.knots{rnk(1)}, B.evalTimes, B.boot, B.Alpha);

F.parent = 'survival/hsp';
F.AIC = AIC;
F.H = H;
F.B = B;

end


