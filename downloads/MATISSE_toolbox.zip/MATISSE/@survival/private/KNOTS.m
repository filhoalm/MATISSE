function B = KNOTS(S, varargin)
% KNOTS - knot locations for B-spline basis functions.

PVP = options(S, varargin{:});

MO = numel(PVP.Order);
MS = numel(PVP.Segments);
M = MO * MS;

knots = cell(1, M);
Order0 = zeros(1, M);
Segments0 = zeros(1, M);

k = 0;
for i = 1:MO
    for j = 1:MS

        k = k + 1;

        % quantiles from segments
        PQ = 0+1/PVP.Segments(j):1/PVP.Segments(j):1-1/PVP.Segments(j);

        if ~isempty(PQ)
            TMP1 = prctile(PVP.tEvents, 100*PQ);
            % weirdness if our data are too sparse
            if any(isnan(TMP1))
                TMP1 = [];
            end
        else
            TMP1 = [];
        end

        % for Order 0 step functions we still need to include edge knots
        knots{k} = [...
            repmat(PVP.timeFrame(1), 1, max(1, PVP.Order(i))), ...
            TMP1, ...
            repmat(max(PVP.timeFrame), 1, max(1, PVP.Order(i)))];

        % add values to our running lists
        Order0(k) = PVP.Order(i);
        Segments0(k) = PVP.Segments(j);

    end
end

B = PVP;
% replace initial lists of Order and Segments with expanded lists after
% discarding any duplicate combinations
TMP = [Order0', Segments0'];
[~, INC] = unique(TMP, 'rows');
B.Order = TMP(INC, 1)';
B.Segments = TMP(INC, 2)';
% and add our penultimate results
B.knots = knots(INC);

end

function PVP = options(S, varargin)
% Helper function

% default values
PVP = struct(...
    'S', [], ...
    'timeFrame', [], ...
    'tEvents', [], ...
    'evalTimes', [], ...
    'boot', 100, ...
    'Alpha', 0.05, ...
    'Order', 4, ...
    'Segments', 3);

%%%
% whittle the arguments
%%%
N = numel(varargin);
lArgin = varargin;

while N >= 2

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('a property must be specified using a string')
    end

    switch lower(propi)

        case 'order'
            % first see if this is a real vector
            if ~(isreal(vali) && isnumeric(vali))
                error('Order must be a scalar or vector')
            end
            if any(vali < 0)
                error('Order must be >= 0')
            end
            if any(rem(vali, 1)~=0)
                error('Order must contain only integers')
            end
            PVP.Order = vali(:)';

        case 'segments'
            % first see if this is a real vector
            if ~(isreal(vali) && isnumeric(vali))
                error('Segments must be a scalar or vector')
            end
            if any(vali <= 0)
                error('Segments must be > 0')
            end
            if any(rem(vali, 1)~=0)
                error('Segments must contain only integers')
            end
            PVP.Segments = vali(:)';

        case 'boot'
            % first see if this is a real vector
            if ~(isscalar(vali))
                error('boot must be a scalar')
            end
            if (vali <= 0)
                error('boot must be non-negative')
            end
            if (rem(vali, 1)~=0)
                error('boot must be an integer')
            end
            PVP.boot = vali;

        case 'alpha'
            if ~(isscalar(vali) && isreal(vali))
                error('Alpha must be a real scalar')
            elseif (vali < 0 || vali > 1)
                error('Alpha must lie between 0 and 1')
            else
                PVP.Alpha = vali;
            end



        otherwise
    end


    %%%
    % Select the unique combinations of Order and Segments
    %%%

    % setup for the next pair
    lArgin = lArgin(3:end);
    N = numel(lArgin);
    if eq(N, 1)
        error('the last property has no matching value');
    end

end

% good (non-missing) data
good.type = '()';
good.subs = {~isnan(S.time)};
S0 = subsref(S, good);

% timeFrame: first entry time, last event time, last exit time.
tEvents = sort(S0.time(logical(S0.status)));
timeFrame = [min(S0.entry) max(tEvents) max(S0.time)];


% evalTimes: useful sequence of evaluation times, including some integers.
evalTimes = unique([timeFrame(1):1:timeFrame(2), ...
    timeFrame(1):(timeFrame(2)-timeFrame(1))/200:timeFrame(2)])';

% commit / our copy of S in PVP has no missing data
PVP.S = S0;
PVP.timeFrame = timeFrame;
PVP.tEvents = tEvents;
PVP.evalTimes = evalTimes;

end