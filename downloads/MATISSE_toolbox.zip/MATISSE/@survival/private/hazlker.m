function [alpha1, hf, Sf, m2loglik] = hazlker(yd, alpha0, Wik, Zik, Eik, Xh, XH)
% HAZLKER wrapper allows fmincon to access srllikb

hOptions = optimset(...
    'TolFun', 1E-6, ...
    'TolX', 1E-6, ...
    'Display', 'none', ...
    'algorithm', 'interior-point', ...
    'GradObj', 'on');

% lower bounds are 0s
LWR = zeros(1, size(Wik, 2));

alpha1 = fmincon(@(alpha0) srllikb(alpha0, yd, Wik, Zik, Eik), ...
    alpha0, [], [], [], [], LWR, [], [], hOptions);
hf = Xh*alpha1';
Sf = exp(-XH*alpha1');

m2loglik = srllikb(alpha1, yd, Wik, Zik, Eik);

end
