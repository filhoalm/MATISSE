function H = hspcore(S, Order, knots, evalTimes, boot, Alpha)
% core function for hsp analysis

% Setup - rescale the time axis to prevent numerical instability

% the S argument has no missing values
n = size(S, 1);

y0 = S.time;
d0 = S.status;
e0 = S.entry;
knots0 = knots;
evalTimes0 = evalTimes;

TMAX = max(y0);
y = y0/TMAX;
e = e0/TMAX;
d = d0;
knots = knots0/TMAX;
t = evalTimes0/TMAX;

% Basis functions to estimate h in terms of 'x<n>'
x1 = y(:, 1);
[sx1, si1] = sort(x1);
Wik(si1, :) = spcol(knots, Order, sx1, 'noderiv');

% Basis functions to estimate the definite integral of h
% * Lower limit of integration is the left endpoint of the basic interval
% * This code is based on spcol and De Boor, PGS, p. 150-151.

nk = length(knots);
% Number of actual parameters
p = nk - Order;
scl = (knots(Order+1:Order+p) - knots(1:p))/Order;
z = (tril(kron(1:p, ones(p, 1))) > 0).*(ones(p, 1)*scl);
TMP1(si1, :) = spcol([knots, knots(end)], Order + 1, sx1, 'noderiv');
Zik = TMP1*z;

% Basis functions for evaluation times t
x2 = t;
[sx2, si2] = sort(x2);
Xh(si2, :) = spcol(knots, Order, sx2, 'noderiv');
TMP2(si2, :) = spcol([knots, knots(end)], Order + 1, sx2, 'noderiv');
XH = TMP2*z;

% Basis functions for e
x3 = e;
[sx3, si3] = sort(x3);
TMP3(si3, :) = spcol([knots, knots(end)], Order + 1, sx3, 'noderiv');
Eik = TMP3*z;

% Initial guess
alpha0 = (sum(d)/sum(y-e)) * ones(1, size(Wik, 2));

% Maximize the likelihood function
[ALPHA, hf, Sf, m2loglik] = hazlker([y d], alpha0, Wik, Zik, Eik, Xh, XH);

% scale back
hf = hf/TMAX;

% Bootstrap? Necessary for variance-covariance matrices
switch boot

    case 0

        aBOOT = zeros(1, numel(ALPHA));

        h = tbl(...
            'data', [evalTimes, hf], ...
            'fullname', S.fullname, ...
            'labels', {S.time_units, ['Hazard of ' S.labels{2}]}, ...
            'col_labels', {S.time_units, ['Hazard of ' S.labels{2}]});

        s = tbl(...
            'data', [evalTimes, Sf], ...
            'fullname', S.fullname, ...
            'labels', {S.time_units, [S.labels{1} ' Probability']}, ...
            'col_labels', {S.time_units, [S.labels{1} ' Probability']});

    otherwise

        Wik0 = Wik;
        Zik0 = Zik;
        Eik0 = Eik;

        N = length(evalTimes);
        hboot = zeros(N, boot);
        Sboot = zeros(N, boot);
        aBOOT = zeros(1 + boot, numel(ALPHA));
        aBOOT(1, :) = ALPHA;

        for b = 1:boot

            i_b = randsample(n, n, true);

            % an explicit call to subsref works
            rsd.type = '()';
            rsd.subs = {i_b};
            S_b = subsref(S, rsd);

            yd_b = [S_b.time S_b.status];
            Wik = Wik0(i_b, :);
            Zik = Zik0(i_b, :);
            Eik = Eik0(i_b, :);

            [aBOOT(1 + b, :), hboot(:, b), Sboot(:, b), ~] = ...
                hazlker(yd_b, ALPHA, Wik, Zik, Eik, Xh, XH);

        end

        %%%
        % bootstrap confidence limits incorporate h >= 0 and 0 <= S <= 1
        %%%
        TMP1 = sort((hboot./TMAX), 2);
        TMP2 = sort(Sboot, 2);
        iLIM = round(prctile(1:boot, 100 * [Alpha/2 1-Alpha/2]));
        hci = TMP1(:, iLIM);
        Sci = TMP2(:, iLIM);

        h = tbl(...
            'data', [evalTimes, hf, hci], ...
            'fullname', S.fullname, ...
            'labels', {S.time_units, ['Hazard of ' S.labels{2}]}, ...
            'col_labels', {S.time_units, ['Hazard of ' S.labels{2}], 'Lo', 'HI'});

        s = tbl(...
            'data', [evalTimes, Sf, Sci], ...
            'fullname', S.fullname, ...
            'labels', {S.time_units, [S.labels{1} ' Probability']}, ...
            'col_labels', {S.time_units, [S.labels{1} ' Probability'], 'Lo', 'HI'});


end

%%%
% rescale the hazard values and coefficients
%%%
aBOOT(1, :) = ALPHA;
aBOOT = aBOOT./TMAX;

H = struct(...
    'data', S, ...
    'h', h, ...
    'S', s, ...
    'coefficients', aBOOT, ...
    'Order', Order, ...
    'knots', knots, ...
    'Xh', Xh, ...
    'm2loglik', m2loglik);

end
