function [l, dl] = srllikb(alpha, yd, Wik, Zik, Eik)
% SRLLIKB -2log likelihood for B-spline hazard function estimator.
%
%  l - objective function (-2 *log likelihood function)
% dl - first derivative

l = -2*sum((yd(:, 2)).*log(Wik*alpha') - Zik*alpha' + Eik*alpha');
np = size(alpha, 2);
h = Wik*alpha';
t1 = (yd(:,2)./h)*ones(1, np);
t1 = Wik.*t1;
score = sum(t1 - Zik + Eik);
dl = -2*score;

