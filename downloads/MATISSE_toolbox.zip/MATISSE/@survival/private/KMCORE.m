function K = KMCORE(S, Alpha)
% KMCORE Kaplan-Meier product-limit estimator.
%
% This program uses the efficient one pass algorithm developed by Jay Lubin.

%%%
% Setup
%%%

% Number of events with a given exit time
D = zeros(1, 1);

% Sum to accumulate over all exit times
RR = zeros(1, 1);

% Sum to decrement for observations that enter after the current time
RRM = zeros(1, 1);

% TSTAR - smallest evaluated event time
% TCURR - most recently evaluated exit time
% ORDYI - pointer to (reverse) sorted exit times
% ORDEI - pointer to (reverse) sorted entry time
%    cc - number who enter between current event and last event

% Counter for number of risk sets (unique event times)
nrisksets = 0;

updateflag = 0;

% Number of evaluated entry times
J =  1;

%%%
% z will contain the current failure time TSTAR, the number of events D,
% and the number at risk rru. z will have at most ND = sum(S.status)
% columns.
%%%

nf = sum(S.status);
z = NaN(nf, 3);

%%%
% End setup
%%%

n = size(S, 1);

if eq(n, 0)

    nf = 0;

    [st, lt] = null(n, nf);

    K = struct('lifetable', lt, 'stairs', st, 'pte', []);

    return

end

[~, ordY] = sort(-S.time(:,1));
persontime = sum(S.time - S.entry);
[~, ordE] = sort(-S.entry);

% no point in continuing if there are no events
if eq(nf, 0)

    [st, lt] = null(n, nf);
    K = struct('lifetable', lt, 'stairs', st, 'pte', [persontime 0]);
    return
end

%%%
% Evaluate data for the first observation ('prime the pump')
%%%

ORDYI = ordY(1);
TCURR = S.time(ORDYI);
RR = RR + 1;
% is this observation an event?
if eq(S.status(ORDYI), 1)
    D = D + 1;
end

%%%
% Loop over observations
%%%
if n >= 2
    for i = 2:n
        ORDYI = ordY(i);

        % is it time to update ll, d1ll, d2ll?
        if (S.time(ORDYI) < TCURR && D > 0),  updateflag = 1;  end

        if eq(updateflag, 1)

            TSTAR = TCURR;
            nrisksets = nrisksets + 1;

            % adjust contributions for observations who enter after TSTAR
            conti = 1;
            cc = 0;
            while le(J, n) && eq(conti, 1)
                ORDEI = ordE(J);
                if TSTAR <= S.entry(ORDEI)
                    cc = cc + 1;
                    RRM = RRM + 1;
                    J = J + 1;
                else
                    conti = 0;
                end
            end

            rru =   RR - RRM;
            z(nrisksets, :) = [TSTAR, D, rru];

            % reset
            D = 0;
            updateflag = 0;
        end

        % evaluate data for the ith observation
        TCURR = S.time(ORDYI);
        RR =   RR +	1;
        % is this observation an event?
        if eq(S.status(ORDYI), 1)
            D = D + 1;
        end

    end

    %%%
    % Update one more time if the last observation is an event
    %%%
    if eq(S.status(ORDYI), 1) || D > 0
        updateflag = 1;
    end

    if eq(updateflag, 1)

        TSTAR = TCURR;
        nrisksets = nrisksets + 1;

        % adjust contributions for subjects who enter after TSTAR
        conti = 1;
        cc = 0;
        while le(J, n) && eq(conti, 1)
            ORDEI = ordE(J);
            if TSTAR <= S.entry(ORDEI)
                cc = cc + 1;
                RRM = RRM + 1;
                J = J + 1;
            else
                conti = 0;
            end
        end

        rru =   RR - RRM;

        z(nrisksets, :) = [TSTAR, D, rru];

    end

    %%%
    % Trim the unused portion of z, which is equal to the number of ties.
    %%%
    z = z(1:nrisksets, :);

    %%%
    % format & report
    %%%
    kmtbl = z;
    kmtbl = kmtbl(nrisksets:-1:1,:);
    yf = kmtbl(:,1);
    d_yf = kmtbl(:,2);
    r_yf = kmtbl(:,3);

    %%%
    %
    % 12 May 2000. Credit to Hormuzd Katki.
    %
    % * With extreme patterns of late entry, it is possible that the d_yf
    %   equals r_yf early on (e.g. 1 person at risk early who fails).
    %
    % * When this happens the Nelson-Aalen estimator is preferred over KM:
    %   Klein and Moeschberger, Survival Analysis, Springer-Verlag, 1997, p. 86.
    %
    %%%

    TEST = r_yf - d_yf;
    % OK for last risk set to have one at risk and one event
    TEST = TEST(1:end-1);
    if all(TEST)
        NAFLAG = 0;
    else
        NAFLAG = 1;
    end

    if NAFLAG
        % survivorship using Nelson-Aalen estimator
        s = exp(-cumsum(d_yf./r_yf));
        vch = cumsum(d_yf./r_yf.^2);
        warning('100% hazard rate in a risk set. Switching to Nelson-Aalen estimator.');
    else
        % survivorship using KM
        s = cumprod(1-d_yf./r_yf);
        % greenwood variance for cumulative hazard
        denom = r_yf.*(r_yf - d_yf);
        vch = cumsum(d_yf./(denom + (denom==0)));
    end

    z_alpha_over_2 = norminv(1 - Alpha/2);

    sci = [exp(log(s+(s==0))-z_alpha_over_2*sqrt(vch)), ...
        exp(log(s+(s==0))+z_alpha_over_2*sqrt(vch))];
    if any(s==0)
        sci(s==0,:) = [NaN NaN];
    end

    % bound upper ci <= 1
    i = find(sci > 1);
    if ~isempty(i)
        sci(i) = ones(1, length(i));
    end

    kmtbl = tbl(...
        'data', [kmtbl, s, s.^2 .* vch], ...
        'fullname', ['lifetable: ' S.fullname], ...
        'col_labels', {'time', 'no. events', 'no. at risk', 'KM', 'Var'});

    % make x and y points for stair plot
    kmlinex = [0, yf(kron(1:nrisksets,[1 1]),1)'];
    kmliney = [1, 1, s(kron(1:nrisksets-1,[1 1]),1)',s(nrisksets)];
    % lower/upper ci
    slo = sci(:,1)';
    kmliney_lo = [1,1,slo(kron(1:nrisksets-1,[1 1])),slo(nrisksets)];
    shi = sci(:,2)';
    kmliney_hi = [1,1,shi(kron(1:nrisksets-1,[1 1])),shi(nrisksets)];
    kmline = [kmlinex',kmliney',kmliney_lo',kmliney_hi'];
    % If last observation is failure there is extra row and CI is NaN
    if isnan(slo(end))
        kmline(end, 3:4) = kmline(end-1, 3:4);
    end

    %%%
    % Extend KM curve to last observed censored time, if this exceeds
    % largest event time. You may want to dummy this out later, but this is
    % a sometimes used "convention".
    %%%
    ydmax = [S.time(ordY(1)), S.status(ordY(1))];
    if eq(ydmax(:,2), 0)
        kmline(end+1,:) = [ydmax(:,1) kmline(end,2:4)];
    end

    kmline = tbl(...
        'data', kmline, ...
        'fullname', ['stairs: ' S.fullname], ...
        'col_labels', {'time', 'KM', 'CILo', 'CIHi'});
else

end

K = struct('lifetable', kmtbl, 'stairs', kmline);

end

%%%%%

function [st, lt] = null(n, nf)
% containers for null outputs

st = tbl(...
    'data', [0 1 1 1], ...
    'col_labels', {'time', 'KM', 'CILo', 'CIHi'});

lt = tbl(...
    'data', [0 nf n 1 0], ...
    'col_labels', ...
    {'time', 'no. events', 'no. at risk', 'KM', 'Var'});

end
