function h = KMPLOT(K, PVP)
% Plot a KM curve.

DATA = K.stairs.data;

% do NOT add labels and legend within this helper function
PVP0 = PVP;
PVP0.Legend = 0;
PVP0.labels = [0 0 0];

h = pcurve(DATA, PVP0);

end

