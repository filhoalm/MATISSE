function varargout = cuboids(varargin)
% CUBOIDS Draw cuboids.
%
% h = CUBOIDS(xyz, lwd, go(...))
%
% Draw cuboids centered at xyz with dimensions lwd, one cuboid per row.
%
% * xyz and lwd must have 3 columns
% * xyz, lwd or both can have 1 row
%
% See also rectangles.

switch nargin
    case 0
        return
    case 1
        xyz = varargin{1};
        lwd = [1 1 1];
        pvp = ego('class', 'graphics', 'method', 'cuboids');

    case 2
        xyz = varargin{1};
        lwd = varargin{2};
        pvp = ego('class', 'graphics', 'method', 'cuboids');

    case 3
        xyz = varargin{1};
        lwd = varargin{2};
        pvp = varargin{3};
    otherwise
        error('too many inputs')
end

D = validate(xyz, lwd, pvp);
h = drawcuboids(D);

axis equal

DAR = [1 1 1/D.PVP.Depth];

% this tightens the x, y, and z axes
axis tight
% this sets the overall DAR
set(gca, 'DataAspectRatio', DAR, 'Box', 'on', 'BoxStyle', 'full')


switch nargout
    case 0
    case 1
        varargout{1} = h;
    otherwise
        error('too many outputs')
end

end

%%%%%%%%
function D = validate(xyz, lwd, pvp)
% validate xyz and lwd values. expand pvp if necessary.

[R1, C1] = size(xyz);
[R2, C2] = size(lwd);

if ne(C1, 3) || ne(C2, 3)
    error('''xyz'' and ''lwd'' must both have 3 columns')
end

if gt(R1, 1) && gt(R2, 1) && ne(R1, R2)
    error('''xyz'' and ''lwd'' must have the same number of rows')
end

% expand either argument to match the other
if eq(R1, 1) && gt(R2, 1)
    xyz = repmat(xyz, R2, 1);
end
if eq(R2, 1) && gt(R1, 1)
    lwd = repmat(lwd, R1, 1);
end

R = size(xyz, 1);
PVP = mascara(R, pvp);

D = struct('R', R, 'xyz', xyz, 'lwd', lwd, 'PVP', PVP);

end

function hndl = drawcuboids(D)
% cuboids at (x,y,z) with dimensions (l,w,d)

%%%
% One cuboid per row - for now, a loop
%%%

for r = 1:D.R

    x = D.xyz(r, 1);
    y = D.xyz(r, 2);
    z = D.xyz(r, 3);
    l = D.lwd(r, 1);
    w = D.lwd(r, 2);
    d = D.lwd(r, 3);

    v1 = [0 0 0; 0 w 0; 0 w d; 0 0 d];
    v2 = [l 0 0; l 0 d; l w d; l w 0];
    v3 = [0 0 0; l 0 0; l 0 d; 0 0 d];
    v4 = [0 w 0; l w 0; l w d; 0 w d];
    v5 = [0 0 d; l 0 d; l w d; 0 w d];
    v6 = [0 0 0; l 0 0; l w 0; 0 w 0];

    center = ones(4, 1)*[x-l/2 y-w/2 z-d/2];
    lcolor = D.PVP.LineColor(r);

    p1 = patch('Vertices', center + v1, 'Faces', 1:4);
    p2 = patch('Vertices', center + v2, 'Faces', 1:4);
    p3 = patch('Vertices', center + v3, 'Faces', 1:4);
    p4 = patch('Vertices', center + v4, 'Faces', 1:4);
    p5 = patch('Vertices', center + v5, 'Faces', 1:4);
    p6 = patch('Vertices', center + v6, 'Faces', 1:4);
   
    ph = [p1 p2 p3 p4 p5 p6];
    
    set(ph, ...
        'FaceColor', D.PVP.MAP(lcolor, :), ...
        'EdgeColor', D.PVP.MAP(lcolor, :), ...
        'FaceAlpha', D.PVP.FaceAlpha, ...
        'EdgeAlpha', D.PVP.EdgeAlpha, ...
        'LineStyle', D.PVP.ls0{D.PVP.LineStyle(r)}, ...
        'LineWidth', D.PVP.LineWidth(r))

    hndl.h = ph;
    hndl.Parent = 'cuboids';

end

end
