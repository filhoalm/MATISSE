function varargout = circles(x, y, r, varargin)
% CIRCLES Draw circles.
%
% CIRCLES(x, y, r)
% CIRCLES(x, y, r, go(...))
% h = CIRCLES(...)
%
% Draw circles centered at (x,y) with radius r.
%
% The appearance of each circle is controlled by go values.
%
% See also squares, rectangles, ellipses, annuli.

switch nargin
    case 3
        PVP = ego('class', 'graphics', 'method', 'circles');
    case 4
        PVP = varargin{1};
    otherwise
        error('wrong number of inputs')
end

h = drawcircles(x(:), y(:) ,r(:), PVP);

ax = gca;
switch PVP.axis
    case 'equal'
        axis equal
end
if eq(PVP.Grid, 1)
    set(ax, ...
        'XGrid', true, 'YGrid', true, ...
        'GridColor', PVP.clarinet(PVP.GridColor, :), ...
        'GridLineWidth', PVP.GridWidth, ...
        'GridAlpha', 0.25)
end

if ~isempty(PVP.XLim)
    set(ax, 'XLim', PVP.XLim)
end

if ~isempty(PVP.YLim)
    set(ax, 'YLim', PVP.YLim)
end

switch nargout
    case 0
    case 1
        varargout{1} = h;
    otherwise
        error('too many outputs')
end

%%%%%%%%
function hndl = drawcircles(x, y, r, pvp)
% Circle at (x,y) with radius r and color c

th = (0:pi/50:2*pi)';
R = length(th);
C = numel(x);

PVP = mascara(C, pvp);

% make C patch objects, one per column
xunit = kron(cos(th), ones(1, C)).*kron(ones(R, 1), r') + kron(ones(R, 1), x');
yunit = kron(sin(th), ones(1, C)).*kron(ones(R, 1), r') + kron(ones(R, 1), y');

cmp = zeros(1, C, 3);
for c = 1:C
    cmp(1, c, 1:3) = PVP.MAP(c, :);
end

% We are drawing two sets of objects - patches without edges and lines
% lines express 'LineStyle', 'LineWidth', etc.
hndl.p = patch(xunit, yunit, cmp, ...
    'FaceAlpha', PVP.FaceAlpha, ...
    'EdgeAlpha', 0);

hndl.l = line(xunit, yunit);
TMP3 = num2cell(PVP.LineWidth);
[hndl.l.LineWidth_I] = deal(TMP3{:});

for c = 1:C
    hndl.l(c).LineStyle = PVP.ls0{PVP.LineStyle(c)};
    hndl.l(c).Color = PVP.MAP(c, :);
end
