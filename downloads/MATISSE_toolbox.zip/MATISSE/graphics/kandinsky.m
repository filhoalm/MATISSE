function [EF, F] = kandinsky(Q)
% KANDINSKY Plot summary curves and estimable functions for apc or sage objects.
%
% KANDINSKY(Q)
% [EF, F] = KANDINSKY(Q)
%
% Q is an apc or sage object.
%
% see also florence.

switch class(Q)
    case 'sage'
        R = Q.R;

        EF = plot(Q, 'Plot', 0);

        F1 = line(Q, 'mpc', go('Plot', 0));
        F2 = line(Q, 'mac', go('Plot', 0));
        F3 = line(Q, 'mcc', go('Plot', 0));
        F4 = line(Q, 'dac', go('Plot', 0));
        F5 = line(Q, 'lpa', go('Plot', 0));
        F6 = line(Q, 'lap', go('Plot', 0));

    case 'apc'
        R = Q.R;

        EF = plot(Q, 'Plot', 0);

        F1 = line(R, 'mpc', go('Plot', 0));
        F2 = line(R, 'mac', go('Plot', 0));
        F3 = line(R, 'mcc', go('Plot', 0));
        F4 = line(R, 'dac', go('Plot', 0));
        F5 = line(R, 'lpa', go('Plot', 0));
        F6 = line(R, 'lap', go('Plot', 0));

    otherwise
        error('Unsupported class')

end

F = {F1, F2, F3, F4, F5, F6};

%%%
% the plot
%%%


figure('Position', [150 250 1200 700])

warning off

pvp1 = go('Width', 1, ...
          'Grid', 1, ...
          'Marker', 16, ...
          'LineWidth', [2 3], ...
          'LineStyle', [1 3], ...
          'FaceAlpha', 0.100, ...
          'EdgeAlpha', 0, ...
          'labels', [1 1 0], ...
          'Legend', 1, ...
          'FontSize', [8 8 10]);

subplot(2, 3, 1)
pvp1.Legend = 1;
pvp1.LineColor = [1 1];

% horrible pattern to get through the mess of label ambiguity
TMP1 = [EF.ftt, F1.mpc];
TMP2 = TMP1.data;
TMP2.col_labels = {'FTT', 'mpc'};
TMP2.labels = {' ', ' '};
TMP1.data = TMP2;
% end of pattern

plot(TMP1, pvp1)
TMP = unique(log(max(1, unique(round(exp(get(gca, 'YTick')))))));
set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))
title('\bf{A}', 'FontSize', pvp1.FontSize(3))
xlabel('Period')
ylabel('log Rate')

pvp1.LineColor = [7 7];
subplot(2, 3, 5)

% horrible pattern to get through the mess of label ambiguity
TMP1 = [EF.cac, F2.mac];
TMP2 = TMP1.data;
TMP2.col_labels = {'CAC', 'mac'};
TMP2.labels = {' ', ' '};
TMP1.data = TMP2;
% end of pattern

plot(TMP1, pvp1)
TMP = unique(log(max(1, unique(round(exp(get(gca, 'YTick')))))));
set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))
title('\bf{E}', 'FontSize', pvp1.FontSize(3))
xlabel('Age')
ylabel('log Rate')

subplot(2, 3, 2)
pvp1.LineColor = [10 10];

% horrible pattern to get through the mess of label ambiguity
TMP1 = [EF.fcp, F3.mcc];
TMP2 = TMP1.data;
TMP2.col_labels = {'FCP', 'mcc'};
TMP2.labels = {' ', ' '};
TMP1.data = TMP2;
% end of pattern

plot(TMP1, pvp1)
TMP = unique(log(max(1, unique(round(exp(get(gca, 'YTick')))))));
set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))
title('\bf{B}', 'FontSize', pvp1.FontSize(3))
xlabel('Cohort')
ylabel('log Rate')
c = type(R, 'comp', 'c');
XL = [c.data(1) - 5, c.data(end) + 5];
set(gca, 'XLim', XL)

text(0.5, 1.15, R.chromacode, ...
    'Units', 'normalized', ...
    'FontSize', pvp1.FontSize(3), ...
    'HorizontalAlignment', 'center', ...
    'Interpreter', 'tex')

ax4 = subplot(2, 3, 3);
pvp1.LineColor = [12 12];

% horrible pattern to get through the mess of label ambiguity
TMP1 = [EF.ld, F5.lpa];
TMP2 = TMP1.data;
TMP2.col_labels = {'LD', '\it{l}\rm^{p|a}'};
TMP2.labels = {' ', ' '};
TMP1.data = TMP2;
% end of pattern

plot(pc(TMP1), pvp1)
title('\bf{C}', 'FontSize', pvp1.FontSize(3))
xlabel('Age')
ylabel('% \Delta per Year')
ax4.YAxis.TickLabelFormat = '%g\%';

ax5 = subplot(2, 3, 6);
pvp1.LineColor = [23 23];

% horrible pattern to get through the mess of label ambiguity
TMP1 = [EF.gs, F6.lap];
TMP2 = TMP1.data;
TMP2.col_labels = {'GS', '\it{l}\rm^{a|p}'};
TMP2.labels = {' ', ' '};
TMP1.data = TMP2;
% end of pattern

plot(pc(TMP1), pvp1)
title('\bf{F}', 'FontSize', 14)
xlabel('Period')
ylabel('% \Delta per Year')
ax5.YAxis.TickLabelFormat = '%g\%';

subplot(2, 3, 4)
pvp1.LineColor = [9 9];

% horrible pattern to get through the mess of label ambiguity
TMP1 = [EF.lac, F4.dac];
TMP2 = TMP1.data;
TMP2.col_labels = {'LAC', 'dac'};
TMP2.labels = {' ', ' '};
TMP1.data = TMP2;
% end of pattern

plot(TMP1 , pvp1)
TMP = unique(log(max(1, unique(round(exp(get(gca, 'YTick')))))));
set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))
title('\bf{D}', 'FontSize', pvp1.FontSize(3))
xlabel('Age')
ylabel('log Rate')

H = findobj(gcf, 'Type', 'Legend');
set(H, 'Location', 'best')

warning on

end