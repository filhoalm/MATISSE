function varargout = thumbnail(CELL, varargin)
% THUMBNAIL Array of heat maps.
%
% THUMBNAIL(CELL, go(...))
% T = thumbnail(...)
%
% CELL is an RxC cell array of double, tbl, matrix, or rates objects all
% the same size:
%
%      { T11, T12, ..., T1C; ...
%        T21, T22, ..., T2C; ...
%         :    :    :    :
%        TR1  TR2, ..., TRC }
%
% THUMBNAIL produces a combined tbl and an array of pcolor plots providing
% a comprehensive overview.
%
% A THUMBNAIL plot has 2 components controlled by go values:
%
% * A thumbnail array of heat maps
%
% * A colorbar
%
% THUMBNAIL outputs a combined tbl of heat map values and labels in T.IMG
% and T.Labels, respectively.
%
% See also circlet.

N = numel(varargin);
switch N
    case 0
        PVP = ego('class', 'graphics', 'method', 'thumbnail');
    otherwise
        PVP = varargin{1};
end

DATA = process_thumb_data(CELL, PVP, 'thumbnail');

T = assemble_thumb_data(DATA, PVP);

% are we drawing the plot?
if ~PVP.Plot
    switch nargout
        case 1
            varargout{1} = T;
        otherwise
    end

    return

end

% NOTE: 'YDir' was already applied at the cell level
PVP.YDir = 'normal';

pcolor(tbl('data', T.IMG), PVP)

% remove meaningless x- and y-axis tick labels
set(gca, 'XTick', [], 'YTick', [], 'Color', PVP.clarinet(PVP.AxisColor, :))

if PVP.labels(1)

    TMP = T.Labels.Text(end:-1:1, :);
    zLoc = zeros(1, numel(TMP));
    text(T.Labels.cLoc(:), T.Labels.rLoc(:), zLoc, TMP(:), ...
        'FontSize', PVP.FontSize(1), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle', ...
        'BackgroundColor', 'none', ...
        'EdgeColor', 'none', ...
        'Rotation', 0)

end

switch nargout
    case 1
        varargout{1} = T;
    otherwise
end

end

