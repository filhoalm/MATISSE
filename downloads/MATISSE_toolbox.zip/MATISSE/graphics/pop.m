function pop(T, varargin)
% POP Stem plot of P-values.
%
% POP(T)
% POP(T, go(...))
%
% T is a tbl object with the following data:
%
%      column 1 - test statistic 
%      column 2 - df
%      column 3 - P-values
%
% * POP resets axis view so the x-axis is vertical and the
%   y-axis is horizontal

if eq(nargin, 1)
    PVP = ego('class', 'graphics', 'method', 'pop');
else
    PVP = varargin{1};
    if ge(numel(PVP.LineColor), 2)
        PVP.LineColor = PVP.LineColor(1:2);
    else
        PVP.LineColor = PVP.LineColor([1 1]);
    end
end

MAP = clarinet(54);

R = size(T, 1);

x = 1:1:R;
y = -log10(T.data(:, 3) + eps);
stem(gca, x, y, ...
    'LineStyle', PVP.ls0{PVP.LineStyle(1)}, ...
    'LineWidth', PVP.LineWidth(1), ...
    'Color', MAP(PVP.LineColor(1), :), ...
    'Marker', PVP.mk0{PVP.Marker(1)}, ...
    'MarkerFaceColor', MAP(PVP.LineColor(2), :), ...
    'MarkerEdgeColor', MAP(PVP.LineColor(1), :), ...
    'MarkerSize', PVP.MarkerSize(1));

set(gca, 'XTick', 1:1:R, 'XLim', [0 R+1], ...
    'XTickLabel', T.row_labels, 'XTickLabelRotation', -0, ...
    'TickDir', 'out', 'FontSize', PVP.FontSize(1))
ylabel('-log_{10}(P-Value)', 'FontSize', PVP.FontSize(2))
rline(-log10(0.05), 0, go('Linestyle', 3, 'LineColor', 52))
xp = [0 0 R+1.5 R+1.5];
patch(xp, [0.01 -log10(0.05) -log10(0.05) 0.01], MAP(54, :), ...
    'FaceAlpha', PVP.FaceAlpha, 'EdgeColor', MAP(54, :));

UL = round(max(y))+1;
if UL < 2
    UL = 2;
end
set(gca, 'YLim', [0 UL], 'Box', 'off')
grid
title(T.fullname, 'FontSize', PVP.FontSize(3), ...
    'Interpreter', 'tex', 'FontWeight', 'normal')
text(R+0.75, -log10(0.055), 'Accept \it{H_0}', ...
    'HorizontalAlignment', 'right', 'Color', MAP(53, :), ...
    'FontSize', PVP.FontSize(1))
text(R+0.75, -log10(0.045), 'Reject \it{H_0}', ...
    'HorizontalAlignment', 'left', 'FontWeight', 'bold', ...
    'FontSize', PVP.FontSize(2))

%%%
% this line of code has a lot of side effects!
%%%
view(90, -90)

set(gca, ...
    'PlotBoxAspectRatio', [1/PVP.Width 1 1], ...
    'XDir', PVP.YDir)

end