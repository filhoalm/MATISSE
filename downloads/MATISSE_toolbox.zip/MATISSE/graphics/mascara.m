function S = mascara(K, PVP)
% MASCARA CoMpute mAny SpecifiCAtions fRom go vAlues.
%
% S = MASCARA(K, PVP)
%
% Property-values sufficient for K curves are obtained by cycling through
% the go values in PVP
%
% Properties affected:
%
% 'CI', 'LineWidth', 'LineStyle', 'LineColor', 'Marker', 'MarkerSize'
%
% See also go.

% impute specific property-values for K curves by cycling through the given
% go values

ci = PVP.CI;
lw = PVP.LineWidth;
ls = PVP.LineStyle;
lc = PVP.LineColor;
mk = PVP.Marker;
ms = PVP.MarkerSize;

if eq(K, 1) 

    CI = ci(1);
    LW = lw(1);
    LC = lc(1);
    LS = ls(1);
    MK = mk(1);
    MS = ms(1);

else

    % CI
    nc = numel(ci);
    if eq(nc, 1)
        CI = ci * ones(1, K);
    elseif eq(nc, K)
        CI = ci;
    elseif gt(nc, K)
        CI = ci(1:K);
    else
        % 1 < nc < K
        % CYCLE: repeat ci in blocks of size nc until you have a total of K values
        c = floor(K/nc);
        d = rem(K, nc);
        CI = ci([kron(ones(1, c), 1:nc), 1:d]);
    end

    % LW
    nw = numel(lw);
    if eq(nw, 1)
        LW = lw * ones(1, K);
    elseif eq(nw, K)
        LW = lw;
    elseif gt(nw, K)
        LW = lw(1:K);
    else
        % 1 < nw < K
        % CYCLE: repeat lw in blocks of size nw until you have a total of K values
        c = floor(K/nw);
        d = rem(K, nw);
        LW = lw([kron(ones(1, c), 1:nw), 1:d]);
    end

    % LC
    nc = numel(lc);
    if eq(nc, 1)
        LC = lc * ones(1, K);
    elseif eq(nc, K)
        LC = lc;
    elseif gt(nc, K)
        LC = lc(1:K);
    else
        % 1 < nc < K
        % CYCLE: repeat lc in blocks of size nc until you have a total of K values
        c = floor(K/nc);
        d = rem(K, nc);
        LC = lc([kron(ones(1, c), 1:nc), 1:d]);
    end

    % LS
    ns = numel(ls);
    if eq(ns, 1)
        LS = ls(ones(1, K));
    elseif eq(ns, K)
        LS = ls(1:K);
    elseif gt(ns, K)
        LS = ls(1:K);
    else
        % 1 < ns < K
        % CYCLE: repeat ls in blocks of size ns until you have a total of K values
        c = floor(K/ns);
        d = rem(K, ns);
        LS = ls([kron(ones(1, c), 1:ns), 1:d]);
    end

    % MK
    nk = numel(mk);
    if eq(nk, 1)
        MK = mk(ones(1, K));
    elseif eq(nk, K)
        MK = mk;
    elseif gt(nk, K)
        MK = mk(1:K);
    else
        % 1 < nk < K
        % CYCLE: repeat mk in blocks of size nk until you have a total of K values
        c = floor(K/nk);
        d = rem(K, nk);
        MK = mk([kron(ones(1, c), 1:nk), 1:d]);
    end

    % MS
    nm = numel(ms);
    if eq(nm, 1)
        MS = ms * ones(1, K);
    elseif eq(nm, K)
        MS = ms;
    elseif gt(nm, K)
        MS = ms(1:K);
    else
        % 1 < nm < K
        % CYCLE: repeat ms in blocks of size nm until you have a total of K values
        c = floor(K/nm);
        d = rem(K, nm);
        MS = ms([kron(ones(1, c), 1:nm), 1:d]);
    end

end

S = PVP;
S.CI = CI;
S.LineWidth = LW;
S.LineStyle = LS;
S.LineColor = LC;
S.Marker = MK;
S.MarkerSize = MS;

% extract K rgb triples, one for each curve
baseMAP = clarinet('StartColor', 1, 'NColors', 54, 'N', 54);
S.MAP = baseMAP(S.LineColor, :);

% tune the EdgeColorMAP
MarkerEdgeColorMAP = zeros(K, 3);

for c = 1:K
    switch S.LineColor(c)
        case {1, 2, 10, 19, 28, 29}
            MarkerEdgeColorMAP(c, :) = [1 0.961 0.933]; % Sea Shell
        case {3, 23, 35, 38, 39}
            MarkerEdgeColorMAP(c, :) = [0.25 0.25 0.25];
        case 5
            MarkerEdgeColorMAP(c, :) = [0 0.25 0];
        case 6
            MarkerEdgeColorMAP(c, :) = [0 0 0.25];
        case 9
            MarkerEdgeColorMAP(c, :) = [0.9 0.9 0.9];
        case 12
            MarkerEdgeColorMAP(c, :) = [1 1 1];
        case {13, 15, 16, 51, 52, 53}
            MarkerEdgeColorMAP(c, :) = [0 0 0];
        case {14, 17}
            MarkerEdgeColorMAP(c, :) = [0.2 0.2 0.2];
        case {24, 36, 54}
            MarkerEdgeColorMAP(c, :) = [0.3333 0.4196 0.1843]; % dark olive green
        otherwise
            MarkerEdgeColorMAP(c, :) = [1 1 1];
    end

    S.MarkerEdgeColorMAP = MarkerEdgeColorMAP;

end



