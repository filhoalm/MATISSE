function F = paragon(Q, curve, PVP)
% PARAGON Plot summARy curve And Gradient Of a staNdard plot.
%
% F = PARAGON(Q, curve, PVP)
%
% Q     - sage object or rates object
% curve - 'mpc', 'mac', 'mcc', 'dac', 'lpa', or 'lap'
% PVP   - go values
%
% See also sage/line, rates/line.

%%%
% openers
%%%
if isempty(Q)
    error('no data to plot')
end

%%%
% data matrix - default to the transposed data
%%%
switch class(Q)
    case 'rates'
        M0 = matrix('data', type(Q, 'comp', 'lr'), ...
            'COV', type(Q, 'comp', 'lv'), ...
            'y', Q.a, 'x', Q.p)';
        R0 = Q;

        MarkerSize = 6;
        fs = [8 8 10];

    case 'sage'
        M0 = Q.S.F.TMA';
        R0 = Q.R;
        % scale from rates per 1 PY up to rates per offset_tick PY
        lot = log(R0.offset_tick);
        M0.data = lot + M0.data;

        MarkerSize = 6;
        fs = [8 8 10];

    otherwise
        error('input must be a sage object or a rates object')

end

%%%
% Choice of Marker based on DELTA
%%%
DELTA = R0.a(2) - R0.a(1);
switch DELTA
    case 1
        Marker = 16;
    case 2
        Marker = 1;
    otherwise
        Marker = 1;
end

if ~(ischar(curve) && ismember(curve, ...
        {'mpc', 'mac', 'dac', 'mcc', 'lpa', 'lap'}))
    error('invalid curve')
end

%%%
% feature extraction
%%%

switch curve
    case 'mpc'
        if isempty(PVP)

            PVP1 = go('Width', 1, ...
                'Grid', 1, ...
                'Marker', Marker, ...
                'MarkerSize', MarkerSize, ...
                'LineWidth', 2, ...
                'LineColor', 1, ...
                'FaceAlpha', 0.100, ...
                'EdgeAlpha', 0, ...
                'labels', [1 1 0], ...
                'legend', 0, ...
                'FontSize', fs);

        else
            PVP1 = PVP;
        end

        % preset go values for the secondary plot of dmpc
        PVP2 = go('Width', PVP1.Width, 'Trim', PVP1.Trim, 'LineWidth', 1.5, ...
            'Grid', 1, 'FaceAlpha', 0.10, 'EdgeAlpha', 0, ...
            'LineColor', 12, 'Grid', 1, ...
            'Legend', 0, 'labels', [0 1 0], 'Marker', 16, ...
            'FontSize', PVP1.FontSize);
        if ~isempty(PVP1.XLim)
            PVP2.XLim = PVP1.XLim;
        end

        mpc = blast(M0, 'rB', 1, 'cB', size(M0.data, 2));
        mpc.y = M0.y;
        fDAT = mpc.data;
        fcl = 'mpc';
        fDAT.col_labels = {fcl};
        fDAT.labels = {'period', 'mpc'};
        fDAT.fullname = 'mpc';
        mpc.data = fDAT;
        F.mpc = mpc;

        dmpc = diff(F.mpc);
        gDAT = dmpc.data;
        gcl = 'dmpc';
        gDAT.row_labels = M0.data.row_labels(2:end);
        gDAT.col_labels = {gcl};
        gDAT.labels = {'period', 'dmpc'};
        gDAT.fullname = 'Gradient of Marginal Period Curve';
        dmpc.data = gDAT;
        F.dmpc = dmpc;

        if PVP1.Plot
            plot(F.mpc, PVP1)
            % Here and below: autoscaling may leave too much white space
            p = type(R0, 'comp', 'p');
            XL = [p.data(1) - 2.5, p.data(end) + 2.5];
            set(gca, 'XLim', XL, 'PlotBoxAspectRatio', [PVP1.Width 1 1])
            % Here and below: y-axis scale is log but we prefer
            % absolute-value labels
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

            yyaxis right          
            ax = gca;
            set(ax, 'YColor', [0 0 0], 'FontSize', PVP1.FontSize(2))
            ax.YAxis(2).TickLabelFormat = '%g\%';
  
            plot(pc(F.dmpc), PVP2)
            
            if PVP2.labels(2)
                ylabel('% \Delta per Year', 'Rotation', -90)
            end
            rline(0, 0, ...
                go('LineColor', 54, 'LineStyle', 3, 'LineWidth', 2, ...
                'FontSize', fs))
            yyaxis left
        end

    case 'mac'
        if isempty(PVP)
            PVP1 = go('Width', 1, 'Trim', 0, 'LineWidth', 2, 'Grid', 1, ...
                'FaceAlpha', 0.10, 'EdgeAlpha', 0, ...
                'LineColor', 7, 'Grid', 1, 'Legend', 0, ...
                'Legend', 0, 'labels', [1 1 0], 'FontSize', fs, ...
                'Marker', Marker, 'MarkerSize', MarkerSize);
        else
            PVP1 = PVP;
        end

        % preset go values for the secondary plot of dmac
        PVP2 = go('Width', PVP1.Width, 'Trim', PVP1.Trim, 'LineWidth', 1, ...
            'Grid', 1, 'FaceAlpha', 0.10, 'EdgeAlpha', 0, ...
            'LineColor', 12, 'Grid', 1, ...
            'Legend', 0, 'labels', [0 1 0], 'Marker', 16, ...
            'FontSize', PVP1.FontSize);
        if ~isempty(PVP1.XLim)
            PVP2.XLim = PVP1.XLim;
        end

        mac = blast(M0, 'rB', size(M0.data, 1), 'cB', 1)';
        mac.y = M0.x;
        fDAT = mac.data;
        fcl = 'mac';
        fDAT.col_labels = {fcl};
        fDAT.labels = {'age', 'mac'};
        fDAT.fullname = 'mac';
        mac.data = fDAT;
        F.mac = mac;

        dmac = diff(F.mac);
        gDAT = dmac.data;
        gcl = 'dmac';
        gDAT.row_labels = M0.data.col_labels(2:end);
        gDAT.col_labels = {gcl};
        gDAT.labels = {'age', 'dmac'};
        gDAT.fullname = M0.data.fullname;
        dmac.data = gDAT;
        F.dmac = dmac;

        if PVP1.Plot
            plot(F.mac, PVP1)
            a = type(R0, 'comp', 'a');
            XL = [a.data(1) - 2.5, a.data(end) + 2.5];
            set(gca, 'XLim', XL, 'PlotBoxAspectRatio', [PVP1.Width 1 1])
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

            yyaxis right
            ax = gca;
            set(ax, 'YColor', [0 0 0], 'FontSize', PVP1.FontSize(2))
            ax.YAxis(2).TickLabelFormat = '%g\%';
            plot(pc(F.dmac), PVP2)
            if PVP1.labels(2)
                ylabel('% \Delta per Year', 'Rotation', -90)
            end

            rline(0, 0, go('LineColor', 54, 'LineStyle', 3, 'LineWidth', 2, ...
                'FontSize', PVP2.FontSize))
            yyaxis left

        end

    case 'mcc'
        M0 = M0';
        if isempty(PVP)
            PVP1 = go('Width', 1, 'LineWidth', 2, 'Grid', 1, ...
                'FaceAlpha', 0.10, 'EdgeAlpha', 0, ...
                'LineColor', 10, 'Grid', 1, 'Legend', 0, ...
                'Legend', 0, 'labels', [1 1 0], 'FontSize', fs, ...
                'Marker', Marker, 'MarkerSize', MarkerSize);
        else
            PVP1 = PVP;
        end

        % preset go values for the secondary plot of dmcc
        PVP2 = go('Width', PVP1.Width, 'Trim', PVP1.Trim, 'LineWidth', 1.5, ...
            'FaceAlpha', 0.10, 'EdgeAlpha', 0, 'Grid', 1, ...
            'LineColor', 12, 'Grid', 1, ...
            'Legend', 0, 'labels', [0 1 0], 'Marker', 16, ...
            'FontSize', PVP1.FontSize);
        if ~isempty(PVP1.XLim)
            PVP2.XLim = PVP1.XLim;
        end

        c = type(R0, 'comp', 'c');
        [A, P] = size(R0);
        DELTA = M0.x(2) - M0.x(1);
        d1 = scale(diff(M0')', DELTA);
        d2 = diagonals(d1);
        d2.x = c.data(2:end);
        % sum of all defined values
        d2s = block(d2, 'rB', A, 'cB', 1)';
        % number of defined values
        W = sum(~isnan(d2.data.data))';
        d3 = scale(d2s, 1./(DELTA*W));
        DAT = d3.data;
        DAT.fullname = 'dmcc';
        DAT.row_labels = c.row_labels(2:end);
        d3.data = DAT;
        d3.y = c.data(2:end);
        d4 = pad(d3, 'rows', 1, 'rpos', 'bottom');
        d5 = scale(cumsum(d4), DELTA);
        rLoc = [floor(A/2), floor(P/2)];
        cLoc = rLoc(2) - rLoc(1) + A;
        % M0 has been transposed
        rVal = M0.data.data(rLoc(1), rLoc(2));

        fDAT = d5.data;
        fDAT = fDAT - fDAT(cLoc, 1);
        fDAT = fDAT + rVal;
        fcl = ['mcc (' num2str(R0.a(rLoc(1))) ')'];
        fDAT.col_labels = {fcl};
        fDAT.labels = {'cohort', 'mcc'};
        fDAT.fullname = 'Marginal Cohort Curve';
        d5.data = fDAT;
        F.mcc = d5;

        gDAT = d3.data;
        gcl = 'dmcc';
        gDAT.col_labels = {gcl};
        gDAT.labels = {'cohort', 'dmcc'};
        gDAT.fullname = 'Gradient of Marginal Cohort Curve';
        d3.data = gDAT;
        F.dmcc = d3;

        if PVP1.Plot
            plot(F.mcc, PVP1)
            ylabel(fcl, 'FontSize', PVP1.FontSize(2))
            xlabel('Cohort', 'FontSize', PVP1.FontSize(1))
            XL = [c.data(1) - 5, c.data(end) + 5];
            set(gca, 'XLim', XL, 'PlotBoxAspectRatio', [PVP1.Width 1 1])
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

            yyaxis right
            ax = gca;
            set(ax, 'YColor', [0 0 0], 'FontSize', PVP2.FontSize(2))
            ax.YAxis(2).TickLabelFormat = '%g\%';
            plot(pc(F.dmcc), PVP2)
            
            if PVP1.labels(2)
                ylabel('% \Delta per Year', 'Rotation', -90)
            end
            rline(0, 0, go('LineColor', 54, ...
                'LineStyle', 3, 'LineWidth', 2, 'FontSize', PVP2.FontSize))
            yyaxis left

        end

    case 'dac'
        if isempty(PVP)
            PVP1 = go('Width', 1, 'Trim', 0, 'LineWidth', 2, 'Grid', 1, ...
                'LineColor', 9, 'Grid', 1, 'Legend', 0, ...
                'FaceAlpha', 0.10, 'EdgeAlpha', 0, ...
                'Legend', 0, 'labels', [1 1 0], 'FontSize', fs, ...
                'Marker', Marker, 'MarkerSize', MarkerSize);
        else
            PVP1 = PVP;
        end

        % preset go values for the secondary plot of dmac
        PVP2 = go('Width', PVP1.Width, 'Trim', PVP1.Trim, 'LineWidth', 1.5, ...
            'FaceAlpha', 0.10, 'EdgeAlpha', 0, 'Grid', 1, ...
            'LineColor', 12, 'Grid', 1, ...
            'Legend', 0, 'labels', [0 1 0], 'Marker', 16, ...
            'FontSize', PVP1.FontSize);
        if ~isempty(PVP1.XLim)
            PVP2.XLim = PVP1.XLim;
        end

        [A, P] = size(R0);

        a = type(R0, 'comp', 'a');
        c = type(R0, 'comp', 'c');
        SW = swag(M0);
        % Row averaging returns one row, turn that into one column
        B = blast(SW, 'rB', P-1, 'cB', 1)';
        B.y = a.data(2:A);
        s = pad(B, 'rows', 1, 'rpos', 'bottom');
        s.y = a.data;
        DELTA = s.y(2) - s.y(1);
        I = scale(cumsum(s), DELTA);
        % reference cell at the center
        rLoc = [floor(A/2), floor(P/2)];
        cLoc = rLoc(2) - rLoc(1) + A;
        cVal = c.data(cLoc);
        % M0 has not been transposed
        rVal = M0.data.data(rLoc(2), rLoc(1));

        DAT = I.data.data;
        DAT = DAT - DAT(rLoc(1), 1);
        DAT = DAT + rVal;
        cl1 = ['dac (' num2str(cVal) ')'];
        T_DAT = tbl('data', DAT, ...
            'row_labels', a.row_labels, ...
            'col_labels', {cl1}, ...
            'fullname', 'Diagonal Age Curve', ...
            'labels', {'age', 'dac'});
        I.data = T_DAT;
        I.y = a.data;
        F.dac = I;

        gDAT = B.data;
        gcl = 'ddac';
        gDAT.row_labels = M0.data.col_labels(2:end);
        gDAT.col_labels = {gcl};
        gDAT.labels = {'age', 'ddac'};
        gDAT.fullname = M0.data.fullname;
        B.data = gDAT;
        F.ddac = B;

        if PVP1.Plot
            plot(F.dac , PVP1)
            XL = [a.data(1) - 2.5, a.data(end) + 2.5];
            set(gca, 'XLim', XL, 'PlotBoxAspectRatio', [PVP1.Width 1 1])
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

            yyaxis right
            ax = gca;
            
            set(ax, 'YColor', [0 0 0], 'FontSize', PVP2.FontSize(2))
            ax.YAxis(2).TickLabelFormat = '%g\%';
            plot(pc(F.ddac), PVP2)
            
            if PVP1.labels(2)
                ylabel('% \Delta per Year', 'Rotation', -90)
            end
            rline(0, 0, go('LineColor', 54, ...
                'LineStyle', 3, 'LineWidth', 2, 'FontSize', PVP2.FontSize))
            yyaxis left
            
        end

    case 'lpa'
        if isempty(PVP)
            PVP1 = go('Width', 1, 'LineWidth', 2, 'Grid', 1, ...
                'FaceAlpha', 0.10, 'EdgeAlpha', 0, ...
                'LineColor', 12, 'Grid', 1, 'Legend', 0, ...
                'Legend', 0, 'labels', [1 1 0], 'FontSize', fs, ...
                'Marker', Marker, 'MarkerSize', MarkerSize);
        else
            PVP1 = PVP;
        end

        F = cell2struct(struct2cell(slopes(M0)), {'lpa', 'dlpa'});

        if PVP1.Plot
            plot(pc(F.lpa), PVP1)
            a = type(R0, 'comp', 'a');
            XL = [a.data(1) - 2.5, a.data(end) + 2.5];
            set(gca, 'XLim', XL, 'PlotBoxAspectRatio', [PVP1.Width 1 1])

            rline(0, 0, go('LineColor', 54, 'LineStyle', 3, 'LineWidth', 2))
            ax = gca;
            ax.YAxis(1).Label.String = 'Period Slopes by Age';
            ax.YAxis(1).TickLabelFormat = '%g\%';
        end

    case 'lap'

        if isempty(PVP)
            PVP1 = go('Width', 1, 'LineWidth', 2, 'Grid', 1, ...
                'FaceAlpha', 0.10, 'EdgeAlpha', 0, ...
                'LineColor', 23, 'Grid', 1, 'Legend', 0, ...
                'Legend', 0, 'labels', [1 1 0], 'FontSize', fs, ...
                'Marker', Marker, 'MarkerSize', MarkerSize);
        else
            PVP1 = PVP;
        end

        F = cell2struct(struct2cell(slopes(M0')), {'lap', 'dlap'});

        if PVP1.Plot
            plot(pc(F.lap), PVP1)
            p = type(R0, 'comp', 'p');
            XL = [p.data(1) - 2.5, p.data(end) + 2.5];
            set(gca, 'XLim', XL, 'PlotBoxAspectRatio', [PVP1.Width 1 1])

            rline(0, 0, go('LineColor', 54, 'LineStyle', 3, 'LineWidth', 2, 'FontSize', fs))
            ax = gca;
            ax.YAxis(1).TickLabelFormat = '%g\%';
            ax.YAxis(1).Label.String = 'Age Slopes by Period';

        end

    otherwise
        error('unsupported graph type')
end


end

