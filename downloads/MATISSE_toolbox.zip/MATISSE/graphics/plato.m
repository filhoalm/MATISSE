function varargout = plato(varargin)
% PLATO - Plot hAzard funcTion estimatOrs.
%
% PLATO(H)
% [f, S] = PLATO(H, go(...))
%
% H is the output of the hsp function for survival or comprisk objects.
%
% For survival objects:
%
%  *  smoothed survival curve and km estimator (top)
%  *  B-spline estimator of the hazard function (bottom)
%
% For comprisk objects:
%
%  *  mdl estimator of cumulative incidence by cause (top)
%  *  B-spline estimators of cause-specific hazard functions (bottom)
%
%  *  Outputs formatted for pcurves function:
%        f - hazard functions
%        S - survivorship or cumulative incidence
%
% see also survival\hsp, comprisk\hsp, pcurves.

PVP = options(varargin{:});
F = varargin{1};

switch PVP.parent

    case 'survival/hsp'

        figure('Position', [100 200 500 750])

        subplot(2, 1, 1)
        pcurve(F.H.S, PVP)
        hold on
        pvp1 = PVP;
        pvp1.labels = [0 0 0];
        pvp1.CI = 0;
        S = km(F.H.data, pvp1);
        XL = get(gca, 'Xlim');

        subplot(2, 1, 2)
        pvp2 = PVP;
        pvp2.labels = [PVP.labels(1:2), 0];
        pvp2.XLim = XL;
        f = F.H.h;
        pcurve(f, pvp2);

    case 'comprisk/hsp'

        % extract the cause-specific hazard functions

        K = length(F);
        f = cell(1, K);
        for i = 1:K
            f{i} = F{i}.H.h;
        end

        % reconstruct the original comprisk variable from the derived
        % survival functions. This seems awkwards, but works for now.

        N = size(F{1}.B.S, 1);
        TIME = zeros(N, K);
        STAT = zeros(N, 1 + K);
        lbls = cell(1, 1 + K);

        for i = 1:K

            TIME(:, i) = F{i}.B.S.time;
            STAT(:, 1 + i) = F{i}.B.S.status;
            lbls{1, 1 + i} = F{i}.B.S.fullname;

        end

        lbls{1} = 'AE-Free';
        [~, TMP1] = max(STAT, [], 2);
        [TMP2, ~] = max(TIME, [], 2);

        Q = comprisk(...
            'status', TMP1 - 1, ...
            'time', TMP2, ...
            'values', 0:K, ...
            'labels', lbls, ...
            'time_units', F{1}.B.S.time_units);

        figure('Position', [100 200 500 750])

        subplot(2, 1, 1)
        S = mdl(Q, PVP);
        XL = get(gca, 'Xlim');

        subplot(2, 1, 2)
        pvp2 = PVP;
        pvp2.Legend = 0;
        pvp2.XLim = XL;
        pcurves(f{:}, pvp2)
        ylabel('Cause-Specific Hazards', 'FontSize', pvp2.FontSize(2))

end

switch nargout
    case 0
    case 1
        varargout{1} = f;
    case 2
        varargout{1} = f;
        varargout{2} = S;
    otherwise
        error('too many outputs')
end


end

function PVP = options(varargin)
% Helper function.

Q = numel(varargin);

switch Q
    case 1
        H = varargin{1};
        pvp = [];
    case 2
        H = varargin{1};
        pvp = varargin{2};
    otherwise
        error('too many inputs')
end

switch class(H)
    case 'struct'
        K = 1;
        TMP = isfield(H, 'parent');
        if TMP
            ok = strcmp(H.parent, 'survival/hsp');
        end
        if ok
            parent = 'survival/hsp';
        else
            error('invalid input')
        end

        if isempty(pvp)
            pvp = ego('class', 'survival', 'method', 'plato');
        end


    case 'cell'
        K = length(H);
        ok = zeros(1, K);

        for i = 1:K
            TMP = isfield(H{i}, 'parent');
            if TMP
                ok(i) = strcmp(H{i}.parent, 'comprisk/hsp');
            end
        end

        if all(ok)
            parent = 'comprisk/hsp';
        else
            error('invalid input')
        end

        if isempty(pvp)
            pvp = ego('class', 'comprisk', 'method', 'plato');
        end

    otherwise
        error('wrong class of input')
end


PVP = mascara(K, pvp);
PVP.parent = parent;



end
