function bentobox(T, D1, D2, GraphNumber, rows, varargin)
% BENTOBOX - Visualizations of matrices with structured columns.
%
% BENTOBOX(T, D1, D2, GraphNumber, rows, go(...))
%
% T is a double, tbl or matrix with R rows and C columns where
% C = D1 x D2.
%
% the selected rows of T are visualized as D1 x D2 arrays.
%
% GraphNumber:
%
% 1 - thumbnail 
% 2 - vistagram 
% 3 - skyline
%
% Each graph will have r0 rows and c0 columns based on N = numel(rows):
%
%    r0 - largest divisor of N from 1 through 10
%    c0 - N/r0
%
% See also thumbnail, vistagram, skyline, depth.

opts = options(T, D1, D2, GraphNumber, rows, varargin{:});

BMAT = preprocess(T, opts);

switch opts.GraphNumber
   
    case 1
        thumbnail(BMAT, opts.PVP)

    case 2
        vistagram(BMAT, opts.PVP)      

    case 3
        skyline(BMAT, opts.PVP)  

    otherwise

end

end

function opts = options(T, D1, D2, GraphNumber, rows, varargin)
% validate inputs

opts = struct('D1', [], 'D2', [], 'rows', [], 'r0', [], 'c0', [], ...
    'GraphNumber', [], 'PVP', [], 'YDir', 'normal');

% validate D1 and D2
[R, C] = size(T);
if D1*D2 ~= C
    error('invalid values for D1 and D2')
end

opts.D1 = D1;
opts.D2 = D2;

% validate GraphNumber
if ~ismember(GraphNumber(1), 1:3)
    error('invalid graph number')
else
    opts.GraphNumber = GraphNumber(1);
end

% validate rows
if ~all(ismember(rows, 1:R))
    error('invalid rows')
else
    opts.rows = rows(:)';
end

if eq(numel(varargin), 0)
    opts.PVP = ego('class', 'graphics', 'method', 'bentobox');
else
    opts.PVP = varargin{1};
end

NR = numel(rows);
% size of thumbnail
divisors = find(mod(NR, 1:10)==0, NR);
divisors(divisors > NR) = [];
if isempty(divisors)
    divisors = 1;
end
c0 = max(divisors);
r0 = NR/c0;

opts.r0 = r0;
opts.c0 = c0;

end

function BMAT = preprocess(T, opts)

switch class(T)
    case 'double'
        TMAT = matrix('data', tbl('data', T));
    case 'tbl'
        TMAT = matrix('data', T);
    case 'matrix'
        TMAT = T;
    otherwise
        error('unsupported input class for bentobox')
end

BMAT = cell(opts.r0, opts.c0);
k = 0;
for r = 1:opts.r0
    for c = 1:opts.c0
        k = k + 1;
        opts.rows(k);
        vr = reshape(TMAT.data.data(opts.rows(k), :), opts.D1, opts.D2);
        % row and column w.r.t. D1 D2
        BMAT{r, c} = tbl('data', vr, 'fullname', TMAT.data.row_labels{opts.rows(k)});
    end
end

end
