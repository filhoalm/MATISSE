function MAP = nepal(varargin)
% NEPAL Bone-copper-autumn color map.
%
% MAP = NEPAL(nColors)
% MAP = NEPAL('nColors', <value>)
% MAP = NEPAL('nColors', <value>, 'Fade', <'in' or 'out'>)
%
% NEPAL colors have a 4:1:4 ratio of bone, copper, and autumn colormap
% values providing shades of white-black-copper-red-yellow.
%
% When 'Fade is 'out' (default) the bone and autumn submaps run the usual way.
% The submaps are reversed when 'Fade' is 'in'.
%
% See also go, africa, clarinet.

INPUTS = nepal_INPUTS(varargin{:});

nColors = INPUTS.nColors;

Q = ceil(nColors/9);

B1 = copper(Q);
M2 = autumn(4*Q);
M3 = bone(4*Q);

switch INPUTS.Fade

    case 'out'
        M2 = M2(end:-1:1, :);
        M3 = M3(end:-1:1, :);
    otherwise

end

B1 = B1(round(Q/2):Q,:);
M1 = [B1(1:1:end,:); B1(end:-1:1,:)];
M3 = M3(end:-1:1, :);

MAP = [M3; M1; M2];

N_MAP = length(MAP);

%%%
% If the length of the colormap is not evenly divisible by 9 the remainder
% is divided evenly. Half the number is deleted from the start of the
% map and the other half from the end.
%%%c

Qr = N_MAP - nColors;
if Qr > 0
    if rem(Qr, 2)==0
        % even
        start = Qr/2 + 1;
        stop = N_MAP - Qr/2;
        INC = start:stop;
        MAP = MAP(INC, :);
    else
        % odd
        start = max(1, (Qr-1)/2);
        stop = N_MAP - (Qr+1)/2;
        INC = start:stop;
        MAP = MAP(INC, :);
    end

end

function INPUTS = nepal_INPUTS(varargin)

if nargin == 0
    varargin = {'nColors', 450};
elseif nargin == 1
    % can check single input below
    varargin = {'nColors', varargin{1}};
else
    % check property-value pairs below
end

INPUTS = struct('nColors', [], 'Fade', 'in');

lArgin = varargin(1:end);
N = numel(lArgin);
while N >= 2
    
    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('A property must be specified using a string.')
    end

    switch lower(propi)

        case 'ncolors'
            % first see if this is a real scalar
            if ~(isscalar(vali) &&  isreal(vali))
                error('nColors must be a positive integer');
            end
            if vali<=0
                error('nColors must be a positive integer')
            end
            INPUTS.nColors = round(vali);

        case 'fade'
            % validate
            if ~ischar(vali)
                error('Fade must be ''in''  or ''out''')
            end
            if size(vali, 1) > 1
                error('Fade must be a string, not a character matrix')
            end
            vali = lower(vali);
            I = strncmp({'in', 'out'}, vali, 1);
            if ~any(I)
                error('Fade must be ''in'' or ''out''')
            end
            INPUTS.Fade = vali;

        otherwise
    end

    % setup for the next pair
    lArgin = lArgin(3:end);
    N = numel(lArgin);
    if eq(N, 1)
        error('last property has no matching value');
    end

end

