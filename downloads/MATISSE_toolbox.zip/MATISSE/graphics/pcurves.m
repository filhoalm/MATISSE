function varargout = pcurves(varargin)
% PCURVES Plot multiple curves.
%
% legos = PCURVES(DATA1, ..., DATAK, go(...))
%
% * DATA1, ..., DATAK can be numeric matrices or tbl objects with 2 or 4 columns
%
%     column 1 - x values
%     column 2 - values
%     column 3 - lower y limit
%     column 4 - upper y limit
%
% * use go values to set the properties of each curve from 1, ..., K
% * axis labels are taken from DATA1
%
% See also pcurve.

lh = findobj(gcf, 'type', 'legend');
if ~isempty(lh)
    set(lh, 'AutoUpdate', 'off')
end

%%%
% Parse
%%%
Q = numel(varargin);
if isa(varargin{Q}, 'struct')
    pvp = varargin{Q};
    K = Q - 1;
else
    pvp = ego('class', 'graphics', 'method', 'pcurves');
    K = Q;
end

PVP = mascara(K, pvp);

%%%
% Preprocess
%%%

DATA = cell(1, K);

for k = 1:K
    DATA{k} = varargin{k};
    if ~(isa(DATA{k}, 'tbl') || isa(DATA{k}, 'numeric'))
        error('DATA1, ..., DATAK must be numeric or tbl')
    end

    [R, C] = size(DATA{k});
    if ~(eq(C, 2) || eq(C, 4))
        error('DATA1, ..., DATAK must have 2 columns or 4')
    end

    if isa(DATA{k}, 'numeric')
        DATA{k} = tbl('data', DATA{k});
    end

    % trim data
    if PVP.Trim > 0
        DATA{k} = DATA{k}(PVP.Trim+1:1:R-PVP.Trim, :);
    end

    % harmonize CI indicators
    if PVP.CI(k) && eq(C, 4)
        PVP.CI(k) = 1;
    end

end

legos = cell(1, K);
ltext = cell(1, K);

for k = 1:K

    data = DATA{k}.data;
    R = size(data, 1);

    switch PVP.CI(k)

        case 1

            % ignore spurious imaginary components in CI limits
            yci = real([data(1:R, 3)', data(R:-1:1, 4)']);
            xci = [data(1:R, 1)', data(R:-1:1, 1)'];

            % remove undefined values from CI limits
            INCi = ~isnan(yci);
            yci = yci(INCi);
            xci = xci(INCi);

            patch(xci, yci, PVP.MAP(k, :), ...
                'LineStyle', PVP.ls0{PVP.LineStyle(k)}, ...
                'EdgeColor', PVP.MAP(k, :), ...
                'EdgeAlpha', PVP.EdgeAlpha, ...
                'FaceAlpha', PVP.FaceAlpha);

            legos{k} = line(data(:, 1), data(:, 2), ...
                'Color', PVP.MAP(k, :), ...
                'MarkerFaceColor', PVP.MAP(k, :), ...
                'MarkerEdgeColor', PVP.MarkerEdgeColorMAP(k, :), ...
                'LineStyle', PVP.ls0{PVP.LineStyle(k)}, ...
                'LineWidth', PVP.LineWidth(k), ...
                'Marker', PVP.mk0{PVP.Marker(k)}, ...
                'MarkerSize', PVP.MarkerSize(k));
            ltext{k} = DATA{k}.labels{2}; % 03 April 2026 / was fullname

        case 0

            legos{k} = line(data(:, 1), data(:, 2), ...
                'Color', PVP.MAP(k, :), ...
                'MarkerFaceColor', PVP.MAP(k, :), ...
                'MarkerEdgeColor', PVP.MarkerEdgeColorMAP(k, :), ...
                'LineStyle', PVP.ls0{PVP.LineStyle(k)}, ...
                'LineWidth', PVP.LineWidth(k), ...
                'Marker', PVP.mk0{PVP.Marker(k)}, ...
                'MarkerSize', PVP.MarkerSize(k));
            ltext{k} = DATA{k}.labels{2}; % 03 April 2026 / was fullname

    end

end

%%%
% axis and labels
%%%
ax = gca;

if eq(PVP.Grid, 1)
    set(ax, ...
        'XGrid', true, 'YGrid', true, ...
        'GridColor', PVP.clarinet(PVP.GridColor, :), ...
        'GridLineWidth', PVP.GridWidth, ...
        'GridAlpha', 0.25)
end

if ~isempty(PVP.XLim)
    set(ax, 'XLim', PVP.XLim)
end

if ~isempty(PVP.YLim)
    set(ax, 'YLim', PVP.YLim)
end
if strcmp(PVP.YDir, 'reverse')
    set(ax, 'YDir', 'reverse')
end

ax.XAxis.FontSize = PVP.FontSize(1);
set(ax, 'TickDir', 'out', 'PlotBoxAspectRatio', [PVP.Width 1 1])

if strcmp(ax.YAxisLocation, 'right') % user can plot data in left or right yaxis
    ax.YAxis(2).FontSize = PVP.FontSize(2);
else
    ax.YAxis(1).FontSize = PVP.FontSize(2);
end

% labels
if PVP.labels(1)
    xlabel(DATA{1}.labels{1}, 'FontSize', PVP.FontSize(1))
end
if PVP.labels(2)
    ylabel(DATA{1}.labels{2}, 'FontSize', PVP.FontSize(2))
end
if PVP.labels(3)
    title(DATA{1}.fullname, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
end

if PVP.Legend
    legend([legos{:}], ltext{:}, 'FontSize', PVP.FontSize(1))
end

switch nargout
    case 0
    case 1
        varargout{1} = legos;
    otherwise
        error('too many outputs')
end

end
