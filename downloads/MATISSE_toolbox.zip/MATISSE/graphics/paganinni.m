function varargout = paganinni(varargin)
% PAGANINNI MultiPle cApricorn GrAdienNs In oNe fIgure.
%
% PAGANINNI(CAP1, CAP2, ..., CAPK, {'Model 1', 'Model 2', ..., 'Model K'})
% G = PAGANINNI(...)
%
% EF gradients obtain from capricorn analysis CAP1 based on Model 1, CAP2 based on
% Model 2, etc.
%
% 'Model 1', ..., 'Model k' can be 'NPH', 'PHL', 'PHT', 'PHX', or 'PHA'
%
% PAGANINNI plots four sets of gradients:
%
%      dFTT, dFCP (top row)
%      dLAC, dCAC (bottom row)
%
% * G contains the data plotted
%
% See also motif.

N = nargin;
K = N - 1;
mod = varargin{N};

if ~(iscellstr(mod) && eq(numel(mod), K)) %#ok<ISCLSTR>
    error('wrong number of model specifications')
end
% coerce to upper case
mod = upper(mod);

dftt = cell(1, K);
dfcp = cell(1, K);
dlac = cell(1, K);
dcac = cell(1, K);

LineColor = cell(1, K);
LineStyle = cell(1, K);
LineWidth = cell(1, K);
Model = cell(1, K);
labels = cell(1, K);
NK = NaN(1, K);

% StyleSheet Values for LineStyle and LineWidth
%        L    T     X    A    N
% ls = {'-', ':', '-.', '-', '--'};
%        1    3     4    1     2     go value
%
% lw = [ 2    2.5  2     1.5  1];

% compute six key EF for each of the K models
for k = 1:K

    dftt{k} = ef(varargin{k}, 'comp', 'dftt', 'Model', mod{k});
    dfcp{k} = ef(varargin{k}, 'comp', 'dfcp', 'Model', mod{k});
    dlac{k} = ef(varargin{k}, 'comp', 'dlac', 'Model', mod{k});
    dcac{k} = ef(varargin{k}, 'comp', 'dcac', 'Model', mod{k});

    labels{k} = varargin{k}.Inputs.labels;
    LineColor{k} = varargin{k}.Inputs.CapColors;

    NK(k) = numel(LineColor{k});
    JkT = ones(1, NK(k));
    switch mod{k}
        case 'PHL'
            LineStyle{k} = JkT;
            LineWidth{k} = 2 * JkT;
            Model{k} = '\bf{\color{red}PH-L:\color[rgb]{0 0 0}}\rm';
        case 'PHT'
            LineStyle{k} = 3 * JkT;
            LineWidth{k} = 2.5 * JkT;
            Model{k} = '\bf{\color{blue}PH-T:\color[rgb]{0 0 0}}\rm';
        case 'PHX'
            LineStyle{k} = 4 * JkT;
            LineWidth{k} = 2 * JkT;
            Model{k} = '\bf{\color[rgb]{0.9216 0.4706 0.2784}PH-X:\color[rgb]{0 0 0}}\rm';
        case 'PHA'
            LineStyle{k} = JkT;
            LineWidth{k} = 1.5 * JkT;
            Model{k} = '\bf{\color[rgb]{0.494  0.184  0.556}PH-A:\color[rgb]{0 0 0}}\rm';
        case 'NPH'
            LineStyle{k} = 2 * JkT;
            LineWidth{k} = JkT;
            Model{k} = '\bf{N-PH:}\rm';
    end

end

PVP = go(...
    'Width', 1, ...
    'LineColor', [LineColor{:}], ...
    'LineStyle', [LineStyle{:}], ...
    'LineWidth', [LineWidth{:}], ...
    'Marker', 16, ...
    'FaceAlpha', 0.10, ...
    'EdgeAlpha', 0, ...
    'Legend', 0, ...
    'FontSize', [10 10 12]);
% metadata for legend
PVP.Model = Model;
PVP.Labels = labels;
PVP.NK = NK;
map = clarinet(54);
PVP.MAP = map(PVP.LineColor, :);

figure('Position', [150 150 1200 750]);
clf

G.dftt = [dftt{:}];
G.dfcp = [dfcp{:}];
G.dlac = [dlac{:}];
G.dcac = [dcac{:}];

subplot(2, 3, 1)
% dftt
plot(G.dftt, PVP)
set(gca, 'YGrid', 'on')
ylabel(G.dftt.data.labels{2})

subplot(2, 3, 2)
% dfcp
plot(G.dfcp, PVP)
set(gca, 'YGrid', 'on')
ylabel(G.dfcp.data.labels{2})

subplot(2, 3, 4)
% dlac
plot(G.dlac, PVP)
set(gca, 'YGrid', 'on')
ylabel(G.dlac.data.labels{2})

subplot(2, 3, 5)
% dcac
plot(G.dcac, PVP)
set(gca, 'YGrid', 'on')
ylabel(G.dcac.data.labels{2})

harmony(varargin{1}.Inputs.geode)

axL = subplot(2, 3, 3);
bespokeLegend(axL, PVP)

switch nargout
    case 0
    case 1
        varargout{1} = G;
    otherwise
        error('too many outputs')
end

end

%%% helper functions

function bespokeLegend(axL, PVP)

subplot(axL)

K = numel(PVP.NK);
N = sum(PVP.NK);
XL = [0 1];
YL = [0.5 N + 0.5];

set(axL, 'XLim', XL, 'YLim', YL)

y = 0;

rline(y + 0.5, 0, go('LineStyle', 3, 'LineWidth', 2, 'LineColor', 14))

y = 0;

for k = 1:K

    mod = PVP.Model{k};

    for j = 1:PVP.NK(k)

        y = y + 1;

        line([0.1, 0.3], [y, y], ...
            'LineStyle', PVP.ls0{PVP.LineStyle(y)}, ...
            'Color', PVP.MAP(y, :), ...
            'LineWidth', PVP.LineWidth(y))
        text(0.4, y, [mod, '  ', PVP.Labels{k}{j}], ...
            'FontSize', PVP.FontSize(3), 'FontName', 'AndaleMono')

    end

    rline(y + 0.5, 0, go('LineStyle', 3, 'LineWidth', 2, 'LineColor', 14))

end

set(axL, 'YDir', 'reverse', 'Visible', 'off')

end

function harmony(G)
% Harmonize axis limits across panels

ROT = -60;


Panels = [1 2 4 5];
for pan = 1:4
    subplot(2, 3, Panels(pan))
    switch Panels(pan)
        case 1
            YL1 = get(gca, 'YLim');
        case 2
            YL2 = get(gca, 'YLim');
        case 4
            YL4 = get(gca, 'YLim');
        case 5
            YL5 = get(gca, 'YLim');
        otherwise
    end
end

% common y-axis limits for panels (1,2) and (4,5)
cYL12 = [min([ YL1(1), YL2(1)]), max([ YL1(2), YL2(2)])];
cYL45 = [min([ YL4(1), YL5(1)]), max([ YL4(2), YL5(2)])];

XL = G.XL([2 3 1 1]);
XT = G.XT([2 3 1 1]);

for pan = 1:4
    switch Panels(pan)
        case {1, 2}
            subplot(2, 3, Panels(pan))
            set(gca, 'YLim', cYL12, ...
                'XLim', XL{pan}, ...
                'XTick', XT{pan}, ...
                'XTickLabelRotation', ROT)
        case {4, 5}
            subplot(2, 3, Panels(pan))
            set(gca, 'YLim', cYL45, ...
                'XLim', XL{pan}, ...
                'XTick', XT{pan}, ...
                'XTickLabelRotation', ROT)
        otherwise
    end
end

end

