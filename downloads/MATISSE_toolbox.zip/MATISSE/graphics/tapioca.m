function F = tapioca(M, varargin)
% TAPIOCA ploT deviAtions from age-PerIOd-Cohort Analysis.
%
% TAPIOCA(M)
% F = TAPIOCA(M, 'Text', <true or false>, 'Plot', <true or false>)
%
% M can be a sage object or an apc object.
%
% See also apc/deviations, sage/deviations.

opts = options(M, varargin{:});

% deviations / complete, quadratic, higher-order
F.ad  = ef(M, 'comp', 'ad');
F.ad2 = ef(M, 'comp', 'ad2');
F.adh = ef(M, 'comp', 'adh');

F.pd  = ef(M, 'comp', 'pd');
F.pd2 = ef(M, 'comp', 'pd2');
F.pdh = ef(M, 'comp', 'pdh');

F.cd  = ef(M, 'comp', 'cd');
F.cd2 = ef(M, 'comp', 'cd2');
F.cdh = ef(M, 'comp', 'cdh');

if ~opts.Plot
    return
end

% key parameters
key = ef(M, 'comp', 'key');

figure('Position', [100 100 1000 375])

Width = 1;
fs = [10 10 12];
fa = 0.10;
%%%
% go values tuned for each panel
%%%
go_ad = go('LineColor', [9 9 9], 'FontSize', fs, ...
    'labels', [1 1 0], 'LineWidth', [1 2 2], 'Width', Width, ...
    'Marker', [1 16 16], 'Legend', 0, ...
    'MarkerSize', opts.ms, ...
    'FaceAlpha', fa, 'EdgeAlpha', 0.00);

go_pd = go('LineColor', [1 1 1], 'FontSize', fs, ...
    'labels', [1 1 0], 'LineWidth', [1 2 2], 'Width', Width, ...
    'Marker', [1 16 16], 'Legend', 0, ...
    'MarkerSize', opts.ms, ...
    'FaceAlpha', fa, 'EdgeAlpha', 0.00);

go_cd = go('LineColor', [10 10 10], 'FontSize', fs, ...
    'labels', [1 1 0], 'LineWidth', [1 2 2], 'Width', Width, ...
    'Marker', [1 16 16], 'Legend', 0, ...
    'MarkerSize', opts.ms, ...
    'FaceAlpha', fa, 'EdgeAlpha', 0.00);

%%%
% 3 panels
%%%

ax1 = subplot(1, 3, 1);
plot([F.ad, F.ad2, F.adh], go_ad)
ylabel('Age Deviations')
set(ax1, 'YGrid', 'on')

ax2 = subplot(1, 3, 2);
plot([F.pd, F.pd2, F.pdh], go_pd)
ylabel('Period Deviations')
set(ax2, 'YGrid', 'on')

ax3 = subplot(1, 3, 3);
plot([F.cd, F.cd2, F.cdh], go_cd)
ylabel('Cohort Deviations')
set(ax3, 'YGrid', 'on')

%%%
% harmonize the axes
%%%
harmony(M.G)

%%%
% Text Annotations
%%%
if opts.Text

    TMP3 = key([5 6 7], 1);
    TMP4 = pc(TMP3);
    TXT2 = scale(TMP4, [10; 10; 10]);

    aq = TXT2.curves{1}.data(1, 2:4);
    pq = TXT2.curves{1}.data(2, 2:4);
    cq = TXT2.curves{1}.data(3, 2:4);

    aqt = ['\it ' num2str(aq(1), '%5.2f') ...
        '%/10 Yrs (' num2str(aq(2), '%5.3f') ', '  num2str(aq(3), '%5.3f') ')'];
    pqt = ['\it ' num2str(pq(1), '%5.2f') ...
        '%/10 Yrs (' num2str(pq(2), '%5.3f') ', '  num2str(pq(3), '%5.3f') ')'];
    cqt = ['\it ' num2str(cq(1), '%5.2f') ...
        '%/10 Yrs (' num2str(cq(2), '%5.3f') ', '  num2str(cq(3), '%5.3f') ')'];

    subplot(1, 3, 1)
    title(aqt, 'FontSize', go_ad.FontSize(3), 'FontWeight', 'normal')

    subplot(1, 3, 2)
    title({M.R.chromacode, pqt}, 'FontSize', go_pd.FontSize(3), ...
        'FontWeight', 'normal', 'VerticalAlignment', 'bottom');

    subplot(1, 3, 3)
    title(cqt, 'FontSize', go_cd.FontSize(3), 'FontWeight', 'normal')

end

end

function harmony(G)
% Harmonize axis limits across panels

ROT = -60;

for i = 1:3

    axi = subplot(1, 3, i);
    set(axi, ...
        'XLim', G.XL{i}, ...
        'XTick', G.XT{i}, ...
        'XTickLabelRotation', ROT)

end

end

function opts = options(M, varargin)
% validate input(s) for main procedure

% default values
opts = struct('Plot', 1, 'Text', 0, 'ms', []);

% tune MarkerSize
DELTA = M.R.a(2) - M.R.a(1);
switch DELTA
    case 1
        opts.ms = 6;
    case 2
        opts.ms = 7;
    case 3
        opts.ms = 7;
    case {4, 5}
        opts.ms = 9;
    otherwise
        opts.ms = 11;
end

lArgin = varargin(1:end);
Nl = numel(lArgin);
while Nl >= 1
    if Nl == 1
        error('last property has no matching value');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('property must be specified using a string')
    end
    switch lower(propi)

        case 'plot'
            if ~(isscalar(vali) && isnumeric(vali))
                error('Plot must be a real scalar')
            else
                if ismember(vali, [0 1])
                    opts.Plot = vali;
                else
                    error('Plot must be 0 or 1')
                end
            end

        case 'text'
            if ~isscalar(vali)
                error('text must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('text must be 0 or 1')
            end
            opts.Text = vali;

        otherwise

    end

end

end



