function varargout = rectangles(x, y, l, w, azd, varargin)
% RECTANGLES Draw rectangles.
%
% RECTANGLES(x, y, l, w, azd)
% RECTANGLES(x, y, l, w, azd, go(...))
% h = RECTANGLES(...)
%
% Draw rectangles centered at (x,y) with length l and width w rotated
% clockwise by azd degrees
%
%                    l
%             ...............
%             .      .      .
%             .      .      .
%             .      .      .
%         w   .....(x,y).....
%             .      .      .
%             .      .      .
%             .      .      .
%             ...............
%
%
% The appearance of each rectangle is controlled by go values.
%
% See also circles, squares, ellipses, annuli.

switch nargin
    case 5
        PVP = ego('class', 'graphics', 'method', 'rectangles');
    case 6
        PVP = varargin{1};
    otherwise
        error('wrong number of inputs')
end

h = drawrectangles(x(:), y(:) ,l(:), w(:), azd(:), PVP);

ax = gca;
switch PVP.axis
    case 'equal'
        axis equal
end
if eq(PVP.Grid, 1)
    set(ax, ...
        'XGrid', true, 'YGrid', true, ...
        'GridColor', PVP.clarinet(PVP.GridColor, :), ...
        'GridLineWidth', PVP.GridWidth, ...
        'GridAlpha', 0.25)
end

if ~isempty(PVP.XLim)
    set(ax, 'XLim', PVP.XLim)
end

if ~isempty(PVP.YLim)
    set(ax, 'YLim', PVP.YLim)
end

switch nargout
    case 0
    case 1
        varargout{1} = h;
    otherwise
        error('too many outputs')
end

end

%%%%%%%%
function h = drawrectangles(x, y, l, w, azd, pvp)
% helper

C = numel(x);
R = 5;
PVP = mascara(C, pvp);

xr = l/2;
yr = w/2;
xunit = [ -xr,  +xr,  +xr,  -xr  -xr]';
yunit = [ -yr,  -yr,  +yr,  +yr  -yr]';

% values of rotation matrices
azr = deg2rad(azd);
vals = [cos(azr) -sin(azr) sin(azr) cos(azr)];
ROT = reshape(vals', 2, 2, C);

X = NaN(R, C);
Y = NaN(R, C);
for c = 1:C
  tmp = kron([x(c); y(c)], ones(1, R)) + ROT(:, :, c)*[xunit(:, c), yunit(:, c)]';
  X(:, c) = tmp(1, :)';
  Y(:, c) = tmp(2, :)';
end

cmp = zeros(1, C, 3);
for c = 1:C
    cmp(1, c, 1:3) = PVP.MAP(c, :);
end

% We are drawing two sets of objects - patches without edges and lines
% lines express 'LineStyle', 'LineWidth', etc.
h.p = patch(X, Y, cmp, 'FaceAlpha', PVP.FaceAlpha, 'EdgeAlpha', 0);

h.l = line(X, Y);

TMP3 = num2cell(PVP.LineWidth);
[h.l.LineWidth_I] = deal(TMP3{:});

for c = 1:C
    h.l(c).LineStyle = PVP.ls0{PVP.LineStyle(c)};
    h.l(c).Color = PVP.MAP(c, :);
end

h.Parent = 'rectangles';

end

