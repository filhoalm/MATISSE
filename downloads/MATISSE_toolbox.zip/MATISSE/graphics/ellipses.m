function varargout = ellipses(x, y, r1, r2, azd, varargin)
% ELLIPSES Draw ellipses.
%
% ELLIPSES(x, y, r1, r2, azd)
% ELLIPSES(x, y, r1, r2, azd, go(...))
% h = ELLIPSES(...)
%
% Draw ellipses with semi-major axis r1, semi-minor axis r2, centered at (x,y),
% and rotated clockwise by azd degrees.
%
% The appearance of each ellipse is controlled by go values.
%
% See also circles, squares, rectangles, annuli.

switch nargin
    case 5
        PVP = ego('class', 'graphics', 'method', 'ellipses');
    case 6
        PVP = varargin{1};
    otherwise
        error('wrong number of inputs')
end

h = drawellipses(x(:), y(:), r1(:), r2(:), azd(:), PVP);

ax = gca;
switch PVP.axis
    case 'equal'
        axis equal
end
if eq(PVP.Grid, 1)
    set(ax, ...
        'XGrid', true, 'YGrid', true, ...
        'GridColor', PVP.clarinet(PVP.GridColor, :), ...
        'GridLineWidth', PVP.GridWidth, ...
        'GridAlpha', 0.25)
end

if ~isempty(PVP.XLim)
    set(ax, 'XLim', PVP.XLim)
end

if ~isempty(PVP.YLim)
    set(ax, 'YLim', PVP.YLim)
end

switch nargout
    case 0
    case 1
        varargout{1} = h;
    otherwise
        error('too many outputs')
end

end

%%%%%%%%
function h = drawellipses(x, y, r1, r2, azd, pvp)
% helper

th = (0:pi/50:2*pi)';
R = length(th);
C = numel(x);

PVP = mascara(C, pvp);

% samples from unit circle
xunit = cos(th);
yunit = sin(th);

% values of rotation matrices
azr = deg2rad(azd);
vals = [cos(azr) -sin(azr) sin(azr) cos(azr)];
ROT = reshape(vals', 2, 2, C);

% scaling factors for major and minor axes
vals = [r1'; zeros(1, C); zeros(1, C); r2'];
S = reshape(vals, 2, 2, C);

X = NaN(R, C);
Y = NaN(R, C);
for c = 1:C
  tmp = [x(c); y(c)] + ROT(:, :, c)*S(:, :, c)*[xunit yunit]';
  X(:, c) = tmp(1, :)';
  Y(:, c) = tmp(2, :)';
end
cmp = zeros(1, C, 3);
for c = 1:C
    cmp(1, c, 1:3) = PVP.MAP(c, :);
end

% We are drawing two sets of objects - patches without edges and lines
% lines express 'LineStyle', 'LineWidth', etc.
h.p = patch(X, Y, cmp, 'FaceAlpha', PVP.FaceAlpha, 'EdgeAlpha', 0);

h.l = line(X, Y);
       
TMP3 = num2cell(PVP.LineWidth);
[h.l.LineWidth_I] = deal(TMP3{:});

for c = 1:C
    h.l(c).LineStyle = PVP.ls0{PVP.LineStyle(c)};
    h.l(c).Color = PVP.MAP(c, :);
end

h.Parent = 'ellipses';

end