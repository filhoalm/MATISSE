function MAP = clarinet(varargin)
% CLARINET A colormap selected from 54 standard colors.
%
% MAP = CLARINET(nColors)
%
% or
%
% MAP = CLARINET('nColors', <value>, 'startColor', <value>)
%
% or
%
% MAP = CLARINET('colors', <values>)
%
% MAP is a matrix of RGB triples.
%
% Property-Value Pairs:
%
% 'nColors'    - integer <= 54 (default 54)
% 'startColor' - integer from 1 through 54 (default 1)
%
% or
%
% 'colors'     - vector of integers with values from 1 through 54
%
% colors:
%
% 1  light blue
% 2  orange
% 3  gold
% 4  purple
% 5  green
% 6  opal
% 7  brick
% 8  blue
% 9  red
% 10 forest green
% 11 magenta
% 12 black
% 13 powder blue
% 14 khaki
% 15 silver
% 16 orange
% 17 yellow
% 18 teal
% 19 turquoise
% 20 purple
% 21 brown
% 22 tomato
% 23 golden rod
% 24 khaki
% 25 olive
% 26 sea green
% 27 dark slate grey
% 28 dark turquoise
% 29 steel blue
% 30 navy
% 31 blue violet
% 32 dark slate blue
% 33 dark orchid
% 34 fuchsia
% 35 pink
% 36 wheat
% 37 sienna
% 38 rosy brown
% 39 peach puff
% 40 light slate grey
% 41 maroon
% 42 dark orange
% 43 dark khaki
% 44 dark olive green
% 45 dark sea green
% 46 dark cyan
% 47 corn flower blue
% 48 dark blue
% 49 medium orchid
% 50 hot pink
% 51 white
% 52 light grey
% 53 medium grey
% 54 dark grey
%
% See also go, africa, nepal.

INPUTS = clarinet_INPUTS(varargin{:});

if isempty(INPUTS.colors)

    MAP = NaN(INPUTS.nColors, 3);
    colors = NaN(1, INPUTS.nColors);

    for c = 1:INPUTS.nColors

        r0 = c;
        r0 = r0 - INPUTS.nColors*(ceil(r0/INPUTS.nColors-1));
        colors(c) = r0;
        MAP(c, :) = INPUTS.RGB(r0, :);

    end

else

    MAP = INPUTS.RGB(INPUTS.colors, :);

end


end

function INPUTS = clarinet_INPUTS(varargin)
% Helper
if nargin == 0
    varargin = {'nColors', 54};
elseif nargin == 1
    varargin = {'nColors', min(54, varargin{1})};
end

INPUTS = struct('RGB', [], 'nColors', 54, 'startColor', 1, 'colors', []);
baseMAP = (1/255) * [...
    0     114   189; ...  % 1  light blue
    217    83    25; ...  % 2  orange
    237   177    32; ...  % 3  gold
    126    47   142; ...  % 4  purple
    119   172    48; ...  % 5  green
    77    190   238; ...  % 6  opal
    162    20    47; ...  % 7  brick
    0       0   255; ...  % 8  blue
    255     0     0; ...  % 9  red
    0     128     0; ...  % 10 forest green
    190     0   190; ...  % 11 magenta
    0       0     0; ...  % 12 black
    176   244   230; ...  % 13 powder blue
    240   230   140; ...  % 14 khaki
    192   192   192; ...  % 15 silver
    235   120    71; ...  % 16 orange
    190   190     0; ...  % 17 yellow
    0     163   163; ...  % 18 teal
    0     168   255; ...  % 19 turquoise
    128     0   255; ...  % 20 purple
    149    99    99; ...  % 21 brown
    255    99    71; ...  % 22 tomato
    218   165    32; ...  % 23 golden rod
    240   230   140; ...  % 24 khaki
    128   128     0; ...  % 25 olive
    46    139    87; ...  % 26 sea green
    47     79    79; ...  % 27 dark slate grey
    0     206   209; ...  % 28 dark turquoise
    70    130   180; ...  % 29 steel blue
    0       0   128; ...  % 30 navy
    148    43   226; ...  % 31 blue violet
    72     61   139; ...  % 32 dark slate blue
    153    50   204; ...  % 33 dark orchid
    255     0   255; ...  % 34 fuchsia
    255   192   203; ...  % 35 pink
    245   222   179; ...  % 36 wheat
    180    82    45; ...  % 37 sienna
    188   143   143; ...  % 38 rosy brown
    255   218   185; ...  % 39 peach puff
    119   136   153; ...  % 40 light slate grey
    128     0     0; ...  % 41 maroon
    255   140     0; ...  % 42 dark orange
    189   183   107; ...  % 43 dark khaki
    85    107    47; ...  % 44 dark olive green
    143   188   143; ...  % 45 dark sea green
    0     139   139; ...  % 46 dark cyan
    100   149   237; ...  % 47 corn flower blue
    0       0   139; ...  % 48 dark blue
    186    85   211; ...  % 49 medium orchid
    255   105   180; ...  % 50 hot pink
    255   255   255; ...  % 51 white
    224   224   224; ...  % 52 light grey
    192   192   192; ...  % 53 medium grey
    160   160   160]; ... % 54 dark grey

lArgin = varargin(1:end);
N = numel(lArgin);

while N >= 2

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('property must be specified using a string')
    end
    switch lower(propi)

        case 'startcolor'
            % first see if this is a real scalar
            if ~(isscalar(vali) && isreal(vali)) 
                error('''startColor'' must be 1 - 54');
            end

            % now check whether it is scalar >= 1 and <= 54
            if ismember(vali, 1:54)
                % this is OK; update
                INPUTS.startColor = vali;
            else
                error('''startColor'' must be 1 - 54');
            end

        case 'ncolors'
            % first see if this is a real scalar
            if ~(isscalar(vali) && isreal(vali)) 
                error('''nColors'' must be 1 - 54');
            end

            % now check whether it is scalar >= 1 and <= 54
            if ismember(vali, 1:54)
                % this is OK; update
                INPUTS.nColors = vali;
            else
                error('''nColors'' must be 1 - 54');
            end

        case 'colors'
            if ~(isreal(vali))
                error('''colors'' must be integers between 1 through 54');
            end

            if all(ismember(vali, 1:54))
                % this is OK; update
                INPUTS.colors = vali;
            else
                error('''colors'' must be integers between 1 through 54');
            end


        otherwise
    end

    % setup for the next pair
    lArgin = lArgin(3:end);
    N = numel(lArgin);
    if eq(N, 1)
        error('The last property has no matching value.');
    end
end

if isempty(INPUTS.colors)

    INPUTS.RGB = circshift(baseMAP, 54 - INPUTS.startColor + 1, 1);
    INPUTS.RGB = INPUTS.RGB(1:INPUTS.nColors, :);

else

    INPUTS.RGB = baseMAP;

end

end