function varargout = rline(b0, bx, PVP)
% RLINE Draw a reference line.
%
% RLINE(b0, bx)
% RLINE(b0, bx, go(...))
% h = RLINE(...)
%
% The reference line is a plot of y = b0 + bx*x versus x. For a vertical
% reference line set bx=Inf in which case the reference line is a plot of
% y = b0 versus x.
%
% see also hband, vband.

if lt(nargin, 2)
    error('you must specify both an intercept and a slope')
end

if ~(isscalar(b0) && isnumeric(b0))
    error('b0 must be a real scalar')
end
if ~(isscalar(bx) && isnumeric(bx))
    error('b1 must be a real scalar')
end
if eq(nargin, 2)
    PVP = ego('class', 'graphics', 'method', 'rline');
end
if isempty(PVP.XLim)
    PVP.XLim = get(gca, 'XLim');
end
if isempty(PVP.YLim)
    PVP.YLim = get(gca, 'YLim');
end
if isfinite(bx)
    y0 = b0 + bx.*PVP.XLim(1);
    y1 = b0 + bx.*PVP.XLim(2);
    x01 = PVP.XLim;
else
    y0 = min(get(gca, 'YLim'));
    y1 = max(get(gca, 'YLim'));
    x01 = [b0 b0];
end
MAP = clarinet;

% Sometimes the act of drawing the line changes the y-axis limits -
% restore the old limits after adding the reference line.
% It can also change the x-axis limits - restore those as well (10 Nov
% 2018)
YL = get(gca, 'YLim');
XL = get(gca, 'XLim');
h = line(x01, [y0 y1], ...
    'LineStyle', PVP.ls0{PVP.LineStyle(1)}, ...
    'Color', MAP(PVP.LineColor(1), :), ...
    'LineWidth', PVP.LineWidth(1));
set(gca, 'YLim', YL, 'XLim', XL)

% Exclude reference line from any future legend calls
h.Annotation.LegendInformation.IconDisplayStyle = 'off';

switch nargout
    case 0
    case 1
        varargout{1} = h;
    otherwise
        error('too many output variables')
end

