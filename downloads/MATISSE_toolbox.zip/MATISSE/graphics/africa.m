function MAP = africa(varargin)
% AFRICA Green-black-red colormap.
%
% MAP = AFRICA(nColors)
%
% MAP has nColors equally-spaced value bins from green [0 1 0] through red [1 0 0].
%
% See also go, nepal, clarinet.

if nargin==1
    nColors = varargin{1};
else
    nColors = 450;
end

RANGE = [0 1];

%%%
% Validate RANGE and nColors arguments.
%%%
switch nColors
    case 1
        MAP = [0 1 0];
    case 2
        MAP = [0 1 0; 1 0 0];
    case 3
        MAP = [0 1 0; .5 .5 .5; 1 0 0];
    otherwise
        
        cuts = RANGE(1):(RANGE(2)-RANGE(1))/(nColors):RANGE(2);
        cuts = cuts(1:end-1);
        nc = length(cuts);
        
        green = 1:floor(nc/2)-1;
        grey = floor(nc/2):ceil(nc/2);
        red = (ceil(nc/2)+1):nc;
        
        ngrey = length(grey);
        ng = length(green);
        nr = length(red);
        
        green_chan = 1:-1/ng:1/ng;
        red_chan = 1/nr:1/nr:1;

        if ~isempty(grey)
            if ngrey==1
                grey_chan = min([green_chan, red_chan]);
            else
                
                switch mod(ngrey, 2)
                    case 0
                        % even
                        G = ngrey/2;
                        grey_chan = 0.3*[1:-1/G:1/G, 1/G:+1/G:1];
                    case 1
                        % odd
                        G = floor(ngrey/2);
                        grey_chan = 0.3*[1:-1/G:1/G, 1/(G+1):+1/(G+1):1];
                end
            end
        end
        
MAP = zeros(nc, 3);
MAP(green, 2) = green_chan';
MAP(red, 1) = red_chan';
MAP(grey, :) = [grey_chan', grey_chan', grey_chan'];

end

