function options = go(varargin)
% GO Set graphics options for MATISSE functions.
%
% PVP = GO(<property-value pairs>)
%
% * Some options apply to all functions, others to particular functions.
%
% Property-Value Pairs:
%
% 'Width'       - width of the x-axis relative to the y-axis (default 1.2672)
% 'CI'          - values of 1 (true) or 0 (false)
% 'Trim'        - number of edge values to trim (default 0)
% 'XLim'        - [Lo Hi], x-axis limits
% 'YLim'        - [Lo Hi], y-axis limits
% 'Legend'      - values of 1 (true) or 0 (false, default)
%
% 'LineWidth'   - scalar or vector, default 1
% 'LineColor'   - scalar or vector of clarinet colors 1 - 54 (default 1)
% 'LineStyle'   - values between 1 (default) and 5 corresponding to:
%                      '-', '--', ':', '-.', 'none'
% 'Marker'      - values between 1 (default) and 16 corresonding to:
%                     'o', 'square', '^', 'diamond', '.',       ( 1 - 5 )
%                     'v', '>', '<', 'pentagram', 'hexagram',   ( 6 - 10)
%                     '*', 'x', '+', '|', '_', 'none'           (11 - 16)
% 'MarkerSize'  - scalar or vector, default 10
%
% 'colormap'    - colormap for heat maps, surface plots etc. (default 'africa')
% 'omitnan'     - color NaN values grey, 0 (false, default) or 1 (true)
% 'omitzero'    - color 0 values grey, 0 (false, default) or 1 (true)
% 'nColors'     - total number of 'colormap' colors (default 100)
% 'YDir'        - 'normal' last row on top (default) or 'reverse' (first row on top)
% 'reversemap'  - 0 (false, default) or 1 (true)
% 'shading'     - 'faceted' or 'flat' (default)
% 'clim'        - 'symmetric', 'tight' (default), '95%', '90%' or [cmin cmax]
% 'colorbar'    - colorbar location ('' for no colorbar)
% 'Grid'        - 0 (false, default) or 1 (true)
% 'GridColor'   - a clarinet color 1 - 54 (52, default)
% 'GridWidth'   - default 0.5
% 'AxisColor'   - color of axis, clarinet value 1 - 54 (51, default)
% 'FaceAlpha'   - scalar between 0 and 1 (1.0, default)
% 'EdgeAlpha'   - scalar between 0 and 1 (0.2, default)
% 'axis'        - 'equal' (default) or 'auto'
% 'orientation' - 'vertical' or 'horizontal' (default)
%
% 'FontSize'    - [10 10 12] (default), x-axis, y-axis, title
% 'labels'      - [0 0 0], [1 0 0], ..., [1 1 0] (default), [1 1 1]
%                 for tbl objects: rows (ylabel), cols (xlabel), title
% 'MaxWidth'    - max characters in xlabel, ylabel, and title text (default 100)
%
% 'Text'        - 0 (false, default) or 1 (true)
% 'TextO'       - Text orientation, 'horizontal' (default), 'orthogonal', 'parallel'
% 'TextRot'     - Text rotation, scalar (default 0)
% 'formatSpec'  - default '%5.1f'
% 'Bands'       - integer, alternating white and grey bands
% 'Scaling'     - 'absolute' (default) or 'range' (from min to max)
% 'Border'      - number of border pixels (default 1)
% 'Depth'       - 'squash factor' to adjust the height of the z-axis (default 1)
%                 0.5 cuts the default height in half
% 'Plot'        - 1 (true, default), generate and plot data, or 0 (false)
%                 generate data without plotting
% 'Origin'      - include origin (1, true) or 0 (false, default)
%
% 'Alpha'       - scalar between 0 and 1 (default 0.05), confidence level
%
%  see also ego, mascara, clarinet.

defaultOptions = struct(...
    'Width', 1.2672, ...
    'CI', 1, ...
    'Trim', 0, ...
    'XLim', [], ...
    'YLim', [], ...
    'Legend', 1, ...
    'LineWidth', 1, ...
    'LineColor', 1:54, ...
    'LineStyle', 1, ...
    'Marker', 1, ...
    'MarkerSize', 10, ...
    'colormap', 'africa', ...
    'omitnan', 1, ...
    'omitzero', 0, ...
    'nColors', 100, ...
    'YDir', 'normal', ...
    'reversemap', 0, ...
    'shading', 'flat', ...
    'clim', 'tight', ...
    'colorbar', 'eastoutside', ...
    'Grid', 0, ...
    'GridColor', 54, ... % was 52
    'startColor', 1, ...
    'GridWidth', 0.5, ...
    'AxisColor', 51, ...
    'FaceAlpha', 1.0, ...
    'EdgeAlpha', 0.5, ...
    'axis', 'equal', ...
    'orientation', 'horizontal', ...
    'FontSize', [10 10 12], ...
    'labels', [1 1 0], ...
    'MaxWidth', 100, ...
    'Text', 0, ...
    'TextO', 'horizontal', ...
    'TextRot', 0, ...
    'formatSpec', '%5.1f', ...
    'Bands', 0, ...
    'Scaling', 'absolute', ...
    'Border', 1, ...
    'Depth', [], ...
    'Plot', 1, ...
    'Origin', 0, ...
    'Alpha', 0.05, ...
    'MAP', [], ...
    'MarkerEdgeColorMAP', []);

options = PlotOptions(defaultOptions, varargin{:});

end

%%%
% validation functions
%%%

function options = PlotOptions(defaultOptions, varargin)

fn0 = fieldnames(defaultOptions);

if eq(rem(nargin - 1, 2), 1)
    error('a property-value is missing')
end
nPairsIn = (nargin - 1)/2;
TMP1 = reshape(varargin, 2, nPairsIn);
fn1 = TMP1(1, :);

if ~iscellstr(fn1) %#ok<ISCLSTR>
    error('property names must be strings')
end

TF = ismember(lower(fn1), lower(fn0));
if ~all(TF)
    error('you specified one or more unknown options')
end
TMP2 = TMP1(:, TF);

nPairsOut = sum(TF);
proposedoptions = reshape(TMP2, 1, 2 * nPairsOut);

options = defaultOptions;
lArgin = proposedoptions;

clarinetRGB = clarinet(54);

for i = 1:nPairsOut

    propi = lower(lArgin{(i-1)*2 + 1});
    vali = lArgin{2*i};

    switch propi

        case 'width'
            if ~(isscalar(vali) && isreal(vali))
                error('Width must be a real scalar')
            else
                if vali <= 0
                    error('Width must be nonnegative')
                else
                    options.Width = vali;
                end
            end

        case 'ci'
            if ~(isnumeric(vali) && isreal(vali))
                error('CI must be a real scalar or vector of 0s and 1s')
            else
                if all(ismember(vali, [0 1]))
                    options.CI = vali(:)';
                else
                    error('CI values must be 0 or 1')
                end
            end

        case 'trim'
            if ~(isscalar(vali) && isreal(vali))
                error('Trim must be a real scalar')
            else
                if vali~=round(vali) || vali < 0
                    error('Trim must be a non-negative scalar')
                else
                    options.Trim = vali;
                end
            end

        case 'xlim'
            XLim = vali;

            if ~(isreal(XLim) && isnumeric(XLim))
                error('XLim must be numeric');
            end
            % rule of 2
            if length(XLim)~=2
                error('XLim must be a 2-vector [lower limit, upper limit]');
            end
            % lower value below upper value
            if XLim(2)<=XLim(1)
                error('XLim values must be strictly increasing');
            end
            options.XLim = XLim;


        case 'ylim'
            YLim = vali;
            if ~(isreal(YLim) && isnumeric(YLim))
                error('YLim must be numeric');
            end
            % rule of 2
            if length(YLim)~=2
                error('YLim must be a 2-vector [lower limit, upper limit]');
            end
            % lower value below upper value
            if YLim(2)<=YLim(1)
                error('YLim values must be strictly increasing');
            end
            options.YLim = YLim;

        case 'legend'
            if ~(isscalar(vali) && isreal(vali))
                error('Legend must be a real scalar')
            else
                if ismember(vali, [0 1])
                    options.Legend = vali;
                else
                    error('Legend must be 0 or 1')
                end
            end

        case 'linewidth'
            if ~(isnumeric(vali) && isreal(vali))
                error('LineWidth must be a real scalar or vector')
            else
                if any(vali < 0)
                    error('LineWidth values must be nonnegative')
                else
                    options.LineWidth = vali(:)';
                end
            end

        case 'linecolor'
            if ~(isnumeric(vali) && isreal(vali))
                error('LineColor must be a real scalar or vector')
            else
                if all(ismember(vali, 1:54))
                    options.LineColor = vali(:)';
                else
                    error('LineColor values must be integers between 1 and 54')
                end
            end

        case 'linestyle'
            if ~(isnumeric(vali) && isreal(vali))
                error('LineStyle must be a real scalar or vector')
            else
                if all(ismember(vali, 1:5))
                    options.LineStyle = vali(:)';
                else
                    error('LineStyle values must be integers between 1 and 5')
                end
            end

        case 'marker'
            if ~(isnumeric(vali) && isreal(vali))
                error('Marker must be a real scalar or vector')
            else
                if all(ismember(vali, 1:16))
                    options.Marker = vali(:)';
                else
                    error('Marker values must be integers between 1 and 16')
                end
            end

        case 'markersize'
            if ~(isnumeric(vali) && isreal(vali))
                error('MarkerSize must be a real scalar or vector')
            else
                if any(vali < 0)
                    error('MarkerSize values must be nonnegative')
                else
                    options.MarkerSize = vali(:)';
                end
            end

        case 'colormap'
            if ~ischar(vali)
                error('''colormap must a be a string')
            end
            vali = lower(vali);
            if ~any(strcmp(vali, ...
                    {'parula', 'turbo', 'hsv', 'hot', 'cool', ...
                    'spring', 'summer', 'autumn', 'winter', ...
                    'gray', 'bone', 'copper', 'pink', ...
                    'sky', 'abyss', 'jet', 'lines', 'colorcube', ...
                    'prism', 'flag', 'white', ...
                    'africa', 'nepal', 'clarinet'}))
                error('Unrecognized colormap')
            end
            options.colormap = vali;

        case 'omitnan'
            if ~isscalar(vali)
                error('omitmin must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('omitmin must be 0 or 1')
            end
            options.omitnan = vali;

        case 'omitzero'
            if ~isscalar(vali)
                error('omitzero must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('omitzero must be 0 or 1')
            end
            options.omitzero = vali;

        case 'ncolors'
            if ~(isscalar(vali) && isreal(vali))
                error('nColors must be a real scalar')
            else
                if vali~=round(vali) || vali < 1
                    error('nColors must be a positive scalar')
                else
                    options.nColors = vali;
                end
            end

        case 'ydir'
            if ~ischar(vali)
                error('YDir must be a string')
            end
            if size(vali, 1) > 1
                error('YDir must be a string')
            end
            vali = lower(vali);
            I = strncmp({'normal', 'reverse'}, vali, 1);
            if ~any(I)
                error('YDir must be ''normal'' or ''reverse''')
            end
            options.YDir = vali;

        case 'reversemap'
            if ~isscalar(vali)
                error('reversemap must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('reversemap must be 0 or 1')
            end
            options.reversemap = vali;

        case 'shading'
            if ~ischar(vali)
                error('shading must be a string')
            end
            vali = lower(vali);
            switch vali
                case 'faceted'
                    options.shading = 'faceted';
                case 'flat'
                    options.shading = 'flat';
                otherwise
                    error('shading must be ''faceted'' or ''flat''')
            end

        case 'clim'
            vali = lower(vali);
            % vali can be character or numeric
            if ischar(vali)
                switch vali
                    case 'symmetric'
                        options.clim = 'symmetric';
                    case 'tight'
                        options.clim = 'tight';
                    case '95%'
                        options.clim = '95%';
                    case '90%'
                        options.clim = '90%';
                    otherwise
                        error('clim must be ''symmetric'', ''tight'', ''95%'' or ''90%''')
                end

            elseif isnumeric(vali)
                if ~(length(vali)==2 && isreal(vali) && isnumeric(vali))
                    error('clim must be a 2-vector')
                end
                if vali(2)<=vali(1)
                    error('upper limit must be greater than lower limit')
                else
                    options.clim = vali;
                end
                if all(isnan(options.clim(:)))
                    error('invalid clim')
                end
            else
                error('invalid clim')
            end

        case 'colorbar'
            if ~ischar(vali)
                error('colorbar must specify a valid location')
            end
            if size(vali, 1) > 1
                error('colorbar must be a string')
            end
            vals = {...
                '', 'North', 'South', 'East', 'West', ...
                'NorthOutside', 'SouthOutside', 'EastOutside', 'WestOutside'};
            I = strcmpi(vali, vals);
            if ~any(I)
                error([vali ' is an unrecognized location'])
            end
            options.colorbar = vali;

        case 'grid'
            if ~isscalar(vali)
                error('Grid must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('Grid must be 0 or 1')
            end
            options.Grid = vali;

        case 'gridcolor'
            if ~(isscalar(vali) && isreal(vali))
                error('GridColor must be a non-negative scalar')
            else
                if vali~=round(vali) || vali < 0 || vali > 54
                    error('GridColor must be an integer between 1 and 54')
                else
                    options.GridColor = vali;
                end
            end

        case 'startcolor'
            if ~(isscalar(vali) && isreal(vali))
                error('startColor must be a non-negative scalar')
            else
                if vali~=round(vali) || vali < 0 || vali > 54
                    error('startColor must be an integer between 1 and 54')
                else
                    options.startColor = vali;
                end
            end

        case 'gridwidth'
            if ~(isscalar(vali) && isreal(vali))
                error('GridWidth must be a real scalar')
            else
                if vali < 0
                    error('GridWidth must be positive')
                else
                    options.GridWidth = vali;
                end
            end

        case 'axiscolor'
            if ~(isscalar(vali) && isreal(vali))
                error('AxisColor must be a non-negative scalar')
            else
                if vali~=round(vali) || vali < 0 || vali > 54
                    error('AxisColor must be an integer between 1 and 54')
                else
                    options.AxisColor = vali;
                end
            end

        case 'facealpha'
            if ~(isscalar(vali) && isreal(vali))
                error('FaceAlpha must be a scalar')
            else
                if vali < 0 || vali > 1
                    error('FaceAlpha value must be between 0.0 and 1.0')
                else
                    options.FaceAlpha = vali;
                end
            end

        case 'edgealpha'
            if ~(isscalar(vali) && isreal(vali))
                error('EdgeAlpha must be a scalar')
            else
                if vali < 0 || vali > 1
                    error('EdgeAlpha value must be between 0.0 and 1.0')
                else
                    options.EdgeAlpha = vali;
                end
            end

        case 'axis'
            if ~ischar(vali)
                error('axis must be a string')
            end
            vali = lower(vali);
            switch vali
                case 'equal'
                    options.axis = 'equal';
                case 'auto'
                    options.axis = 'auto';
                otherwise
                    error('axis must be ''equal'' or ''auto''')
            end

        case 'orientation'
            if ~ischar(vali)
                error('orientation must be a string')
            end
            vali = lower(vali);
            switch vali
                case 'vertical'
                    options.orientation = 'vertical';
                case 'horizontal'
                    options.orientation = 'horizontal';
                otherwise
                    error('orientation must be ''vertical'' or ''horizontal''')
            end

        case 'text'
            if ~isscalar(vali)
                error('text must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('text must be 0 or 1')
            end
            options.Text = vali;

        case 'texto'
            if ~ischar(vali)
                error('TextO must be a string')
            end
            vali = lower(vali);
            switch vali
                case 'orthogonal'
                    options.TextO = 'orthogonal';
                case 'horizontal'
                    options.TextO = 'horizontal';
                case 'parallel'
                    options.TextO = 'parallel';
                otherwise
                    error('TextO must be ''orthogonal'', ''horizontal'' or ''parallel''')
            end

        case 'textrot'
            if ~(isscalar(vali) && isreal(vali))
                error('TextRot must be a scalar')
            else
                options.TextRot = vali;
            end

        case 'formatspec'
            if ~ischar(vali)
                error('formatSpec must be a string')
            end
            options.formatSpec = vali;

        case 'fontsize'
            % must be a real scalar or a 3-vector
            if ~isreal(vali)
                error('invalid FontSize')
            end
            nvali = numel(vali);
            switch nvali
                case 1
                    vali = repmat(vali, 1, 3);
                case 3
                    % OK
                otherwise
                    error('FontSize must be a scalar or a 3-vector')
            end

            options.FontSize = round(vali);

        case 'labels'
            % must be a real scalar or a 3-vector
            if ~isreal(vali)
                error('invalid labels')
            end
            nvali = numel(vali);
            switch nvali
                case 1
                    vali = repmat(vali, 1, 3);
                case 3
                    % OK
                otherwise
                    error('labels must be a scalar or 3-vector')
            end
            if ~all(ismember(vali, [0 1]))
                error('labels must contain only 0s or 1s')
            end
            options.labels = vali;

        case 'maxwidth'
            if ~(isscalar(vali) && isreal(vali))
                error('MaxWidth must be a scalar')
            else
                if vali < 1
                    error('MaxWidth value must be >= 1')
                else
                    options.MaxWidth = vali;
                end
            end

        case 'bands'
            if ~(isscalar(vali) && isreal(vali))
                error('Bands must be non-negative integer')
            else
                if vali~=round(vali) || vali < 0
                    error('Bands must be a non-negative integer')
                else
                    options.Bands = vali;
                end
            end

        case 'scaling'
            vali = lower(vali);

            % validate
            if ~ischar(vali)
                error('scaling must be ''absolute'' or ''range''')
            end
            if size(vali, 1)>1
                error('scaling must be a string, not a character matrix')
            end
            vali = lower(vali);
            I = strncmp({'absolute', 'range'}, vali, 1);
            if ~any(I)
                error([vali ' is an unrecognized Scaling property value, valid values are ''absolute'' or ''range'''])
            end
            options.Scaling = vali;

        case 'border'
            if ~(isscalar(vali) && isreal(vali))
                error('Border must be a real scalar')
            else
                if vali < 0
                    error('Border must be >= 0')
                else
                    options.Border = round(vali);
                end
            end

        case 'depth'
            if ~isempty(vali)
                if ~(isscalar(vali) && isreal(vali))
                    error('Depth must be a real scalar')
                else
                    if le(vali, 0)
                        error('Depth must be > 0')
                    else
                        options.Depth = vali;
                    end
                end
            end

        case 'plot'
            if ~(isscalar(vali) && isnumeric(vali))
                error('Plot must be a real scalar')
            else
                if ismember(vali, [0 1])
                    options.Plot = vali;
                else
                    error('Plot must be 0 or 1')
                end
            end

        case 'origin'
            if ~(isscalar(vali) && isnumeric(vali))
                error('Origin must be a real scalar')
            else
                if ismember(vali, [0 1])
                    options.Origin = vali;
                else
                    error('Origin must be 0 or 1')
                end
            end

        case 'alpha'
            if ~(isscalar(vali) && isreal(vali))
                error('Alpha must be a real scalar')
            elseif (vali < 0 || vali > 1)
                error('Alpha must lie between 0 and 1')
            else
                options.Alpha = vali;
            end

        otherwise

            error(['unrecognized propery: ' propi])

    end

end

% extract an rgb triple for each curve when clarinet is the chosen map
options.MAP = clarinetRGB(options.LineColor, :);

% tune the EdgeColorMAP
C = numel(options.LineColor);
MarkerEdgeColorMAP = zeros(C, 3);

for c = 1:C
    switch options.LineColor(c)
        case {1, 2, 10, 19, 28, 29}
            MarkerEdgeColorMAP(c, :) = [1 0.961 0.933]; % Sea Shell
        case {3, 23, 35, 38, 39}
            MarkerEdgeColorMAP(c, :) = [0.25 0.25 0.25];
        case 5
            MarkerEdgeColorMAP(c, :) = [0 0.25 0];
        case 6
            MarkerEdgeColorMAP(c, :) = [0 0 0.25];
        case 9
            MarkerEdgeColorMAP(c, :) = [0.9 0.9 0.9];
        case 12
            MarkerEdgeColorMAP(c, :) = [1 1 1];
        case {13, 15, 16, 51, 52, 53}
            MarkerEdgeColorMAP(c, :) = [0 0 0];
        case {14, 17}
            MarkerEdgeColorMAP(c, :) = [0.2 0.2 0.2];
        case {24, 36, 54}
            MarkerEdgeColorMAP(c, :) = [0.3333 0.4196 0.1843]; % dark olive green
        otherwise
            MarkerEdgeColorMAP(c, :) = [1 1 1];
    end

    options.MarkerEdgeColorMAP = MarkerEdgeColorMAP;

    %%%
    % this copy of the clarinet 54 color colormap provides a look-up table
    % for GridColor and AxisColor
    %%%
    options.clarinet = clarinet(54);

    %%%
    % ls0 and mk0 are also added to provide a look-up table for LineStyle
    % and Marker properties
    %%%
    options.ls0 = {'-', '--', ':', '-.', 'none'};
    options.mk0 = {'o', 'square', '^', 'diamond', '.', 'v', '>', '<', ...
        'pentagram', 'hexagram', '*', 'x', '+', '|', '_', 'none'};


end

end



