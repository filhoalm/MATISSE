function varargout = vband(varargin)
% VBAND Draw vertical reference bands.
%
% VBAND(DATA)
% h = VBAND(DATA, go(...))
%
% * DATA can be a double or tbl.
%
% To declare specific starting and ending x-values:
%     column 1 - starting x values
%     column 2 - ending x values
%     column 3 - reference y values
%     column 4 - lower y limits
%     column 5 - upper y limits
%
% To start and end each band at the current x-axis limits:
%     column 1 - reference y values
%     column 2 - lower y limits
%     column 3 - upper y limits
%
% see also rline, hband.

INPUTS = options(varargin{:});

if eq(nargin, 1)
    PVP = ego('class', 'graphics', 'method', 'vband');
else
    PVP = varargin{2};
end

PVP = mascara(INPUTS.R, PVP);

h2 = NaN(1, INPUTS.R);
h1 = NaN(1, INPUTS.R);
for r = 1:INPUTS.R

    COLORr = PVP.MAP(r, :);

    ph = patch(INPUTS.xci(r, :)', INPUTS.yci(r, :)', ...
        COLORr, 'LineStyle', PVP.ls0{PVP.LineStyle(r)}, ...
        'edgecolor', COLORr, ...
        'facecolor', COLORr, ...
        'FaceAlpha', PVP.FaceAlpha, ...
        'EdgeAlpha', PVP.EdgeAlpha);

    % Not to appear in any legend
    ph.Annotation.LegendInformation.IconDisplayStyle = 'off';
    h2(r) = ph(1);
    lh = line(INPUTS.x(r, :)', INPUTS.y(r, :)', ...
        'LineStyle', PVP.ls0{PVP.LineStyle(r)}, ...
        'Color', COLORr, ...
        'LineWidth', PVP.LineWidth);
    if ~PVP.Legend
        lh.Annotation.LegendInformation.IconDisplayStyle = 'off';
    end
    h1(r) = lh(1);
end

if PVP.Legend
    legend(h2, INPUTS.Labels)
end

set(gca, 'PlotBoxAspectRatio', [PVP.Width 1 1])
if ~isempty(PVP.XLim)
    set(gca, 'XLim', PVP.XLim)
end
if ~isempty(PVP.YLim)
    set(gca, 'YLim', PVP.YLim)
end

switch nargout
    case 0
    case 1
        if ~isempty(INPUTS.yci)

            varargout{1} = h2;
        else
            varargout{1} = h1;
        end
    case 2
        if ~isempty(yci)
            varargout{1} = h2;
            varargout{2} = h1;
        else
            varargout{1} = [];
            varargout{2} = h1;
        end
    otherwise
        error('too many output variables')
end


function INPUTS = options(varargin)
% supply validated inputs to main procedure

INPUTS = struct('R', [], 'x', [], 'y', [], 'Labels', {''}, ...
    'xci', [], 'yci', [], ...
    'XLim', [], 'YLim', []);

DATA = varargin{1};
C = size(DATA, 2);
R = size(DATA, 1);
INPUTS.R = R;
if ~(C==3 || C==5)
    error('input data must have 3 or 5 columns')
end
INPUTS.nColors = min(54, C);

if isa(DATA, 'double')
    DATA = tbl(...
        'data', DATA, ...
        'fullname', 'RBANDS', ...
        'row_labels', cellstr(num2str((1:INPUTS.R)'))' );
elseif isa(DATA, 'tbl')
    if isscalar(DATA.row_labels) && isempty(DATA.row_labels{1})
        DATA.row_labels = cellstr(num2str((1:INPUTS.R)'))';
    end
else
end

INPUTS.Labels = DATA.row_labels;

switch C
    case 3
        YL = get(gca, 'YLim');
        INPUTS.y = repmat(YL, R, 1);
        INPUTS.x = DATA.data(:, [1 1]);
        INPUTS.xci = DATA.data(:, [2 2 3 3]);


    case 5
        INPUTS.y = DATA.data(:, 1:2);
        INPUTS.x = DATA.data(:, [3 3]);
        INPUTS.xci = DATA.data(:, [4 4 5 5]);

end

INPUTS.yci = INPUTS.y(:,[1 2 2 1]);


