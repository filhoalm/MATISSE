function varargout = vista(M, varargin)
% VISTA - Visualize sIngular values decompoSiTion of a 2x2 mAtrix.
%
% VISTA(M)
% E = VISTA(M, 'Plot', <1 (true, default) or 0 (false)>)
%
% See also ellipses

PVP = options(varargin{:});

FS = 16;
MS = 24;

E = struct(...
    'V', [], 'VROT', [], 'vreflection', [], 'VREF', [], ...
    'U', [], 'UROT', [], 'ureflection', [], 'UREF', [], ...
    'S', [], ...
    'VROTr', [], ...
    'VROTd', [], ...
    'UROTr', [], ...
    'UROTd', [], ...
    'Foci', []);

[E.U, E.S, E.V] = svd(M);

%%%
% Compute angle of semi-major axis of V basis
%%%
V1 = E.V(:, 1);
y0 = V1(2); x0 = V1(1);
E.VROTr = (y0>=0).*atan2(y0,x0) + (y0<0).*(pi - atan2(y0,-x0));
E.VROTd = rad2deg(E.VROTr);
E.VROT = [cos(E.VROTr) -sin(E.VROTr); sin(E.VROTr) cos(E.VROTr)];
% reflect around pi unless VROTr is 0: if VROTr is 0 E.VREF is eye(2)
E.vreflection = sign(E.VROTr/pi);
E.VREF = [cos(2*pi) sin(2*pi); sin(2*pi) ((-1)^(E.vreflection))*cos(2*pi)];

% angle of semi-major axis of U basis
U1 = E.U(:, 1);
y0 = U1(2); x0 = U1(1);
E.UROTr = (y0>=0).*atan2(y0,x0) + (y0<0).*(pi - atan2(y0,-x0));
E.UROTd = rad2deg(E.UROTr);
E.UROT = [cos(E.UROTr) -sin(E.UROTr); sin(E.UROTr) cos(E.UROTr)];
% reflect around pi unless UROTr is 0: if UROTr is 0 E.UREF is eye(2)
E.ureflection = sign(E.UROTr/pi);
E.UREF = [cos(2*pi) sin(2*pi); sin(2*pi) ((-1)^(E.ureflection))*cos(2*pi)];

dfoci = sqrt(E.S(1,1)^2-E.S(2,2)^2);

% after rotation:
F2 = [-dfoci; 0];
F1 = [+dfoci; 0];
ROTF1 = E.U*F1;
ROTF2 = E.U*F2;
E.Foci = [ROTF1, ROTF2];

if PVP.Plot

    % standard circle
    R = 1;
    rad = (0:(2*pi)/360:2*pi)';
    x = R*cos(rad);
    y = R*sin(rad);

    % standard circle mapped by M
    MXY = M*[x, y]';

    axis image

    AxesLimits = max(max(E.S(:)), 1);
    XL = [-AxesLimits, +AxesLimits];
    YL = [-AxesLimits, +AxesLimits];
    set(gca, 'XLim', XL, 'YLim', YL)
    hold on

    line(MXY(1, :), MXY(2, :), 'color', [1 0 0], 'linewidth', 2)

    % Columns of U
    line([0 E.U(1,1)], [0 E.U(2,1)], 'LineWidth', 5, 'Color', [1 0 0])
    % text(E.U(1,1), E.U(2,1), 'U_1', 'Color', [1 0 0], 'Rotation', E.UROTd+180, 'HorizontalAlignment', 'right', ...
    %     'FontSize', FS, 'EdgeColor', [0 0 0], 'BackGroundColor', [1 1 1], ...
    %     'Margin', 0.25, 'VerticalAlignment', 'baseline', 'HorizontalAlignment', 'left')

    line([0 E.U(1,2)], [0 E.U(2,2)], 'LineWidth', 5, 'Color', [1 0 0])
    % text(E.U(1,2), E.U(2,2), 'U_2', 'Color', [1 0 0], 'Rotation', E.UROTd+270, 'HorizontalAlignment', 'left', ...
    %     'FontSize', FS, 'EdgeColor', [0 0 0], 'BackGroundColor', [1 1 1], ...
    %     'Margin', 0.25', 'VerticalAlignment', 'baseline', 'HorizontalAlignment', 'left')

    % columns of V'
    VT = E.V;
    line([0 VT(1,1)], [0 VT(2,1)], 'LineWidth', 5, 'Color', [0 1 0])
    % text(VT(1,1), VT(2,1), 'V''_1', 'Color', [0 0.5 0], 'Rotation', E.VROTd+180, 'HorizontalAlignment', 'right',  ...
    %     'FontSize', FS, 'EdgeColor', [0 0 0], 'BackGroundColor', [1 1 1], ...
    %     'Margin', 0.25, 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right')

    line([0 VT(1,2)], [0 VT(2,2)], 'LineWidth', 5, 'Color', [0 1 0])
    % text(VT(1,2), VT(2,2), 'V''_2', 'Color', [0 0.5 0], 'Rotation', E.VROTd+270, 'HorizontalAlignment', 'left', ...
    %     'FontSize', FS, 'EdgeColor', [0 0 0], 'BackGroundColor', [1 1 1], ...
    %     'Margin', 0.25, 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right')

    circles(0, 0, 1, go('LineColor', 12, 'LineWidth', 2, 'FaceAlpha', 0, 'EdgeAlpha', 1));
    annuli([0 0 0.9 1 0 E.VROTd], go('LineColor', 10, 'FaceAlpha', 0.15, 'labels', [0 0 0]));
    annuli([0 0 0.8 0.9 0 E.UROTd], go('LineColor', 9, 'FaceAlpha', 0.15, 'labels', [0 0 0]))

    C2 = E.S*E.V'*[x, y]';
    line(C2(1,:), C2(2, :), 'Color', [0 0.5 0], 'LineWidth', 2)
    b1 = tan(E.UROTr);
    if b1 == 0
        b2 = Inf;
    else
        b2 = tan(E.UROTr - pi/2);
    end

    rline(0, b2, go('LineColor', 7, 'LineStyle', 3, 'LineWidth', 2))
    rline(0, b1, go('LineColor', 7, 'LineStyle', 3, 'LineWidth', 2))
    rline(0, 0, go('LineStyle', 3, 'LineColor', 14))
    rline(0, Inf, go('LineStyle', 3, 'LineColor', 14))
    
    circles(0, 0, E.S(1,1), go('FaceAlpha', 0, 'LineColor', 10));

    C3 = E.S*E.V'*[x, y]';
    line(C3(1,:), C3(2, :), 'Color', [0 0.5 0], 'LineWidth', 2)
    rline(0, 0, go('LineStyle', 3, 'LineColor', 14))
    rline(0, Inf, go('LineStyle', 3, 'LineColor', 14))

    % plot the foci

    % prior to rotation:
    line(-dfoci, 0, 'marker', 'pentagram', 'MarkerFaceColor', [0 0.5 0], 'MarkerEdgeColor', [0 1 0], 'MarkerSize', MS)
    line(+dfoci, 0, 'Marker', 'pentagram', 'MarkerFaceColor', [0 0.5 0], 'MarkerEdgeColor', [0 1 0], 'MarkerSize', MS)
    % after rotation:
   %line(ROTF1(1,1), ROTF1(2,1), 'marker', 'pentagram', 'MarkerEdgeColor', [1 0 0], 'MarkerSize', MS)
    %line(ROTF2(1,1), ROTF2(2,1), 'Marker', 'pentagram', 'MarkerEdgeColor', [1 0 0], 'MarkerSize', MS)

    % Starting Values
    X1 = [+1;0];
    X2 = [0;+1];
    X3 = [-1;0];
    X4 = [0;-1];
    txt1 = {'$\enspace A$', '$\enspace B$', '$\enspace C$', '$\enspace D$'};

    % Ending Values
    Y1 = M*X1;
    Y2 = M*X2;
    Y3 = M*X3;
    Y4 = M*X4;
    txt4 = {'$\enspace USV''A$', '$\enspace USV''B$', ' $\enspace USV''C$', '$\enspace USV''D$'};

    % after V'
    VT = E.V';
    RX1 = VT*X1;
    RX2 = VT*X2;
    RX3 = VT*X3;
    RX4 = VT*X4;
    txt2 = {'$\enspace V''A$', '$\enspace V''B$', '$\enspace V''C$', '$\enspace V''D$'};
 
    % after S*V'
    SRX1 = E.S*RX1;
    SRX2 = E.S*RX2;
    SRX3 = E.S*RX3;
    SRX4 = E.S*RX4;
    txt3 = {'$\enspace SV''A$', ' $\enspace SV''B$', ' $\enspace SV''C$', ' $\enspace SV''D$'};

    data1 = [X1, X2, X3, X4];
    data2 = [RX1, RX2, RX3, RX4];
    data3 = [SRX1, SRX2, SRX3, SRX4];
    data4 = [Y1, Y2, Y3, Y4];

    text(data1(1, :), data1(2, :), txt1, 'Color', [0 0 0], 'FontSize', FS, 'Margin', 0.05, 'Interpreter', 'latex');
    text(data2(1, :), data2(2, :), txt2, 'Color', [0 0.5 0], 'FontSize', FS, 'Margin', 0.05, 'Interpreter', 'latex');
    text(data3(1, :), data3(2, :), txt3, 'Color', [0 0.5 0], 'FontSize', FS, 'Margin', 0.05, 'Interpreter', 'latex');
    text(data4(1, :), data4(2, :), txt4, 'Color', [1 0 0], 'FontSize', FS, 'Margin', 0.05, 'Interpreter', 'latex');

    line(data1(1, :), data1(2, :), 'Color', [0 0 0], 'LineStyle', 'none', 'Marker', '.', 'MarkerSize', MS)
    %line(data2(1, :), data2(2, :), 'Color', [0 0.5 0], 'LineStyle', 'none', 'Marker', '.', 'MarkerSize', MS)
    %line(data3(1, :), data3(2, :), 'Color', [0 0.5 0], 'LineStyle', 'none', 'Marker', '.', 'MarkerSize', MS)
    line(data4(1, :), data4(2, :), 'Color', [1 0 0], 'LineStyle', 'none', 'Marker', '.', 'MarkerSize', MS)

    grid

    % use ellipses to show consistency
    if E.ureflection
        azd = -E.UROTd;
    else
        azd = E.UROTd;
    end

    ellipses(0, 0, E.S(1,1), E.S(2,2), azd, go('LineColor', 53, 'FaceAlpha', 0.10))

    set(gca, 'XLim', XL, 'YLim', YL);
end

switch nargout
    case 0
    case 1
        varargout{1} = E;
    otherwise
        error('Too many outputs.')
end

function PVP = options(varargin)
% validate input(s)

PVP = struct('Plot', 1);

lArgin = varargin(1:end);
Nl = numel(lArgin);
while ge(Nl, 1)
    if eq(Nl, 1)
        error('last property has no matching value');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);

    if ~ischar(propi)
        error('a property must be specified using a string')
    end
    switch lower(propi)

        case 'plot'
            if ~(isscalar(vali) && isnumeric(vali))
                error('Plot must be a real scalar')
            else
                if ismember(vali, [0 1])
                    PVP.Plot = vali;
                else
                    error('Plot must be 0 or 1')
                end
            end

        otherwise
            error(['Unrecognized method property: ' propi])
    end

    lArgin = lArgin(3:end);
    Nl = numel(lArgin);
end



