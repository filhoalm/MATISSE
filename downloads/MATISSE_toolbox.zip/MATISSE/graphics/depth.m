function varargout = depth(ax, factor)
% DEPTH - Adjust the height of a 3D graph.
% 
% [Depth, DAR] = DEPTH(ax, factor)
%
% ax     - target axis
%
% factor - a scalar > 0:
%          values gt 1 increase the height of the z-axis
%          values lt 1 decrease the height of the z-axis
%
% See also go.

if ~(isscalar(factor) && isreal(factor))
    error('factor value must be a nonnegative scalar')
end

if le(factor, 0)
    error('factor values must be positive')
end


ODAR = get(ax, 'DataAspectRatio');
NDAR = ODAR;
NDAR(3) = ODAR(3)/factor;
Depth = 1/NDAR(3);

set(ax, 'DataAspectRatio', NDAR)

switch nargout
    case 0
    case 1
        varargout{1} = Depth;
    case 2
        varargout{1} = Depth;
        varargout{2} = NDAR;
    otherwise
        error('too many outputs')
end

end