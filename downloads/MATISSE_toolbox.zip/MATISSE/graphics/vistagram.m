function varargout = vistagram(CELL, varargin)
% VISTAGRAM Array of surface plots.
%
% VISTAGRAM(CELL, go(...))
% T = VISTAGRAM(...)
%
% CELL is an RxC cell array of double, tbl, matrix, or rates objects all
% the same size:
%
%      { T11, T12, ..., T1C; ...
%        T21, T22, ..., T2C; ...
%         :    :    :    :
%        TR1  TR2, ..., TRC }
%
% VISTAGRAM produces a combined tbl and an array of surface plots providing
% a bird's-eye view.
%
% A VISTAGRAM plot has 2 components controlled by go values:
%
% * An array of surfaces
%
% * A colorbar
%
% See also skyline, depth.

N = numel(varargin);
switch N
    case 0
        PVP = ego('class', 'graphics', 'method', 'vistagram');
    otherwise
        PVP = varargin{1};
end

DATA = process_thumb_data(CELL, PVP, 'vistagram');

T = assemble_thumb_data(DATA, PVP);

% Are we drawing the plot?
if ~PVP.Plot
    switch nargout
        case 1
            varargout{1} = T;
        otherwise
    end

    return

end

% NOTE: 'YDir' was already applied at the cell level
PVP.YDir = 'normal';

surf(tbl('data', T.IMG), PVP)
% remove meaningless x- and y-axis tick labels
set(gca, 'XTick', [], 'YTick', [], 'Color', PVP.clarinet(PVP.AxisColor, :))

if PVP.Text || eq(PVP.labels(3), 1) || eq(PVP.labels(2), 1)

    TMP = T.Labels.Text(end:-1:1, :);
    zLoc = 1.0 * max(get(gca, 'ZLim')) * ones(1, numel(TMP));
    text(T.Labels.cLoc(:), T.Labels.rLoc(:), zLoc, TMP(:), ...
        'FontSize', PVP.FontSize(3), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle', ...
        'BackgroundColor', [1 1 1], ...
        'EdgeColor', [0 0 0], ...
        'Rotation', PVP.TextRot)

end

switch nargout
    case 1
        varargout{1} = T;
    otherwise
end

end
