function F = leonardo(M, varargin)
% LEONARDO pLot Estimable functiONs from Age-peRioD-cOhort analysis.
%
% LEONARDO(M)
% F = LEONARDO(M, 'RVals', <value>, 'Plot', <true or false>)
%
% M can be a sage or apc object.
%
% See also apc/plot, sage/plot, kandinsky.


% make sure we have RVals
opts = options(M, varargin{:});

% Six key EFs
F.ftt = ef(M, 'comp', 'ftt', 'RVals', opts.RVals);
F.fcp = ef(M, 'comp', 'fcp', 'RVals', opts.RVals);
F.ld  = ef(M, 'comp', 'ld',  'RVals', opts.RVals);
F.lac = ef(M, 'comp', 'lac', 'RVals', opts.RVals);
F.cac = ef(M, 'comp', 'cac', 'RVals', opts.RVals);
F.gs  = ef(M, 'comp', 'gs',  'RVals', opts.RVals);

% quadratic components of the EFs
F.ftt2 = ef(M, 'comp', 'ftt2', 'RVals', opts.RVals);
F.fcp2 = ef(M, 'comp', 'fcp2', 'RVals', opts.RVals);
F.ld2  = ef(M, 'comp', 'ld2',  'RVals', opts.RVals);
F.lac2 = ef(M, 'comp', 'lac2', 'RVals', opts.RVals);
F.cac2 = ef(M, 'comp', 'cac2', 'RVals', opts.RVals);
F.gs2  = ef(M, 'comp', 'gs2',  'RVals', opts.RVals);

% key parameters
F.key = ef(M, 'comp', 'key');

if ~opts.Plot
    return
end

figure('Position', [100 100 1000 750])

warning off

Width = 1;
fs = [8 8 12];
fa = 0.10;
%%%
% go values tuned for each panel
%%%
go_p = go('LineColor', [1 1], 'LineWidth', [1 2], ...
    'Marker', [1 16], 'FontSize', fs, ...
    'labels', [1 1 0], 'Width', Width, ...
    'Legend', 0, 'MarkerSize', opts.ms, ...
    'FaceAlpha', fa, 'EdgeAlpha', 0.00);

go_c = go('LineColor', [10 10], 'LineWidth', [1 2], ...
    'Marker', [1 16], 'FontSize', fs, ...
    'labels', [1 1 0], 'Width', Width, ...
    'Legend', 0, 'MarkerSize', opts.ms, ...
    'FaceAlpha', fa, 'EdgeAlpha', 0.00);

go_ld = go('LineColor', [12 18], 'LineWidth', [1 2], ...
    'Marker', [1 16], 'FontSize', fs, ...
    'labels', [1 1 0], 'Width', Width, ...
    'Legend', 0, 'MarkerSize', opts.ms, ...
    'FaceAlpha', fa, 'EdgeAlpha', 0.00);

go_nd = go('LineColor', 12, 'LineWidth', 1, 'LineStyle', 3, ...
    'Marker', 16, 'FontSize', fs, ...
    'labels', [0 0 0], 'Width', Width, ...
    'Legend', 0, 'MarkerSize', opts.ms, ...
    'FaceAlpha', fa, 'EdgeAlpha', 0.00);

go_la = go('LineColor', [9 9], 'LineWidth', [1 2], ...
    'Marker', [1 16], 'FontSize', fs, ...
    'labels', [1 1 0], 'Width', Width, ...
    'Legend', 0, 'MarkerSize', opts.ms, ...
    'FaceAlpha', fa, 'EdgeAlpha', 0.00);

go_xa = go('LineColor', [7 7], 'LineWidth', [1 2], ...
    'Marker', [1 16], 'FontSize', fs, ...
    'labels', [1 1 0], 'Width', Width, ...
    'Legend', 0, 'MarkerSize', opts.ms, ...
    'FaceAlpha', fa, 'EdgeAlpha', 0.00);

go_gs = go('LineColor', [23 22], 'LineWidth', [1 2], ...
    'Marker', [1 16], 'FontSize', fs, ...
    'labels', [1 1 0], 'Width', Width, ...
    'Legend', 0, 'MarkerSize', opts.ms, ...
    'FaceAlpha', fa, 'EdgeAlpha', 0.00);

%%%
% 6 panels
%%%
ax1 = subplot(2, 3, 1);
plot(horzcat(F.ftt, F.ftt2, 'Fitted Temporal Trends'), go_p)
set(ax1, 'YGrid', 'on')

ax2 = subplot(2, 3, 2);
plot(horzcat(F.fcp, F.fcp2, 'Fitted Cohort Pattern'), go_c)
set(ax2, 'YGrid', 'on')
title({M.R.chromacode, ''}, 'FontSize', fs(3), ...
    'FontWeight', 'normal', 'VerticalAlignment', 'bottom');

ax3 = subplot(2, 3, 3);
plot(pc(horzcat(F.ld, F.ld2)), go_ld)
ylabel('Local Drifts')
% add the Net Drift
TMP1 = pc(F.key(3, :));
TMP2 = TMP1.curves{1}.data(1, 2:4);
hband(TMP2, go_nd)
set(ax3, 'YGrid', 'on')
ax3.YAxis.TickLabelFormat = '%g\%';

ax4 = subplot(2, 3, 4);
plot(horzcat(F.lac, F.lac2, 'Longitdinal Age Curve'), go_la)
set(ax4, 'YGrid', 'on')

ax5 = subplot(2, 3, 5);
plot(horzcat(F.cac, F.cac2, 'Cross-Sectional Age Curve'), go_xa)
set(ax5, 'YGrid', 'on')

ax6 = subplot(2, 3, 6);
plot(pc(horzcat(F.gs, F.gs2)), go_gs)
ylabel('Gradient Shifts')
set(ax6, 'YGrid', 'on')
ax6.YAxis.TickLabelFormat = '%g\%';

%%%
% harmonize the axes
%%%
harmony(M.G)

warning on

end

function harmony(G)
% Harmonize axis limits across panels

ROT = -60;

for i = 1:6
    subplot(2, 3, i)
    switch i
        case 1
            YL1 = get(gca, 'YLim');
        case 2
            YL2 = get(gca, 'YLim');
        case 3
            YL3 = get(gca, 'YLim');
        case 4
            YL4 = get(gca, 'YLim');
        case 5
            YL5 = get(gca, 'YLim');
        case 6
            YL6 = get(gca, 'YLim');
        otherwise
    end
end

% common y-axis limits for panels (1,2) and (4,5) 
cYL12 = [min([ YL1(1), YL2(1)]), max([ YL1(2), YL2(2)])];
cYL45 = [min([ YL4(1), YL5(1)]), max([ YL4(2), YL5(2)])];

% harmonization of 3 and 6
rng3 = range(YL3);
rng6 = range(YL6);

if rng3 > rng6
    % extend YL6
    d6 = (rng3 - rng6)/2;
    YL6 = YL6 + [-d6 +d6];
end

if rng6 > rng3
    % extend YL3
    d3 = (rng6 - rng3)/2;
    YL3 = YL3 + [-d3 +d3];
end

XL = G.XL([2 3 1 1 1 2]);
XT = G.XT([2 3 1 1 1 2]);

for i = 1:6
    switch i
        case {1, 2}
            subplot(2, 3, i)
            set(gca, 'YLim', cYL12, ...
                'XLim', XL{i}, ...
                'XTick', XT{i}, ...
                'XTickLabelRotation', ROT)
            TMP = unique(log(max(1, unique(round(exp(get(gca, 'YTick')))))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

        case {4, 5}
            subplot(2, 3, i)
            set(gca, 'YLim', cYL45, ...
                'XLim', XL{i}, ...
                'XTick', XT{i}, ...
                'XTickLabelRotation', ROT)
            TMP = unique(log(max(1, unique(round(exp(get(gca, 'YTick')))))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

        case 3
            subplot(2, 3, i)
            set(gca, ...
                'XLim', XL{i}, ...
                'XTick', XT{i}, ...
                'YLim', YL3, ...
                'XTickLabelRotation', ROT)

        case 6
            subplot(2, 3, i)
            set(gca, ...
                'XLim', XL{i}, ...
                'XTick', XT{i}, ...
                'YLim', YL6, ...
                'XTickLabelRotation', ROT)

        otherwise
    end

end

end

function opts = options(M, varargin)
% validate input(s) for main procedure

% default values
opts = struct('RVals', [], 'rVals', [], 'Plot', 1, 'ms', []);

% tune MarkerSize
DELTA = M.R.a(2) - M.R.a(1);
switch DELTA
    case 1
        opts.ms = 6;
    case 2
        opts.ms = 7;
    case 3
        opts.ms = 7;
    case {4, 5}
        opts.ms = 8;
    otherwise
        opts.ms = 10;
end

lArgin = varargin(1:end);
Nl = numel(lArgin);
while Nl >= 1
    if Nl == 1
        error('last property has no matching value');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('property must be specified using a string')
    end
    switch lower(propi)

        case 'plot'
            if ~(isscalar(vali) && isnumeric(vali))
                error('Plot must be a real scalar')
            else
                if ismember(vali, [0 1])
                    opts.Plot = vali;
                else
                    error('Plot must be 0 or 1')
                end
            end

        case 'rvals'
            RVals = vali;
            if ~(isreal(RVals) && isnumeric(RVals))
                error('RVals must be numeric');
            end
            % rule of 3
            if length(RVals)~=3
                error(...
                    'specify a 3-vector of reference values for age, period, and cohort');
            end
            opts.RVals = RVals;

        otherwise

    end

end

if isempty(opts.RVals) % DEFAULT

    A = M.G.APC(1);
    P = M.G.APC(2);
    % Floor function insures reference values occur in AGE, PER, and COH.
    aREF = floor((A+1)/2);
    pREF = floor((P+1)/2);
    cREF = pREF - aREF + A;
    ageref = M.G.AGE.values(aREF);
    perref = M.G.PER.values(pREF);
    cohref = M.G.COH.values(cREF);
    opts.RVals = [ageref perref cohref];
    opts.rVals = [aREF, pREF, cREF];

    opts.Default_RVals = 1;

else

    [TA, aREF] = ismember(opts.RVals(1), M.G.AGE.values);

    [TB, pREF] = ismember(opts.RVals(2), M.G.PER.values);

    [TC, cREF] = ismember(opts.RVals(3), M.G.COH.values);

    if TA && TB && TC

        opts.rVals = [aREF, pREF, cREF];
        opts.Default_RVals = 0;

    else

        msg1 = '';
        msg2 = '';
        msg3 = '';
        if ~TA
            msg1 = 'Invalid referent age. ';
        end
        if ~TB
            msg2 = 'Invalid referent period. ';
        end
        if ~TC
            msg3 = 'Invalid referent cohort. ';
        end
        error([msg1, msg2, msg3])

    end
end

end



