function varargout = hband(varargin)
% HBAND Draw horizontal reference bands.
%
% HBAND(DATA)
% HBAND(DATA, go(...))
% h = HBAND(...)
%
% * DATA can be a double or tbl.
%
% To declare specific starting and ending x-values:
%     column 1 - starting x values
%     column 2 - ending x values
%     column 3 - reference y values
%     column 4 - lower y limits
%     column 5 - upper y limits
%
% To start and end each band at the current x-axis limits:
%     column 1 - reference y values
%     column 2 - lower y limits
%     column 3 - upper y limits
%
% see also rline, vband.

INPUTS = options(varargin{:});

if eq(nargin, 1)
    PVP = ego('class', 'graphics', 'method', 'hband');
else
    PVP = varargin{2};
end

PVP = mascara(INPUTS.R, PVP);

h2 = NaN(1, INPUTS.R);
h1 = NaN(1, INPUTS.R);
for r = 1:INPUTS.R

    COLORr = PVP.MAP(r, :);

    if PVP.CI(r)
        ph = patch(INPUTS.xci(r, :)', INPUTS.yci(r, :)', ...
            COLORr, 'LineStyle', PVP.ls0{PVP.LineStyle(r)}, ...
            'Marker', 'none', ...
            'edgecolor', COLORr, ...
            'facecolor', COLORr, ...
            'FaceAlpha', PVP.FaceAlpha, ...
            'EdgeAlpha', PVP.EdgeAlpha);

        % Not to appear in any legend
        ph.Annotation.LegendInformation.IconDisplayStyle = 'off';
        h2(r) = ph(1);
    else

    end

    lh = line(INPUTS.x(r, :)', INPUTS.y(r, :)', ...
        'LineStyle', PVP.ls0{PVP.LineStyle(r)}, ...
        'Marker', PVP.mk0{PVP.Marker(r)}, ...
        'Color', COLORr, ...
        'LineWidth', PVP.LineWidth(r));
    if ~PVP.Legend
        lh.Annotation.LegendInformation.IconDisplayStyle = 'off';
    end
    h1(r) = lh(1);
end

if PVP.Legend
    % legend of patches will fail if CI includes 1's and 0's
    % when that happens, switch to legend of lines
    try
        legend(h2, INPUTS.row_labels)
    catch
        legend(h1, INPUTS.row_labels)
    end

end

% labels
if PVP.labels(1)
    xlabel(INPUTS.labels{1}, 'FontSize', PVP.FontSize(1))
end
if PVP.labels(2)
    ylabel(INPUTS.labels{2}, 'FontSize', PVP.FontSize(2))
end
if PVP.labels(3)
    title(INPUTS.fullname, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
end

set(gca, 'PlotBoxAspectRatio', [PVP.Width 1 1], 'XGrid', PVP.Grid, 'YGrid', PVP.Grid)
if ~isempty(PVP.XLim)
    set(gca, 'XLim', PVP.XLim)
end
if ~isempty(PVP.YLim)
    set(gca, 'YLim', PVP.YLim)
end

switch nargout
    case 0
    case 1
        if ~isempty(h2)
            varargout{1} = h2;
        else
            varargout{1} = h1;
        end
    case 2
        if ~isempty(h2)
            varargout{1} = h2;
            varargout{2} = h1;
        else
            varargout{1} = [];
            varargout{2} = h1;
        end
    otherwise
        error('too many output variables')
end


function INPUTS = options(varargin)
% supply validated inputs to main procedure

INPUTS = struct('R', [], 'x', [], 'y', [], 'labels', {''}, ...
    'fullname', '', ...
    'xci', [], 'yci', [], ...
    'XLim', [], 'YLim', []);

DATA = varargin{1};
C = size(DATA, 2);
R = size(DATA, 1);
INPUTS.R = R;
if ~(C==3 || C==5)
    error('input data must have 3 or 5 columns')
end
INPUTS.nColors = min(54, C);

if isa(DATA, 'double')
    DATA = tbl(...
        'data', DATA, ...
        'fullname', 'HBAND', ...
        'row_labels', cellstr(num2str((1:INPUTS.R)'))' );
elseif isa(DATA, 'tbl')
    if isscalar(DATA.row_labels) && isempty(DATA.row_labels{1})
        DATA.row_labels = cellstr(num2str((1:INPUTS.R)'))';
    end
else
end

INPUTS.row_labels = DATA.row_labels;
INPUTS.labels = DATA.labels;
INPUTS.fullname = DATA.fullname;

switch C
    case 3
        XL = get(gca, 'XLim');
        INPUTS.x = repmat(XL, R, 1);
        INPUTS.y = DATA.data(:, [1 1]);
        INPUTS.yci = DATA.data(:, [2 2 3 3]);


    case 5
        INPUTS.x = DATA.data(:, 1:2);
        INPUTS.y = DATA.data(:, [3 3]);
        INPUTS.yci = DATA.data(:, [4 4 5 5]);

end

INPUTS.xci = INPUTS.x(:,[1 2 2 1]);


