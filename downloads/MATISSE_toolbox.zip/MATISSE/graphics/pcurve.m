function varargout = pcurve(DATA, varargin)
% PCURVE Plot a curve.
%
% lego = PCURVE(DATA, go(...))
%
% * DATA can be a numeric matrix or a tbl with 2 or 4 columns
%
%     column 1 - x values
%     column 2 - values
%     column 3 - lower y limit
%     column 4 - upper y limit
%
% See also plotmatrix, pcurves.

lh = findobj(gcf, 'type', 'legend');
if ~isempty(lh)
    set(lh, 'AutoUpdate', 'off')
end

switch nargin
    case 0
        return
    case 1
        pvp = ego('class', 'graphics', 'method', 'pcurve');
    case 2
        pvp = varargin{1};
    otherwise
        error('too many inputs')
end

if ~(isa(DATA, 'tbl') | isa(DATA, 'numeric'))
    error('DATA must be numeric or a tbl')
end

[R, C] = size(DATA);
if ~(eq(C, 2) || eq(C, 4))
    error('DATA must have 2 columns or 4')
end

if isa(DATA, 'numeric')
    DATA = tbl('data', DATA);
end

% leaves us with the FIRST set of values
PVP = mascara(1, pvp);

data = DATA.data;

%%%
% are we trimming?
%%%
if pvp.Trim > 0
    data = DATA.data(pvp.Trim+1:1:R-pvp.Trim, :);
    R = R - 2*pvp.Trim;
end

if PVP.CI(1) && eq(C, 4)
    CIFlag = 1;
else
    CIFlag = 0;
end

switch CIFlag

    case 1

        % ignore spurious imaginary components in CI limits
        yci = real([data(1:R, 3)', data(R:-1:1, 4)']);
        xci = [data(1:R, 1)', data(R:-1:1, 1)'];
        %%%
        % remove undefined values from CI limits
        %%%
        INCi = ~isnan(yci);
        yci = yci(INCi);
        xci = xci(INCi);

        patch(xci, yci, PVP.MAP, ...
            'LineStyle', PVP.ls0{PVP.LineStyle}, ...
            'EdgeColor', PVP.MAP, ...
            'EdgeAlpha', PVP.EdgeAlpha, ...
            'FaceAlpha', PVP.FaceAlpha);

        lego = line(data(:, 1), data(:, 2), ...
            'Color', PVP.MAP, ...
            'MarkerFaceColor', PVP.MAP, ...
            'MarkerEdgeColor', PVP.MarkerEdgeColorMAP, ...
            'LineStyle', PVP.ls0{PVP.LineStyle}, ...
            'LineWidth', PVP.LineWidth, ...
            'Marker', PVP.mk0{PVP.Marker}, ...
            'MarkerSize', PVP.MarkerSize);

    case 0

        lego = line(data(:, 1), data(:, 2), ...
            'Color', PVP.MAP, ...
            'MarkerFaceColor', PVP.MAP, ...
            'MarkerEdgeColor', PVP.MarkerEdgeColorMAP, ...
            'LineStyle', PVP.ls0{PVP.LineStyle}, ...
            'LineWidth', PVP.LineWidth, ...
            'Marker', PVP.mk0{PVP.Marker}, ...
            'MarkerSize', PVP.MarkerSize);
end

%%%
% axis and labels
%%%
ax = gca;

if eq(PVP.Grid, 1)
    set(ax, ...
        'XGrid', true, 'YGrid', true, ...
        'GridColor', PVP.clarinet(PVP.GridColor, :), ...
        'GridLineWidth', PVP.GridWidth, ...
        'GridAlpha', 0.25)
end

if ~isempty(PVP.XLim)
    set(ax, 'XLim', PVP.XLim)
end
if ~isempty(PVP.YLim)
    set(ax, 'YLim', PVP.YLim)
end
if strcmp(PVP.YDir, 'reverse')
    set(ax, 'YDir', 'reverse')
end

ax.XAxis.FontSize = PVP.FontSize(1);
set(ax, 'TickDir', 'out', 'PlotBoxAspectRatio', [PVP.Width 1 1])

ax.YAxis.FontSize = PVP.FontSize(2);

% DATA.labels contains
% row labels label / y-axis in position 1 and
% col labels label / x-axis in position 2
% PVP.labels is a 3-vector, label x-axis (1), label y-axis (2), title (3)

if PVP.labels(1) % label the x-axis
    TMP = DATA.labels{1};
    if numel(TMP) > PVP.MaxWidth
        TMP = TMP(1:PVP.MaxWidth);
    end
    xlabel(TMP, 'FontSize', PVP.FontSize(1))
end

if PVP.labels(2)
    % no perfect choice / fullname could be very long if M resulted from
    % a matrix/horzcat operation
    TMP = DATA.labels{2};
    if numel(TMP) > PVP.MaxWidth
        TMP = TMP(1:PVP.MaxWidth);
    end
    ylabel(TMP, 'FontSize', PVP.FontSize(2))
end

if PVP.labels(3)
    TMP = DATA.fullname;
    if numel(TMP) > PVP.MaxWidth
        TMP = TMP(1:PVP.MaxWidth);
    end
    title(TMP, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
end

switch nargout
    case 0
    case 1
        varargout{1} = lego;
    otherwise
        error('too many outputs')
end

end
