function varargout = annuli(A, varargin)
% ANNULI Draw annuli.
%
% ANNULI(A)
% ANNULI(A, go(...))
% h = ANNULI(...)
%
% Draw regions between two concentric circles centered at (x0,y0), with
% inner radius r and outer radius R, starting at d1 degrees and ending at
% d2 degrees.
%
% A is a K x 6 or K x 7 double or tbl that defines K annuli:
%
%     column 1 - x0 central abscissas
%     column 2 - y0 central ordinates
%     column 3 - r  inner radii
%     column 4 - R  outer radii
%     column 5 - d1 starting location in degrees
%     column 6 - d2 ending location in degrees
%     column 7 - (optional) associated values
%
% The appearance of each annulus is controlled by go values.
%
% See also circles, squares, rectangles, ellipses.

switch nargin
    case 1
        pvp = ego('class', 'graphics', 'method', 'annuli');
    case 2
        pvp = varargin{1};
    otherwise
        error('too many inputs')
end

[K, C] = size(A);

if ~(eq(C, 6) || eq(C, 7))
    error('input must have 6 or 7 columns')
end

% matrix data is coerced to a tbl with row and column labels
D = matrix('data', A).data;

PVP = mascara(K, pvp);

h = drawannuli(D, PVP);

ax = gca;
switch PVP.axis
    case 'equal'
        axis equal
end

if ~isempty(PVP.XLim)
    set(ax, 'XLim', PVP.XLim)
end

if ~isempty(PVP.YLim)
    set(ax, 'YLim', PVP.YLim)
end

switch nargout
    case 0
    case 1
        varargout{1} = h;
    otherwise
        error('too many outputs')
end

end

% Helper Function

function h = drawannuli(D, PVP)
% draw annuli

[K, C] = size(D);

p = cell(K, 1);
t = cell(K, 1);
v = cell(K, 1);
X = NaN(K, 1);
Y = NaN(K, 1);
Z = NaN(K, 1);

x0 = D.data(:, 1);
y0 = D.data(:, 2);

r = D.data(:, 3);
if any(r < 0)
    error('inner radii must all have length >= 0')
end

R = D.data(:, 4);
if any(R < r)
    error('outer radii must all be greater than or equal to inner radii')
end

d1 = D.data(:, 5);
d2 = D.data(:, 6);
switch C
    case 7
        avals = D.data(:, 7);
        haveVals = 1;
    case 6
        avals = NaN(K, 1);
        haveVals = 0;
    otherwise
end

for k = 1:K

    ck = PVP.MAP(k, :);
    DELTA = (d2(k) - d1(k))/60;  % was 60
    pdeg = (d1(k):DELTA:d2(k))';
    if DELTA == 0
        break
    end
    prad = deg2rad(pdeg);
    xins = cos(prad).*r(k) + x0(k);
    yins = sin(prad).*r(k) + y0(k);
    xout = cos(prad).*R(k) + x0(k);
    yout = sin(prad).*R(k) + y0(k);

    XDAT = [xout; xins(end:-1:1)];
    YDAT = [yout; yins(end:-1:1)];


    TMP1 = patch(XDAT, YDAT, ck,  ...
        'FaceAlpha', PVP.FaceAlpha, ...
        'EdgeAlpha', PVP.EdgeAlpha, ...
        'EdgeColor', ck, ...
        'LineStyle', PVP.ls0{PVP.LineStyle(k)}, ...
        'LineWidth', PVP.LineWidth(k));
    if eq(k, 1)
        p = TMP1;
    else
        p(k) = TMP1;
    end

    switch PVP.TextO
        case 'horizontal'
            rv = 0;
            p30 = pdeg(30);
            l = 1*(0 <= p30 && p30 <= 90) + 2*(90 < p30 && p30 <= 180) + ...
                3*(180 < p30 && p30 <= 270) + 4*(270 < p30 && p30 <= 360);
            switch l
                case 0
                    ha = 'left';
                    va = 'bottom';
                case 1
                    ha = 'left';
                    va = 'bottom';
                case 2
                    ha = 'right';
                    va = 'bottom';
                case 3
                    ha = 'right';
                    va = 'cap';
                case 4
                    ha = 'left';
                    va = 'cap';
                otherwise
            end

        case 'orthogonal'
            rv = pdeg(30);
            ha = 'left';
            va = 'Baseline';

        case 'parallel'
            rv = pdeg(30) - 90;
            ha = 'Center';
            va = 'Bottom';

        otherwise
    end

    if PVP.Text
        TMP2 = text(xout(31), yout(31),  ...   % was 31
            D.row_labels(k), ...
            'Color', ck, ...
            'FontSize', PVP.FontSize(1), ...
            'Rotation', rv, ...
            'HorizontalAlignment', ha, ...
            'VerticalAlignment', va, 'Interpreter', 'tex');
        if eq(k, 1)
            t = TMP2;
        else
            t(k) = TMP2;
        end

    end

    if haveVals && PVP.Text
        Z(k) = avals(k);
        tv = num2str(Z(k));
        X(k) = 0.5*(xins(31+1)+xout(31+1));       % was 31
        Y(k) = 0.5*(yins(31+1)+yout(31+1));       % was 31
        TMP3 = text(X(k), Y(k), tv, ...
            'Color', ck, ...
            'FontSize', PVP.FontSize(1), ...
            'Rotation', rv, ...
            'HorizontalAlignment', ha, ...
            'VerticalAlignment', va);
        if eq(k, 1)
            v = TMP3;
        else
            v(k) = TMP3;
        end

    end

    h.p = p;
    h.t = t;
    h.v = v;
    h.Parent = 'annuli';

end

end
