function T = assemble_thumb_data(DATA, PVP)
% Create large IMG array RxC arrays of size R0xC0

% IMG data
T.IMG = NaN(...
    DATA.R0*DATA.R + DATA.R*PVP.Border + PVP.Border, ...
    DATA.C0*DATA.C + DATA.C*PVP.Border + PVP.Border);

for c = 1:DATA.C
    for r = 1:DATA.R
        rr = PVP.Border + (r-1)*(DATA.R0+PVP.Border) + (1:DATA.R0)';
        cc = PVP.Border + (c-1)*(DATA.C0+PVP.Border) + (1:DATA.C0)';
        T.IMG(rr, cc) = DATA.pcolorData{r,c};
    end
end
% Output the Labels
T.Labels.Text = DATA.Labels;

% Outputs abscissas and ordinates of the Labels
T.Labels.rLoc = NaN(DATA.R*DATA.C, 1);
T.Labels.cLoc = NaN(DATA.R*DATA.C, 1);
k = 0;
for c = 1:DATA.C
    for r = 1:DATA.R
        k = k + 1;
        T.Labels.rLoc(k, 1) = (r-0)*(DATA.R0+PVP.Border) + PVP.Border + 1.0 - (PVP.Border/2);
        T.Labels.cLoc(k, 1) = (c-1)*(DATA.C0+PVP.Border) + PVP.Border + 0.5 + ((DATA.C0+1)/2);
    end
end

end
