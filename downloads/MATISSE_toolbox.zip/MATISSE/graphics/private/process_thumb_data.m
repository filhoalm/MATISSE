function DATA = process_thumb_data(inptData, PVP, PlotMethod)
% Construct image data from input data.

[R, C] = size(inptData);
for c = 1:C
    for r = 1:R
        if ~(isnumeric(inptData{r,c}) || isa(inptData{r,c}, 'tbl') ||  isa(inptData{r,c}, 'rates') || isa(inptData{r,c}, 'matrix'))
            error(['input (' num2str(r) ', '  num2str(c)  ') has class ' class(inptData{c}) ', must be numeric, tbl, matrix or rates.'])
        end
    end
end
% All the inputs must have the same size as the first.
[R0, C0] = size(inptData{1});
Labels = cell(R, C);
pcolorData = cell(R, C);

for r = 1:R
    for c = 1:C
        [Rr, Cc] = size(inptData{r,c});
        if ~(R0==Rr && C0==Cc)
            error(['input (' num2str(r) ', ' num2str(c) ') has size ' num2str(Rr) ' x ' num2str(Cc), ...
                ' must be ' num2str(R0) ' x ' num2str(C0)])
        end

        switch class(inptData{r,c})
            case 'double'
                DATAi = inptData{r,c};
                Labels{r,c} = ['(' num2str(r), ', ' num2str(c) ')'];

            case 'tbl'
                DATAi = inptData{r,c}.data;
                Labels{r,c} = inptData{r,c}.fullname;

            case 'matrix'
                DATAi = inptData{r,c}.data.data;
                Labels{r,c} = inptData{r,c}.data.fullname;

            case 'rates'
                TMPi = type(inptData{r,c}, 'comp', 'r');
                DATAi = TMPi.data;
                Labels{r,c} = inptData{r,c}.chromacode;

            otherwise

        end

        if strcmpi(PVP.YDir, 'reverse')
            DATAi = DATAi(end:-1:1, :);
        end

        if strcmpi(PVP.Scaling, 'range')
            % evaluate bounds excluding both Infs and NaNs
            [Si, Li] = bounds(DATAi(isfinite(DATAi)), 'all', 'omitnan');
            DATAi = (DATAi - Si)./(Li - Si);
        end

        switch PlotMethod
            case 'vistagram'
                % need to add duplicate last row and last column
                DATAi = [ DATAi; DATAi(end,:)]; %#ok<*AGROW>
                DATAi = [ DATAi, DATAi(:,end)];
            otherwise
        end

        pcolorData{r,c} = DATAi;

    end

end

%%%
% set colormap axis limits
%%%
z = [pcolorData{:}];
z = z(:);
if ischar(PVP.clim)
    switch PVP.clim

        case 'tight'
            climValues = [min(z) max(z)];

        case 'symmetric'
            if min(z)<0 && max(z)>0
                climValues = [-max(abs([min(z) max(z)])) +max(abs([min(z) max(z)]))];
            else
                climValues = [min(z) max(z)];
            end

        case '95%'
            climValues = quantile(z, [0.025 0.975]);
            if eq(climValues(1), climValues(2))
                m = mean(T.data(:), 'omitnan');
                climValues = [m-1, m+1];
            end

        case '90%'
            climValues = quantile(z, [0.05 0.95]);
            if eq(climValues(1), climValues(2))
                m = mean(T.data(:), 'omitnan');
                climValues = [m-1, m+1];
            end

    end

    if eq(climValues(1), climValues(2))
        climValues = climValues + [-0.5 +0.5];
    end

    if all(isnan(climValues(:)))
        climValues = [0 1];
    end

else
    % user-specified numeric limits
    climValues = PVP.clim;
end

switch PlotMethod
    case 'vistagram'
        R0 = R0 + 1;
        C0 = C0 + 1;
    otherwise
end

DATA = struct('R0', R0, 'C0', C0, 'R', R, 'C', C, ... 
    'Labels', [], 'pcolorData', [], 'climValues', []);
DATA.Labels = Labels;
DATA.pcolorData = pcolorData;
DATA.climValues = climValues;
end
