function varargout = vbar(varargin)
% VBAR Draw vertical reference bars.
%
% VBAR(DATA)
% VBAR(DATA, go(...))
% h = VBAR(...)
%
% * DATA can be a double or tbl.
%
% To declare specific starting and ending x-values:
%     column 1 - x values
%     column 2 - reference y values
%     column 3 - lower y limits
%     column 4 - upper y limits
%
% see also rline, hband, vband.

INPUTS = options(varargin{:});

if eq(nargin, 1)
    PVP = ego('class', 'graphics', 'method', 'vbar');
else
    PVP = varargin{2};
end

PVP = mascara(INPUTS.R, PVP);

h1 = NaN(1, INPUTS.R);
h2 = NaN(1, INPUTS.R);

for r = 1:INPUTS.R

    COLORr = PVP.MAP(r, :);

    lh1 = line(INPUTS.x(r, :), INPUTS.yci(r, :), ...
        'Color', COLORr, ...
        'LineWidth', PVP.LineWidth(r), ...
        'Marker', 'none');

    % Not to appear in any legend
    lh1.Annotation.LegendInformation.IconDisplayStyle = 'off';

    h1(r) = lh1;

    lh2 = line(INPUTS.x(r, 1), INPUTS.y(r), ...
        'Color', COLORr, ...
        'LineWidth', PVP.LineWidth(r), ...
        'MarkerFaceColor', COLORr, ...
        'MarkerEdgeColor', PVP.MarkerEdgeColorMAP(r, :), ...
        'Marker', PVP.mk0{PVP.Marker(r)}, ...
        'MarkerSize', PVP.MarkerSize(r));

    if ~PVP.Legend
        lh2.Annotation.LegendInformation.IconDisplayStyle = 'off';
    end

    h2(r) = lh2;
end

if PVP.Legend
    legend(h2, INPUTS.Labels)
end

set(gca, 'PlotBoxAspectRatio', [PVP.Width 1 1], ...
    'XGrid', PVP.Grid, 'YGrid', PVP.Grid)

if ~isempty(PVP.XLim)
    set(gca, 'XLim', PVP.XLim)
end
if ~isempty(PVP.YLim)
    set(gca, 'YLim', PVP.YLim)
end


switch nargout
    case 0
    case 1
        varargout{1} = h2;
    otherwise
        error('too many output variables')
end


function INPUTS = options(varargin)
% supply validated inputs to main procedure

INPUTS = struct('R', [], 'x', [], 'y', [], 'Labels', {''}, ...
    'xci', [], 'yci', [], ...
    'XLim', [], 'YLim', []);

DATA = varargin{1};
C = size(DATA, 2);
R = size(DATA, 1);
INPUTS.R = R;
if ~(C == 4)
    error('input data must have 4 columns')
end
INPUTS.nColors = min(54, C);

if isa(DATA, 'double')
    DATA = tbl(...
        'data', DATA, ...
        'fullname', 'RBARS', ...
        'row_labels', cellstr(num2str((1:INPUTS.R)'))' );
elseif isa(DATA, 'tbl')
    if isscalar(DATA.row_labels) && isempty(DATA.row_labels{1})
        DATA.row_labels = cellstr(num2str((1:INPUTS.R)'))';
    end
else
end

INPUTS.Labels = DATA.row_labels;
INPUTS.x = DATA.data(:, [1 1]);
INPUTS.y = DATA.data(:, 2);
INPUTS.yci = DATA.data(:,[3 4]);

