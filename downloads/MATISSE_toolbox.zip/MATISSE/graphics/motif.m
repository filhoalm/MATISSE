function varargout = motif(varargin)
% MOTIF Multiple capricOrn esTimable functIons in one Figure.
%
% MOTIF(CAP1, CAP2, ..., CAPK, {'Model 1', 'Model 2', ..., 'Model K'})
% F = MOTIF(...)
%
% EF obtain from capricorn analysis CAP1 based on Model 1, CAP2 based on
% Model 2, etc.
%
% 'Model 1', ..., 'Model k' can be 'NPH', 'PHL', 'PHT', 'PHX', or 'PHA'
%
% MOTIF plots six sets of Estimable Functions:
%
%      FTT, FCP, LD (top row)
%      LAC, CAC, GS (bottom row)
%
% * F contains the data plotted
%
% See also paganinni.

N = nargin;
K = N - 1;
mod = varargin{N};

if ~(iscellstr(mod) && eq(numel(mod), K)) %#ok<ISCLSTR>
    error('wrong number of model specifications')
end
% coerce to upper case
mod = upper(mod);

ftt = cell(1, K);
fcp = cell(1, K);
ld = cell(1, K);
lac = cell(1, K);
cac = cell(1, K);
gs = cell(1, K);

LineColor = cell(1, K);
LineStyle = cell(1, K);
LineWidth = cell(1, K);
Model = cell(1, K);
labels = cell(1, K);
NK = NaN(1, K);

% StyleSheet Values for LineStyle and LineWidth
%        L    T     X    A    N
% ls = {'-', ':', '-.', '-', '--'};
%        1    3     4    1     2     go value
%
% lw = [ 2    2.5  2     1.5  1];

% compute six key EF for each of the K models
for k = 1:K

    ftt{k} = ef(varargin{k}, 'comp', 'ftt', 'Model', mod{k});
    fcp{k} = ef(varargin{k}, 'comp', 'fcp', 'Model', mod{k});
    ld{k}  = ef(varargin{k}, 'comp', 'ld', 'Model', mod{k});
    lac{k} = ef(varargin{k}, 'comp', 'lac', 'Model', mod{k});
    cac{k} = ef(varargin{k}, 'comp', 'cac', 'Model', mod{k});
    gs{k}  = ef(varargin{k}, 'comp', 'gs', 'Model', mod{k});

    labels{k} = varargin{k}.Inputs.labels;
    LineColor{k} = varargin{k}.Inputs.CapColors;

    NK(k) = numel(LineColor{k});
    JkT = ones(1, NK(k));
    switch mod{k}
        case 'PHL'
            LineStyle{k} = JkT;
            LineWidth{k} = 2 * JkT;
            Model{k} = '\bf{\color{red}PH-L:\color[rgb]{0 0 0}}\rm';
        case 'PHT'
            LineStyle{k} = 3 * JkT;
            LineWidth{k} = 2.5 * JkT;
            Model{k} = '\bf{\color{blue}PH-T:\color[rgb]{0 0 0}}\rm';
        case 'PHX'
            LineStyle{k} = 4 * JkT;
            LineWidth{k} = 2 * JkT;
            Model{k} = '\bf{\color[rgb]{0.9216 0.4706 0.2784}PH-X:\color[rgb]{0 0 0}}\rm';
        case 'PHA'
            LineStyle{k} = JkT;
            LineWidth{k} = 1.5 * JkT;
            Model{k} = '\bf{\color[rgb]{0.494  0.184  0.556}PH-A:\color[rgb]{0 0 0}}\rm';
        case 'NPH'
            LineStyle{k} = 2 * JkT;
            LineWidth{k} = JkT;
            Model{k} = '\bf{N-PH:}\rm';
    end

end

F.ftt = [ftt{:}];
F.fcp = [fcp{:}];
F.ld = [ld{:}];
F.lac = [lac{:}];
F.cac = [cac{:}];
F.gs = [gs{:}];

PVP = go(...
    'Width', 1, ...
    'LineColor', [LineColor{:}], ...
    'LineStyle', [LineStyle{:}], ...
    'LineWidth', [LineWidth{:}], ...
    'Marker', 16, ...
    'FaceAlpha', 0.10, ...
    'EdgeAlpha', 0, ...
    'Legend', 0, ...
    'FontSize', [8 8 10]);

% metadata for legend
PVP.Model = Model;
PVP.Labels = labels;
PVP.NK = NK;
map = clarinet(54);
PVP.MAP = map(PVP.LineColor, :);

figure('Position', [150 150 1500 750])

subplot(2, 4, 1)
% ftt
plot(F.ftt, PVP)
set(gca, 'YGrid', 'on')
ylabel(F.ftt.data.labels{2})

subplot(2, 4, 2)
% fcp
plot(F.fcp, PVP)
set(gca, 'YGrid', 'on')
ylabel(F.fcp.data.labels{2})

subplot(2, 4, 3)
% ld
plot(F.ld, PVP)
set(gca, 'YGrid', 'on')
ylabel(F.ld.data.labels{2})

subplot(2, 4, 5)
% lac
plot(F.lac, PVP)
set(gca, 'YGrid', 'on')
ylabel(F.lac.data.labels{2})

subplot(2, 4, 6)
% cac
plot(F.cac, PVP)
set(gca, 'YGrid', 'on')
ylabel(F.cac.data.labels{2})

subplot(2, 4, 7)
% gs
plot(F.gs, PVP)
set(gca, 'YGrid', 'on')
ylabel(F.gs.data.labels{2})

harmony(varargin{1}.Inputs.geode)

axL = subplot(2, 4, 4);
bespokeLegend(axL, PVP)

switch nargout
    case 0
    case 1
        varargout{1} = F;
    otherwise
        error('too many outputs')
end
end

%%% helper functions

function bespokeLegend(axL, PVP)

subplot(axL)

K = numel(PVP.NK);
N = sum(PVP.NK);
XL = [0 1];
YL = [0.5 N + 0.5];

set(axL, 'XLim', XL, 'YLim', YL)

y = 0;

rline(y + 0.5, 0, go('LineStyle', 3, 'LineWidth', 2, 'LineColor', 14))

y = 0;

for k = 1:K

    mod = PVP.Model{k};

    for j = 1:PVP.NK(k)

        y = y + 1;

        line([0.1, 0.3], [y, y], ...
            'LineStyle', PVP.ls0{PVP.LineStyle(y)}, ...
            'Color', PVP.MAP(y, :), ...
            'LineWidth', PVP.LineWidth(y))
        text(0.4, y, [mod, '  ', PVP.Labels{k}{j}], ...
            'FontSize', PVP.FontSize(3), 'FontName', 'AndaleMono')

    end

    rline(y + 0.5, 0, go('LineStyle', 3, 'LineWidth', 2, 'LineColor', 14))

end

set(axL, 'YDir', 'reverse', 'Visible', 'off')

end

function harmony(geo)
% Harmonize axis limits across panels

%%%
% Set up parameters for the axes.
%%%

ROT = -60;

Panels = [1 2 3 5 6 7];
for pan = 1:6
    subplot(2, 4, Panels(pan))
    switch Panels(pan)
        case 1
            YL1 = get(gca, 'YLim');
        case 2
            YL2 = get(gca, 'YLim');
        case 5
            YL5 = get(gca, 'YLim');
        case 6
            YL6 = get(gca, 'YLim');
        otherwise
    end
end

% common y-axis limits for panels (1,2) and (5,6)
cYL12 = [min([ YL1(1), YL2(1)]), max([ YL1(2), YL2(2)])];
cYL56 = [min([ YL5(1), YL6(1)]), max([ YL5(2), YL6(2)])];


XL = geo.XL([2 3 1 1 1 2]);
XT = geo.XT([2 3 1 1 1 2]);

for pan = 1:6
    switch Panels(pan)
        case {1, 2}
            subplot(2, 4, Panels(pan))
            set(gca, 'YLim', cYL12, ...
                'XLim', XL{pan}, ...
                'XTick', XT{pan}, ...
                'XTickLabelRotation', ROT)
            TMP = unique(log(max(1, unique(round(exp(get(gca, 'YTick')))))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

        case {5, 6}
            subplot(2, 4, Panels(pan))
            set(gca, 'YLim', cYL56, ...
                'XLim', XL{pan}, ...
                'XTick', XT{pan}, ...
                'XTickLabelRotation', ROT)
            TMP = unique(log(max(1, unique(round(exp(get(gca, 'YTick')))))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

        case {3, 7}
            ax = subplot(2, 4, Panels(pan));
            set(ax, ...
                'XLim', XL{pan}, ...
                'XTick', XT{pan}, ...
                'XTickLabelRotation', ROT)
            TMP1 = get(gca, 'YTick');
            TMP2 = 100 * (exp(TMP1) - 1);
            TMP3 = cellstr(num2str(TMP2', '%3.1f %%'));
            set(ax, 'YTickLabel', TMP3)

        otherwise
    end
end

end

