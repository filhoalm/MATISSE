function circlet(varargin)
% CIRCLET Circular heat maps.
%
% CIRCLET({T1, T2, ..., TK}, ANNULUS, go(...))
%
% * T1, ..., TK are double, tbl, matrix, or rates objects all the same size,
%   inside a 1 x K cell array.
%
% * ANNULUS is a six-vector: [x0 y0 r R d1 d2] (default [0 0 2.5 5 0 180])
%
% A CIRCLET plot has 3 components controlled by go values:
%
% * K circular heat maps:
%
% * K enclosing annuli set within ANNULUS:
%
% * A colorbar:
%
% See also annuli, thumbnail.

Narg = nargin;

defaultpvp = ego('class', 'graphics', 'method', 'circlet');

switch Narg
    case 1
        annulus = [0 0 2.5 5 0 180];
        pvp = defaultpvp;
    case 2
        annulus = varargin{2};
        pvp = defaultpvp;
    case 3
        annulus = varargin{2};
        pvp = varargin{3};
    otherwise
        error('too many inputs')
end

if isnumeric(annulus) && ( eq(numel(annulus), 6) || eq(numel(annulus), 7) )
    % OK
else
    error('annulus must have length 6 or 7')
end

% coerce input data to a 1xK cell array
DATA = process_thumb_data(varargin{1}(:)', pvp, 'circlet');

PVP = mascara(DATA.R*DATA.C, pvp);

T = assemble_thumb_data(DATA, PVP);

draw_circlet(T, annulus, PVP, DATA.climValues)

landmarks(T, annulus, PVP)

end

function draw_circlet(T, annulus, PVP, climValues)
% Sandwich abscissa values along the annulus

% add extra row and column
DATA = T.IMG;
% need to add duplicate last row and last column
DATA = [ DATA; DATA(end,:)];
DATA = [ DATA, DATA(:,end)];

[R, C] = size(DATA);
x0 = annulus(1);
y0 = annulus(2);
r0 = annulus(3);
R0 = annulus(4);
theta1 = deg2rad(annulus(5));
theta2 = deg2rad(annulus(6));
Width = (theta2 - theta1);
theta = theta1 + Width*(1/(C-1))*(0:1:C-1);
THETA = kron(ones(R, 1), theta);
YDAT0 = kron((1:1:R)', ones(1, C));
Ly = 1;
Uy = R;

%%%
% Set to NaN data points outside external limits
%%%
yvals = (YDAT0 - Ly)./(Uy - Ly);
YDAT0 = r0 + (R0-r0)*yvals;

%%%
% transform cartesian co-ordinates to loci on the annulus
%%%

X_annulus = x0 + YDAT0.*cos(THETA);
Y_annulus = y0 + YDAT0.*sin(THETA);

h = pcolor(X_annulus, Y_annulus, DATA);

set(h, 'FaceAlpha', PVP.FaceAlpha, 'EdgeAlpha', PVP.EdgeAlpha, ...
    'EdgeColor', PVP.clarinet(PVP.GridColor, :), ...
    'LineStyle', PVP.ls0{PVP.LineStyle(1)}, 'LineWidth', PVP.LineWidth(1))

% Make o-s look like o-s
axis image

colormap(PVP.colormap)
if ~isempty(PVP.colorbar)
    colorbar(gca, 'Location', PVP.colorbar, 'FontSize', PVP.FontSize(2))
end
clim(climValues)
set(gca, 'Visible', 'off')

end

function landmarks(T, annulus, PVP)

% use annuli to separate the data sets and add labels

%%%
% A complication is we have B = PVP.Border empty cells before the first
% heat map, and B empty cells after the last heat map, but in between, the
% adjacent heat maps share the B empty cells. Aesthetically, it looks nicer
% if the annuli fall at an equal distance in between every adjacent pair,
% start from B/2 cells before the first heat map, and end B/2 cells after
% the last heat map. 
%
% To make that happen we need to adjust the overarching annulus to start a
% bit after the starting degree, and end a bit before the last heat map.
% 
% This is done using the adjustment to the original d1 and d2 shown in the
% code.
%
% This adjustment looks the nicest when there is no visible grid, meaning
% that 'EdgeAlpha' is 0.
%%%

d10 = annulus(5);
d20 = annulus(6);
C = numel(T.Labels.Text);

TMP = PVP.Border/size(T.IMG, 2);
d1 = d10 + TMP * (d20 - d10)/2;
d2 = d20 - TMP * (d20 - d10)/2;
wr = (d2 - d1)/C;

D1 = zeros(C, 6);
D1(:, 1:4) = kron(ones(C, 1), annulus(1:4));

D1(:, 5) = d1 + wr*(0:1:C-1)';
D1(:, 6) = d1 + wr*(1:1:C)';

D1 = tbl('data', D1, 'fullname', 'Annuli', 'row_labels', T.Labels.Text);

APV = go('Grid', 0, 'FontSize', PVP.FontSize, ...
    'LineColor', PVP.LineColor, 'LineStyle', 1, ...
    'FaceAlpha', 0, 'EdgeAlpha', 1, 'Text', PVP.Text, ...
    'TextO', PVP.TextO);

annuli(D1, APV);


end