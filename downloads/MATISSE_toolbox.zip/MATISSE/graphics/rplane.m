function varargout = rplane(varargin)
% RPLANE Draw a reference plane.
%
% RPLANE(b0, bx, by)
% RPLANE(b0, bx, by, go(...))
% h = RPLANE(...)
%
% h is a patch object representing the graph of z = b0 + bx*x + by*y
% versus (x,y).
%
% For
% * h parallel to the y-axis at x == b0 set bx = Inf
% * h parallel to the x-axis at y == b0 set by = Inf
% * h parallel to the z-axis at z == b0 set bx = 0 and by = 0
%
% see also rline.

P = options(varargin{:});

situation = 2*isfinite(P.bx) + 1*isfinite(P.by);

switch situation

    case 3
        % two finite slopes.
        xy0 = [P.pvp.XLim(2) P.pvp.YLim(1)];
        xy1 = [P.pvp.XLim(2) P.pvp.YLim(2)];
        xy2 = [P.pvp.XLim(1) P.pvp.YLim(2)];
        xy3 = [P.pvp.XLim(1) P.pvp.YLim(1)];
        xy4 = [P.pvp.XLim(2) P.pvp.YLim(1)];
        xy = [xy0; xy1; xy2; xy3; xy4];

        z0 = P.b0 + P.bx.*xy0(1) + P.by*xy0(2);
        z1 = P.b0 + P.bx.*xy1(1) + P.by*xy1(2);
        z2 = P.b0 + P.bx.*xy2(1) + P.by*xy2(2);
        z3 = P.b0 + P.bx.*xy3(1) + P.by*xy3(2);
        z4 = P.b0 + P.bx.*xy4(1) + P.by*xy4(2);
        z = [z0; z1; z2; z3; z4];

    case 2
        % bx is finite, by is not: plane is parallel to x-axis.
        z00 = P.pvp.ZLim(1);
        z10 = P.pvp.ZLim(2);

        xy0 = [P.b0 P.pvp.YLim(1)];
        xy1 = [P.b0 P.pvp.YLim(2)];
        xy2 = [P.b0 P.pvp.YLim(2)];
        xy3 = [P.b0 P.pvp.YLim(1)];
        xy4 = [P.b0 P.pvp.YLim(1)];
        xy = [xy0; xy1; xy2; xy3; xy4];

        z0 = z00 ;
        z1 = z00 ;
        z2 = z10 ;
        z3 = z10 ;
        z4 = z00 ;
        z = [z0; z1; z2; z3; z4];

    case 1
        % by is finite, bx is not: plane is parallel to y-axis.
        z00 = P.pvp.ZLim(1);
        z10 = P.pvp.ZLim(2);

        xy0 = [P.pvp.XLim(1) P.b0];
        xy1 = [P.pvp.XLim(2) P.b0];
        xy2 = [P.pvp.XLim(2) P.b0];
        xy3 = [P.pvp.XLim(1) P.b0];
        xy4 = [P.pvp.XLim(1) P.b0];
        xy = [xy0; xy1; xy2; xy3; xy4];

        z0 = z00 ;
        z1 = z00 ;
        z2 = z10 ;
        z3 = z10 ;
        z4 = z00 ;
        z = [z0; z1; z2; z3; z4];

    otherwise

end

rgb = P.pvp.MAP(1, :);

h = patch(xy(:, 1), xy(:, 2), z, rgb, ...
    'LineStyle', P.pvp.ls0{P.pvp.LineStyle(1)}, ...
    'FaceColor', rgb, ...
    'LineWidth', P.pvp.LineWidth(1), ...
    'FaceAlpha', P.pvp.FaceAlpha, ...
    'EdgeAlpha', P.pvp.EdgeAlpha);

% Hide h from legends
h.Annotation.LegendInformation.IconDisplayStyle = 'off';

switch nargout
    case 0
    case 1
        varargout{1} = h;
    otherwise
        error('too many outputs')
end

end

%%%%

function P = options(varargin)

switch nargin
    case {0, 1, 2}
        error('too few inputs')

    case 3
        [b0, bx, by] = deal(varargin{:});
        pvp = ego('class', 'graphics', 'method', 'rplane');

    case 4
        [b0, bx, by, pvp] = deal(varargin{:});
    otherwise
end

if ~(isscalar(b0) && isreal(b0))
    error('b0 must be a scalar')
else
    P.b0 = b0;
end

if ~(isscalar(bx) && isreal(bx))
    error('bx must be a scalar')
else
    P.bx = bx;
end

if ~(isscalar(by) && isreal(by))
    error('by must be a scalar')
else
    P.by = by;
end

if isempty(pvp.XLim)
    pvp.XLim = get(gca, 'XLim');
end

if isempty(pvp.YLim)
    pvp.YLim = get(gca, 'YLim');
end

pvp.ZLim = get(gca, 'ZLim');

P.pvp = pvp;

end