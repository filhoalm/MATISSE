function varargout = squares(x, y, r, varargin)
% SQUARES Draw squares.
%
% SQUARES(x, y, r)
% SQUARES(x, y, r, go(...))
% h = SQUARES(...)
%
% Draw squares centered at (x,y) with radius r:
%
%                 r  
%             .................
%             .       .       .
%          r  .       .       .
%             .       .       .
%             ......(x,y)......
%             .       .       .
%             .       .       .
%             .       .       .
%             .................
%
% The appearance of each square is controlled by go values.
%
% See also circles, rectangles, ellipses, annuli.

switch nargin
    case 3
        PVP = ego('class', 'graphics', 'method', 'squares');
    case 4
        PVP = varargin{1};
    otherwise
        error('wrong number of inputs')
end

h = drawsquares(x(:), y(:) ,r(:), PVP);

ax = gca;
switch PVP.axis
    case 'equal'
        axis equal
end
if eq(PVP.Grid, 1)
    set(ax, ...
        'XGrid', true, 'YGrid', true, ...
        'GridColor', PVP.clarinet(PVP.GridColor, :), ...
        'GridLineWidth', PVP.GridWidth, ...
        'GridAlpha', 0.25)
end

if ~isempty(PVP.XLim)
    set(ax, 'XLim', PVP.XLim)
end

if ~isempty(PVP.YLim)
    set(ax, 'YLim', PVP.YLim)
end

switch nargout
    case 0
    case 1
        varargout{1} = h;
    otherwise
        error('too many outputs')
end

end

%%%%%%%%
function h = drawsquares(x, y, r, pvp)
% helper

C = numel(x);

PVP = mascara(C, pvp);

xunit = [x - r, x + r, x + r, x - r, x-r]';
yunit = [y - r, y - r, y + r, y + r, y-r]';
cmp = zeros(1, C, 3);
for c = 1:C
    cmp(1, c, 1:3) = PVP.MAP(c, :);
end

% We are drawing two sets of objects - patches without edges and lines
% lines express 'LineStyle', 'LineWidth', etc.
h.p = patch(xunit, yunit, cmp, 'FaceAlpha', PVP.FaceAlpha, 'EdgeAlpha', 0);

h.l = line(xunit, yunit);

TMP3 = num2cell(PVP.LineWidth);
[h.l.LineWidth_I] = deal(TMP3{:});

for c = 1:C
    h.l(c).LineStyle = PVP.ls0{PVP.LineStyle(c)};
    h.l(c).Color = PVP.MAP(PVP.LineColor(c), :);
end

h.Parent = 'squares';

end

