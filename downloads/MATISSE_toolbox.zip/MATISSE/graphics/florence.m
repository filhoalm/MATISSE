function F = florence(Q, varargin)
% FLORENCE Plot summary curves and gradients of an apc or sage object.
%
% F = FLORENCE(Q, 'Plot', <1 (default) or 0>)
%
% FLORENCE generates a 2 x 3 array of graphs using preset go values:
%
%     (1,1) mpc/dmpc, (1,2) mcc/dmcc, (1,3) lpa
%     (2,1) dac/ddac, (2,2) mac/dmac, (2,3) lap
%
% F is a cell array containing summary curves and gradients:
%   * F{1}   mpc, dmpc
%   * F{2}   mcc, dmcc
%   * F{3}   lpa, dlpa
%   * F{4}   dac, ddac
%   * F{5}   mac, dmac
%   * F{6}   lap, dlap
%
% See also rates/line, sage/line.

opts = options(Q, varargin{:});

fs3 = opts.FontSize(3);

F = cell(1, 6);

switch opts.Plot
 
    case 1
        warning off

        figure('Position', [100 100 1200 650])

        subplot(2, 3, 1)
        F{1} = line(Q, 'mpc');
        title('\bf{A} $mpc$', 'Interpreter', 'latex', 'FontSize', fs3)

        subplot(2, 3, 2)
        F{2} = line(Q, 'mcc');
        title('\bf{B} $mcc$', 'Interpreter', 'latex', 'FontSize', fs3)

        text(0.5, 1.2, opts.fn, ...
            'Units', 'normalized', ...
            'FontSize', fs3, ...
            'HorizontalAlignment', 'center', ...
            'VerticalAlignment', 'top', ...
            'Interpreter', 'tex')

        subplot(2, 3, 3)
        F{3} = line(Q, 'lpa');
        title('\bf{C} $\ell^{p|a}$', 'Interpreter', 'latex', 'FontSize', fs3)

        subplot(2, 3, 4)
        F{4} = line(Q, 'dac');
        title('\bf{D} $dac$', 'Interpreter', 'latex', 'FontSize', fs3)

        subplot(2, 3, 5)
        F{5} = line(Q, 'mac');
        title('\bf{E} $mac$', 'Interpreter', 'latex', 'FontSize', fs3)

        subplot(2, 3, 6)
        F{6} = line(Q, 'lap');
        title('\bf{F} $\ell^{a|p}$', 'Interpreter', 'latex', 'FontSize', fs3)

        warning on

    case 0
        
        noPlot = go('Plot', 0);
        F{1} = line(Q, 'mpc', noPlot);
        F{2} = line(Q, 'mcc', noPlot);
        F{3} = line(Q, 'lpa', noPlot);
        F{4} = line(Q, 'dac', noPlot);
        F{5} = line(Q, 'mac', noPlot);
        F{6} = line(Q, 'lap', noPlot);
        
    otherwise
end

end

function opts = options(Q, varargin)
% validate input(s) for main procedure

opts = struct('Plot', 1, 'fn', [], 'FontSize', [9 9 11]);


switch class(Q)
    case 'rates'
        opts.fn = Q.chromacode;
    case 'sage'
        opts.fn = Q.R.chromacode;
    otherwise
        error('input must be an apc or sage object')
end

lArgin = varargin(1:end);
Nl = numel(lArgin);
while Nl >= 1
    if Nl == 1
        error('last property has no matching value');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('property must be specified using a string')
    end
    switch lower(propi)

        case 'plot'
            if ~(isscalar(vali) && isnumeric(vali))
                error('Plot must be a real scalar')
            else
                if ismember(vali, [0 1])
                    opts.Plot = vali;
                else
                    error('Plot must be 0 or 1')
                end
            end

        otherwise

    end

end

end