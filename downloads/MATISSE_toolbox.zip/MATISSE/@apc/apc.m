classdef apc
    % APC apc objects contain a New Age-Period-Cohort Model.
    %
    % APC analysis is a foundational method in epidemiology, demography and
    % sociology.
    %
    % A New APC Model is fitted to a rates object. APC methods provide
    % Estimable Functions (EFs) of age, period, and cohort effects
    % including Longitudinal and Cross-Sectional Age Curves, Fitted
    % Temporal Trends, Fitted Cohort Patterns, and Local Drifts.
    %
    % See https://pubmed.ncbi.nlm.nih.gov/30306829/ for details.
    %
    % APC methods provide all of the outputs provided by the Age Period
    % Cohort Analysis Web Tool (https://dceg.cancer.gov/tools/analysis/apc)
    % and more.
    %
    % The New APC Model is the foundation for comparative and
    % semiparametric age-period-cohort analysis.
    %
    % See also apc/apc, rates, capricorn, epiphany, sage.

    properties

        R rates = rates; % input rates object
        B struct = struct('B', [], 's2', 1, 's2VAR', [], 'DEV', NaN, 'resids', []); % coefficients
        G struct = struct; % age-period-cohort design matrix

    end

    methods

        function M = apc(varargin)
            % APC Fit the New APC Model to a rates object.
            %
            % M = APC(R, ...)
            %
            % M is an apc model.
            %
            % Property-value pairs:
            %
            % Method         - 'wls' (default) or 'poisson'
            % overdispersion - 1 (true, default) or 0 (false)
            %
            % See also stem, plot.

            if nargin == 0
                % contents of an empty apc model
                M.R = rates;
                M.B = struct('B', [], 's2', 1, 's2VAR', [], 'DEV', NaN, 'resids', []);
                M.G = struct;
                return
            end

            if isa(varargin{1}, 'apc')
                M = varargin{1};
                return
            end

            % Contents of an empty apc model
            M.R = rates;
            M.B = struct('B', [], 's2', 1, 's2VAR', [], 'DEV', NaN, 'resids', []);
            M.G = struct;

            N = numel(varargin);

            if N == 0
                return
            end

            % Fit the model
            M = apc;
            m = APC(varargin{:});
            M.R = varargin{1};
            M.B = m.B;
            M.G = m.G;

        end

        function T = lrt(M)
            % LRT Likelihood Ratio and Combination Tests for an APC model.
            %
            % T = LRT(M)
            %
            % M is an apc model.
            %
            % * T.LRTests is a tbl of Likelihood Ratio Tests
            % * T.ComboTests is a tbl of Combination Tests
            %
            % See also wald, aic, stem.

            T = LRT(M);

        end

        function W = wald(M, varargin)
            % WALD Wald Tests for an APC model.
            %
            % W = WALD(M, 'Plot', <1 or 0 (default))
            %
            % M is an apc model.
            %
            % * W contains Wald significance tests of Local Drifts and
            %   Gradient shifts
            % * For consistency with the LRT tests, the covariance matrix
            %   is divided by the estimated overdisperson parameter
            %
            % See also lrt, aic, stem.

            W = WALD(M, varargin{:});

        end

        function varargout = aic(M)
            % AIC Bias-corrected aic for APC submodels.
            %
            % S = AIC(M)
            %
            % M is an apc model.
            %
            % S is a tbl of model results in rank order.
            %
            % * AIC values are evaluated using Poisson regression.
            %
            % See also lrt, wald, stem.

            S = AIC(M);

            switch nargout
                case {0, 1}
                    varargout{1} = S;
                otherwise
            end

        end

        function varargout = ef(M, varargin)
            % EF Estimable Functions of an APC model.
            %
            % F = EF(M, 'Comp', <value>, 'RVals', <value>, 'Alpha', <value>, 'Plot', <value>)
            %
            % [F, PVP, C] = EF(M, ...)
            %
            % M is an apc model. F is a matrix object. PVP contains the
            % reference values, and C the contrast matrix for F
            %
            % Property-value pairs:
            %
            % 'Comp'    -   Value        Estimable Function
            %
            %                'lac'        Longitudinal Age Curve (LAC)
            %                'cac'        Cross-Sectional Age Curve (CAC)
            %                'ftt'        Fitted Temporal Trends (FTT)
            %                'fcp'        Fitted Cohort Pattern (FCP)
            %                'ld'         Local Drifts (LD)
            %                'gs'         Gradient Shifts (GS)
            %
            %                'lac2'       LAC, quadratic
            %                'cac2'       CAC, quadratic
            %                'ftt2'       FTT, quadratic
            %                'fcp2'       FCP, quadratic
            %                'ld2'        LD,  quadratic
            %                'gs2'        GS,  quadratic
            %
            %                'ad'         Age Deviations
            %                'ad2'        Quadratic Age Deviations
            %                'adh'        HiOrd Age Deviations
            %                'pd'         Period Deviations
            %                'pd2'        Quadratic Period Deviations
            %                'pdh'        HiOrd Per Deviations
            %                'cd'         Cohort Deviations
            %                'cd2'        Quadratic Cohort Deviations
            %                'cdh'        HiOrd Coh Deviations
            %
            %                'crr'        Cohort Rate Ratios
            %                'prr'        Period Rate Ratios
            %                'xarr'       Cross-Sectional Age Rate Ratios
            %                'larr'       Longitudinal Age Rate Ratios
            %
            %                'key'        key parameters
            %
            %                'mpc'        Marginal Period Curve (MPC)
            %                'mac'        Marginal Age Curve (MAC)
            %
            %                'dlac'       gradient of LAC
            %                'dcac'       gradient of CAC
            %                'dftt'       gradient of FTT
            %                'dfcp'       gradient of FCP
            %                'dmpc'       gradient of MPC
            %                'dmac'       gradient of MAC
            %
            % 'RVals'   -    3-vector, age, period and cohort for the referent cell
            % 'Alpha'   -    0.05 (default)
            % 'Plot'    -    1 (true, uses default go values) or 0 (false, default)
            %
            % See also plot, deviations.

            [F, PVP, C] = macaroons(M, varargin{:});
            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                case 2
                    varargout{1} = F;
                    varargout{2} = PVP;
                case 3
                    varargout{1} = F;
                    varargout{2} = PVP;
                    varargout{3} = C;
                otherwise
                    error('too many outputs')
            end

        end

        function varargout = plot(M, varargin)
            % PLOT Line plots of APC Estimable Functions.
            %
            % PLOT(M)
            % PLOT(M, 'RVals', <value>)
            % F = PLOT(M, 'RVals', <value>, 'Plot', <true or false>)
            %
            % M is an apc model.
            %
            % PLOT produces a 2 x 3 array of EFs using preset go values:
            %
            %      (1,1) FTT, (1,2) FCP, (1,3) LD
            %      (2,1) LAC, (2,2) CAC, (2,3) GS
            %
            % 'RVals' - 3-vector age, period, cohort referent values
            % 'Plot'  - true or false
            %
            % F contains the EFs.
            %
            % See also ef, deviations.

            F = leonardo(M, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                otherwise
                    error('too many outputs')
            end

        end

        function varargout = stem(M, varargin)
            % STEM Stem plot of lrt, combo, wald and aic results for an APC model.
            %
            % STEM(M)
            % S = STEM(M)
            % S = STEM(M, 'Threshold', value)
            %
            % M is an apc model.
            %
            % 'Threshold' - x-axis cutoff for aic (default none)
            %
            % S containts lrt, combo, and aic outputs.
            %
            % See also lrt, aic.

            S = STEM(M, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = S;
                otherwise
                    error('too many outputs')
            end

        end

        function varargout = scan(M)
            % SCAN Plot Summary Curves and estimAble fuNctions of an apc model.
            %
            % SCAN(M)
            % [EF, F] = SCAN(M)
            %
            % M is an apc model.
            %
            % See also rates/scan, sage/scan.

            [EF, F] = kandinsky(M);

            switch nargout
                case 0
                case 1
                    varargout{1} = EF;
                case 2
                    varargout{1} = EF;
                    varargout{2} = F;
                otherwise
                    error('too many outputs')
            end

        end

        function varargout = deviations(M, varargin)
            % DEVIATIONS Plot APC deviations.
            %
            % DEVIATIONS(M)
            % F = DEVIATIONS(M, 'Plot', <true or false>)
            %
            % DEVIATIONS produces a 1 x 3 array of deviations using preset go values:
            %
            %      (1,1) ad2, adh, ad (1,2) pd2, pdh, pd (1,3) cd2, cdh, cd
            %
            % 'Plot'  - true or false
            %
            % F contains quadratic, higher-order, and combined deviations
            % for age, period, and cohort, respectively.
            %
            % See also ef, plot.

            F = tapioca(M, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                otherwise
                    error('too many outputs')
            end

        end

        function D = fv(M, varargin)
            % FV Fitted Values of an APC model.
            %
            % D = FV(M)
            % D = FV(M, 'RVals', <value>)
            %
            % M is an apc model. 
            %
            % D contains 4 decompositions of the fitted values:
            %
            %              lr = fv  + e 
            %
            %  D.ac   fv(a|c) = lac + crr + pd        
            %
            %  D.ap   fv(a|p) = cac + prr + pd
            %
            %  D.pa   fv(p|a) = ftt + xarr + cd
            %
            %  D.ca   fv(c|a) = fcp + larr + pd
            %  
            % * The decompositions are centered on u0 = fv(aref, pref)
            %
            %       (lr - u0) = (fv - u0) + e
            %
            %   therefore u0 is subtracted from lac, cac, ftt, and fcp.
            % 
            % See also ef.

            D = FV(M, varargin{:});

        end

        % end methods
    end
    % end classdef
end