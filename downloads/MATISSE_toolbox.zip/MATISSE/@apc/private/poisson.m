function [df, DEV] = poisson(Y, O, X)
% Poisson regression df and Deviance
%
% [DEV, df] = poisson(Y, O, X)

[n, p0] = size(X);
W = ones(n, 1);

% If X is rank deficient - perhaps the model is overparameterized? -
% issue and warning, remove aliased columns, force the corresponding
% beta coefficients, variances, and covariances to 0.

[~, UTFM, perm] = qr(full(X) .* W(:,ones(1, p0)), 0);

rankX = sum(abs(diag(UTFM)) > abs(UTFM(1))*max(n, p0)*eps(class(UTFM)));
if rankX < p0
    warning('X is ill conditioned or the model is overparameterized')
    perm = perm(1:rankX);
    X0 = X(:, perm);
    df = numel(perm);
else
    X0 = X;
    df = p0;
end

r0 = Y./O;
B0 = X0\log(r0+0.1*(r0==0)); % changed from 0.5
DEV = Inf;
cycles = 1;
cnvg = 0;
maxiter = 40;

while cnvg==0 && cycles<=maxiter

    B00 = B0;

    DEV0 = DEV;

    cycle = glmcycle(B0, Y, O, X0, W);
    DEV = sum(cycle.devres);
    z = cycle.eta + (1./cycle.D).*(Y - cycle.u);
    % Weighted Regression
    WX0 = (cycle.W*ones(1,rankX)).*X0;
    B0 = (X0'*WX0)\(WX0'*z);
    if abs(DEV0 - DEV) <= 1E-10 || max(abs(B00 - B0)) < 1E-10
        cnvg = 1;
    end

    cycles = cycles + 1;

end

end

function cycle = glmcycle(beta, Y, O, X, W)
% one iteration of weighted least squares algorithm for Poisson regression

eta = log(O) + X*beta;
u = exp(eta);
cycle.D = u;
cycle.V = u;
cycle.devres = 2*(W.*(Y.*log((Y+(Y==0))./(u+(u==0))) - (Y-u)));

% The generic GLM formula W = W.*(1./cycle.V).*cycle.D.^2 is prone to
% round-off errors: The specific formula for Poisson regression is not.
cycle.W = u;

cycle.u = u;
cycle.eta = (eta - log(O));

end

