function S = AIC(M)
% AIC Bias-corrected AIC for sub-models of the New Age-Period-Cohort Model.

[A, P] = size(M.R);
C = A + P - 1;
G = M.G;
D = vec(M.R);

model_name = {...
    'AGE', ...                                   %   1
    'AGE + Drift', ...                           %   2
    'AGE + Drift + per^2', ...                   %   3
    'AGE + PER', ...                             %   4
    'AGE + Drift + coh^2', ...                   %   5
    'AGE + COH', ...                             %   6
    'AGE + Drift + per^2 + coh^2', ...           %   7
    'AGE + COH + per^2', ...                     %   8
    'AGE + PER + coh^2', ...                     %   9
    'AGE + PER + COH', ...                       %  10
    'LAT + age^2', ...                           %  11
    'LAT + age^2 + Drift', ...                   %  12
    'LAT + age^2 + Drift + per^2', ...           %  13
    'LAT + age^2 + PER', ...                     %  14
    'LAT + age^2 + Drift + coh^2', ...           %  15
    'LAT + age^2 + COH', ...                     %  16
    'LAT + age^2 + Drift + per^2 + coh^2', ...   %  17
    'LAT + age^2 + COH + per^2', ...             %  18
    'LAT + age^2 + PER + coh^2', ...             %  19
    'LAT + age^2 + PER + COH', ...               %  20
    'LAT', ...                                   %  21
    'LAT + Drift', ...                           %  22
    'LAT + Drift + per^2', ...                   %  23
    'LAT + PER', ...                             %  24
    'LAT + Drift + coh^2', ...                   %  25
    'LAT + COH', ...                             %  26
    'LAT + Drift + per^2 + coh^2', ...           %  27
    'LAT + COH + per^2', ...                     %  28
    'LAT + PER + coh^2', ...                     %  29
    'LAT + PER + COH'};                          %  30

model_df = [...
    1 + 1 + 1 + (A - 3); ...                                  % 'Int + AGE', ...                                  %   1
    1 + 1 + 1 + (A - 3) + 1; ...                              % 'Int + AGE + Drift', ...                          %   2
    1 + 1 + 1 + (A - 3) + 1 + 1; ...                          % 'Int + AGE + Drift + per^2', ...                  %   3
    1 + 1 + 1 + (A - 3) + 1 + 1 + (P - 3); ...                % 'Int + AGE + PER', ...                            %   4
    1 + 1 + 1 + (A - 3) + 1 + 1; ...                          % 'Int + AGE + Drift + coh^2', ...                  %   5
    1 + 1 + 1 + (A - 3) + 1 + 1 + (C - 3); ...                % 'Int + AGE + COH', ...                            %   6
    1 + 1 + 1 + (A - 3) + 1 + 1 + 1; ...                      % 'Int + AGE + Drift + per^2 + coh^2', ...          %   7
    1 + 1 + 1 + (A - 3) + 1 + 1 + (C - 3) + 1; ...            % 'Int + AGE + COH + per^2', ...                    %   8
    1 + 1 + 1 + (A - 3) + 1 + 1 + (P - 3) + 1; ...            % 'Int + AGE + PER + coh^2', ...                    %   9
    1 + 1 + 1 + (A - 3) + 1 + 1 + (P - 3) + 1 + (C - 3); ...  % 'Int + AGE + PER + COH', ...                      %  10
    1 + 1 + 1; ...                                            % 'Int + LAT + age^2', ...                          %  11
    1 + 1 + 1 + 1; ...                                        % 'Int + LAT + age^2 + Drift', ...                  %  12
    1 + 1 + 1 + 1 + 1; ...                                    % 'Int + LAT + age^2 + Drift + per^2', ...          %  13
    1 + 1 + 1 + 1 + 1 + (P - 3); ...                          % 'Int + LAT + age^2 + PER', ...                    %  14
    1 + 1 + 1 + 1 + 1; ...                                    % 'Int + LAT + age^2 + Drift + coh^2', ...          %  15
    1 + 1 + 1 + 1 + 1 + (C - 3); ...                          % 'Int + LAT + age^2 + COH', ...                    %  16
    1 + 1 + 1 + 1 + 1 + 1; ...                                % 'Int + LAT + age^2 + Drift + per^2 + coh^2', ...  %  17
    1 + 1 + 1 + 1 + 1 + (C - 3) + 1; ...                      % 'Int + LAT + age^2 + COH + per^2', ...            %  18
    1 + 1 + 1 + 1 + 1 + (P - 3) + 1; ...                      % 'Int + LAT + age^2 + PER + coh^2', ...            %  19
    1 + 1 + 1 + 1 + 1 + (P - 3) + 1 + (C - 3);                % 'Int + LAT + age^2 + PER + COH'};                 %  20
    1 + 1; ...                                                % 'Int + LAT', ...                                  %  21
    1 + 1 + 1; ...                                            % 'Int + LAT + Drift', ...                          %  22
    1 + 1 + 1 + 1; ...                                        % 'Int + LAT + Drift + per^2', ...                  %  23
    1 + 1 + 1 + 1 + (P - 3); ...                              % 'Int + LAT + PER', ...                            %  24
    1 + 1 + 1 + 1; ...                                        % 'Int + LAT + Drift + coh^2', ...                  %  25
    1 + 1 + 1 + 1 + (C - 3); ...                              % 'Int + LAT + COH', ...                            %  26
    1 + 1 + 1 + 1 + 1; ...                                    % 'Int + LAT + Drift + per^2 + coh^2', ...          %  27
    1 + 1 + 1 + 1 + (C - 3) + 1; ...                          % 'Int + LAT + COH + per^2', ...                    %  28
    1 + 1 + 1 + 1 + (P - 3) + 1; ...                          % 'Int + LAT + PER + coh^2', ...                    %  29
    1 + 1 + 1 + 1 + (P - 3) + 1 + (C - 3)];                   % 'Int + LAT + PER + COH'};                         %  30

%%%
% Indicator which components (columns, 1, ..., 9) are included in which
% models (rows, 1, ..., 30)
%%%

model_number = (1:30)';

MODELS = logical([...
    1 1 0 1 0 0 1 0 0; ...
    1 1 1 1 0 0 1 0 0; ...
    1 1 1 1 1 0 1 0 0; ...
    1 1 1 1 1 0 1 1 0; ...
    1 1 1 1 0 1 1 0 0; ...
    1 1 1 1 0 1 1 0 1; ...
    1 1 1 1 1 1 1 0 0; ...
    1 1 1 1 1 1 1 0 1; ...
    1 1 1 1 1 1 1 1 0; ...
    1 1 1 1 1 1 1 1 1; ...
    1 1 0 1 0 0 0 0 0; ...
    1 1 1 1 0 0 0 0 0; ...
    1 1 1 1 1 0 0 0 0; ...
    1 1 1 1 1 0 0 1 0; ...
    1 1 1 1 0 1 0 0 0; ...
    1 1 1 1 0 1 0 0 1; ...
    1 1 1 1 1 1 0 0 0; ...
    1 1 1 1 1 1 0 0 1; ...
    1 1 1 1 1 1 0 1 0; ...
    1 1 1 1 1 1 0 1 1; ...
    1 1 0 0 0 0 0 0 0; ...
    1 1 1 0 0 0 0 0 0; ...
    1 1 1 0 1 0 0 0 0; ...
    1 1 1 0 1 0 0 1 0; ...
    1 1 1 0 0 1 0 0 0; ...
    1 1 1 0 0 1 0 0 1; ...
    1 1 1 0 1 1 0 0 0; ...
    1 1 1 0 1 1 0 0 1; ...
    1 1 1 0 1 1 0 1 0; ...
    1 1 1 0 1 1 0 1 1]);

%%%
% Indicator which models (rows, 1, ..., 30) can be fitted given size of
% Lexis Diagram (columns: A x P = 4+ x 4+, ...
%                                  3 x 3, ...
%                                 4+ x 2, ...
%                                  2 x 4+, ...
%                                  3 x 2, ...
%                                  2 x 3, ...
%                                 4+ x 3, ...
%                                  3 x 4+)
%%%

FEASIBILITY = logical([...
    1 0 1 0 0 0 1 0; ...  % AGE
    1 0 1 0 0 0 1 0; ...  % AGE + Drift
    1 0 0 0 0 0 0 0; ...  % AGE + Drift + per^2
    1 0 0 0 0 0 0 0; ...  % AGE + PER
    1 0 1 0 0 0 1 0; ...  % AGE + Drift + coh^2
    1 0 1 0 0 0 1 1; ...  % AGE + COH
    1 0 0 0 0 0 1 0; ...  % AGE + Drift + per^2 + coh^2
    1 0 0 0 0 0 1 0; ...  % AGE + COH + per^2
    1 0 0 0 0 0 0 0; ...  % AGE + PER + coh^2
    1 0 0 0 0 0 0 0; ...  % AGE + PER + COH
    1 1 1 0 1 0 1 0; ...  % LAT + age^2
    1 1 1 0 1 0 1 0; ...  % LAT + age^2 + Drift
    1 1 0 0 0 0 0 0; ...  % LAT + age^2 + Drift + per^2
    1 0 0 0 0 0 0 0; ...  % LAT + age^2 + PER
    1 1 1 0 1 0 1 0; ...  % LAT + age^2 + Drift + coh^2
    1 1 1 0 1 0 1 0; ...  % LAT + age^2 + COH
    1 1 0 0 0 0 0 0; ...  % LAT + age^2 + Drift + per^2 + coh^2
    1 1 0 0 0 0 0 0; ...  % LAT + age^2 + COH + per^2
    1 0 0 0 0 0 0 0; ...  % LAT + age^2 + PER + coh^2
    1 0 0 0 0 0 0 0; ...  % LAT + age^2 + PER + COH
    1 1 1 1 1 1 1 1; ...  % LAT
    1 1 1 1 1 1 1 1; ...  % LAT + Drift
    1 1 0 1 0 1 0 1; ...  % LAT + Drift + per^2
    1 0 0 1 0 0 0 1; ...  % LAT + PER
    1 1 1 1 1 1 1 1; ...  % LAT + Drift + coh^2
    1 1 1 1 1 1 1 1; ...  % LAT + COH
    1 1 0 1 0 1 0 1; ...  % LAT + Drift + per^2 + coh^2
    1 1 0 1 0 1 0 1; ...  % LAT + COH + per^2
    1 0 0 1 0 0 0 1; ...  % LAT + PER + coh^2
    1 0 0 1 0 0 0 1]);    % LAT + PER + COH

%%%
% How big is this Lexis? SOL = Size Of Lexis
%%%
SOL = NaN;
[A, P] = size(M.R);
if A>=4 && P>=4
    SOL = 1;
elseif A==3 && P==3
    SOL = 2;
elseif A>=4 && P==2
    SOL = 3;
elseif A==2 && P>=4
    SOL = 4;
elseif A==3 && P==2
    SOL = 5;
elseif A==2 && P==3
    SOL = 6;
elseif A>=4 && P==3
    SOL = 7;
elseif A==3 && P>=4
    SOL = 8;
else
end

MINC = FEASIBILITY(:, SOL);
N_0 = sum(MINC);
model_number_0 = model_number(MINC);
model_name_0 = model_name(MINC);
model_df_0 = model_df(MINC, :);
MODELS_0 = MODELS(MINC, :);

DEV_0 = NaN(N_0, 1);
DF_0 = NaN(N_0, 1);

warning off

for s = 1:N_0

    [DF_0(s), DEV_0(s)] = poisson(D.E, D.O, G.X(:, [G.Pt{MODELS_0(s, :)}]));

end

warning on


%%%
% Raw and Corrected AIC
%%%
AIC = DEV_0 + 2*model_df_0;
AICc = AIC + (2*model_df_0.*(model_df_0+1))./(A*P - model_df_0 - 1);

[~, rnk] = sort(AICc);
[~, irnk] = ismember((1:N_0)', rnk);

%%%
% Rescaled AIC
%%%
rAICc = AICc - AICc(rnk(1));

DATA = [model_df_0 DEV_0 AICc rAICc irnk model_number_0];

S = tbl(...
    'data', DATA, ...
    'fullname', 'AICc', ...
    'labels', {'AICc', 'Model'}, ...
    'row_labels', model_name_0, ...
    'col_labels', {'df', 'DEV', 'AICc', 'DELTA', 'rank', 'model number'});


% Return in rank order
[~, RankOrder] = ismember((1:N_0)', S.data(:, 5));
S = S(RankOrder, :);


