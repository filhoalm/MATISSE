function varargout = STEM(M, varargin)
% STEM STEM plot lrt, combo and aic results for an APC Model.

T = lrt(M);

T.WaldTests = wald(M);

T.AIC = sort(matrix('data', aic(M)), 4);

OPT = AIC_opt(varargin{:});

pvp = go(...
    'FontSize', [8 8 10], ...
    'labels', [1 1 0], ...
    'Marker', 1, ...
    'MarkerSize', 8, ...
    'Width', 0.5, ...
    'LineWidth', 1.5, ...
    'LineStyle', 3, ...
    'LineColor', 12, ...
    'FaceAlpha', 0.125, ...
    'EdgeAlpha', 1, ...
    'Legend', 0, ...
    'Grid', 1);

if isfinite(OPT.Threshold)
    pvp.XLim = [0 OPT.Threshold];
end

figure('Position', [150 150 1200 800])

subplot(1, 2, 1)
% this function resets the view so x is y and y is x
pop([T.WaldTests; T.ComboTests; T.LRTests], pvp)

% annotations
dar = get(gca, 'DataAspectRatio');
vband([0.5 0.5 4.5], ...
    go('LineStyle', 5, 'LineColor', 23, 'FaceAlpha', 0.05, 'EdgeAlpha', 0, 'Legend', 0))
set(gca, 'DataAspectRatio', dar)
vband([4.5 4.5 8.5], ...
    go('LineStyle', 5, 'LineColor', 47, 'FaceAlpha', 0.10, 'EdgeAlpha', 0, 'Legend', 0))
set(gca, 'DataAspectRatio', dar)

title('Hypothesis Tests', 'FontSize', pvp.FontSize(3))

% text labels zones of lrt, Wald, and combo tests
YL = get(gca, 'YLim');
text(2.25, YL(2), 'Wald', 'Rotation', -90, 'FontAngle', 'italic', ...
    'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom')

text(6.25 + 0.5, YL(2), 'Combo','Rotation', -90, 'FontAngle', 'italic', ...
    'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom')

text(14.25, YL(2), 'LRT', 'Rotation', -90, 'FontAngle', 'italic', ...
    'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom')

subplot(1, 2, 2);
pvp.labels = [1 0 0]; % prevents unwanted y-axis label
forestplot(T.AIC, 4, pvp)
title(M.R.fullname, 'FontSize', pvp.FontSize(3), 'FontWeight', 'bold')

% more annotation
txt = cellstr(num2str(T.AIC.data.data(:, 1)));
yyaxis right
ax = gca;
N = size(T.AIC, 1); % could vary from usual case with 30 models
set(ax, 'YLim', [0.5 N + 0.5], 'YTick', 1:N, 'YTickLabel', txt, ...
    'FontSize', pvp.FontSize(1), 'YColor', [0 0 0])
ylabel('Degrees of Freedom', 'FontSize', pvp.FontSize(1))

v1PVP = go('Width', 0.5, 'Legend', 0, ...
    'LineColor', 10, 'LineStyle', 5, 'FaceAlpha', 0.10, 'EdgeAlpha', 0);
vband([ax.YLim 1 0.01 2], v1PVP)

v2PVP = go('Width', 0.5, 'Legend', 0, ...
    'LineColor', 17, 'LineStyle', 5, 'FaceAlpha', 0.10, 'EdgeAlpha', 0);
vband([ax.YLim 3 2 4], v2PVP)

switch nargout
    case 0
    case 1
        varargout{1} = T;
    otherwise
        error('too many outputs')
end

end

function OPT = AIC_opt(varargin)
% Helper

OPT = struct('Threshold', Inf);

%%%
% process
%%%
if length(varargin) > 1
    lArgin = varargin(1:end);
else
    lArgin = [];
end

Nl = numel(lArgin);
if eq(Nl, 1)
    error('The property you specified has no matching value.');
end

while ge(Nl, 1)
    if eq(Nl, 1)
        error('The last property has no matching value.');
    end

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('A property must be specified using a string.')
    end

    switch lower(propi)

        case 'threshold'
            % first see if this is a real scalar
            if ~(isscalar(vali) && isreal(vali))
                error('Threshold must be a scalar');
            end
            if vali <= 0
                error('Threshold must be positive')
            end
            OPT.Threshold = vali;

        otherwise

    end

    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

end

end

