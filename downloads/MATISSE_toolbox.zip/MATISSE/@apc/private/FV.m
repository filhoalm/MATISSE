function D = FV(M, varargin)
% Decompose apc fitted rates as sums of estimable functions.

A = M.G.APC(1);
JA = ones(A, 1);

P = M.G.APC(2);
JPT = ones(1, P);

pvp = checkPVP(M, varargin{:});

y = type(M.R, 'comp', 'lr');

rl = y.row_labels;
cl = y.col_labels;

u = log(M.R.offset_tick) + reshape(M.G.X * M.B.B, A, P);
D.u0 = u(pvp.rLOC);

e = y - u; e.fullname = 'e';
y0 = y - D.u0; y0.fullname = 'log(r)'; 

%%%
% fv(a|c)
%%%
f.lac = ef(M, 'comp', 'lac', 'RVals', pvp.RVals);
f.crr = ef(M, 'comp', 'crr', 'RVals', pvp.RVals);
f.pd = ef(M, 'comp', 'pd');

[~, Ic] = ismember(M.G.COH.data, M.G.COH.values);
CRR = reshape(f.crr.data.data(Ic), A, P);
LAC0 = f.lac.data.data * JPT - D.u0;
PD = JA * f.pd.data.data';

% shared meta data
meta = {'row_labels', rl, 'col_labels', cl, 'labels', {'Age', 'Period'}};

fv = tbl('data', u - D.u0, 'fullname', 'fv(a|c)', meta{:}); 
lac0 = tbl('data', LAC0, 'fullname', 'lac', meta{:}); 
crr = tbl('data', CRR, 'fullname', 'crr', meta{:}); 
pd = tbl('data', PD, 'fullname', 'pd', meta{:}); 

% fv(a|c) = lac0 + crr + pd
D.ac = struct(...
    'lr', y0, ...
    'fv', fv, ...
    'lac', lac0, ...
    'crr', crr, ...
    'pd', pd, ...
    'e', e);

%%%
% fv(a|p)
%%%
f.cac = ef(M, 'comp', 'cac', 'RVals', pvp.RVals);
f.prr = ef(M, 'comp', 'prr', 'RVals', pvp.RVals);
f.cd = ef(M, 'comp', 'cd');

CAC0 = f.cac.data.data * JPT - D.u0;
PRR = JA * f.prr.data.data';
CD = reshape(f.cd.data.data(Ic), A, P);

fv.fullname = 'fv(a|p)';
cac0 = tbl('data', CAC0, 'fullname', 'cac', meta{:}); 
prr = tbl('data', PRR, 'fullname', 'prr', meta{:}); 
cd = tbl('data', CD, 'fullname', 'cd', meta{:}); 

% fv(a|p) = cac + prr + cd
D.ap = struct(...
    'lr', y0, ...
    'fv', fv, ...
    'cac', cac0, ...
    'prr', prr, ...
    'cd', cd, ...
    'e', e);

%%%
% fv(p|a)
%%%
f.ftt = ef(M, 'comp', 'ftt', 'RVals', pvp.RVals);
f.xarr = ef(M, 'comp', 'xarr', 'RVals', pvp.RVals);

FTT0 = JA * f.ftt.data.data' - D.u0;
XARR = f.xarr.data.data * JPT;

fv.fullname = 'fv(p|a)';
ftt = tbl('data', FTT0, 'fullname', 'ftt', meta{:}); 
xarr = tbl('data', XARR, 'fullname','xarr', meta{:}); 

% fv(p|a) = ftt + xarr + cd
D.pa = struct(...
    'lr', y0, ...
    'fv', fv, ...
    'ftt', ftt, ...
    'xarr', xarr, ...
    'cd', cd, ...
    'e', e);

%%%
% fv(c|a)
%%%
f.fcp = ef(M, 'comp', 'fcp', 'RVals', pvp.RVals);
f.larr = ef(M, 'comp', 'larr', 'RVals', pvp.RVals);

FCP0 = reshape(f.fcp.data.data(Ic), A, P) - D.u0;
LARR = f.larr.data.data * JPT;

fv.fullname = 'fv(c|a)';
fcp = tbl('data', FCP0, 'fullname', 'fcp', meta{:}); 
larr = tbl('data', LARR, 'fullname', 'larr', meta{:}); 

% fv(c|a) = fcp + larr + pd
D.ca = struct(...
    'lr', y0, ...
    'fv', fv, ...
    'fcp', fcp, ...
    'larr', larr, ...
    'pd', pd, ...
    'e', e);

end

function PVP = checkPVP(M, varargin)
% Validate inputs.

% default values
PVP = struct(...
    'RVals', [], ...
    'rVals', [], ...
    'Default_RVals', 1, ...
    'rLOC' , []);

A = M.G.APC(1);
P = M.G.APC(2);

lArgin = varargin(1:end);
Nl = numel(lArgin);
while Nl >= 1
    if Nl == 1
        error('The last property has no matching value.');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('A property must be specified using a string.')
    end
    switch lower(propi)

        case 'rvals'
            RVals = vali;
            if ~(isreal(RVals) && isnumeric(RVals))
                error('RVals must be numeric.');
            end
            % rule of 3
            if length(RVals)~=3
                error('You must specify a 3-vector of reference values for age, period, and cohort.');
            end
            PVP.RVals = RVals;

    end

end

if isempty(PVP.RVals) % DEFAULT

    % Floor function insures reference values occur in AGE, PER, and COH.
    aREF = floor((A+1)/2);
    pREF = floor((P+1)/2);
    cREF = pREF - aREF + A;
    ageref = M.G.AGE.values(aREF);
    perref = M.G.PER.values(pREF);
    cohref = M.G.COH.values(cREF);

    PVP.RVals = [ageref perref cohref];
    PVP.rVals = [aREF, pREF, cREF];
    PVP.Default_RVals = 1;
    PVP.rLOC = (A - 1) * pREF + aREF;

else

    [TA, aREF] = ismember(PVP.RVals(1), M.G.AGE.values);

    [TB, pREF] = ismember(PVP.RVals(2), M.G.PER.values);

    [TC, cREF] = ismember(PVP.RVals(3), M.G.COH.values);

    if TA && TB && TC

        PVP.rVals = [aREF, pREF, cREF];
        PVP.Default_RVals = 0;
        PVP.rLOC = (A - 1) * pREF + aREF;

    else

        msg1 = '';
        msg2 = '';
        msg3 = '';
        if ~TA
            msg1 = 'Invalid referent age. ';
        end
        if ~TB
            msg2 = 'Invalid referent period. ';
        end
        if ~TC
            msg3 = 'Invalid referent cohort. ';
        end
        error([msg1, msg2, msg3])

    end
end

end



