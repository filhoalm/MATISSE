function m = APC(varargin)
% Fit the New Age-Period-Cohort Model to a rates object.

R = varargin{1};

m = struct('B', [], 'G', []);

opt = options(varargin{2:end});

[m.B, m.G] = fit(R, opt);

end

% helper functions

function [B, G] = fit(R, opt)
% Fit APC model by weighted least squares or Poisson regression analysis

G = geode(R);

Y = R.Events(:);
O = R.Offset(:);

lY = log(Y);
lO = log(O);
X = G.X;

A = G.APC(1);
P = G.APC(2);
n = size(X, 1);
p = size(X, 2);

% knock out age curvature if A==2
if A==2
    INC = [1:3 5:p];
    X = X(:, INC);
end

% knock out period curvature if P==2
if P==2
    INC = [1:4 6:p];
    X = X(:, INC);
end

p0 = size(X, 2);

W = Y;
WX = (W*ones(1, p0)).*X;

switch opt.method
    case 'wls'
        z = (lY - lO);
        XTWX = X'*WX;

        B = XTWX\(WX'*z);
        V = inv(XTWX);

        u = O.*exp(X*B);
        wr2 = W.*(z - X*B).^2;
        resids = sign(Y - u).*sqrt(wr2);
        DEV = sum(wr2);

    case 'poisson'
        [B, DEV, V, resids] = poisson(Y, O, X, 1, 0);

end

if A==2
    % restore model to nominal size
    B = [B(1:3); 0; B(4:p0)];
    V = blkdiag(V(1:3, 1:3), 0, V(4:p0, 4:p0));
end

if P==2
    % restore model to nominal size
    B = [B(1:4); 0; B(5:end)];
    V = blkdiag(V(1:4, 1:4), 0, V(5:p0, 5:p0));
end

if opt.overdispersion
    s2 = max(1, DEV./(n - p0));
else
    s2 = 1;
end

% check for 0 DEV - can happen if P==2 or A==2
if isinf(s2)
    s2 = 1;
end
s2V = s2.*V;

tr = tbl(...
    'data', reshape(resids, size(R)), ...
    'fullname', ['Resids, ' R.fullname], ...
    'row_labels', R.age_labels, ...
    'col_labels', R.per_labels);

B = struct(...
    'B', B, ...
    's2', s2, ...
    's2VAR', s2V, ...
    'DEV', DEV, ...
    'resids', tr);

end


function [B, DEV, V, resids] = poisson(Y, O, X, W, LPO)
% Poisson regression.
%
% [B, DEV, V, resids] = poisson(Y, X, W, LP0)
%
% * Use W = 1 for unweighted analysis
% * Use LPO = 0 for models without an offset term
% * all data must be 'clean' - no missing values

[n, p0] = size(X);
if isscalar(W)
    W = W.*ones(n, 1);
end

% If X is rank deficient - perhaps the model is overparameterized? -
% issue and warning, remove aliased columns, force the corresponding
% beta coefficients, variances, and covariances to 0.

[~, UTFM, perm] = qr(full(X) .* W(:,ones(1, p0)), 0);
rankX = sum(abs(diag(UTFM)) > abs(UTFM(1))*max(n, p0)*eps(class(UTFM)));
if rankX < p0
    warning('X is ill conditioned or the model is overparameterized')
    perm = perm(1:rankX);
    X0 = X(:, perm);
else
    X0 = X;
    perm = 1:p0;
end

r0 = Y./O;
B0 = X0\log(r0+0.1*(r0==0)); % changed from 0.5
DEV = Inf;
cycles = 1;
cnvg = 0;
maxiter = 40;

while cnvg==0 && cycles<=maxiter

    B00 = B0;

    DEV0 = DEV;

    cycle = glmcycle(B0, Y, O, X0, W, LPO);
    DEV = sum(cycle.devres);
    z = cycle.eta + (1./cycle.D).*(Y - cycle.u);
    % Weighted Regression
    WX0 = (cycle.W*ones(1,rankX)).*X0;
    B0 = (X0'*WX0)\(WX0'*z);
    if abs(DEV0 - DEV) <= 1E-10 || max(abs(B00 - B0)) < 1E-10
        cnvg = 1;
    end

    cycles = cycles + 1;

end

B = zeros(p0, 1);
B(perm, 1) = B0;

resids = sqrt(abs(cycle.devres)).*sign(Y - cycle.u);

V0 = inv(X0'*WX0);
V = zeros(p0, p0);
V(perm, perm) = V0;

end

function cycle = glmcycle(beta, Y, O, X, W, LPO)
% one iteration of weighted least squares algorithm for Poisson regression

eta = log(O) + LPO + X*beta;
u = exp(eta);
cycle.D = u;
cycle.V = u;
cycle.devres = 2*(W.*(Y.*log((Y+(Y==0))./(u+(u==0))) - (Y-u)));

% The generic GLM formula W = W.*(1./cycle.V).*cycle.D.^2 is prone to
% round-off errors: The specific formula for Poisson regression is not.
cycle.W = W.*u;

cycle.u = u;
cycle.eta = (eta - log(O) - LPO);

end

function PVP = options(varargin)
% Helper function


PVP = struct('method', 'wls', 'overdispersion', 1);
N = numel(varargin);
lArgin = varargin;

while N >= 2
    propi = lArgin{1};
    vali = lArgin{2};
    switch lower(propi)

        case 'overdispersion'
            if ~isscalar(vali)
                error('overdispersion must be a scalar.')
            end
            if ~(vali==0 || vali==1)
                error('overdisperson must be 0 or 1')
            end

            PVP.overdispersion = vali;

        case 'method'
            % validate
            if ~ischar(vali)
                error('''method'' must be ''wls''  or ''poisson''')
            end
            if size(vali, 1) > 1
                error('''Direction'' must be a string, not a character matrix.')
            end
            vali = lower(vali);
            I = strncmp({'wls', 'poisson'}, vali, 1);
            if ~any(I)
                error([vali ' is an unrecognized ''method'', valid methods are ''wls'' or ''poisson'''])
            end

            PVP.method = lower(vali);

        otherwise
    end

    % setup for the next pair
    lArgin = lArgin(3:end);
    N = numel(lArgin);
    if eq(N, 1)
        error('The last property has no matching value.');
    end

end

end


