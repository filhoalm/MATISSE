function T = LRT(M)
% LRT Likelihood Ratio Tests for the New Age-Period-Cohort Model.

% set up
D = vec(M.R);
G = M.G;
X = G.X;
Pt = G.Pt;

L0 = tbl(...
    'data', NaN(12, 3), ...
    'fullname', 'Likelihood Ratio Tests', ...
    'labels', {'H0', 'LRT'}, ...
    'row_labels', {...
    'NetDrift = 0', ...                             % 1
    'THETAa = 0', ...                               % 2
    'All Higher-Order Age Deviations = 0', ...      % 3
    'All Age Deviations = 0', ...                   % 4
    'THETAp = 0', ...                               % 5
    'All Higher-Order Period Deviations = 0', ...   % 6
    'All Period Deviations = 0', ...                % 7
    'THETAc = 0', ...                               % 8
    'All Higher-Order Cohort Deviations = 0', ...   % 9
    'All Cohort Deviations = 0' ...                 % 10
    'All PRR = 1', ...                              % 11
    'All CRR = 1'}, ...                             % 12
    'col_labels',  {'LRT', 'df', 'P-Value'});

warning off

[DFapc, DEVapc] = poisson(D.E, D.O, X);

DF = NaN(12, 1);
DEV = NaN(12, 1);

[DF(1), DEV(1)] = poisson(D.E, D.O, X(:, [Pt{[1:2 4:9]}]));

[DF(2), DEV(2)] = poisson(D.E, D.O, X(:, [Pt{[1:3 5:9]}]));

[DF(3), DEV(3)] = poisson(D.E, D.O, X(:, [Pt{[1:6 8:9]}]));

[DF(4), DEV(4)] = poisson(D.E, D.O, X(:, [Pt{[1:3 5:6 8:9]}]));

[DF(5), DEV(5)] = poisson(D.E, D.O, X(:, [Pt{[1:4 6:9]}]));

[DF(6), DEV(6)] = poisson(D.E, D.O, X(:, [Pt{[1:7 9]}]));

[DF(7), DEV(7)] = poisson(D.E, D.O, X(:, [Pt{[1:4 6:7 9]}]));

[DF(8), DEV(8)] = poisson(D.E, D.O, X(:, [Pt{[1:5 7:9]}]));

[DF(9), DEV(9)] = poisson(D.E, D.O, X(:, [Pt{1:8}]));

[DF(10), DEV(10)] = poisson(D.E, D.O, X(:, [Pt{[1:5 7:8]}]));

[DF(11), DEV(11)] = poisson(D.E, D.O, X(:, [Pt{[1:2 4 6:7 9]}]));

[DF(12), DEV(12)] = poisson(D.E, D.O, X(:, [Pt{[1:2 4:5 7:8]}]));

warning on

lrt = DEV - DEVapc;
df = DFapc - DF;
P = chi2cdf(lrt, df, 'upper');
P(df==0) = NaN;
L0.data = [lrt, df, P];

T.LRTests = L0;

% Combination Tests

% All Period Deviations = 0 
% * thetap and Higher-Order Period Deviations
cp1 = min([2*L0.data(5, 3), 2*L0.data(6, 3), 1]);

% All PRR = 1 <=> FTT = constant 
% * NetDrift and thetap and Higher-Order Period Deviations
cp2 = min([3*L0.data(1, 3), 3*L0.data(5, 3), 3*L0.data(6, 3), 1]);

% All Cohort Deviations = 0
% * thetac and Higher-Order Cohort Deviations
cp3 = min([2*L0.data(8, 3), 2*L0.data(9, 3), 1]);

% All CRR = 1 <==> FCP = constant
% * NetDrift and thetac and Higher-Order Cohort Deviations
cp4 = min([3*L0.data(1, 3), 3*L0.data(8, 3), 3*L0.data(9, 3), 1]);

% format for graphics/pop / test statistic, df, P-value
CP = [cp1; cp2; cp3; cp4];
CD = [CP, [2; 3; 2; 3], CP];
T.ComboTests = tbl(...
    'data', CD, ...
    'fullname', 'Combination Tests', ...
    'row_labels', {...
    'All Period Deviations = 0', ...
    'All PRR = 1 / FTT = constant', ...
    'All Cohort Deviations = 0', ...
    'All CRR = 1 / FCP = constant'}, ...
    'col_labels', {'P-Value', 'edf', 'P-Value'});

end
