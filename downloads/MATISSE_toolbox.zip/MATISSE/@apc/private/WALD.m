function W = WALD(M, varargin)
% Wald tests of LD and GS.

opts = options(varargin{:});

[A, P] = size(M.R);
DELTA = M.R.a(2) - M.R.a(1);
fn = M.R.fullname;
s2i = 1/M.B.s2;

C1 = (1/A) * ones(A, 1);
C2 = (1/P) * ones(P, 1);

L1 = (12/(DELTA*(A-1)*A*(A+1))) * ((1:1:A)' - ((A+1)/2)*ones(A, 1));
L2 = (12/(DELTA*(P-1)*P*(P+1))) * ((1:1:P)' - ((P+1)/2)*ones(P, 1));

X1 = [C1, L1];
X2 = [C2, L2];

P10 = C1 * ((C1'*C1) \ C1');
P11 = X1 * ((X1'*X1) \ X1');

P20 = C2 * ((C2'*C2) \ C2');
P21 = X2 * ((X2'*X2) \ X2');

f1 = ef(M, 'comp', 'ld');
f2 = ef(M, 'comp', 'gs');

IMP10 = eye(A) - P10;
d1 = IMP10 * f1.data.data;
vd1 = IMP10 * f1.COV * IMP10';

IMP11 = eye(A) - P11;
d2 = IMP11 * f1.data.data;
vd2 = IMP11 * f1.COV *IMP11';

IMP20 = eye(P) - P20;
p1 = IMP20 * f2.data.data;
vp1 = IMP20 * f2.COV * IMP20';

IMP21 = eye(P) - P21;
p2 = IMP21 * f2.data.data;
vp2 = IMP21 * f2.COV *IMP21';

dfd1 = rank(vd1);
dfd2 = rank(vd2);
dfp1 = rank(vp1);
dfp2 = rank(vp2);

xd1 = d1' * (pinv(vd1 * s2i) * d1);
xd2 = d2' * (pinv(vd2 * s2i) * d2);
xp1 = p1' * (pinv(vp1 * s2i) * p1);
xp2 = p2' * (pinv(vp2 * s2i) * p2);

DTA1 = [xd1 dfd1; xd2 dfd2; xp1 dfp1; xp2 dfp2];
PVL = chi2cdf(DTA1(:, 1), DTA1(:, 2), 'upper');
DTA2 = [DTA1, PVL];

W = tbl(...
    'data', DTA2, ...
    'fullname', 'Walds Tests', ...
    'row_labels', ...
    {'LD: mean', 'LD: LS line', 'GS: mean', 'GS: LS line'}, ...
    'col_labels', {'X2', 'df', 'P-value'});

if opts.Plot
D1 = matrix(...
    'data', ...
    tbl('data', d1, ...
    'fullname', 'LD', ...
    'row_labels', M.R.age_labels, ...
    'col_labels', {'Deflections from Mean'}, ...
    'labels', {'Age Group', 'Deflections'}), ...
    'COV', vd1, ...
    'y', M.R.a);

D2 = matrix('data', ...
    tbl('data', d2, ...
    'fullname', 'LD', ...
    'row_labels', M.R.age_labels, ...
    'col_labels', {'Deflections from LS Line'}, ...
    'labels', {'Age Group', 'Deflections'}), ...
    'COV', vd2, ...
    'y', M.R.a);

P1 = matrix(...
    'data', ...
    tbl('data', p1, ...
    'fullname', 'GS', ...
    'row_labels', M.R.per_labels, ...
    'col_labels', {'Perturbations from Mean'}, ...
    'labels', {'Calendar Period', 'Perturbations'}), ...
    'COV', vp1, ...
    'y', M.R.p);

P2 = matrix('data', ...
    tbl('data', p2, ...
    'fullname', 'GS', ...
    'row_labels', M.R.per_labels, ...
    'col_labels', {'Perturbations from LS Line'}, ...
    'labels', {'Calendar Period', 'Pertubations'}), ...
    'COV', vp2, ...
    'y', M.R.p);

    waldo(f1, f2, D1, D2, P1, P2, M.G, fn, W)

end

end

%%%%

function opts = options(varargin)

opts = struct('Plot', 0);

lArgin = varargin(1:end);
Nl = numel(lArgin);

while Nl >= 1
    if Nl == 1
        error('last property has no matching value');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('property must be specified using a string')
    end
    switch lower(propi)

        case 'plot'
            if ~(isscalar(vali) && isnumeric(vali))
                error('Plot must be a real scalar')
            else
                if ismember(vali, [0 1])
                    opts.Plot = vali;
                else
                    error('Plot must be 0 or 1')
                end
            end

        otherwise

    end

end

end

function waldo(f1, f2, D1, D2, P1, P2, G, fn, W)

figure('Position', [100 100 1500 800])
clf

pvp1 = ego('class', 'matrix', 'method', 'plot');
pvp1.Width = 1;
pvp1.labels = [1 0 0];
pvp1.FontSize = [8 8 8];
pvp1.Legend = 0;
pvp1.LineColor = 12;
pvp1.MarkerSize = 7;

subplot(2, 3, 1)
plot(f1, pvp1)
ylabel('Local Drifts')
set(gca, 'XLim', G.XL{1})
YL1 = get(gca, 'YLim');

subplot(2, 3, 2)
pvp1.LineColor = 23;
plot(f2, pvp1)
ylabel('Gradient Shifts')
set(gca, 'XLim', G.XL{2})
YL2 = get(gca, 'YLim');

% harmonization of 1 and 2
rng1 = range(YL1);
rng2 = range(YL2);

if rng1 > rng2
    % extend YL2
    del2 = (rng1 - rng2)/2;
    YL2 = YL2 + [-del2 +del2];
end

if rng2 > rng1
    % extend YL1
    del1 = (rng2 - rng1)/2;
    YL1 = YL1 + [-del1 +del1];
end

subplot(2, 3, 1)
set(gca, 'YLim', YL1)
subplot(2, 3, 2)
set(gca, 'YLim', YL2)
title(fn, 'FontSize', 14, 'FontWeight', 'normal')

pvp2 = ego('class', 'matrix', 'method', 'plot');
pvp2.Width = 1;
pvp2.labels = [1 0 0];
pvp2.FontSize = [8 8 10];
pvp2.MarkerSize = [7 5];
pvp2.LineColor = [2 4];

subplot(2, 3, 4)
plot([D1, D2], pvp2)
ylabel('Local Drifts')
pvpl = go('LineColor', 53, 'LineStyle', 3, 'LineWidth', 2);
rline(0, 0, pvpl)
YL3 = get(gca, 'YLim');

subplot(2, 3, 5)
plot([P1, P2], pvp2)
ylabel('Gradient Shifts')
set(gca, 'XLim', G.XL{2})
rline(0, 0, pvpl)
YL4 = get(gca, 'YLim');

% harmonization of 3 and 4
rng3 = range(YL3);
rng4 = range(YL4);

if rng3 > rng4
    % extend YL4
    del4 = (rng3 - rng4)/2;
    YL4 = YL4 + [-del4 +del4];
end

if rng4 > rng3
    % extend YL3
    del3 = (rng4 - rng3)/2;
    YL4 = YL4 + [-del3 +del3];
end

subplot(2, 3, 4)
set(gca, 'YLim', YL3)
subplot(2, 3, 5)
set(gca, 'YLim', YL4)

subplot(1, 3, 3)
pop(W)
OPOS = get(gca, 'Position');
NPOS = OPOS;
NPOS(4) = 0.8*OPOS(4);
NPOS(2) = 1.5*OPOS(2);
set(gca, 'XDir', 'reverse', 'Position', NPOS)

end