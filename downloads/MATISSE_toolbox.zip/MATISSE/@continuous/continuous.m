classdef continuous
    % CONTINUOUS continuous objects contain numeric data vectors and metadata.
    %
    % A CONTINUOUS object is a lightweight container used by MATISSE.
    %
    % See also continuous/continuous

    properties

        data (:, 1) {mustBeNumeric} = [];           % a numeric array (coerced to a vector)
        fullname (1, :) {mustBeTextScalar} = '';    % scientific name for the vector

    end

    methods

        %%%
        % housekeeping
        %%%

        function X = continuous(varargin)
            % CONTINUOUS continuous object class constructor.
            %
            % X = CONTINUOUS('data', <array of real values>, 'fullname', 'string')
            %
            % The array of real values is coerced to a column vector. NaN
            % represents missing data.
            %
            % Example:
            %
            % Z = CONTINUOUS('data', randn(100, 1), 'fullname', 'Z');
            %
            % See also categoric.

            if nargin == 0
                % Contents of an empty tbl
                X.data = [];
                X.fullname = '';
                return
            end

            if isa(varargin{1}, 'continuous')
                X = varargin{1};
                return
            end

            % Contents of an empty boolean
            X.data = [];
            X.fullname = '';

            N = numel(varargin);

            if N == 0
                return
            end

            %%%
            % whittle the arguments
            %%%
            lArgin = varargin;

            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};

                if ~ischar(propi)
                    error('a property must be specified using a string')
                end

                switch lower(propi)

                    case 'data'
                        if ~(ismatrix(vali) && isreal(vali))
                            error('continuous data must contain real numbers')
                        end

                        X.data = vali(:);

                    case 'fullname'
                        if ischar(vali)
                            X.fullname = vali;
                        else
                            error('fullname must be a string')
                        end

                    otherwise

                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('the last property has no matching value');
                end

            end

        end

        function U = subsref(X, S)
            % SUBSREF subscripted reference for continuous objects.

            if length(S) > 1

                DEPTH = numel(S);
                for d = 1:DEPTH
                    if d == 1
                        U = subsref(X, S(1));
                    else
                        q = numArgumentsFromSubscript(U, S(d), ...
                            matlab.mixin.util.IndexingContext.Statement);
                        if q > 1
                            warning('only one output was captured')
                        end
                        U = subsref(U, S(d));
                    end
                end

            else

                switch S.type

                    case '.'

                        switch S.subs

                            case 'data'
                                U = X.data;
                            case 'fullname'
                                U = X.fullname;

                            otherwise

                        end

                    case '()'
                        % if it's a boolean, replace S.subs{1} with indices
                        if isa(S.subs{1}, 'boolean')
                            S.subs = find(S.subs{1}.data == 1);
                            S.subs = {S.subs};
                        elseif isa(S.subs{1}, 'logical')
                            S.subs = S.subs{1};
                            S.subs = {S.subs};
                        else
                            % let MATLAB handle any errors
                        end
                        NI = numel(S.subs);
                        switch NI
                            case {0, 1}
                                SUBS = cell(1, 2);
                                SUBS{1} = S.subs{1};
                                SUBS{2} = ':';
                            case 2
                                SUBS = S.subs;
                            otherwise

                        end

                        DATA = X.data(SUBS{1}(:), SUBS{2}(:));

                        U = continuous('data', DATA, 'fullname', X.fullname);

                    case '{}'

                        % do nothing
                        U = X;

                end

            end

        end

        function G = subsasgn(X, S, V)
            % SUBSASGN subscripted assignment for continuous objects.

            if length(S) > 1
                DEPTH = numel(S);
                error('index expression has depth %g, cannot be > 1', DEPTH)
            end

            switch S.type

                case '.'

                    switch S.subs
                        case 'data'
                            G = continuous('data', V, 'fullname', X.fullname);

                        case 'fullname'
                            G = X;
                            G.fullname = V;

                        otherwise

                    end

                case '()'
                    % if it's a boolean, replace S.subs{1} with indices
                    if isa(S.subs{1}, 'boolean')
                        S.subs{1} = find(S.subs{1}.data == 1);
                    end
                    NI = numel(S.subs);
                    switch NI
                        case 1
                            SUBS = cell(1, 2);
                            SUBS{1} = S.subs{1};
                            SUBS{2} = ':';
                        case 2
                            SUBS = S.subs;
                        otherwise
                            SUBS = S.subs{1:2};
                    end

                    DATA = X.data;
                    DATA(SUBS{1}(:)', SUBS{2}(:)') = V;

                    G = continuous('data', DATA, 'fullname', X.fullname);

                case '{}'
                    warning('brace indexing is undefined')

                otherwise

            end

        end

        function r = end(g, k, ~)
            % END end method for continuous objects.

            switch k
                case 1
                    r = size(g, 1);
                case 2
                    r = size(g, 2);
                otherwise
            end

        end

        function S = isempty(X)
            % ISEMPTY isempty method for continuous objects.
            %
            % S = isempty(X)
            %
            % S is logical true or false
            %
            % See also size.

            S = isempty(X.data);

        end

        function disp(X)
            % DISP command window disp of a continuous object.
            %
            % DISP(X)
            %
            % DISP produces a tbl of descriptive statistics.

            if ~isempty(X)

                TX = tbl('data', X.data, 'fullname', X.fullname);
                stats = uni(TX);
                disp(stats)

            else
                disp(tbl)

            end
        end

        function varargout = size(X, varargin)
            % SIZE size of a continuous object.
            %
            % [R, C] = size(X)
            % R = size(X, 1)
            % C = size(X, 2)
            %
            % Number of rows R and columns C of X.
            %
            % See also isempty.

            switch nargin
                case 1
                    switch nargout
                        case {0, 1}
                            varargout{1} = [size(X.data, 1), size(X.data, 2)];
                        case 2
                            varargout{1} = size(X.data, 1);
                            varargout{2} = size(X.data, 2);
                        otherwise
                            error('too many outputs')
                    end

                case 2
                    d = varargin{1};
                    switch nargout
                        case {0, 1}
                            varargout{1} = size(X.data, d(1));
                        case 2
                            varargout{1} = size(X.data, d(1));
                            varargout{2} = size(X.data, d(2));
                        otherwise
                            error('too many outputs')
                    end
            end
        end

        function L = length(X)
            % LENGTH length of a continuous object.
            %
            % L = LENGTH(X)
            %
            % See also size, isempty.

            L = size(X.data, 1);

        end

        %%%
        % unary operators
        %%%

        function F = sin(X)
            % SIN sine of a continuous object.
            %
            % F = SIN(X)
            %
            % X is interpreted as an input angle in radians.
            %
            % See also cos, tan, atan

            F = continuous(...
                'data', sin(X.data), ...
                'fullname', ['sin(' X.fullname ')']);
        end

        function F = cos(X)
            % COS cosine of a continuous object.
            %
            % F = COS(X)
            %
            % X is interpreted as an input angle in radians.
            %
            % See also sin, tan, atan

            F = continuous(...
                'data', cos(X.data), ...
                'fullname', ['cos(' X.fullname ')']);
        end

        function F = tan(X)
            % TAN tangent of a continuous object.
            %
            % F = TAN(X)
            %
            % X is interpreted as an input angle in radians.
            %
            % See also sin, cos, atan

            F = continuous(...
                'data', tan(X.data), ...
                'fullname', ['tan(' X.fullname ')']);
        end

        function F = atan(X)
            % ATAN inverse tangent of a continuous object.
            %
            % F = ATAN(X)
            %
            % X is interpreted as an input angle in radians.
            %
            % See also sin, cos, tan

            F = continuous(...
                'data', atan(X.data), ...
                'fullname', ['atan(' X.fullname ')']);
        end

        function F = sqrt(X)
            % SQRT square root of a continuous object.
            %
            % F = SQRT(X)
            %
            % Negative values in X are set to NaNs in F.
            %
            % See also power

            DATA = X.data;
            DATA(DATA < 0) = NaN;
            DATA = sqrt(DATA);
            
            F = continuous(...
                'data', DATA, ...
                'fullname', ['sqrt(' X.fullname ')']);
        end

        function F = uminus(X)
            % UMINUS unary minus of a continuous object.
            %
            % F = UMINUS(X)

            F = continuous(...
                'data', -X.data, ...
                'fullname', ['-(' X.fullname ')']);
        end

        function F = abs(X)
            % ABS absolute value of a continuous object.
            %
            % F = ABS(X)

            F = continuous(...
                'data', abs(X.data), ...
                'fullname', ['abs(' X.fullname ')']);
        end

        function F = log(X)
            % LOG natural log of a continuous object.
            %
            % F = LOG(X)
            %
            % Negative values in X are set to NaNs in F.
            %
            % See also log10, log2, exp

            DATA = X.data;
            DATA(DATA < 0) = NaN;
            DATA = log(DATA);

            F = continuous(...
                'data', DATA, ...
                'fullname', ['log(' X.fullname ')']);
        end

        function F = log2(X)
            % LOG2 log base 2 of a continuous object.
            %
            % F = log2(X)
            %
            % Negative values in X are set to NaNs in F.
            %
            % See also log, log10, exp


            DATA = X.data;
            DATA(DATA < 0) = NaN;
            DATA = log2(DATA);

            F = continuous(...
                'data', DATA, ...
                'fullname', ['log2(' X.fullname ')']);
        end

        function F = log10(X)
            % LOG10 log base 10 of a continuous object.
            %
            % F = LOG10(X)
            %
            % Negative values in X are set to NaNs in F.
            %
            % See also log, log2, exp

            DATA = X.data;
            DATA(DATA < 0) = NaN;
            DATA = log10(DATA);

            F = continuous(...
                'data', DATA, ...
                'fullname', ['log10(' X.fullname ')']);
        end

        function F = exp(X)
            % EXP exponential of a continuous object.
            %
            % F = EXP(X)
            %
            % See also log, log10, log2

            F = continuous(...
                'data', exp(X.data), ...
                'fullname', ['exp(' X.fullname ')']);
        end

        function varargout = sort(X, varargin)
            % SORT sort the data in a continuous object.
            %
            % S = SORT(X)
            % S = SORT(X, ...)
            % [S, I] = SORT(X, ...)
            %
            % See also sort

            [X.data, I] = sort(X.data, varargin{:});

            switch nargout
                case {0, 1}
                    varargout{1} = X;
                case 2
                    varargout{1} = X;
                    varargout{2} = I;
                otherwise
                    error('too many outputs')
            end

        end

        %%%
        % binary operators
        %%%

        function F = plus(X1, X2)
            % PLUS plus operator for continuous objects.
            %
            % F = X1 + Y
            % F = PLUS(X1, X2)
            %
            % One argument can be a double or scalar. The output F is
            % continuous.
            %
            % See also minus, rdivide, power, times.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                F = continuous('data', [], 'fullname', ['( - ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                F = continuous('data', [], 'fullname', ['(' X1.fullname ' - )']);
                return
            elseif (lv == 0) && (lw == 0)
                F = continuous;
                return
            end
            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl

                case {1}
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('  namev  ' + '  namew  ')'];
                    DATA = vdat + wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(vdat);
                    namew = X2.fullname;
                    nameo = ['('  namev  ' + '  namew  ')'];
                    DATA = vdat + wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(wdat);
                    nameo = ['('  namev  ' + '  namew  ')'];
                    DATA = vdat + wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end

        end

        function F = minus(X1, X2)
            % MINUS minus operator for continuous objects.
            %
            % F = X1 - Y
            % F = MINUS(X1, X2)
            %
            % One argument can be a double or scalar. The output F is
            % continuous.
            %
            % See also plus, rdivide, power, times.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                F = continuous('data', [], 'fullname', ['( - ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                F = continuous('data', [], 'fullname', ['(' X1.fullname ' - )']);
                return
            elseif (lv == 0) && (lw == 0)
                F = continuous;
                return
            end
            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl

                case {1}
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('  namev  ' - '  namew  ')'];
                    DATA = vdat - wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(vdat);
                    namew = X2.fullname;
                    nameo = ['('  namev  ' - '  namew  ')'];
                    DATA = vdat - wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(wdat);
                    nameo = ['('  namev  ' - '  namew  ')'];
                    DATA = vdat - wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end

        end

        function F = rdivide(X1, X2)
            % RDIVIDE rdivide operator for continuous objects.
            %
            % F = X1 ./ Y
            % F = RDIVIDE(X1, X2)
            %
            % One argument can be a double or scalar. The output F is
            % continuous.
            %
            % See also plus, minus, power, times.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                F = continuous('data', [], 'fullname', ['( ./ ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                F = continuous('data', [], 'fullname', ['(' X1.fullname ' ./ )']);
                return
            elseif (lv == 0) && (lw == 0)
                F = continuous;
                return
            end
            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl

                case {1}
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('  namev  ' ./ '  namew  ')'];
                    DATA = vdat ./ wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(vdat);
                    namew = X2.fullname;
                    nameo = ['('  namev  ' ./ '  namew  ')'];
                    DATA = vdat ./ wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(wdat);
                    nameo = ['('  namev  ' ./ '  namew  ')'];
                    DATA = vdat ./ wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end

        end

        function F = times(X1, X2)
            % TIMES times operator for continuous objects.
            %
            % F = X1 .* Y
            % F = TIMES(X1, X2)
            %
            % One argument can be a double or scalar. The output F is
            % continuous.
            %
            % See also plus, minus, power, rdivide.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                F = continuous('data', [], 'fullname', ['( .* ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                F = continuous('data', [], 'fullname', ['(' X1.fullname ' .* )']);
                return
            elseif (lv == 0) && (lw == 0)
                F = continuous;
                return
            end
            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl

                case {1}
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('  namev  ' .* '  namew  ')'];
                    DATA = vdat .* wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(vdat);
                    namew = X2.fullname;
                    nameo = ['('  namev  ' .* '  namew  ')'];
                    DATA = vdat .* wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(wdat);
                    nameo = ['('  namev  ' .* '  namew  ')'];
                    DATA = vdat .* wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end

        end

        function F = power(X1, X2)
            % POWER power operator for continuous objects.
            %
            % F = X1 .^ Y
            % F = POWER(X1, X2)
            %
            % One argument can be a double or scalar. The output F is
            % continuous.
            %
            % See also plus, minus, rdivide, times.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                F = continuous('data', [], 'fullname', ['( .^ ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                F = continuous('data', [], 'fullname', ['(' X1.fullname ' .^ )']);
                return
            elseif (lv == 0) && (lw == 0)
                F = continuous;
                return
            end
            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl

                case {1}
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('  namev  ' .^ '  namew  ')'];
                    DATA = vdat .^ wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(vdat);
                    namew = X2.fullname;
                    nameo = ['('  namev  ' .^ '  namew  ')'];
                    DATA = vdat .^ wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(wdat);
                    nameo = ['('  namev  ' .^ '  namew  ')'];
                    DATA = vdat .^ wdat;
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end
        end

        function F = max(X1, X2)
            % MAX max operator for continuous objects.
            %
            % F = MAX(X1, X2)
            %
            % One argument can be a double or scalar. The output F is
            % continuous.
            %
            % See also min.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                F = continuous('data', [], 'fullname', ['max([], ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                F = continuous('data', [], 'fullname', ['max(' X1.fullname ', [])']);
                return
            elseif (lv == 0) && (lw == 0)
                F = continuous;
                return
            end
            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl

                case {1}
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['max('  namev  ', '  namew  ')'];
                    DATA = max(vdat, wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(vdat);
                    namew = X2.fullname;
                    nameo = ['max('  namev  ', '  namew  ')'];
                    DATA = max(vdat, wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(wdat);
                    nameo = ['max('  namev  ', '  namew  ')'];
                    DATA = max(vdat, wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end

        end

        function F = min(X1, X2)
            % MIN min operator for continuous objects.
            %
            % F = MIN(X1, X2)
            %
            % One argument can be a double or scalar. The output F is
            % continuous.
            %
            % See also max.

            if eq(nargin, 1)
                error('you need to specify two input arguments')
            end
            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                F = continuous('data', [], 'fullname', ['min([], ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                F = continuous('data', [], 'fullname', ['min(' X1.fullname ', [])']);
                return
            elseif (lv == 0) && (lw == 0)
                F = continuous;
                return
            end
            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl

                case {1}
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['min('  namev  ', '  namew  ')'];
                    DATA = min(vdat, wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(vdat);
                    namew = X2.fullname;
                    nameo = ['min('  namev  ', '  namew  ')'];
                    DATA = min(vdat, wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(wdat);
                    nameo = ['min('  namev  ', '  namew  ')'];
                    DATA = min(vdat, wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    F = continuous(...
                        'data', DATA, ...
                        'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end

        end

        %%%
        % comparison operators
        %%%

        function B = eq(X1, X2)
            % EQ (equal to) comparison operator for continuous objects.
            %
            % B = X1 == X2
            % B = EQ(X1, X2)
            %
            % One argument can be a double or scalar. The output B is
            % boolean.
            %
            % If X1 or X2 is NaN, all values in B are NaN. Use isnan to
            % identify NaN values in X1 or X2.
            %
            % See also isnan, ne, ge, gt, le, lt.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                B = boolean('data', [], 'fullname', ['( == ' w.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                B = boolean('data', [], 'fullname', ['(' v.fullname ' == )']);
                return
            elseif (lv == 0) && (lw == 0)
                B = boolean;
                return
            end
            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl
                case 1
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('    namev     ' == '     namew    ')'];
                    DATA = +(vdat == wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data', DATA, 'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(X1);
                    namew = X2.fullname;
                    nameo = ['('    namev     ' == '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat == wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(X2);
                    nameo = ['('    namev     ' == '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat == wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end

        end

        function B = isnan(X)
            % ISNAN isnan for continuous objects.
            %
            % B = ISNAN(X)
            %
            % The output B is boolean with no missing values.
            %
            % See also eq.

            B = boolean('data', isnan(X.data), ...
                'fullname', [X.fullname ' == NaN']);

        end

        function B = ne(X1, X2)
            % NE (not equal to) comparison operator for continuous objects.
            %
            % B = X1 ~= X2
            % B = NE(X1, X2)
            %
            % One argument can be a double or scalar. The output B is
            % boolean.
            %
            % See also eq, ge, gt, le, lt.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                B = boolean('data', [], 'fullname', ['( ~= ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                B = boolean('data', [], 'fullname', ['(' X1.fullname ' ~= )']);
                return
            elseif (lv == 0) && (lw == 0)
                B = boolean;
                return
            end
            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl
                case 1
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('    namev     ' ~= '     namew    ')'];
                    DATA = +(vdat ~= wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data', DATA, 'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(X1);
                    namew = X2.fullname;
                    nameo = ['('    namev     ' ~= '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat ~= wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(X2);
                    nameo = ['('    namev     ' ~= '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat ~= wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end

        end

        function B = gt(X1, X2)
            % GT (greater than) comparison operator for continuous objects.
            %
            % B = X1 > X2
            % B = GT(X1, X2)
            %
            % The data values are compared. One argument can be a double or
            % scalar. The output B is boolean.
            %
            % See also eq, ne, ge, le, lt.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                B = boolean('data', [], 'fullname', ['( > ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                B = boolean('data', [], 'fullname', ['(' X1.fullname ' > )']);
                return
            elseif (lv == 0) && (lw == 0)
                B = boolean;
                return
            end

            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl
                case 1
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('    namev     ' > '     namew    ')'];
                    DATA = +(vdat > wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data', DATA, 'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(X1);
                    namew = X2.fullname;
                    nameo = ['('    namev     ' > '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat > wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(X2);
                    nameo = ['('    namev     ' > '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat > wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end

        end

        function B = ge(X1, X2)
            % GE (greater than or equal to) comparison operator for continuous objects.
            %
            % B = X1 >= X2
            % B = GE(X1, X2)
            %
            % The data values are compared. One argument can be a double or
            % scalar. The output B is boolean.
            %
            % See also eq, ne, gt, le, lt.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                B = boolean('data', [], 'fullname', ['( >= ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                B = boolean('data', [], 'fullname', ['(' X1.fullname ' >= )']);
                return
            elseif (lv == 0) && (lw == 0)
                B = boolean;
                return
            end

            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl
                case 1
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('    namev     ' >= '     namew    ')'];
                    DATA = +(vdat >= wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data', DATA, 'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(X1);
                    namew = X2.fullname;
                    nameo = ['('    namev     ' >= '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat >= wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(X2);
                    nameo = ['('    namev     ' >= '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat >= wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end
        end

        function B = lt(X1, X2)
            % LT (less than) comparison operator for continuous objects.
            %
            % B = X1 < X2
            % B = LT(X1, X2)
            %
            % One argument can be a double or scalar. The output B is
            % boolean.
            %
            % See also eq, ne, ge, gt, le.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                B = boolean('data', [], 'fullname', ['( < ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                B = boolean('data', [], 'fullname', ['(' X1.fullname ' < )']);
                return
            elseif (lv == 0) && (lw == 0)
                B = boolean;
                return
            end

            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl
                case 1
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('    namev     ' < '     namew    ')'];
                    DATA = +(vdat < wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data', DATA, 'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(X1);
                    namew = X2.fullname;
                    nameo = ['('    namev     ' < '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat < wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(X2);
                    nameo = ['('    namev     ' < '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat < wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end

        end

        function B = le(X1, X2)
            % LE (less than or equal to) comparison operatior for continuous objects.
            %
            % B = X1 <= X2
            % B = LE(X1, X2)
            %
            % The data values are compared. One argument can be a double or
            % scalar. The output B is boolean.
            %
            % See also eq, ne, ge, gt, lt.

            if isa(X1, 'numeric')
                vdat = X1;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end
            if isa(X2, 'numeric')
                wdat = X2;
                lw = numel(wdat);
                vdat = X1.data;
                lv = numel(vdat);
            end
            if isa(X1, 'continuous') && isa(X2, 'continuous')
                vdat = X1.data;
                lv = numel(vdat);
                wdat = X2.data;
                lw = numel(wdat);
            end

            if (lv == 0) && (lw ~= 0)
                B = boolean('data', [], 'fullname', ['( <= ' X2.fullname ')']);
                return
            elseif (lw == 0) && (lv ~= 0)
                B = boolean('data', [], 'fullname', ['(' X1.fullname ' <= )']);
                return
            elseif (lv == 0) && (lw == 0)
                B = boolean;
                return
            end

            % lengths must be the same, or one length must be 1; determine case
            cl = ...
                1*(lv==lw) + ...
                2*(lv==1 & lw>1) + ...
                3*(lv>1 & lw==1) + ...
                4*((lv>1 & lw>1) & (lv~=lw));

            switch cl
                case 1
                    % data vectors are the same length
                    namev = X1.fullname;
                    namew = X2.fullname;
                    nameo = ['('    namev     ' <= '     namew    ')'];
                    DATA = +(vdat <= wdat);
                    % crucial to reset existing NaN's
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data', DATA, 'fullname', nameo);

                case 2
                    % the first vector is a scalar - proceed
                    namev = num2str(X1);
                    namew = X2.fullname;
                    nameo = ['('    namev     ' <= '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat <= wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 3
                    % the second vector is a scalar - proceed
                    namev = X1.fullname;
                    namew = num2str(X2);
                    nameo = ['('    namev     ' <= '     namew    ')'];
                    % crucial to reset existing NaN's
                    DATA = +(vdat <= wdat);
                    DATA(isnan(vdat) | isnan(wdat)) = NaN;
                    B = boolean('data' , DATA, 'fullname', nameo);

                case 4
                    % oops
                    error('continuous variables must have the same length')

                otherwise
                    error('invalid arguments')
            end
        end

        %%%
        % binning and alignment
        %%%

        function C = bin(X, varargin)
            % BIN partion continuous data into bins using histcounts.
            %
            % C = BIN(X, nbins)
            % C = BIN(X, edges)
            % C = BIN(X, ...)
            %
            % BIN produces a categoric.
            %
            % see also histcounts

            [~, Edges, BinData] = histcounts(X.data, varargin{:});
            TMP = cellstr(num2str(Edges'));
            l = str('data', ['*'; TMP], 'fullname', 'Category Labels');
            blb = ['[' l(1:end-1) ', ' l(2:end) ')'];

            C = categoric(...
                'data', BinData, ...
                'fullname', X.fullname, ...
                'values', 0:numel(Edges)-1, ...
                'labels', blb.data);
            % convert missing data to NaN
            C = value2nan(C, 0);

        end

        function varargout = align(Y, C, varargin)
            % ALIGN align continuous data according to another variable.
            %
            % Y = ALIGN(y, c)
            % Y = ALIGN(y, c, x)
            % [Y, X] = ALIGN(y, c, x)
            %
            % y - continuous object to ALIGN
            % c - categoric, boolean, continuous or double
            % x - optional categoric, continuous, tbl or double
            % Y - tbl of aligned y values
            % X - tbl of corresponding x values, if x is specified
            %
            % * Rows of Y contain sorted y values conditional on c values,
            %   optionally sorted by x values.
            %
            % * The number of columns of Y depends on the results of the
            %   alignment.
            %
            % * Y will have a 'ragged right' trailing edge because rows
            %   with fewer aligned values are padded with NaNs.

            switch nargout
                case 1
                    varargout{1} = ALIGN(Y, C, varargin{:});
                case 2
                    [varargout{1}, varargout{2}] = ALIGN(Y, C, varargin{:});
                otherwise
            end

        end

    end

end



