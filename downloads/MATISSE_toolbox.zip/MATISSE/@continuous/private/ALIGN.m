function varargout = ALIGN(y, c, varargin)
% CONTINUOUS/ALIGN ALIGN y values according to another variable.

INPUTS = validate_inputs(y, c, varargin{:});

R = length(INPUTS.c.values);
n = length(INPUTS.y);

[~, cLOC] = ismember(INPUTS.c.data, INPUTS.c.values);
cLOCvalues = 1:R;

Nc = histcounts(cLOC, 'binmethod', 'integers');

C = max(Nc);
TyDAT = NaN(R, C);
if ~isempty(INPUTS.x)
    TxDAT = NaN(R, C);
end

S = (1:1:n)';

for v = 1:R
    if Nc(v)>0
        Iv = S(cLOC==cLOCvalues(v));
        yv = INPUTS.y.data(Iv)';

        if isempty(INPUTS.x)

            %%%
            % Assign the y-sorted values of y to consecutive rows of Ty.
            %%%
            yv = sort(yv);
            TyDAT(v, (1:Nc(v))) = yv;

        else

            %%%
            % Assign the x-sorted values of y to consecutive rows of Ty.
            %%%
            xv = INPUTS.x.data(Iv');
            [xvs, xvJ] = sort(xv);
            yvs = yv(xvJ);
            TyDAT(v, (1:Nc(v))) = yvs;
            TxDAT(v, (1:Nc(v))) = xvs;

        end

    end
end

%%%
% Format Ty as a tbl object.
%%%
if isempty(INPUTS.x)
    fny = INPUTS.y.fullname;
    fnx = '';

else
    fny = INPUTS.y.fullname;
    fnx = INPUTS.x.fullname;

end

rl = INPUTS.c.labels;

% Because TyDAT may be ragged right, our information about the relationship
% between columns of TyDAT and values of x is contained in TxDAT. So column
% labels of each default to 1, 2, ..., C
cl = cellstr(char(num2str((1:C)')));

Y = tbl('data', TyDAT, 'fullname', fny, 'row_labels', rl, 'col_labels', cl);

if ~isempty(INPUTS.x)
    X = tbl('data', TxDAT, 'fullname', fnx, 'row_labels', rl, 'col_labels', cl);
else
    X = [];
end

switch nargout
    case {0, 1}
        varargout{1} = Y;
    case 2
        varargout{1} = Y;
        varargout{2} = X;
    otherwise
        error('too many outputs')
end

end

%%%%%%%%%%

function INPUTS = validate_inputs(y, c, varargin)

INPUTS.y = y;

if length(y)~=length(c)
    error('y and c must have the same length.')
end

switch class(c)
    case 'categoric'
        % you can't align values w.r.t. a missing category
        INPUTS.c = squeeze(c);
    case 'boolean'
        INPUTS.c = bool2cat(c);
    case 'continuous'
        INPUTS.c = categoric('data', c.data, 'fullname', c.fullname);
    case 'double'
        INPUTS.c = categoric('data', c, 'fullname', inputname(2));
    otherwise
        error('c must be a categoric, boolean, continuous or double')
end

switch length(varargin)
    case 0
        INPUTS.x = continuous;
        INPUTS.x_labels = {};
    case 1
        x = varargin{1};
        if isa(x, 'continuous')
            INPUTS.x_labels = {};
        elseif isa(x, 'double')
            INPUTS.x_labels = {};
            x = continuous('data', x(:), 'fullname', inputname(3));
        elseif isa(x, 'categoric')
            INPUTS.x_labels = x.labels;
            x = continuous('data', x.data(:), 'fullname', x.fullname);
        elseif isa(x, 'tbl')
            INPUTS.x_labels = x.col_labels;
            x = continuous('data', x.data(:), 'fullname', x.fullname);
        else
            error('invalid x data')
        end

        if length(x)==length(y)
            INPUTS.x = x;
        else
            error('x must have the same length as y and c')
        end
    otherwise
        error('too many inputs')

end

end
