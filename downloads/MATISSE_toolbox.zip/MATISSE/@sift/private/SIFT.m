function [f, OPTS] = SIFT(M, P, opts)
% Singular values adaptive kernel filtration.

% Validate options
OPTS = options(M, opts);

f = struct(...
    'TMA', matrix, ...
    's2hat', [], ...
    'AIC', [], ...
    'GAP', [], ...
    'Akaike', [], ...
    'Pie', []);

%%%
% Calculate weighted grand means
%%%
RC = numel(M.data.data);
vY = M.data.data(:);

switch M.type

    case {0, 1}
        ybar = mean(vY);

    case 2
        w = 1./M.COV(:);
        % fix w values of Inf
        w(~isfinite(w)) = 0;
        w = w./sum(w);
        ybar = sum(w.*vY);

    case 3
        % Gauss-Markov theorem
        % https://en.wikipedia.org/wiki/Weighted_arithmetic_mean#Accounting_for_correlations
        J = ones(RC, 1);
        V = M.COV;
        % use pinv since V may not have full rank 
        pinvV = pinv(V);
        s2ybar = 1/(J'*(pinvV*J));
        ybar = s2ybar*(J'*(pinvV*vY));

end

%%%
% Estimate over-dispersion parameter using rule-of-thumb method
%%%
if eq(OPTS.overdispersion, 1)
    Ko = kernel('y', M.y, 'x', M.x, 'k', 3);
    ko2 = 2*Ko.K - Ko.K*Ko.K;
    Z = speye(RC) - ko2;
    r = Z*vY;

    switch M.type

        case {0, 1}
            f.s2hat = sum(r.*r)/(RC - 1);
            s2hati = 1/f.s2hat;

        case 2
            w = 1./M.COV(:);
            % fix w values of Inf
            w(~isfinite(w)) = 0;
            f.s2hat = sum(r.*(w.*r))/(RC - 1);
            s2hati = 1/f.s2hat;

        case 3
            % inverse variance weights blow up if M.COV is not full rank
            rnk = rank(pinvV);
            if eq(rnk, RC)
                f.s2hat = sum(r.*(pinvV*r))/(RC - 1);
            else
                f.s2hat = sum(r.*r)/(RC - 1);
            end
            s2hati = 1/f.s2hat;

    end

else

    f.s2hat = 1;
    s2hati = 1;

end

%%%
% Subtract the grand mean prior to filtering. Centering reduces the order
% of magnitude of the AIC values and that makes it easier to see fine-scale
% differences.
%%%
vY0 = vY - ybar;

%%%
% Calculate the deviance for each filter (j) and cut-off
% using vectorized computations for efficiency.
%%%
NK = size(P.kernels, 2);
DEV0 = NaN(RC, NK);
AICcCurve = NaN(RC, NK);
%%%
% dfc0 would blow up for c0 values of RC-1 and RC: threshold at RC - 2
%%%
c0 = ([1:1:RC-2, RC-2, RC-2])';
dfc0 = 2*c0 + (2*c0.^2 + 2*c0)./(RC - c0 - 1);
yi = vY0;
Yi = repmat(yi, 1, RC);

switch M.type
    case 0

    case 1
        % i.i.d.
    case 2
        vi = M.COV(:);
        wi = 1./vi;
        wi(~isfinite(wi)) = 0;
        Wi = repmat(wi, 1, RC);

    case 3
        Vii = pinvV;

end

for j = 1:NK

    sji = P.kernels(j).V'*yi;
    lsji = P.kernels(j).L.*sji;
    LSji = repmat(lsji', RC, 1);
    cLSUji = cumsum(LSji.*P.kernels(j).U, 2);
    ri = Yi - cLSUji;

    switch M.type

        case {0, 1}
            DEV0(:, j) = s2hati*sum(ri.*ri, 1)';

        case 2
            DEV0(:, j) = s2hati*sum(Wi.*(ri.*ri), 1)';

        case 3
            DEV0(:, j) = s2hati*sum(ri.*(Vii*ri), 1)';

    end

    AICcCurve(:, j) = DEV0(:, j) + dfc0;

end

AICc = NaN(NK, 1);
Deviance = NaN(NK, 1);
edf = NaN(NK, 1);
modnum = repmat((1:NK)', 1);
modrnk = NaN(NK, 1);
AICcCurve = AICcCurve(1:OPTS.max_edf, :);

for i = 1:NK
    [~, mini] = mink(AICcCurve(OPTS.min_edf:OPTS.max_edf, i), 1);
    mini = mini + OPTS.min_edf - 1;
    AICc(i, :) = AICcCurve(mini, i);
    Deviance(i, :) = DEV0(mini, i);
    edf(i, 1) = mini;
end

%%%
% Assemble results for plotting
%%%
[~, b] = min(AICc, [], 1);
bAICc = diag(AICc(b, :))';
DELTA = AICc - repmat(bAICc, NK, 1);

% Calculate the ranks
[~, modrnk(:, 1)] = ismember(DELTA(:, 1), sort(DELTA(:, 1)));

rl = cell(1, NK);
for i = 1:NK
    rl{i} = P.kernels(i).fullname;
end

f.GAP = tbl(...
    'data', ...
    [edf(:, 1), Deviance(:, 1), AICc(:, 1), DELTA(:, 1), modrnk(:, 1), modnum(:, 1)], ...
    'fullname', M.data.fullname, ...
    'row_labels', rl, ...
    'col_labels', {'edf', 'DEV', 'AICc', 'DELTA', 'rank', 'modnum'}, ...
    'labels', {'AICc', 'kernels'});

f.AIC = tbl(...
    'data', squeeze(AICcCurve(1:OPTS.max_edf, :)), ...
    'fullname', M.data.fullname, ...
    'col_labels', rl);

% model averaging
tma = ModelAverage(M, P, f.GAP, f.AIC, ybar, f.s2hat, OPTS);

f.TMA = tma.TMA;
f.Akaike = tma.Akaike;
f.Pie = tma.Pie;
f.K = tma.K;

end

function OPTS = options(M, opts)
% validate options for sift analysis

% maximum number of edf
edfmax = numel(M.data.data(:)) - 2;

OPTS = struct('overdispersion', 1, ...
    'min_edf', 1, ...
    'max_edf', edfmax);

if isfield(opts, 'min_edf')
    vali = opts.min_edf;
    if ~(isnumeric(vali) && isreal(vali) && eq(numel(vali), 1))
        error('min_edf must be a positive scalar')
    else
        if vali <= 0
            error('min_edf must be positive')
        else
            OPTS.min_edf = round(vali);
        end
    end
end

if isfield(opts, 'max_edf')
    vali = opts.max_edf;
    if ~(isnumeric(vali) && isreal(vali) && eq(numel(vali), 1))
        error('max_edf must be a positive scalar')
    else
        if (vali <= 0) || (vali > edfmax)
            error(['max_edf must lie between 1 and ' num2str(edfmax)])
        else
            OPTS.max_edf = round(vali);
        end
    end
end

if isfield(opts, 'overdispersion')
    vali = opts.overdispersion;
    if ~(isscalar(vali) && isnumeric(vali))
        error('overdispersion must be a real scalar')
    else
        if ismember(vali, [0 1])
            OPTS.overdispersion = vali;
        else
            error('overdispersion must be 0 or 1')
        end
    end

end

end

function tma = ModelAverage(M, P, GAP, AIC, ybar, s2hat, OPTS)
% model average

tma = struct('TMA', [], 'Akaike', [], 'Pie', [], 'K', []);

[R, C] = size(M);
RC = R*C;

switch M.type
    case {0, 1}
        % i.i.d.
        Vi = 1;
    case 2
        vi = M.COV(:);
        Vi = spdiags(vi, 0, RC, RC);

    case 3
        Vi = M.COV;

end

aic = AIC.data;
Kernels = 1:1:size(aic, 2);

gap = GAP.data;
INC = gap(:, 4) <= 7;
KernelID = Kernels(INC);

aic0 = aic(:, INC);
% how many kernels are within 7 of the best
G = size(aic0, 2);
gap0 = gap(INC, :);

best = min(gap0(:, 3));
del0 = aic0(OPTS.min_edf:OPTS.max_edf,:) - best;
edf0 = (OPTS.min_edf:1:OPTS.max_edf)';

edf = cell(1, G);
LOC = cell(1, G);
seq = 1:1:(OPTS.max_edf - OPTS.min_edf + 1);
n = NaN(1, G);

for g = 1:G
    TMP = del0(:, g) <= 7;
    LOC{g} = seq(TMP);
    % how many edf within 7 of the best for kernel g
    edf{g} = edf0(LOC{g});
    n(g) = length(edf{g});
end

models = [(KernelID)', n', NaN(G, max(n))];
deltas = [(KernelID)', n', NaN(G, max(n))];
for g = 1:G
    models(g, 3:n(g)+2) = edf{g}';
    deltas(g, 3:n(g)+2) = del0(LOC{g}, g)';
end

rl = GAP.row_labels(INC);
cl = ['kernel'; '#edf'; cellstr(num2str((1:max(n))'))]';

MODELS = tbl(...
    'data', models, ...
    'fullname', 'Models', ...
    'row_labels', GAP.row_labels(INC), ...
    'col_labels', cl, ...
    'labels', {'kernel', 'edf'});

dels = exp(-0.5*deltas(:, 3:end));
tma.Akaike = tbl(...
    'data', [(KernelID)' n', dels/sum(dels(:), 'omitnan')], ...
    'fullname', 'Akaike Weights', ...
    'row_labels', rl, ...
    'col_labels', cl, ...
    'labels', {'kernel', 'edf'});

Y = reshape(M.data.data, R, C);
y0 = Y(:) - ybar;
P0.kernels = P.kernels(INC);
N = size(P0.kernels(1).K, 1);
% total edf to include
edfTOT = sum(models(:, 2));

k0 = cell(1, edfTOT);
w0 = NaN(1, edfTOT);
ym = cell(1, edfTOT);
yma = zeros(N, 1);
Vma1 = zeros(N, N);
Vma2 = zeros(N, N);

m = 0;
for g = 1:G
    for edf = 1:n(g) % edf is a counter
        m = m + 1;
        w0(m) = tma.Akaike.data(g, 2 + edf);

        if eq(edf, 1)
            e = MODELS.data(g, 2 + edf);
            k0{m} = P0.kernels(g).U(:, 1:e)*diag(P0.kernels(g).L(1:e))*P0.kernels(g).V(:, 1:e)';
        else
            e0 = MODELS.data(g, 2 + edf - 1);
            e1 = MODELS.data(g, 2 + edf);
            INC = e0+1:e1; % pick off the columns one-by-one
            k0{m} = k0{m-1} + ...
                P0.kernels(g).U(:, INC)*diag(P0.kernels(g).L(INC))*P0.kernels(g).V(:, INC)';
        end
        TMP = ybar + k0{m}*y0;
        ym{m} = TMP;
        yma = yma + w0(m)*ym{m};
        % this is an expensive calculation . . .
        switch M.type
            case 1
                Vma1 = Vma1 + w0(m)*k0{m}*(k0{m}');

            case 2
                Vma1 = Vma1 + w0(m)*k0{m}*Vi*k0{m}';

            case 3
                Vma1 = Vma1 + w0(m)*k0{m}*Vi*k0{m}';
        end

    end
end

%%%
% If any cells have variance 0, reset the tma of those to what was observed
%%%
switch M.type
    case 2
        vo = M.COV(:);
        zv = isapprox(vo, 0);
        yo = y0 + ybar;
        yma0 = yma;
        yma0(zv) = yo(zv);

    case 3
        vo = diag(M.COV);
        zv = isapprox(vo, 0);
        yo = y0 + ybar;
        yma0 = yma;
        yma0(zv) = yo(zv);

    otherwise
        yma0 = yma;

end

Tma = tbl(...
    'data', reshape(yma0, R, C), ...
    'fullname', [M.data.fullname ' (TMA)'], ...
    'row_labels', M.data.row_labels, ...
    'col_labels', M.data.col_labels, ...
    'labels', M.data.labels);

for m = 1:edfTOT
    Vma2 = Vma2 + w0(m)*(ym{m} - yma)*(ym{m} - yma)';
end
Vma = s2hat*Vma1 + Vma2;

tma.TMA = matrix(...
    'data', Tma, ...
    'COV', Vma, ...
    'x', M.x, ...
    'y', M.y, ...
    'Alpha', M.Alpha);

%%%
% labels for each kernel-edf combo included in the model average
%%%
k = 0;
Nedf = sum(tma.Akaike.data(:, 2));
MLabels = cell(1, Nedf);
for g = 1:G
    for h = 1:n(g)
        k = k + 1;
        kid = MODELS.data(g, 1);
        MLabels{k} = [P.kernels(kid).fullname '-' num2str(models(g, 2 + h), '%3.0f')];
    end
end

%%%
% pie data
%%%
TMP1 = tma.Akaike.data(:, 3:end);
TMP2 = TMP1';
TMP3 = TMP2(:);
TMP = TMP3(~isnan(TMP3));
[sv, so] = sort(TMP(:), 'descend');
tma.Pie = tbl(...
    'data', sv, ...
    'fullname', 'Akaike Weights', ...
    'row_labels', MLabels(so), ...
    'col_labels', {'Weight'});

% TMA kernel
K0 = w0(1)*k0{1};
for m = 2:edfTOT
    K0 = K0 + w0(m)*k0{m};
end
tma.K = K0;

end
