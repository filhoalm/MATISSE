function AIC(S, varargin)
% AIC Plot aic results and Akaike weights.

A = sort(matrix('data', S.F.GAP), 4);

OPT = AIC_opt(varargin{:});

PVP = go(...
    'FontSize', [8 8 10], ...
    'labels', [1 1 0], ...
    'Marker', 1, ...
    'MarkerSize', 12, ...
    'Width', 1.0, ...
    'LineWidth', 1.5, ...
    'LineStyle', 3, ...
    'LineColor', 12, ...
    'colormap', 'clarinet', ...
    'Legend', 0, ...
    'Grid', 1);

if isfinite(OPT.Threshold)
    PVP.XLim = [0 OPT.Threshold];
end

figure('Position', [150 150 1200 600]), clf

%%%
% forest plot of GAP data
%%%
ax1 = subplot(1, 2, 1);

forestplot(A, 4, PVP)

% annotation
v1PVP = go('Width', PVP.Width, 'Legend', 0, ...
    'LineColor', 10, 'LineStyle', 5, 'FaceAlpha', 0.10, 'EdgeAlpha', 0);
vband([ax1.YLim 1 0.01 2], v1PVP)

v2PVP = go('Width', PVP.Width, 'Legend', 0, ...
    'LineColor', 17, 'LineStyle', 5, 'FaceAlpha', 0.10, 'EdgeAlpha', 0);
vband([ax1.YLim 3 2 4], v2PVP)

v3PVP = go('Width', PVP.Width, 'Legend', 0, ...
    'LineColor', 17, 'LineStyle', 5, 'FaceAlpha', 0.05, 'EdgeAlpha', 0);
vband([ax1.YLim 5.5 4 7], v3PVP)

%%%
% pie chart of Pie data
%%%
ax2 = subplot(1, 2, 2);
P = S.F.Pie;

m = numel(P.data);
EXC = P.data <= 0.02;
rl = cellstr(num2str(100*P.data, '%3.0f%%'));
for j = 1:m
    if EXC(j)==1
        rl{j} = '';
    end
end
warning off % remove warning when legend entries truncated after 50
pie(P.data, rl);
lh = legend(P.row_labels,...
    'NumColumns', 2, ...
    'Location', 'southoutside', ...
    'Orientation','horizontal', ...
    'Box', 'off', ...
    'FontSize', PVP.FontSize(1));
warning on
set(lh.Title, 'String', 'K_{kernel:df}', ...
    'FontSize', PVP.FontSize(3), ...
    'FontWeight', 'normal');
title({'Akaike Weights', ''}, ...
    'FontSize', PVP.FontSize(3), ...
    'FontWeight', 'normal', ...
    'VerticalAlignment', 'bottom')
colormap(ax2, parula(m))

end

function OPT = AIC_opt(varargin)
% Helper

OPT = struct('Threshold', Inf);

%%%
% process
%%%
if length(varargin) > 1
    lArgin = varargin(1:end);
else
    lArgin = [];
end

Nl = numel(lArgin);
if eq(Nl, 1)
    error('The property you specified has no matching value.');
end

while ge(Nl, 1)
    if eq(Nl, 1)
        error('The last property has no matching value.');
    end

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('A property must be specified using a string.')
    end

    switch lower(propi)

        case 'threshold'
            % first see if this is a real scalar
            if ~(isscalar(vali) && isreal(vali))
                error('Threshold must be a scalar');
            end
            if vali <= 0
                error('Threshold must be positive')
            end
            OPT.Threshold = vali;

        otherwise

    end

    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

end

end

