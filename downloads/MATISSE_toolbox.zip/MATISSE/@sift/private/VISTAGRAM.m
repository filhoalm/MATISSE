function VISTAGRAM(S, varargin)
% SIFT/VISTAGRAM surface plots of observed and filtered data and residuals.

if eq(nargin, 1)
    PVP = ego('class', 'sift', 'method', 'vistagram');
    d0 = min(size(S.M));
    PVP.Depth = d0/2;

else
    PVP = varargin{1};
end

figure('Position', [180 180 1000 600])

m = mean(S.M.data.data(:));

DATRaw = tbl('data', S.M.data.data - m, 'fullname', 'Raw');
DATFil = tbl('data', S.F.TMA.data.data - m, 'fullname', 'SIFT');
DATRes = tbl('data', DATRaw - DATFil, 'fullname', 'Residuals');

vistagram({DATRaw, DATFil, DATRes}, PVP);

if eq(1, PVP.labels(3))
    title({S.M.data.fullname, '^{(values are centered)}'}, ...
        'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
end

end