classdef sift
    % SIFT sift objects contain a Singular values adaptIve kernel FilTration.
    %
    % The main input to SIFT is a matrix object.
    %
    % The main output of SIFT is a truncated model average (TMA) estimator
    % obtained using a panel of bivariate kernel operators.
    %
    % See https://pubmed.ncbi.nlm.nih.gov/37621099/ for details.
    %
    % The TMA estimator provides 'denoised' or 'smoothed' values with an
    % optimal bias-variance trade-off. It's estimated variance-covariance
    % matrix takes kernel selection into account.
    %
    % See also panko, sift/sift.

    properties

        M matrix = matrix;         % input matrix object 
        opts struct = struct(...   % a few options for tuning
            'overdispersion', [], ...
            'min_edf', [], ...
            'max_edf', []); 
        F struct = struct;         % model identification and TMA estimator

    end

    methods

        function S = sift(M, varargin)
            % SIFT SIngular values adaptive kernel FilTration.
            %
            % S = SIFT(M)
            % S = SIFT(M, P)
            % S = SIFT(M, P, opts)
            %
            % * M is a matrix object
            %
            % * P is a panel of kernel operators
            %
            % * opts is a structure with fields:
            %
            %   overdispersion - 1 (true, default) or 0 (false)
            %   min_edf        - smallest edf for sift (default 1)
            %   max_edf        - largest edf <= prod(size(M)) - 2 (default)
            %
            % * Cells in M with zero variance
            %    + are excluded from model identification
            %    + have fitted values equal to observed values
            %
            % * Type 0 matrices are treated as type 1
            %
            % * The truncated model average (TMA) filtration is S.F.TMA
            %
            % See also panko/panko, aic, thumbnail, vistagram.

            if nargin == 0
                % Contents of an empty sift
                S.M = matrix;
                S.opts = struct('overdispersion', [], 'min_edf', [], 'max_edf', []);
                S.F = struct;
                return
            end

            if isa(M, 'sift')
                S = varargin{1};
                return
            end

            % Contents of an empty sift object
            S.M = matrix;
            S.opts = struct('overdispersion', [], 'min_edf', [], 'max_edf', []);
            S.F = struct;

            S.M = M;

            optsDefault = struct('overdispersion', 1, ...
                'min_edf', 1, ...
                'max_edf', numel(M.data.data) - 2);

            switch nargin
                case 1
                    P = panko('x', M.x, 'y', M.y, 'k', 3, 'k2', 3, 'shape', 'boxcar');
                    opts = optsDefault;
                case 2
                    P = varargin{1};
                    opts = optsDefault;
                case 3
                    P = varargin{1};
                    opts = varargin{2};
                otherwise
                    error('too many inputs')
            end

            if isempty(S.M)
                return
            end

            [f, OPTS] = SIFT(S.M, P, opts);
            S.F = f;
            S.opts = OPTS;

        end

        %%%
        % Visualization
        %%%
        function aic(S, varargin)
            % AIC Plot AIC values and Akaike weights from a sift analysis.
            %
            % AIC(S)
            % AIC(S, 'Threshold', value)
            %
            % See also thumbnail, vistagram.

            AIC(S, varargin{:})

        end

        function thumbnail(S, varargin)
            % THUMBNAIL Thumbnail plots of observed and filtered data.
            %
            % THUMBNAIL(S)
            % THUMBNAIL(S, go(...))
            %
            % See also aic, vistagram.

            THUMBNAIL(S, varargin{:})

        end

        function vistagram(S, varargin)
            % VISTAGRAM Surface plots of observed and filtered data.
            %
            % VISTAGRAM(S)
            % VISTAGRAM(S, go(...))
            %
            % See also depth, aic, thumbnail.

            VISTAGRAM(S, varargin{:})

        end

    end

end

