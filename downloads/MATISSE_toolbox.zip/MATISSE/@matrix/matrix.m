classdef (InferiorClasses = {?tbl}) matrix
    % MATRIX matrix objects contain a tbl of data and its variance-covariance matrix.
    %
    % MATRIX methods allow MATISSE to automatically calculate the
    % variance-covariance matrix of any linear combination of tbl values.
    %
    % Statistical models in MATISSE use MATRIX objects to store model
    % inputs and outputs.
    %
    % See also matrix/matrix, tbl.
    %
    % * Type 'doc matrix/matrix' to view the ouput from the doc function.

    properties

        data {mustBeA(data, {'tbl'})} = tbl;     % tbl of data
        y (1, :) {mustBeNumeric} = [];           % row scores, y-axis
        x (1, :) {mustBeNumeric} = [];           % column scores, x-axis
        COV (:, :) {mustBeNumeric} = 0;          % variance-covariance matrix of the vectorized data
        type (1, 1) {mustBeNumeric} = 0;         % structure of the covariance matrix, scalar, 0 - 3
        Alpha (1, 1) {mustBeNumeric} = 0.05;     % alpha level of confidence limits in curves
        curves {mustBeA(curves, 'cell')} = {};   % cell array of curves, one for each column

    end


    methods

        %%%
        % housekeeping
        %%%

        function M = matrix(varargin)
            % A MATRIX object contains a tbl of data and its variance-covariance matrix.
            %
            % M = MATRIX('data', T, 'COV', V, 'x', x, 'y', y, 'Alpha', val)
            %
            % T is an RxC tbl or double.
            %
            % Four types of V:
            %
            % 0 - values of T are deterministic
            %      V = scalar = 0
            % 1 - values of T are independent and homoscedatic
            %      V = scalar > 0
            % 2 - values of T are independent but heteroscedastic
            %      V(r, c) = Var(T(r, c)), r = 1, ..., R, c = 1, ..., C
            % 3 - values of T covary
            %     t = vec(T)
            %     V(j, k) = Cov(t(j), t(k)), j,k = 1, ..., R*C, where:
            %     The multilinear correspondence between t(j) and T(r,c) is
            %      t(j) <-> T(r, c)
            %          r = j - R*floor((j-1)/R)
            %          c = 1 + floor((j-1)/R)
            %
            % x - evenly spaced length C sequence of column scores (default 1:C)
            % y - evenly spaced length R sequence of row scores (default 1:R)
            %
            % M.curves is a 1xC cell array of tbl objects:
            %
            % column / contents
            % 1 - row scores y
            % 2 - values in column c of T
            % 3 - * lower confidence limit
            % 4 - * upper confidence limit
            %
            % * limits set based on the value of 'Alpha' (default 0.05)
            %
            % see also matrix/matrix, tbl.

            if nargin == 0
                % Contents of an empty matrix
                M.data = tbl;
                M.y = [];
                M.x = [];
                M.type = 0;
                M.Alpha = 0.05;
                M.curves = {};
                return
            end

            if isa(varargin{1}, 'matrix')
                M = varargin{1};
                return
            end

            % Contents of an empty matrix
            M.data = tbl;
            M.y = [];
            M.x = [];
            M.COV = 0;
            M.type = 0;
            M.Alpha = 0.05;
            M.curves = {};

            N = numel(varargin);

            if N == 0
                return
            end

            %%%
            % whittle the arguments
            %%%
            lArgin = varargin;

            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};

                if ~ischar(propi)
                    error('a property must be specified using a string')
                end

                switch lower(propi)

                    case 'data'

                        switch class(vali)
                            case 'double'
                                M.data = tbl('data', vali, ...
                                    'fullname', 'numeric', ...
                                    'labels', {'y', 'x'}, ...
                                    'row_labels', cellstr(num2str((1:size(vali, 1))')), ...
                                    'col_labels', cellstr(num2str((1:size(vali, 2))')));

                            case 'tbl'
                                data = vali;
                                % must pull out the labels so that numel is
                                % dispatched to generic numel NOT tbl/numel
                                rl = data.row_labels;
                                cl = data.col_labels;
                                if eq(numel(rl), 1) && isempty(rl{1})
                                    data.row_labels = cellstr(num2str((1:size(data, 1))'));
                                end
                                if eq(numel(cl), 1) && isempty(cl{1})
                                    data.col_labels = cellstr(num2str((1:size(data, 2))'));
                                end
                                TMP = data.labels;
                                if isempty(TMP{1})
                                    TMP{1} = 'y';
                                end
                                if isempty(TMP{2})
                                    TMP{2} = 'x';
                                end
                                data.labels = TMP;
                                M.data = data;

                            otherwise
                                error('invalid class for data')
                        end

                    case 'x'
                        % must be a vector
                        if ~isreal(vali)
                            error('invalid x values')
                        end
                        vali = vali(:)';
                        if ~all(diff(vali) > 0)
                            error('x values must be a non-decreasing sequence')
                        end
                        M.x = vali;

                    case 'y'
                        % must be a vector
                        if ~isreal(vali)
                            error('invalid y values')
                        end
                        vali = vali(:)';
                        if ~all(diff(vali) > 0)
                            error('y values must be a non-decreasing sequence')
                        end
                        M.y = vali;

                    case 'cov'

                        switch class(vali)
                            case 'double'
                                % good to go
                            case 'tbl'
                                vali = vali.data;
                            otherwise
                                error('COV must be numeric or tbl')
                        end

                        % must be a scalar or numeric matrix
                        if ~isreal(vali)
                            error('COV must contain real values')
                        end
                        % Sometimes 0 covariances come in as approximately
                        % 0 but with a negative sign. Leave out the imaginary
                        % part.
                        M.COV = real(vali);

                    case 'alpha'
                        if ~(isscalar(vali) && isreal(vali))
                            error('Alpha must be a real scalar')
                        elseif (vali < 0 || vali > 1)
                            error('Alpha must lie between 0 and 1')
                        else
                            M.Alpha = vali;
                        end

                    otherwise

                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('the last property has no matching value');
                end

            end

            %%%%
            % piece together x and y
            %%%
            [R, C] = size(M.data);
            if isempty(M.y)
                M.y = 1:R;
            else
                if ne(numel(M.y), R)
                    error('y data has the wrong number of values')
                end
            end

            if isempty(M.x)
                M.x = 1:C;
            else
                if ne(numel(M.x), C)
                    error('x data has the wrong number of values')
                end
            end

            %%%
            % validate COV
            %%%

            [cR, cC] = size(M.COV);

            if (cR == R && cC == C)
                M.type = 2;
            elseif (cR == C*R && cC == C*R)
                M.type = 3;
            elseif (cR==1 && cC==1)
                if eq(M.COV, 0)
                    M.type = 0;
                else
                    if M.COV > 0
                        M.type = 1;
                    else
                        error('scalar COV must be nonnegative')
                    end
                end
            else
                error('type must be 0, 1, 2, or 3')
            end

            %%%
            % construct one curve per column
            %%%
            M.curves = cell(1, C);
            z = norminv(1 - M.Alpha/2);

            switch M.type
                case 0
                    sd = 0;
                case {1, 2}
                    sd = sqrt(M.COV);
                case 3
                    sd = sqrt(reshape(diag(M.COV), R, C));
            end
            %%%%
            % Rarely, we see an sd value that isapprox 0 but has a
            % negative sign. Omit the imaginary part.
            %%%
            sd = real(sd);

            for i = 1:C
                f = M.data.data(:, i);
                cl = M.data.col_labels;
                rl = M.data.row_labels;
                lb = M.data.labels;
                switch M.type
                    case 0
                        dat = [M.y', f];
                        M.curves{i} = tbl(...
                            'data', dat, ...
                            'fullname', cl{i}, ...
                            'labels', {lb{1}, cl{i}}, ...
                            'row_labels', rl, ...
                            'col_labels', {lb{1}, cl{i}});

                    case 1
                        ci = [f - z*sd, f + z*sd];
                        dat = [M.y', f, ci];
                        M.curves{i} = tbl(...
                            'data', dat, ...
                            'fullname', cl{i}, ...
                            'labels', {lb{1}, cl{i}}, ...
                            'row_labels', rl, ...
                            'col_labels', {lb{1}, cl{i}, 'Lo', 'Hi'});

                    case 2
                        ci = [f - z*sd(:, i), f + z*sd(:, i)];
                        dat = [M.y', f, ci];
                        M.curves{i} = tbl(...
                            'data', dat, ...
                            'fullname', cl{i}, ...
                            'labels', {lb{1}, cl{i}}, ...
                            'row_labels', rl, ...
                            'col_labels', {lb{1}, cl{i}, 'Lo', 'Hi'});

                    case 3
                        ci = [f - z*sd(:, i), f + z*sd(:, i)];
                        dat = [M.y', f, ci];
                        M.curves{i} = tbl(...
                            'data', dat, ...
                            'fullname', cl{i}, ...
                            'labels', {lb{1}, cl{i}}, ...
                            'row_labels', rl, ...
                            'col_labels', {lb{1}, cl{i}, 'Lo', 'Hi'});
                end

            end

        end

        function r = end(g, k, ~)
            % END End method for matrix objects.

            switch k
                case 1
                    r = size(g, 1);
                case 2
                    r = size(g, 2);
                otherwise
            end

        end

        function S = isempty(M)
            % ISEMPTY Determine whether a matrix object is empty.
            % S = isempty(M)
            %
            % S is logical true or false
            %
            % See also size.

            S = isempty(M.data);
        end

        function varargout = size(M, varargin)
            % SIZE of a matrix object.
            %
            % [R, C] = size(M)
            % R = size(M, 1)
            % C = size(M, 2)
            %
            % Number of rows R and columns C of M.
            %
            % See also isempty.

            switch nargin
                case 1
                    switch nargout
                        case {0, 1}
                            varargout{1} = [size(M.data, 1), size(M.data, 2)];
                        case 2
                            varargout{1} = size(M.data, 1);
                            varargout{2} = size(M.data, 2);
                        otherwise
                            error('too many outputs')
                    end

                case 2
                    d = varargin{1};
                    switch nargout
                        case {0, 1}
                            varargout{1} = size(M.data, d(1));
                        case 2
                            varargout{1} = size(M.data, d(1));
                            varargout{2} = size(M.data, d(2));
                        otherwise
                            error('too many outputs')
                    end
            end
        end

        function U = subsref(M, S)
            % SUBSREF Subscripted referencing for matrix objects.

            if length(S) > 1

                DEPTH = numel(S);
                for d = 1:DEPTH
                    if d == 1
                        U = subsref(M, S(1));
                    else
                        % q = numArgumentsFromSubscript(U, S(d), ...
                        %     matlab.mixin.util.IndexingContext.Statement);
                        % if q > 1
                        %     warning('only one output was captured')
                        % end
                        U = subsref(U, S(d));
                    end
                end

            else

                switch S.type

                    case '.'

                        switch S.subs

                            case 'data'
                                U = M.data;
                            case 'x'
                                U = M.x;
                            case 'y'
                                U = M.y;
                            case 'COV'
                                U = M.COV;
                            case 'type'
                                U = M.type;
                            case 'Alpha'
                                U = M.Alpha;
                            case 'curves'
                                U = M.curves;

                            otherwise

                        end

                    case '()'
                        [R, C] = size(M.data);
                        % if it's a boolean, replace S.subs{1} with indices
                        if isa(S.subs{1}, 'boolean')
                            S.subs{1} = find(S.subs{1}.data == 1);
                        elseif isa(S.subs{1}, 'logical')
                            S.subs{1} = S.subs{1};
                        elseif isa(S.subs{1}, 'char')
                            % for now we are assuming this is going to be a ':'
                            S.subs{1} = 1:R;
                        elseif isa(S.subs{1}, 'numeric')
                            % should be good
                        else
                            % let MATLAB hande any errors
                        end
                        if isa(S.subs{2}, 'boolean')
                            S.subs{2} = find(S.subs{2}.data == 1);
                        elseif isa(S.subs{2}, 'logical')
                            S.subs{2} = S.subs{2};
                        elseif isa(S.subs{2}, 'char')
                            S.subs{2} = 1:C;
                        else
                            % let MATLAB handle any errors
                        end

                        %%%
                        % coerce logical indices to numeric indices
                        %%%
                        JR = (1:R)';
                        JC = (1:C)';
                        if isa(S.subs{1}, 'logical')
                            S.subs{1} = JR(S.subs{1});
                        end
                        if isa(S.subs{2}, 'logical')
                            S.subs{2} = JC(S.subs{2});
                        end

                        SUBS = S.subs;

                        DATA = M.data(SUBS{1}(:), SUBS{2}(:));

                        switch M.type
                            case {0, 1}
                                cov = M.COV;

                            case 2
                                cov = M.COV(SUBS{1}(:), SUBS{2}(:));

                            case 3
                                ri = SUBS{1}(:);
                                cj = SUBS{2}(:);

                                I = numel(ri);

                                J = numel(cj);
                                k = NaN(I*J, 1);

                                c = 0;
                                for j = 1:J
                                    for i = 1:I
                                        c = c + 1;
                                        k(c) = ri(i) + R*(cj(j) - 1);
                                    end
                                end
                                cov = M.COV(k, k);
                        end

                        % As coded, the x and y scores are not very
                        % 'sticky' - BOTH have to be evenly spaced and
                        % increasing, otherwise we revert to default
                        % scores.
                        % are the references to EVENLY spaced rows and
                        % columns? (In this expression we are calculating
                        % second differences)
                        isOKy2 = ~any(diff(SUBS{1}, 2));
                        isOKx2 = ~any(diff(SUBS{2}, 2));

                        % are the references also INCREASING?
                        if isOKy2
                            isOKy1 = all(diff(SUBS{1}, 1) > 0);
                        else
                            isOKy1 = false;
                        end
                        if isOKx2
                            isOKx1 = all(diff(SUBS{2}, 1) > 0);
                        else
                            isOKx1 = false;
                        end

                        isOKy = isOKy2 && isOKy1;
                        isOKx = isOKx2 && isOKx1;

                        if isOKy && isOKx

                            U = matrix(...
                                'data', DATA, ...
                                'x', M.x(SUBS{2}), ...
                                'y', M.y(SUBS{1}), ...
                                'Alpha', M.Alpha', ...
                                'COV', cov);
                        else
                            % constructor must insert default scores because
                            % subsref values of x and y for subsref data
                            % were not BOTH evenly spaced and increasing
                            U = matrix(...
                                'data', DATA, ...
                                'Alpha', M.Alpha, ...
                                'COV', cov);


                        end


                        % constructor must insert default scores because
                        % subsref values of x and y for subsref data may or
                        % may not be an evenly spaced sequence
                        % U = matrix(...
                        %     'data', DATA, ...
                        %     'Alpha', M.Alpha, ...
                        %     'COV', cov);

                    case '{}'

                        % do nothing
                        U = M;

                end
            end
        end

        function G = subsasgn(M, S, V)
            % SUBSASGN Subscripted assignment for matrix objects.

            if length(S) > 1
                error('Index expression has depth %g, cannot be > 1', numel(S))
            end

            G = M;

            switch S.type

                case '.'

                    switch S.subs

                        case 'data'
                            G = matrix('data', V, ...
                                'x', M.x, ...
                                'y', M.y, ...
                                'COV', M.COV, ...
                                'Alpha', M.Alpha);

                        case 'x'
                            G = matrix(...
                                'data', M.data, ...
                                'x', V, ...
                                'y', M.y, ...
                                'COV', M.COV, ...
                                'Alpha', M.Alpha);

                        case 'y'
                            G = matrix(...
                                'data', M.data, ...
                                'x', M.x, ...
                                'y', V, ...
                                'COV', M.COV, ...
                                'Alpha', M.Alpha);

                        case 'COV'
                            G = matrix('data', M.data, ...
                                'x', M.x, ...
                                'y', M.y, ...
                                'COV', V, ...
                                'Alpha', M.Alpha);

                        case 'Alpha'
                            G = matrix(...
                                'data', M.data, ...
                                'x', M.x, ...
                                'y', M.y, ...
                                'COV', M.COV, ...
                                'Alpha', V);

                    end

                case '()'
                    warning('parentheses indexing is undefined')

                case '{}'
                    warning('brace indexing is undefined')

                otherwise

            end

        end

        function [S, si] = sort(M, varargin)
            % SORT Sort matrix data based on the values in a column.
            %
            % S = sort(M)
            % S = sort(M, col)
            % S = sort(M, col, direction)
            % [S, si] = sort(M, ...)
            %
            % col       - sort column (default 1)
            % direction - 'ascend' (default), 'descend', or 'precision'
            %
            % The y and x scores of S are 1:size(M, 1) and 1:size(M, 2).
            switch nargin
                case 1
                    col = 1;
                    DIR = 'ascend';
                case 2
                    col = varargin{1};
                    DIR = 'ascend';
                case 3
                    col = varargin{1};
                    DIR = varargin{2};
                otherwise
                    error('wrong number of inputs')
            end

            [S, si] = SORT(M, col, DIR);

        end

        %%%
        % unary operators
        %%%

        function E = exp(M)
            % EXP Exponentiate data values in a matrix object.
            %
            % E = EXP(M)
            %
            % E contains transformed data exp(M) and its delta method
            % variance-covariance matrix.
            %
            % See also pc, log, log10.

            E = EXP(M);

        end

        function P = pc(M)
            % PC Percent Change rescaling of values in a matrix object.
            %
            % E = PC(M)
            %
            % E contains transformed data 100 .* (exp(M) - 1) and its
            % delta method variance-covariance matrix.
            %
            % See also exp, log, log10.

            P = PC(M);

        end

        function L = log(M)
            % LOG Natural logarithm of data values in a matrix data.
            %
            % L = log(M)
            %
            % L contains transformed data log(M) and its delta method
            % variance-covariance matrix.
            %
            % See also exp, pc, log10.

            L = LOG(M);

        end

        function L = log10(M)
            % LOG10 Base 10 logarithm of data values in a matrix object.
            %
            % L = log10(M)
            %
            % L contains transformed data log10(M) and its delta method
            % variance-covariance matrix.
            %
            % See also exp, pc, log.

            L = LOG10(M);

        end

        function S = cumsum(M)
            % CUMSUM CUMulative SUMs down the columns of a matrix.
            %
            % S = cumsum(M)
            %
            % See also diagonals.

            S = CUMSUM(M);

        end

        function D = diagonals(M)
            % DIAGONALS of a matrix object.
            %
            % D = diagonals(M)
            %
            % See also tbl/diagonals, cumsum.

            D = DIAGONALS(M);

        end

        function V = vec(M)
            % VEC stack the columns of a matrix object.
            %
            % V = vec(M)
            %
            % See also horzcat.

            vdat = vec(M.data);

            switch M.type
                case {0, 1, 3}
                    V = matrix('data', vdat, 'COV', M.COV, 'Alpha', M.Alpha);
                case 2
                    RC = size(M, 1) * size(M, 2);
                    V = matrix('data', vdat, 'COV', spdiags(M.COV(:), 0, RC, RC), 'Alpha', M.Alpha);
                otherwise
            end

        end

        %%%
        % binary operators
        %%%

        function C = horzcat(varargin)
            % HORZCAT Horizontally join matrix objects with equal y.
            %
            % C = [A1, A2, ..., AK]
            % C = horzcat(A1, ..., AK)
            % C = horzcat(A1, ..., AK, 'text')
            %
            % 'text' - alternative fullname for C.data
            %
            % See also vec.

            C = HORZCAT(varargin{:});

        end

        %%%
        % multilinear (tensor) operators
        %%%

        function [P, L] = pad(M, varargin)
            % PAD Border a matrix with rows and columns of 0s or NaNs.
            %
            % P = PAD(M, ...)
            %
            % Property-value pairs:
            %
            % 'rows' - number of rows to add
            % 'rpos' - position of new rows, 'top' or 'bottom'
            % 'cols' - integer, number of columns to add
            % 'cpos' - position of new cols, 'left' or 'right'
            % 'fill' - 1 (true, default) pad with 0s, or 0 (false), pad with NaNs
            %
            % See also scale.

            [P, L] = PAD(M, varargin{:});

        end

        function [B, Aplus] = block(M, varargin)
            % BLOCK Matrix sums within blocked rows and columns.
            %
            % B = BLOCK(M, ...) or [B, APlus] = BLOCK(M, ...)
            %
            % Property-value pairs:
            %
            % 'rB'   - number of rows to combine (default 1)
            % 'RDir' - row selection 'L2F' (end to 1, default) or 'F2L' (1 to end)
            % 'cB'   - number of cols to combine (default 1)
            % 'CDir' - col selection 'L2F' (end to 1, default) or 'F2L', (1 to end)
            %
            % 'fill' - treat NaN, +Inf, -Inf as 0, 1 (true, default) or 0 (false)
            %
            % If M is too small to complete a first (L2F) or last (F2L) block:
            %
            % 'trim' - 1 (true, default) hanging rows and cols are discarded
            %          0 (false) missing rows and cols are filled with 0s or NaNs
            %
            % Outputs:
            %
            % B      - matrix object containing the block sums 
            %
            % Aplus  - the block sum operator vec(B) = Aplus * vec(M)
            %
            % See also blast.

            [B, Aplus] = BLOCK(M, varargin{:});


        end

        function [G, Abar] = blast(M, varargin)
            % BLAST Matrix averages within blocked rows and columns.
            %
            % G = BLAST(M, ...) or [G, Abar] = BLAST(M, ...)
            %
            % Property-value pairs:
            %
            % 'rW'   - row weights
            % 'cW'   - col weights
            % 'rB'   - number of rows to combine (default 1)
            % 'RDir' - row selection 'L2F' (end to 1, default) or 'F2L' (1 to end)
            % 'cB'   - number of cols to combine (default 1)
            % 'CDir' - col selection 'L2F' (end to 1, default) or 'F2L', (1 to end)
            %
            % 'fill' - treat NaN, +Inf, -Inf as 0, 1 (true, default) or 0 (false)
            %
            % If M is too small to complete a first (L2F) or last (F2L) block:
            %
            % 'trim' - 1 (true, default) hanging rows and cols are discarded
            %          0 (false) missing rows and cols are filled with 0s or NaNs
            %
            % Outputs:
            %
            % G      - matrix object containing the block averages 
            %
            % Abar   - the block average operator vec(B) = Abar * vec(M)
            %
            % See also block.

            [G, Abar] = BLAST(M, varargin{:});

        end

        function S = scale(varargin)
            % SCALE Element-wise (Hadamard) product of matrix M by values W.
            %
            % S = scale(M, W)
            % S = scale(W, M)
            %
            % * Only one argument can be a matrix object
            % * W can be a scalar or array (a double or tbl) the same size as M            %
            %
            % See also pad.

            S = SCALE(varargin{:});

        end

        function [F, BCL] = contrasts(varargin)
            % CONTRASTS Calculate linear contrasts L of the columns of matrix object M.
            %
            % F = CONTRASTS(L, M) or [F, BCL] = CONTRASTS(L, M)
            %
            % F is a matrix object containing the contrasts.
            %
            % * size(L, 2) must equal size(M, 1)
            % * L can be a tbl or double
            % * You can input L and M in either order
            %
            % BCL is the contrast matrix vec(F) = BCL * vec(M)
            %
            % See also diff, swag, slopes.

            [F, BCL] = CONTRASTS(varargin{:});

        end

        function [S, BCL] = slopes(M)
            % SLOPES Least squares slopes within columns of a matrix object.
            %
            % S = SLOPES(M) or [S, BCL] = SLOPES(M)
            %
            % S.L is a matrix objects containing the slopes, and S.l
            % contains the slope of the slopes.
            %
            % * M must have 2 or more rows.
            %
            % BCL is the contrast matrix S.L = BCL * vec(M)
            %
            % See also diff, swag, contrasts.

            [S, BCL] = SLOPES(M);

        end

        function [D, BCL] = diff(M)
            % DIFF Scaled first differences within columns of a matrix object.
            %
            % D = DIFF(M) or [D, BCL] = DIFF(M)
            %
            % D is a matrix object containing first differences divided by
            % the common increment between M.y values.
            %
            % * M must have 2 or more rows
            %
            % BCL is the contrast matrix vec(D) = BCL * vec(M)
            %
            % See also slopes, swag, contrasts.

            [D, BCL] = DIFF(M);

        end

        function [D, BCL] = swag(M)
            % SWAG scaled first differences of rowS Within diAGonals of a matrix object.
            %
            % D = SWAG(M) or [D, BCL] = SWAG(M)
            %
            % a e i m
            % b f j n              f-a j-e n-i
            % c g k o  ->  (1/dy)  g-b k-j o-j
            % d h l p              h-c l-g p-k
            %
            % D is a matrix object containing first differences of rows
            % within diagonals, divided by the common increment dy between
            % M.y values.
            %
            % * M must have 2 or more rows and columns.
            %
            % BCL is the contrast matrix vec(D) = BCL * vec(M)
            %
            % See also slopes, diff, contrasts.

            [D, BCL] = SWAG(M);

        end

        function D = jpx(M, col, varargin)
            % JPX Setup for a joinpoint regression of a column in a matrix object.
            %
            % D = JPX(M, col, 'mink', <value>, 'maxk', <value>, 'a', <value>, 'b', <value>)
            %
            % * M is an RxC matrix object
            % * col is the target column 1, ..., C
            % * M(:, col) cannot contain missing data
            % * covariance matrix of M(:, col) must have full rank
            %
            % Property-Value Pairs:
            %
            % 'mink'           - min number of segments (1, default)
            % 'maxk'           - max number of segments (5, default)
            % 'a'              - min number of values per segment (1, default)
            % 'b'              - max number of values per segment (R, default)
            %
            % 'overdispersion' - 1 (true, default) or 0 (false)
            % 'Alpha'          - scalar between 0 and 1 (default 0.05), confidence level
            %
            % D contains inputs needed for the joinpoint regression of M(:, col).
            %
            % See also statistics/jpx, joinpoint/joinpoint.

            D = JPX(M, col, varargin{:});

        end

        function T = ctranspose(M)
            % CTRANPOSE Transpose a matrix object.
            %
            % T = M'
            % T = ctranpose(M)
            %
            % See also diagonals.

            T = CTRANSPOSE(M);

        end

        %%%
        % visualization
        %%%

        function plot(M, varargin)
            % PLOT Plot the columns of a matrix object.
            %
            % PLOT(M)
            % PLOT(M, go(...))
            %
            % * PVP options are cycled to provide values for each column:
            %  [1 2] -> [1 2 1 2 1 2 ...]
            %
            % See also forestplot, arrows, compass, pcolor.

            switch nargin
                case 1
                    PVP = ego('class', 'matrix', 'method', 'plot');
                case 2
                    PVP = varargin{1};
                otherwise
                    dbquiterror('too many inputs')
            end

            PCURVES(M, PVP)

        end

        function plotmatrix(M, varargin)
            % PLOTMATRIX Plot the columns of a matrix object in separate panels.
            %
            % PLOTMATRIX(M)
            % PLOTMATRIX(M, go(...))
            %
            % * Columns are plotted versus M.y in successive panels
            %
            % * The plot matrix will have r0 rows and c0 columns:
            %    r0 - largest divisor of C from 1 through 10
            %    c0 - C/r0
            %
            % See also forestplot, arrows, compass, plot, pcolor.

            switch nargin
                case 1
                    PVP = ego('class', 'matrix', 'method', 'plotmatrix');
                case 2
                    PVP = varargin{1};
                otherwise
                    error('too many inputs')
            end

            PLOTMATRIX(M, PVP)

        end

        function forestplot(M, varargin)
            % FORESTPLOT Forest plot of matrix data in a selected column.
            %
            % FORESTPLOT(M)
            % FORESTPLOT(M, col)
            % FORESTPLOT(M, col, go(...))
            %
            % * col = target column
            %
            % See also arrows, compass, plot, pcolor.

            switch nargin
                case 1
                    col = 1;
                    PVP = ego('class', 'matrix', 'method', 'forestplot');
                case 2
                    col = varargin{1};
                    PVP = ego('class', 'matrix', 'method', 'forestplot');
                case 3
                    col = varargin{1};
                    PVP = varargin{2};
                otherwise
                    error('too many inputs')
            end

            FORESTPLOT(M, col, PVP)

        end

        function arrows(M, col1, col2, varargin)
            % ARROWS Arrows plot of matrix data in two columns.
            %
            % ARROWS(M, col1, col2)
            % ARROWS(M, col1, col2, PVP)
            %
            % * col1 = 'from' column
            % * col2 = 'to' column
            % * PVP from go
            %
            % See also forestplot, compass, plot, pcolor.

            switch nargin
                case 3
                    PVP = ego('class', 'matrix', 'method', 'arrows');
                case 4
                    PVP = varargin{1};
                otherwise
                    error('wrong number of inputs')
            end

            ARROWS(M, col1, col2, PVP)

        end

        function varargout = compass(M, col1, col2, varargin)
            % COMPASS Compass plot of matrix data in two columns.
            %
            % COMPASS(M, col1, col2)
            % COMPASS(M, col1, col2, PVP)
            %
            % * col1 = 'from' column
            % * col2 = 'to' column
            % * PVP from go
            %
            % See also forestplot, arrows, plot, pcolor.

            switch nargin
                case 3
                    PVP = ego('class', 'matrix', 'method', 'compass');
                case 4
                    PVP = varargin{1};
                otherwise
                    error('wrong number of inputs')
            end

            X = COMPASS(M, col1, col2, PVP);

            switch nargout
                case 0
                case 1
                    varargout{1} = X;
                otherwise
                    error('too many outputs')
            end

        end

        function scatter(M, col1, col2, varargin)
            % SCATTER Scatter plot of matrix data in two columns.
            %
            % SCATTER(M, col1, col2)
            % SCATTER(M, col1, col2, PVP)
            %
            % * col1 = 'from' column
            % * col2 = 'to' column
            % * PVP from go
            %
            % See also forestplot, arrows, compass, plot, pcolor.

            switch nargin
                case 3
                    PVP = ego('class', 'matrix', 'method', 'scatter');
                case 4
                    PVP = varargin{1};
                otherwise
                    error('wrong number of inputs')
            end

            SCATTER(M, col1, col2, PVP)

        end

        function pcolor(M, varargin)
            % PCOLOR heat map of data in a matrix object.
            %
            % PCOLOR(M)
            % PCOLOR(M, go(...))
            % 
            % See also surf, hexmap.

            pcolor(M.data, varargin{:})

        end

        function hexmap(M, varargin)
            % HEXMAP hex map of data in a matrix object.
            %
            % HEXMAP(M)
            % HEXMAP(M, go(...))
            % 
            % See also surf, pcolor.

            hexmap(M.data, varargin{:})

        end

        function surf(M, varargin)
            % SURF surface plot of data in a matrix object.
            %
            % SURF(M)
            % SURF(M, go(...))
            % 
            % See also forestplot, arrows, compass, plot.

            surf(M.data, varargin{:})

        end

        function varargout = pcurve(M, c, varargin)
            % PCURVE Plot one column of a matrix.
            %
            % lego = PCURVE(M, c, go(...))
            %
            % See also matrix/plot, matrix/plotmatrix.

            lego = PCURVE(M, c, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = lego;
                otherwise
                    error('too many outputs')
            end

        end


        %%%
        % utilities
        %%%%

        function writematrix(M, fn)
            % WRITEMATRIX Write matrix object to an xls spreadsheet.
            %
            % WRITEMATRIX(M, 'FileName')
            %
            % This is a wrapper to MATLAB's writematrix function.
            %
            % See also tbl2table.

            WRITEMATRIX(M, fn)

        end

        % end methods
    end

    % end classdef
end
