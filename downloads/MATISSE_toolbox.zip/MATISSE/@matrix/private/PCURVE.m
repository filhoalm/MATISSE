function lego = PCURVE(M, c, varargin)
% PCURVE Plot one column of a matrix.
%
% lego = PCURVE(M, c, PVP)
%
% See also matrix/plot, matrix/plotmatrix.

lh = findobj(gcf, 'type', 'legend');
if ~isempty(lh)
    set(lh, 'AutoUpdate', 'off')
end

switch nargin
    case 0
        return
    case 1
        error('wrong number of inputs')
    case 2
        pvp = ego('class', 'matrix', 'method', 'pcurve');
    case 3
        pvp = varargin{1};
    otherwise
        error('too many inputs')
end

if ~isscalar(c)
    error('invalid column number')
end

if ~isa(M, 'matrix')
    error('M must be a matrix object')
end

[R, C] = size(M);
PVP = mascara(C, pvp);
DATA = M.curves{c};
data = DATA.data;

%%%
% are we trimming?
%%%
if pvp.Trim > 0
    data = DATA.data(pvp.Trim+1:1:R-pvp.Trim, :);
    R = R - 2*pvp.Trim;
end

if PVP.CI(c) && ne(M.type, 0)
    CIFlag = 1;
else
    CIFlag = 0;
end

switch CIFlag

    case 1

        % ignore spurious imaginary components in CI limits
        yci = real([data(1:R, 3)', data(R:-1:1, 4)']);
        xci = [data(1:R, 1)', data(R:-1:1, 1)'];
        %%%
        % remove undefined values from CI limits
        %%%
        INCi = ~isnan(yci);
        yci = yci(INCi);
        xci = xci(INCi);

        patch(xci, yci, PVP.MAP(c, :), ...
            'LineStyle', PVP.ls0{PVP.LineStyle(c)}, ...
            'EdgeColor', PVP.MAP(c, :), ...
            'EdgeAlpha', PVP.EdgeAlpha, ...
            'FaceAlpha', PVP.FaceAlpha);

        lego = line(data(:, 1), data(:, 2), ...
            'Color', PVP.MAP(c, :), ...
            'MarkerFaceColor', PVP.MAP(c, :), ...
            'MarkerEdgeColor', PVP.MarkerEdgeColorMAP(c, :), ...
            'LineStyle', PVP.ls0{PVP.LineStyle(c)}, ...
            'LineWidth', PVP.LineWidth(c), ...
            'Marker', PVP.mk0{PVP.Marker(c)}, ...
            'MarkerSize', PVP.MarkerSize(c));

    case 0

        lego = line(data(:, 1), data(:, 2), ...
            'Color', PVP.MAP(c, :), ...
            'MarkerFaceColor', PVP.MAP(c, :), ...
            'MarkerEdgeColor', PVP.MarkerEdgeColorMAP(c, :), ...
            'LineStyle', PVP.ls0{PVP.LineStyle(c)}, ...
            'LineWidth', PVP.LineWidth(c), ...
            'Marker', PVP.mk0{PVP.Marker(c)}, ...
            'MarkerSize', PVP.MarkerSize(c));
end

%%%
% axis and labels
%%%
ax = gca;

if eq(PVP.Grid, 1)
    set(ax, ...
        'XGrid', true, 'YGrid', true, ...
        'GridColor', PVP.clarinet(PVP.GridColor, :), ...
        'GridLineWidth', PVP.GridWidth, ...
        'GridAlpha', 0.25)
end

if ~isempty(PVP.XLim)
    set(ax, 'XLim', PVP.XLim)
end

if ~isempty(PVP.YLim)
    set(ax, 'YLim', PVP.YLim)
end
if strcmp(PVP.YDir, 'reverse')
    set(ax, 'YDir', 'reverse')
end

ax.XAxis.FontSize = PVP.FontSize(1);
set(ax, 'TickDir', 'out', 'PlotBoxAspectRatio', [PVP.Width 1 1])

if strcmp(ax.YAxisLocation, 'right') % user can plot data in left or right yaxis
    ax.YAxis(2).FontSize = PVP.FontSize(2);
else
    ax.YAxis(1).FontSize = PVP.FontSize(2);
end

% DATA.labels contains
% row labels label / y-axis in position 1 and
% col labels label / x-axis in position 2
% PVP.labels is a 3-vector, label x-axis (1), label y-axis (2), title (3)

if PVP.labels(1)
    TMP = M.data.labels{1};
    if numel(TMP) > PVP.MaxWidth
        TMP = TMP(1:PVP.MaxWidth);
    end
    xlabel(TMP, 'FontSize', PVP.FontSize(1))
end
if PVP.labels(2)
    switch C
        case {1, 2, 3}
            % use the fullname
            TMP = M.data.fullname;
        otherwise
            % no perfect choice / fullname could be very long if M resulted from
            % a matrix/horzcat operation
            TMP = M.data.labels{2};
            if numel(TMP) > PVP.MaxWidth
                TMP = TMP(1:PVP.MaxWidth);
            end
    end

    ylabel(TMP, 'FontSize', PVP.FontSize(2))
end
if PVP.labels(3)
    TMP = M.data.col_labels{c};
    if numel(TMP) > PVP.MaxWidth
        TMP = TMP(1:PVP.MaxWidth);
    end
    title(TMP, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
end


end
