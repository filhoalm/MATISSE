function D = JPX(M, col, varargin)

% Validate options
OPTS = options(M, col, varargin{:});

% select the target column / this will error out if col does not exist
S.type = '()';
S.subs = {':', col};
Mcol = subsref(M, S);

% we can and should restore to the original y values
Mcol.y = M.y;

% error out if any values are missing 
dat = Mcol.data.data;
if any(isnan(dat)) || any(~isfinite(dat))
    error('data contains one or more NaN, +Inf, or -Inf values')
end

% convert type 2 to type 3 COV (must be full for now)
switch M.type
    case 0
        error('joinpoint methods are not applicable to type 0 matrices')
    case {1, 3}
        COV = full(Mcol.COV);

    case 2
        % COV = spdiags(Mcol.COV, 0, R, R);
        COV = diag(Mcol.COV);
end

% calculate design matrices using statistics/jpx 
D = jpx(Mcol.y(:), OPTS.mink, OPTS.maxk, OPTS.a, OPTS.b, COV);

% save the joinpoint-specific options along with D
D.opts = struct(...
    'overdispersion', OPTS.overdispersion, ...
    'Alpha', OPTS.Alpha);

% save the selected column of M as well
D.M = Mcol;

end

function OPTS = options(M, col, varargin)
% Helper function

[R, C] = size(M);

if ~ismember(col, 1:C)
    error('invalid column')
end

OPTS = struct('mink', 1, 'maxk', 5, 'a', 3, 'b', R, 'overdispersion', 1, 'Alpha', 0.05);

N = numel(varargin);
lArgin = varargin;

while N >= 2
    propi = lArgin{1};
    vali = lArgin{2};
    switch lower(propi)

        case 'mink'
            if ~(isscalar(vali) && isreal(vali))
                error('mink must be a real scalar')
            else
                if vali~=round(vali) || vali < 0
                    error('mink must be a positive scalar')
                else
                    OPTS.mink = vali;
                end
            end

        case 'maxk'
            if ~(isscalar(vali) && isreal(vali))
                error('maxk must be a real scalar')
            else
                if vali~=round(vali) || vali < 0
                    error('maxk must be a positive scalar')
                else
                    OPTS.maxk = vali;
                end
            end

        case 'a'
            if ~(isscalar(vali) && isreal(vali))
                error('a must be a real scalar')
            else
                if vali~=round(vali) || vali < 0 || vali > R
                    error('a must be a positive scalar between 1 and the number of rows of the target matrix')
                else
                    OPTS.a = vali;
                end
            end

        case 'b'
            if ~(isscalar(vali) && isreal(vali))
                error('b must be a real scalar')
            else
                if vali~=round(vali) || vali < 0 || vali > R
                    error('b must be a positive scalar between 1 and the number of rows of the target matrix')
                else
                    OPTS.b = vali;
                end
            end

        case 'overdispersion'
            if ~isscalar(vali)
                error('overdispersion must be a scalar.')
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('overdisperson must be 0 or 1')
            end

            OPTS.overdispersion = vali;

        
        case 'alpha'
            if ~(isscalar(vali) && isreal(vali))
                error('Alpha must be a real scalar')
            elseif (vali < 0 || vali > 1)
                error('Alpha must lie between 0 and 1')
            else
                OPTS.Alpha = vali;
            end


        otherwise
    end

    % setup for the next pair
    lArgin = lArgin(3:end);
    N = numel(lArgin);
    if eq(N, 1)
        error('The last property has no matching value.');
    end

end

% consistency checks

if OPTS.mink > OPTS.maxk
    error('mink must be less than or equal to maxk')
end

if OPTS.a > OPTS.b 
    error('a must be less than or equal to b')
end


end


