function [S, BCL] = SLOPES(M)
% SLOPES Least squares slopes along the columns of matrix object M.

[R, C] = size(M);

% R must be >= 2
if R < 2
    S = struct('L', [], 'l', []);
    return
end

%%%
% slopes in the y direction (down the rows) conditional on x (columns)
%%%
DELTAy = M.y(2) - M.y(1);
l_R = (12/(DELTAy*(R-1)*R*(R+1))) * ((1:1:R)' - ((R+1)/2)*ones(R, 1))';
[TMP1, BCL] = contrasts(M, tbl('data', l_R, 'fullname', 'Slope Contrasts'));
S.L = TMP1';
DATA = S.L.data;
DATA.row_labels = M.data.col_labels;
DATA.col_labels = {'slope'};
% need to reverse
DATA.labels = M.data.labels([2 1]);
S.L.data = DATA;
S.L.y = M.x;

%%%
% slope in the x direction (across the columns)
%%%
if C >= 2
    DELTAx = M.x(2) - M.x(1);
    l_C = (12/(DELTAx*(C-1)*C*(C+1))) * ((1:1:C)' - ((C+1)/2)*ones(C, 1))';
    S.l = contrasts(S.L, l_C);
    DATA = S.l.data;
    DATA.fullname = [M.data.fullname ', Slope of Slopes'];
    DATA.labels = {'', ''};
    S.l.data = DATA;
else
    S.l = [];
end

end