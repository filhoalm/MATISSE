function SCATTER(M, col1, col2, pvp)
% scatter plot of matrix data in two columns

S.type = '()';
S.subs = {':', [col1 col2]};
P = subsref(M, S);

data1 = P.curves{1}.data;
data2 = P.curves{2}.data;

R = size(data1, 1);
% coMpute Actual SpecifiCAtions fRom go vAlues
PVP = mascara(R, pvp);

% R separate line objects, each with one data point
PT = line([data1(:, 2)'; data1(:, 2)'], [data2(:, 2)'; data2(:, 2)'], ...
    'LineStyle', 'none', 'Marker', 'o');

%%%
% set the properties of each point in PT
%%%

% Marker
[PT.Marker_I] = deal(PVP.mk0{PVP.Marker(:)});

% MarkerSize
TMP1 = num2cell(PVP.MarkerSize);
[PT.MarkerSize_I] = deal(TMP1{:});

% MarkerFaceColor
TMP2 = num2cell(PVP.MAP, 2);
[PT.MarkerFaceColor_I] = deal(TMP2{:});

% MarkerEdgeColor
TMP3 = num2cell(PVP.MarkerEdgeColorMAP, 2);
[PT.MarkerEdgeColor_I] = deal(TMP3{:});

if PVP.Legend
    txt = ['  ' str('data', cellstr(num2str((1:R)')))];
    text(data1(:, 2), data2(:, 2), ...
        txt.data, 'Color', [0 0 0], 'VerticalAlignment', 'middle', ...
        'HorizontalAlignment', 'left', ...
        'FontSize', PVP.FontSize(2));
end

    set_scatter_axis(gca, P, PT, PVP)

end

    function set_scatter_axis(ax, P, PT, PVP)
        % set scatter plot axis

        fn = [P.data.col_labels{2} ' vs ', P.data.col_labels{1}];
        %%%
        % axes
        %%%
        if eq(PVP.Grid, 1)
            set(ax, ...
                'XGrid', true, 'YGrid', true, ...
                'GridColor', PVP.clarinet(PVP.GridColor, :), ...
                'GridLineWidth', PVP.GridWidth, ...
                'GridAlpha', 0.25)
        end

        if ~isempty(PVP.XLim)
            set(ax, 'XLim', PVP.XLim)
        end

        if ~isempty(PVP.YLim)
            set(ax, 'YLim', PVP.YLim)
        end

        ax.YDir = PVP.YDir;
        ax.TickDir = 'out'; % author preference
        ax.PlotBoxAspectRatio = [PVP.Width 1 1];
        xlabel(P.data.col_labels{1}, 'FontSize', PVP.FontSize(1))
        ylabel(P.data.col_labels{2}, 'FontSize', PVP.FontSize(2))
        ax.YAxis.FontSize = PVP.FontSize(2);
        ax.XAxis.FontSize = PVP.FontSize(1);
        set(ax.Title, 'String', fn, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
        if PVP.Legend
            TMP = ['\color[rgb]{' str('data', num2str(PVP.MAP)) '}'];
            txt = ['^{' str('data', cellstr(num2str((1:size(P, 1))'))) '}', TMP, str('data', P.data.row_labels)];
            legend(PT(:), txt.data, ...
                'Location', 'southoutside', 'NumColumns', 4, 'Box', 'off', 'FontSize', PVP.FontSize(1))
        end

    end