function E = PC(M)
% percent change function


T = M.data;
[R, C] = size(T);
T.data = 100 * (exp(T.data) - 1);
T.fullname = ['pc( ' T.fullname ' )'];
dat = M.data.data;
dmv = 100 * exp(dat(:));

switch M.type

    case 0
        COV = 0;

    case {1, 2}
        COV = M.COV .* reshape(dmv .* dmv, R, C);
  
    case 3
        N = numel(dmv);
        DMV = spdiags(dmv, 0, N, N);
        COV = DMV * M.COV * DMV';

end

E = matrix(...
    'data', T, ...
    'x', M.x, ...
    'y', M.y, ...
    'COV', COV, ...
    'Alpha', M.Alpha);

