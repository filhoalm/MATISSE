function [P, L] = PAD(M, varargin)
% PAD Border a matrix with rows and columns containing 0 or NaN.

N = numel(varargin);

if N == 0
    P = M;
    L = [];
    return
end

PVP = options(varargin{:});

if eq(PVP.rows, 0) && eq(PVP.cols, 0)
    P = M;
    L = [];
    return
end

% selection matrix for rows
[R, C] = size(M);
RC = R*C;
IR = speye(R);
IC = speye(C);

blank = '*';
rl = M.data.row_labels;
cl = M.data.col_labels;
fn = M.data.fullname;
lb =  M.data.labels;

if PVP.rows > 0
    switch PVP.rpos
        case 'top'
            rSEL = [IR; PVP.fill*sparse(PVP.rows, R)];
            rNaN = [IR; NaN(PVP.rows, R)];
            yl = M.y(R);
            if R > 1
                dy = yl - M.y(R-1);
            else
                dy = 1;
            end
            ystar = [M.y, (yl + dy * (1:1:PVP.rows))];
            rls = [str('data', rl); repmat(blank, PVP.rows, 1); ];
        case 'bottom'
            rSEL = [sparse(PVP.rows, R); IR];
            rNaN = [NaN(PVP.rows, R); IR];
            yf = M.y(1);
            if R > 1
                dy = M.y(2) - yf;
            else
                dy = 1;
            end
            %ystar = [(yf - dy * (1:1:PVP.rows)), M.y];
                  ystar = [(yf - dy * (PVP.rows:-1:1)), M.y];

            rls = [repmat(blank, PVP.rows, 1); str('data', rl)];
    end

else
    rSEL = IR;
    rNaN = IR;
    ystar = M.y;
    rls = str('data', rl);
end

if PVP.cols > 0
    switch PVP.cpos
        case 'left'
            cSEL = [sparse(C, PVP.cols), IC];
            cNaN = [NaN(C, PVP.cols), IC];
            xf = M.x(1);
            if C > 1
                dx = M.x(2) - xf;
            else
                dx = 1;
            end
            xstar = [(xf - dx * (PVP.cols:-1:1)), M.x];
            cls = [repmat(blank, PVP.cols, 1); str('data', cl)];
        case 'right'
            cSEL = [IC, sparse(C, PVP.cols)];
            cNaN = [IC, NaN(C, PVP.cols)];
            xl = M.x(C);
            if C > 1
                dx = xl - M.x(C-1);
            else
                dx = 1;
            end
            xstar = [M.x, (xl + dx * (1:1:PVP.cols))];
            cls = [str('data', cl); repmat(blank, PVP.cols, 1)];
    end
else
    cSEL = IC;
    cNaN = IC;
    xstar = M.x;
    cls = str('data', cl);
end


%%%
% Key result from linear algebra:
% S = vec(A*B*C) = kron(C', A)*vec(B)
% COV_S = kron(C', A) * COV_B * kron(C', A)'
%%%

L = kron(cSEL', rSEL);
DAT = M.data.data;
m = sparse(DAT);

switch PVP.fill
    case 1
        DAT = reshape(L*m(:), R + PVP.rows, C + PVP.cols);
    case 0
        DAT = rNaN * m * cNaN;
end

T = tbl(...
    'data', DAT, ...
    'fullname', fn, ...
    'labels', lb, ...
    'row_labels', rls.data, ...
    'col_labels', cls.data);

switch M.type

    case 0
        COV = 0;

    case 1
        COV = M.COV * (L*L');

    case 2
        COV = L * spdiags(M.COV(:), 0, RC, RC) * L';

    case 3
        COV = L * M.COV * L';

end


P = matrix(...
    'data', T, ...
    'x', xstar, ...
    'y', ystar, ...
    'COV', COV, ...
    'Alpha', M.Alpha);

end

% helper functions

function PVP = options(varargin)

% default values
PVP = struct(...
    'rows', 0, ...
    'rpos', 'bottom', ...
    'cols', 0, ...
    'cpos', 'right', ...
    'fill', 1);

%%%
% whittle the arguments
%%%
N = nargin;
lArgin = varargin;

while N >= 2

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('a property must be specified using a string')
    end

    switch lower(propi)

        case {'row', 'rows'}
            if ~(isscalar(vali) && isreal(vali))
                error('rows must be a real scalar')
            elseif (vali < 0)
                error('rows must non-negative')
            else
                PVP.rows = lower(vali);
            end

        case 'rpos'
            if ~ischar(vali)
                error('''rpos must a be a string')
            end
            vali = lower(vali);
            if ~any(strcmp(vali, {'top', 'bottom'}))
                error('invalid rpos')
            end
            
            PVP.rpos = vali;

        case {'col', 'cols'}
            if ~(isscalar(vali) && isreal(vali))
                error('cols must be a real scalar')
            elseif (vali < 0)
                error('cols must non-negative')
            else
                PVP.cols = lower(vali);
            end

        case 'cpos'
            if ~ischar(vali)
                error('''cpos must a be a string')
            end
            vali = lower(vali);
            if ~any(strcmp(vali, {'left', 'right'}))
                error('invalid cpos')
            end
           
            PVP.cpos = vali;

        case 'fill'
            if ~(isscalar(vali) && isreal(vali))
                error('fill must be 0 or 1')
            end
            if eq(vali, 0) || eq(vali, 1)
                PVP.fill = vali;
            else
                error('fill must be 0 or 1')
            end

        otherwise
    end

    % setup for the next pair
    lArgin = lArgin(3:end);
    N = numel(lArgin);
    if eq(N, 1)
        error('the last property has no matching value');
    end

end

end


