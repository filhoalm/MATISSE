function E = CUMSUM(M)
% Cumulative sums down the columns of matrix M. 

[R, C] = size(M);
RC = R*C;

B = tril(true(R, R));
IC = speye(C);
S = kron(IC, B);

m = M.data.data(:);
y = S*m;
Y = reshape(y, R, C);

T = M.data;
T.data = Y;
ol = T.labels;
nl = ol;
nl{1} = ['cumsum( ' ol{1} ' )'];
T.labels = nl;
T.fullname = ['cumsum( ' T.fullname ')'];

switch M.type

    case 0
        COV = 0;

    case 1
        COV = M.COV * (S*S');
  
    case 2
        COV = S * spdiags(M.COV(:), 0, RC, RC) * S';

    case 3      
        COV = S * M.COV * S';

end

E = matrix(...
    'data', T, ...
    'x', M.x, ...
    'y', M.y, ...
    'COV', COV, ...
    'Alpha', M.Alpha);

