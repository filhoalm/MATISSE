function [F, BCL] = CONTRASTS(varargin)
% Apply contrast matrix L to the columns of M.

arg1 = varargin{1};
arg2 = varargin{2};

if isa(arg1, 'matrix') && isa(arg2, 'matrix')
    error('only one argument can be a matrix')
end

if isa(arg1, 'matrix')
    M = arg1;
    L = arg2;
else
    M = arg2;
    L = arg1;
end

[R, C] = size(M);
[rL, cL] = size(L);


if ne(cL, R)
    error('the number of columns of L must equal the number of rows of M')
end

switch class(L)
    case 'tbl'
        if isempty(L.row_labels{1}) && eq(numel(L.row_labels), 1)
            rl = cellstr(num2str((1:rL)', 'C%g'));
        else
            rl = L.row_labels;
        end
        
        if isempty(L.fullname)
            fn = ' Contrasts';
        else
            fn = [' ' L.fullname];
        end
        
        cl = M.data.col_labels;

        CM = L.data;
      
    case 'double'
        rl = cellstr(num2str((1:rL)'));
        cl = cellstr(num2str((1:C)'));
        fn = ' Contrasts';

        CM = L;

    otherwise
        error('L must be a double or tbl')

end

F = tbl(...
    'data', CM * M.data.data, ...
    'fullname', [M.data.fullname ', ' fn], ...
    'row_labels', rl, ...
    'col_labels', cl, ...
    'labels', {[M.data.labels{1} fn], M.data.labels{2}});

switch M.type
    case {0, 1, 3}
        COV = M.COV;
    case 2
        COV = spdiags(M.COV(:), 0, R*C, R*C);
    otherwise
end

BCL = kron(speye(C), CM);

V = BCL * COV * BCL';

%%%
% When rL == R let F inherit y from M
% and let F.data inherit col_labels from M
%%%
if eq(rL, R)
    y = M.y;
    F.col_labels = M.data.col_labels;
else
    y = 1:rL;
end

F = matrix(...
    'data', F, ...
    'y', y, ...
    'COV', V, ...
    'Alpha', M.Alpha);

end

