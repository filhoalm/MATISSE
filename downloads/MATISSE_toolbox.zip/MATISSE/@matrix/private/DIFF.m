function [D, BCL] = DIFF(M)
% DIFF Scaled first differences within the columns of matrix object M.

R = size(M, 1);

% R must be >= 2
if R < 2
    D = [];
    return
end

DELTAy = M.y(2) - M.y(1);
R0 = R - 1;

D_R = (1/DELTAy) * ...
    [speye(R0), sparse(R0, 1)] * ...
    (spdiags(-ones(1, R), 0, R, R) + spdiags(ones(1, R0), +1, R, R));

[d, BCL] = contrasts(M, D_R);
TMP = d.data;
TMP.labels = M.data.labels;

D = matrix(...
    'data', d.data, ...
    'y', M.y(2:R), ...
    'x', M.x, ...
    'COV', d.COV, ...
    'Alpha', d.Alpha);

end