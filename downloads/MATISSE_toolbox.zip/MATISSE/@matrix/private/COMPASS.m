function X = COMPASS(M, col1, col2, pvp)
% compass plot of matrix data in two columns

S.type = '()';
S.subs = {':', [col1 col2]};
P = subsref(M, S);
[R, C] = size(P);
RC = R*C;
PVP = mascara(R, pvp);

% confidence radius for standard normal
confidenceRadius = crr([1 1], 1 - PVP.Alpha);

switch P.type
    case {0, 1, 3}
        cov = P.COV;
    case 2
        cov = spdiags(P.COV(:), 0, RC, RC);
end

COV = zeros(2, 2, R);
for r = 1:R
    switch P.type
        case 0
        case 1
            COV(:, :, r) = cov * eye(2);
        otherwise
            COV(:, :, r) = cov([r R+r], [r R+r]);
    end
end

[U, S, V] = pagesvd(COV);

r1 = zeros(R, 1);
r2 = zeros(R, 1);
azd = zeros(R, 1);
XY = zeros(2, 361, R);
for r = 1:R
    Er = landmarks(U(:, :, r), S(:, :, r), V(:, :, r), confidenceRadius);
    r1(r) = Er.S(1,1);
    r2(r) = Er.S(2,2);
    azd(r) = Er.azd;
    XY(:, :, r) = Er.XY;
end

%%%
% Sector analysis
%%%
Sector = NaN(R, 16);
for r = 1:R

    y = P.data.data(r, 1) + XY(1, :, r)';
    z = P.data.data(r, 2) + XY(2, :, r)';

    score = [...
        (abs(z) < 1e6 * eps) & (y >= 0) , ... % 1
        (z <   y) & (y >  0) & (z > 0) & ~(abs(z - y) < 1e6 * eps), ... % 2
        (abs(z - y) < 1e6 * eps) & (y >  0) , ... % 3
        (z >   y) & (sign(y) == 1) & ~(abs(y) < 1e6 * eps) & ~(abs(z - y) < 1e6 * eps), ... % 4
        (z >   0) & (abs(y) < 1e6 * eps) , ... % 5
        (z >   0) & (y <  0) & (z > -y) & ~(abs(z + y) < 1e6 * eps), ... % 6
        (abs(z + y) < 1e6 * eps) & (y <  0) , ... % 7
        (z <  -y) & (y <  0) & (z > 0) & ~(abs(z + y) < 1e6 * eps) & ~(abs(z) < 1e6 * eps), ... % 8
        (abs(z) < 1e6 * eps) & (y <  0) , ... % 9
        (z <   0) & (z >  y) & (y < 0) & ...
        ~(abs(z) < 1e6 * eps) & ~(abs(y) < 1e6 * eps) & ~(abs(z - y) < 1e6 * eps), ... % 10
        (abs(z - y) < 1e6 * eps) & (y <  0) & (z < 0), ... % 11
        (z <   y) & (y <  0) & (z < 0) & ...
        ~(abs(z - y) < 1e6 * eps) & ~(abs(y) < 1e6 * eps), ... % 12
        (z <   0) &  (abs(y) < 1e6 * eps), ... % 13
        (z <  -y) & (y >  0) & ~(abs(z + y) < 1e6 * eps), ... % 14
        (abs(z + y) < 1e6 * eps) & (y >  0) , ... % 15
        (z <   0) & (z > -y) & (y > 0)]; % 16
    Sector(r, :) = sum(score, 1);

end

X.SectorData = Sector;

%%%
% Direction
%%%
n = NaN(R, 1);
TMP1 = NaN(R, 16);
TMP2 = NaN(R, 1);
for r = 1:R

    Js = find(X.SectorData(r, :));
    n(r) = numel(Js);
    TMP1(r, 1:n(r)) = Js;
    if n(r) == 1
        TMP2(r) = Js;
    else
        TMP2(r) = 0;
    end
end

nl = {'1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', ...
    '10th', '11th', '12th', '13th', '14th', '15th', '16th'};
sl = {...
    ' zeroed ', ...
    ' shrunk ', ...
    ' unchanged ', ...
    ' amplified ', ...
    ' induced_{\it{0/+}} ', ...
    ' flipped_{\it{-/+}}^{amplified} ', ...
    ' reversed_{\it{-/+}} ', ...
    ' flipped_{\it{-/+}} ', ...
    ' zeroed ', ...
    ' shrunk ', ...
    ' unchanged ', ...
    ' amplified ', ...
    ' induced_{\it{0/-}} ', ...
    ' flipped_{\it{+/-}}^{amplified} ', ...
    ' reversed_{\it{+/-}} ', ...
    ' flipped_{\it{+/-}} '};
rl = cell(1, R);
for r = 1:R
    if n(r) == 1
        rl{r} = sl{TMP1(r, 1)};
    elseif n(r) == 0
        rl{r} = ' ';
    else
        rl{r} = ' mixed ';
    end
end

cl0 = {'Singleton', 'No. Sectors'};
cl1 = nl(1:max(n));
cl = [cl0, cl1];
X.Summary = tbl(...
    'data', [TMP2, n, TMP1(:, 1:max(n))], ...
    'fullname', 'Direction', ...
    'row_labels', rl, ...
    'col_labels', cl);

if PVP.Plot

    X.CR = ellipses(P.data.data(:, 1), P.data.data(:, 2), r1, r2, azd, PVP);
    axis image
    [X.CR.centroids, ~] = goCentroids(P, PVP);
    goOrigin(gca, PVP)
    goLabels(X.CR.centroids, P, PVP)

else

    X.CR = [];

end

end

function E = landmarks(U, S, V, confidenceRadius)
% landmarks

E.U = U;
E.S = S;
E.V = V;

V1 = E.V(:, 1);
y0 = V1(2); x0 = V1(1);
E.VROTr = (y0>=0).*atan2(y0,x0) + (y0<0).*(pi - atan2(y0,-x0));
E.VROTd = rad2deg(E.VROTr);
E.VROT = [cos(E.VROTr) -sin(E.VROTr); sin(E.VROTr) cos(E.VROTr)];
% reflect around pi unless VROTr is 0: if VROTr is 0 E.VREF is eye(2)
E.vreflection = sign(E.VROTr/pi);
E.VREF = [cos(2*pi) sin(2*pi); sin(2*pi) ((-1)^(E.vreflection))*cos(2*pi)];

% angle of semi-major axis of U basis
U1 = E.U(:, 1);
y0 = U1(2); x0 = U1(1);
E.UROTr = (y0>=0).*atan2(y0,x0) + (y0<0).*(pi - atan2(y0,-x0));
E.UROTd = rad2deg(E.UROTr);
E.UROT = [cos(E.UROTr) -sin(E.UROTr); sin(E.UROTr) cos(E.UROTr)];
% reflect around pi unless UROTr is 0: if UROTr is 0 E.UREF is eye(2)
E.ureflection = sign(E.UROTr/pi);
E.UREF = [cos(2*pi) sin(2*pi); sin(2*pi) ((-1)^(E.ureflection))*cos(2*pi)];

dfoci = sqrt(E.S(1,1)^2-E.S(2,2)^2);

% after rotation:
F2 = [-dfoci; 0];
F1 = [+dfoci; 0];
ROTF1 = E.U*F1;
ROTF2 = E.U*F2;
E.Foci = [ROTF1, ROTF2];

if E.ureflection
    E.azd = -E.UROTd;
else
    E.azd = E.UROTd;
end

% standard circle
rad = (0:(2*pi)/360:2*pi)';
x = cos(rad);
y = sin(rad);

% standard circle expanded by the confidence radius and then mapped by M
E.XY = (U * S * V')*(confidenceRadius.*[x, y]');

end

function goOrigin(ax, PVP)
% draw axis with or without inclusion of origin and compass lines

if isempty(PVP.XLim)
    XL = get(ax, 'XLim');
else
    XL = PVP.XLim;
end
YL = get(ax, 'YLim');

if PVP.Origin

    set(ax, 'YAxisLocation', 'origin', 'XAxisLocation', 'origin', ...
        'TickDir', 'both', 'Box', 'off', ...
        'FontSize', PVP.FontSize(1))

    XL0 = [-max(abs(XL)) +max(abs(XL))];
    YL0 = [-max(abs(YL)) +max(abs(YL))];

    XYL = [min([XL0(1), YL0(1)]), max([XL0(2), YL0(2)])];

    set(ax, 'XLim', XYL, 'YLim', XYL)

    XT = get(ax, 'XTick');
    XT = XT(XT > 0);
    YT = get(ax, 'YTick');
    YT = YT(YT > 0);
    if numel(XT) > numel(YT)
        AT = XT;
    else
        AT = YT;
    end
    nT = numel(AT);
    switch nT
        case 0
            cf = 0;
            cn = 0;

        case {1, 2, 3}
            cf = 1;
            r = AT;
            cn = nT;

        otherwise
            cf = 1;
            if rem(nT, 2) == 0
                % even
                r = AT([1, nT/2, nT]);
            else
                % odd
                cf = 1;
                r = AT([1 floor(nT/2) nT]);
            end
            cn = 3;
    end

    if cf == 1
        circles(zeros(1, cn), zeros(1, cn), r, ...
            go('LineColor', 15, 'FaceAlpha', 0, 'LineStyle', 3, 'LineWidth', 2))
    end

    rline(0, +1, go('LineStyle', 1, 'LineColor', 15, 'LineWidth', 1))
    rline(0, -1, go('LineStyle', 1, 'LineColor', 15, 'LineWidth', 1))

else

    if ~isempty(PVP.XLim)

        set(ax, 'XLim', PVP.XLim, 'YLim', PVP.XLim)
        set(ax, 'TickDir', 'both', 'Box', 'off')

    end

end

end

function goLabels(H, P, PVP)
% add labels and legend

if PVP.Origin
    if PVP.labels(1)
        xlabel(P.data.col_labels{1}, 'VerticalAlignment', 'bottom', ...
            'HorizontalAlignment', 'left', ...
            'FontSize', PVP.FontSize(1))
    end
    if PVP.labels(2)
        ylabel(P.data.col_labels{2}, 'VerticalAlignment', 'top', ...
            'HorizontalAlignment', 'left', ...
            'FontSize', PVP.FontSize(2))
    end
else
    if PVP.labels(1)
        xlabel(P.data.col_labels{1}, 'VerticalAlignment', 'top', ...
            'HorizontalAlignment', 'left', ...
            'FontSize', PVP.FontSize(1))
    end
    if PVP.labels(2)
        ylabel(P.data.col_labels{2}, 'VerticalAlignment', 'baseline', ...
            'HorizontalAlignment', 'left', ...
            'FontSize', PVP.FontSize(2))
    end
end

if PVP.Legend
    TMP = ['\color[rgb]{' str('data', num2str(PVP.MAP)) '}'];
    txt = ['^{' str('data', cellstr(num2str((1:size(P, 1))'))) '}', TMP, str('data', P.data.row_labels)];
    legend([H{:}], txt.data, ...
        'Location', 'southoutside', 'NumColumns', 4, 'Box', 'off', 'FontSize', PVP.FontSize(1))
end

end

function [D, T] = goCentroids(P, PVP)
% Add centroids

R = size(P, 1);
D = cell(1, R);

for r = 1:R

    D{r} = line(P.data.data(r, 1), P.data.data(r, 2), ...
        'Color', PVP.MAP(r, :), ...
        'MarkerFaceColor', PVP.MAP(r, :), ...
        'MarkerEdgeColor', [0.925 0.925 0.925], ...
        'LineStyle', 'none', ...
        'Marker', PVP.mk0{PVP.Marker(r)}, ...
        'MarkerSize', PVP.MarkerSize(r));
end

if PVP.Legend
    txt = ['  ' str('data', cellstr(num2str((1:R)')))];
    T = text(P.data.data(:, 1), P.data.data(:, 2), ...
        txt.data, 'Color', [0 0 0], 'VerticalAlignment', 'middle', ...
        'HorizontalAlignment', 'left', ...
        'FontSize', PVP.FontSize(2));
else
    T = [];
end
end