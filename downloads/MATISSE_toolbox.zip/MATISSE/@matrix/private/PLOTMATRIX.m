function PLOTMATRIX(M, pvp)
% PLOTMATRIX Plot the columns of matrix M in separate panels.

opts = options(M, pvp);

if isempty(M), return, end

pixels = 350;
set(gcf, 'Position', [100 100 opts.PVP.Width*opts.c0*pixels opts.r0*pixels])
C = size(M, 2);
for c = 1:C
    subplot(opts.r0, opts.c0, c)
    pcurve(M, c, opts.PVP)
end

end

function opts = options(M, pvp)

opts = struct('r0', [], 'c0', [], 'PVP', []);

C = size(M, 2);

% round C to the nearest even number
Cstar = C + rem(C, 2);

opts.PVP = mascara(C, pvp);

% size of plotmatrix allowing for at most XX columns
XX = 6;
divisors = find(mod(Cstar, 1:XX)==0, Cstar);
divisors(divisors > Cstar) = [];
if isempty(divisors)
    divisors = 1;
end
c0 = max(divisors);
r0 = Cstar/c0;

opts.r0 = r0;
opts.c0 = c0;

end