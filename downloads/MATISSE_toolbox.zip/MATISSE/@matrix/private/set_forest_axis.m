function set_forest_axis(ax, caller, M, cols, PVP)
% common code used by forestplot and arrows

% NOTE: forestplot and arrows use ordinates 1, 2, 3, etc.
%     > M.y values are not used
%     * that is why options like 'Bands' work consistently

switch caller
    case 'forestplot'
        col1 = cols;
        fn = M.data.col_labels{col1};
    case 'arrows'
        col1 = cols(1);
        col2 = cols(2);
        fn = [M.data.col_labels{col1} '\rightarrow', M.data.col_labels{col2}];
    otherwise
end

switch PVP.orientation

    case 'horizontal'

        %%%
        % axes
        %%%
        if eq(PVP.Grid, 1)
            set(ax, ...
                'XGrid', true, 'YGrid', true, ...
                'GridColor', PVP.clarinet(PVP.GridColor, :), ...
                'GridLineWidth', PVP.GridWidth, ...
                'GridAlpha', 0.25)
        end

        if ~isempty(PVP.XLim)
            set(ax, 'XLim', PVP.XLim)
        end

        ax.TickDir = 'out'; % author preference
        ax.PlotBoxAspectRatio = [PVP.Width 1 1];
        if PVP.labels(1)
            xlabel(M.data.labels{1}, 'FontSize', PVP.FontSize(1))
        end
        if PVP.labels(2)
            ylabel(fn, 'FontSize', PVP.FontSize(2))
        end
        if PVP.labels(3)
            set(ax.Title, 'String', fn, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
        end

        R = size(M, 1);
        ax.YTick = (1:R)';
        q1 = str('data', num2str(PVP.MAP));
        r1 = str('data', M.data.row_labels);
        s1 = ['\color[rgb]{' q1 '}' r1];
        ax.YTickLabel = s1.data;
        ax.YAxis(1).FontSize = PVP.FontSize(2);
        ax.XAxis.FontSize = PVP.FontSize(1);
        ax.YLim = [0.5 R+0.5];
        ax.YDir = PVP.YDir;

        %%%
        % Text annotations along the right y-axis
        %%%%
        if PVP.Text
            yyaxis right
            axr = gca;
            axr.YTick = M.y;
            axr.YLabel.String = '';
            switch caller
                case 'forestplot'
                    if all(PVP.CI) && ne(M.type, 0)
                        vals = M.curves{col1}.data(:, 2:4);
                        txts = cellstr(num2str(vals(:, 1), PVP.formatSpec));
                        txtl = cellstr(num2str(vals(:, 2), PVP.formatSpec));
                        txth = cellstr(num2str(vals(:, 3), PVP.formatSpec));
                        r2 = ['\bf' str('data', txts) '\rm (' str('data', txtl) ',' str('data', txth) ')'];
                        s2 = ['\color[rgb]{' q1 '}' r2];
                    else
                        vals = M.curves{col1}.data(:, 2);
                        txts = cellstr(num2str(vals(:, 1), PVP.formatSpec));
                        r2 = ['\bf' str('data', txts) '\rm'];
                        s2 = ['\color[rgb]{' q1 '}' r2];
                    end

                case 'arrows'
                    vals = M.data.data(:, [col1 col2]);
                    txt1 = cellstr(num2str(vals(:, 1), PVP.formatSpec));
                    txt2 = cellstr(num2str(vals(:, 2), PVP.formatSpec));
                    r1 = str('data', txt1);
                    r2 = str('data', txt2);
                    s2 = ['\color[rgb]{' q1 '}' r1 '\rightarrow' r2];

                otherwise
            end

            axr.YTickLabel = s2.data;
            axr.YAxis(2).FontSize = PVP.FontSize(2);
            axr.YLim = [0.5 R+0.5];
            axr.YDir = PVP.YDir;

        end

        %%%
        % Demarcation bands
        %%%
        if PVP.Bands > 0
    
            DEL = (PVP.Bands - 1)/2;

            sR = (1:PVP.Bands:R)';
            lR = sR - 0.5*PVP.Bands + DEL;
            uR = sR + 0.5*PVP.Bands + DEL;
            NB = numel(sR);
            for i = 1:2:NB

                y0 = [lR(i), lR(i), uR(i), uR(i)];
                patch(ax.XAxis(1).Limits([1 2 2 1]), y0, [0.5 0.5 0.5], ...
                    'FaceAlpha', 0.10, 'LineStyle', 'none')

            end
          
            % Freeze changes to x-axis limits
            ax.XAxis(1).LimitsMode = 'manual';
           
        end

    case 'vertical'

        %%%
        % axes
        %%%
        if eq(PVP.Grid, 1)
            set(ax, ...
                'XGrid', true, 'YGrid', true, ...
                'GridColor', PVP.clarinet(PVP.GridColor, :), ...
                'GridLineWidth', PVP.GridWidth, ...
                'GridAlpha', 0.25)
        end

        if ~isempty(PVP.XLim)
            set(ax, 'XLim', PVP.XLim)
        end

        ax.TickDir = 'out'; % author preference
        ax.PlotBoxAspectRatio = [PVP.Width 1 1];
        if PVP.labels(1)
            xlabel(fn, 'FontSize', PVP.FontSize(1))
        end
        if PVP.labels(2)
            ylabel(M.data.labels{1}, 'FontSize', PVP.FontSize(2))
        end
        if PVP.labels(3)
            set(ax.Title, 'String', fn, 'FontSize', PVP.FontSize(3), 'FontWeight', 'normal')
        end

        R = size(M, 1);
        ax.XTick = (1:R)';
        q1 = str('data', num2str(PVP.MAP));
        r1 = str('data', M.data.row_labels);
        s1 = ['\color[rgb]{' q1 '}' r1];
        ax.XTickLabel = s1.data;
        ax.XAxis(1).FontSize = PVP.FontSize(1);
        ax.XAxis.FontSize = PVP.FontSize(2);
        ax.XLim = [0.5 R+0.5];
        ax.XDir = PVP.YDir;

        %%%
        % Text annotations along the top x-axis
        %%%%
        if PVP.Text
            axr = gca;
            axr.XTick = M.y;
            switch caller
                case 'forestplot'
                    if all(PVP.CI) && ne(M.type, 0)
                        vals = M.curves{col1}.data(:, 2:4);
                        txts = cellstr(num2str(vals(:, 1), PVP.formatSpec));
                        txtl = cellstr(num2str(vals(:, 2), PVP.formatSpec));
                        txth = cellstr(num2str(vals(:, 3), PVP.formatSpec));
                        r2 = ['\bf' str('data', txts) '\rm (' str('data', txtl) ',' str('data', txth) ')'];
                        s2 = ['\color[rgb]{' q1 '}' r2];
                    else
                        vals = M.curves{col1}.data(:, 2);
                        txts = cellstr(num2str(vals(:, 1), PVP.formatSpec));
                        r2 = ['\bf' str('data', txts) '\rm'];
                        s2 = ['\color[rgb]{' q1 '}' r2];
                    end

                case 'arrows'
                    vals = M.data.data(:, [col1 col2]);
                    txt1 = cellstr(num2str(vals(:, 1), PVP.formatSpec));
                    txt2 = cellstr(num2str(vals(:, 2), PVP.formatSpec));
                    r1 = str('data', txt1);
                    r2 = str('data', txt2);
                    s2 = ['\color[rgb]{' q1 '}' r1 '\rightarrow' r2];

                otherwise
            end
            YL = axr.YLim;
            switch PVP.YDir
                case 'normal'
                    yv = YL(2)*ones(1, R);
                case 'reverse'
                    yv = YL(1)*ones(1, R);
            end

            text(ax.XTick, yv, s2.data, ...
                'Rotation', -90, 'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'bottom', ...
                'FontSize', PVP.FontSize(1))
            axr.YDir = PVP.YDir;

        end

        %%%
        % Demarcation bands
        %%%
        if PVP.Bands > 0

            % Freeze changes to y-axis limits
            ax.YAxis(1).LimitsMode = 'manual';

            DEL = (PVP.Bands - 1)/2;

            sR = (1:PVP.Bands:R)';
            lR = sR - 0.5*PVP.Bands + DEL;
            uR = sR + 0.5*PVP.Bands + DEL;
            NB = numel(sR);
            for i = 1:2:NB

                y0 = [lR(i), lR(i), uR(i), uR(i)];
                patch(y0, ax.YAxis(1).Limits([1 2 2 1]), y0, [0.5 0.5 0.5], ...
                    'FaceAlpha', 0.10, 'LineStyle', 'none')
            end

        end

end
