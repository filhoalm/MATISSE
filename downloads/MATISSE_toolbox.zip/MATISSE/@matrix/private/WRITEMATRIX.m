function WRITEMATRIX(M, fn)
% WRITEMATRIX - Write the fields in matrix object M to sheets in spreadsheet fn.

% The column labels of the data must all be distinct. If this is not the
% case, enhance them with an index number.

nu = numel(unique(M.data.col_labels));
C = size(M, 2);

if ~eq(nu, C)
    
    uniqueColLabels = ...
        [str('data', M.data.col_labels), ' ', str('data', cellstr(num2str((1:C)')))];
    DAT = M.data;
    DAT.col_labels = uniqueColLabels.data;
    M.data = DAT;

end

writetable(tbl2table(M.data), fn, 'FileType', 'spreadsheet', ...
    'WriteRowNames', true, 'WriteVariableNames', true, 'Sheet', 'data')

writematrix(M.y', fn, 'FileType', 'spreadsheet', 'Sheet', 'y')
writematrix(M.x', fn, 'FileType', 'spreadsheet', 'Sheet', 'x')

writetable(...
    tbl2table(tbl('data', [M.type, M.Alpha], 'col_labels', {'type', 'Alpha'})), ...
    fn, 'FileType', 'spreadsheet', 'Sheet', 'metadata')
try
    [s1, s2] = size(M.COV);
    RANGE = excela1(1, 1, s1, s2);
    writematrix(full(M.COV), fn, 'FileType', 'spreadsheet', 'Range', RANGE, 'Sheet', 'COV')
catch
    writematrix('COV matrix is too large for export to a spreadsheet', fn, ...
        'FileType', 'spreadsheet', 'Sheet', 'COV')
end

[~, C] = size(M);
for c = 1:C
    writetable(tbl2table(M.curves{c}), fn, ...
        'FileType', 'spreadsheet', 'Sheet', ['Curve ' num2str(c)])
end

end