function S = SCALE(varargin)
% Element-wise product of matrix M by values W.

arg1 = varargin{1};
arg2 = varargin{2};

if isa(arg1, 'matrix') && isa(arg2, 'matrix')
    error('only one argument can be a matrix')
end

if isa(arg1, 'matrix')
    M = arg1;
    w = arg2;
else
    M = arg2;
    w = arg1;
end

[R, C] = size(M);

%%%
% pre-process: coerce w to a (1 x 1) or (R x C) tbl
%%%

if isreal(w)
    if isscalar(w)
        WisScalar = 1;
        sw = num2str(w, '%g');
        W = tbl('data', w, 'fullname', sw, 'labels', {sw, sw});
    else
        [r, c] = size(w);
        if ne(r, R) || ne(c, C)
            error('size mismatch')
        end
        WisScalar = 0;
        W = tbl('data', w, 'fullname', 'numeric', ...
            'labels', {'numeric', 'numeric'});
    end
elseif isa(w, 'tbl')
    if isscalar(w.data)
        WisScalar = 1;
    else
        [r, c] = size(w.data);
        if ne(r, R) || ne(c, C)
            error('size mismatch')
        end
        WisScalar = 0;
    end
    W = w;
else
    error('values W must be numeric or tbl')
end

%%%
% scale the data using tbl/times function
%%%
DAT = times(M.data, W);

%%%
% compute the scaled variance-covariance matrix
%%%
switch WisScalar
    case 1

        COV = W.data.^2 .* M.COV;

    otherwise

        switch M.type
            case 0
                COV = 0;

            case {1, 2}
                COV = (W.data.^2) .* M.COV;

            case 3
                v = W.data(:);
                COV = (v * v') .* M.COV;

            otherwise

        end

end

%%%
% pass the new data and COV matrix through the constructor
%%%

S = matrix(...
    'data', DAT, ...
    'x', M.x, ...
    'y', M.y, ...
    'COV', COV, ...
    'Alpha', M.Alpha);

end