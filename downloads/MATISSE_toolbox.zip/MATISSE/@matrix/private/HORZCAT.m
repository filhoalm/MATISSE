function T = HORZCAT(varargin)
% MATRIX/HORZCAT Horizontally concatenate matrix objects with equal y

I = precheck(varargin{:});

switch I.K
    case 1
        T = varargin{1};

    case 2
        v = varargin{1};
        w = varargin{2};

        %%%
        % join two matrix objects along the rows
        %%%
        T = RJOIN(v, w);

    otherwise
        v = varargin{1};
        q = varargin{nargin};
        for i = nargin-1:-1:2
            w = varargin{i};
            q = horzcat(w, q); %#ok<AGROW>
        end
        T = horzcat(v, q);
end

switch I.altText

    case 1
        DAT = T.data;
        DAT.fullname = I.txt;
        T.data = DAT;

    otherwise
end

end

%%%%%%%%%%%%%%%%

function T = RJOIN(A, B)
% helper function joins two matrix objects along the rows

if ~(isa(A, 'matrix') && isa(B, 'matrix'))
    error('all inputs must be matrix objects')
end

[rA, cA] = size(A);
[rB, cB] = size(B);

if rA~=rB
    error('number of rows of the input matrix objects must all be the same')
end

if ~(all(eq(A.y, B.y)))
    error('all inputs must have equal y')
end

% this is the easy part
DATA = [A.data, B.data];
% values must be a non-decreasing sequence
x = 1:cA+cB;
y = A.y;

%%%
% 9 possible combinations of A.type and B.type
%%%

NA = rA * cA;
NB = rB * cB;
N = NA + NB;

COV3 = sparse(N, N);

switch A.type
    case 0
        switch B.type
            case 0
                COV = 0;
            case 1
                COV = spdiags([zeros(1, NA), B.COV * ones(1, NB)], 0, N, N);
            case 2
                COV = spdiags([zeros(1, NA), diag(B.COV)'], 0, N, N);
            case 3
                COV = COV3;
                COV(NA+1:N, NA+1:N) = B.COV;
        end

    case 1
        switch B.type
            case 0
                COV = spdiags([A.COV * ones(1, NA), zeros(1, NB)], 0, N, N);
            case 1
                COV = spdiags([A.COV * ones(1, NA), B.COV * ones(1, NB)], 0, N, N);
            case 2
                COV = spdiags([A.COV * ones(1, NA), diag(B.COV)'], 0, N, N);
            case 3
                COV = COV3;
                COV(1:NA, 1:NA) = A.COV * speye(NA);
                COV(NA+1:N, NA+1:N) = B.COV;
        end

    case 2
        switch B.type
            case 0
                COV = COV3;
                COV(1:NA, 1:NA) = spdiags(A.COV(:), 0, NA, NA);
            case 1
                COV = COV3;
                COV(1:NA, 1:NA) = spdiags(A.COV(:), 0, NA, NA);
                COV(NA+1:N, NA+1:N) = B.COV * speye(NB);
            case 2
                COV = spdiags([A.COV(:); B.COV(:)], 0, N, N);
            case 3
                COV = COV3;
                COV(1:NA, 1:NA) = spdiags(A.COV(:), 0, NA, NA);
                COV(NA+1:N, NA+1:N) = B.COV;
        end

    case 3
        switch B.type
            case 0
                COV = COV3;
                COV(1:NA, 1:NA) = A.COV;
            case 1
                COV = COV3;
                COV(1:NA, 1:NA) = A.COV;
                COV(NA+1:N, NA+1:N) = B.COV * speye(NB);
            case 2
                COV = COV3;
                COV(1:NA, 1:NA) = A.COV;
                COV(NA+1:N, NA+1:N) = spdiags(B.COV(:), 0, NB, NB);
            case 3
                COV = COV3;
                COV(1:NA, 1:NA) = A.COV;
                COV(NA+1:N, NA+1:N) = B.COV;
        end

end

T = matrix(...
    'data', DATA, ...
    'COV', COV, ...
    'x', x, ...
    'y', y);

end

function I = precheck(varargin)

K0 = nargin;

if ischar(varargin{K0})
    I.altText = 1;
    I.txt = varargin{K0};
    I.K = K0 - 1;
else
    I.altText = 0;
    I.txt = '';
    I.K = K0;
end

end