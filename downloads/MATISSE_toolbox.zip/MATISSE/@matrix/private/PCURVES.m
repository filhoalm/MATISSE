function PCURVES(M, PVP)
% Plot columns of a matrix.

if isempty(M), return, end

ax = gca;
if eq(PVP.Grid, 1)
    set(ax, ...
        'XGrid', true, 'YGrid', true, ...
        'GridColor', PVP.clarinet(PVP.GridColor, :), ...
        'GridLineWidth', PVP.GridWidth, ...
        'GridAlpha', 0.25)
end

C = size(M, 2);

% coMpute Actual SpecifiCAtions fRom go vAlues
S = mascara(C, PVP);

% container for legend objects
LEGOS = cell(1, C);

% draw each curve using pcurve utility graphics function
for c = 1:C
    LEGOS{c} = pcurve(M, c, S);
end

%%%
% add white space to left or right if corresponding abscissa matches XLim
% this must be done after the last call to pcurve
%%%
XL = get(ax, 'XLim');
R = size(M.y, 2);
DELTA = [0 0];
if eq(XL(1), M.y(1)) && R >= 4
    DELTA(1) = -(M.y(2) - M.y(1))/2;
end
if eq(XL(2), M.y(R)) && R >= 4
    DELTA(2) = +(M.y(R) - M.y(R - 1))/2;
end
if any(DELTA)
    set(ax, 'XLim', XL + DELTA)
end

if eq(PVP.Legend, 1)
    % embelishments aid readability
    cl = M.data.col_labels;
    cl = strrep(cl, ' vs ', ' \bf{vs} \rm');
    lh = legend(ax, [LEGOS{:}], cl, 'FontSize', S.FontSize(1));
    lh.Title.String = [M.data.labels{2}];
    lh.Title.FontSize = S.FontSize(1);
    lh.Box = 'off';

    % freeze legend
    lh.AutoUpdate = "off";
else

end

end
