function [B, Aplus] = BLOCK(M0, varargin)
% BLOCK Matrix sums within blocked rows and columns.

N = numel(varargin);

if N == 0
    B = M0;
    return
end

[R0, C0] = size(M0);

PVP = options(R0, C0, varargin{1:end});

if PVP.rB == 1 && PVP.cB == 1
    B = M0;
    return
end

%%%
% Calculate number of missing rows and cols (if any)
%%%
rR = rem(R0, PVP.rB);
rC = rem(C0, PVP.cB);

switch PVP.trim
    case 1
        % subset the data to exclude 'hanging' cells
        switch PVP.RDir
            case 'LTF'
                % discard first rR
                rINC = (rR+1):1:R0;
            case 'FTL'
                % Discard last rR
                rINC = 1:1:(R0-rR);
        end
        switch PVP.CDir
            case 'LTF'
                % discard first rC
                cINC = (rC+1):1:C0;
            case 'FTL'
                % discard last rR
                cINC = 1:1:(C0-rC);
        end

        S.type = '()';
        S.subs{1} = rINC;
        S.subs{2} = cINC;
        M = subsref(M0, S);

    case 0
        % pad the data to include 'missing' cells
        switch PVP.RDir
            case 'LTF'
                rpos = 'top';
            case 'FTL'
                rpos = 'bottom';
        end
        switch PVP.CDir
            case 'LTF'
                cpos = 'left';
            case 'FTL'
                cpos = 'right';
        end

        M = pad(M0, 'rows', rR, 'rpos', rpos, 'cols', rC, 'cpos', cpos, 'fill', PVP.fill);

end

%%%
% Calculate number of blocked rows and cols in the trimmed or padded data
%%%
[R, C] = size(M);
RC = R*C;
RB = floor(R./PVP.rB);
CB = floor(C./PVP.cB);

%%%
% Computation of block sums of M:
%
% 1. accumulate sums of blocked rows within columns, R x C -> RB x C
% 2. transpose, RB x C -> C x RB
% 3. accumulate sums of blocked rows within columns, C x RB -> CB x RB
% 4. transpose, CB x RB -> RB x CB
%
% In terms of Toolkit operators:
%
% 1. H_(R, C, rB)    -> L1
% 2. T(RB, C)        -> L2
% 3. H_(C, RB, rC)   -> L3
% 4. T(CB, RB)       -> L4
%
% blocksum tensor is L4 * L3 * L2 * L1
%
%%%

L1 = kron(speye(C*RB), ones(1, PVP.rB));
L2 = TransposeMatrix(RB, C);
L3 = kron(speye(RB*CB), ones(1, PVP.cB));
L4 = TransposeMatrix(CB, RB);
Aplus = L4 * L3 * L2 * L1;

%%%
% fill NaNs, +Infs, and -Infs with 0 - or leave as is
%%%
DAT = M.data.data(:);
if eq(1, PVP.fill)
    DAT(~isfinite(DAT)) = 0;
end

s = reshape(Aplus*DAT, RB, CB);

sx = mean(reshape(M.x, PVP.cB, CB), 1);
sy = mean(reshape(M.y, PVP.rB, RB), 1);

ir = min(reshape(1:R, PVP.rB, RB), [], 1);
jc = min(reshape(1:C, PVP.cB, CB), [], 1);

if PVP.rB > 1
    TMP = ['[' str('data', M.data.row_labels(floor(ir))) ' ..)'];
    rl = TMP.data;
else
    rl = M.data.row_labels;
end

if PVP.cB > 1
    TMP = ['[' str('data', M.data.col_labels(floor(jc))) ' ..)'];
    cl = TMP.data;
else
    cl = M.data.col_labels;
end

DAT = tbl(...
    'data', s, ...
    'fullname', M.data.fullname, ...
    'labels', M.data.labels, ...
    'row_labels', rl, ...
    'col_labels', cl);

switch M.type

    case 0
        COV = 0;

    case 1
        COV = M.COV * (Aplus*Aplus');

    case 2
        COV = Aplus * spdiags(M.COV(:), 0, RC, RC) * Aplus';

    case 3
        COV = Aplus * M.COV * Aplus';

end

%%%
% output matrix
%%%

B = matrix(...,
    'data', DAT, ...
    'x', sx, ...
    'y', sy, ...
    'Alpha', M.Alpha, ...
    'COV', COV);

end

% helper functions

function T_RC = TransposeMatrix(R, C)
% transposition tensor for an R x C matrix

T_RC = ...
    ( kron( kron(ones(1, C), speye(R)), ones(C, 1)) ).* ...
    ( kron( ones(R, 1), kron(speye(C), ones(1, R))) );

end

function PVP = options(R, C, varargin)

% default values
PVP = struct(...
    'rB', 1, ...
    'RDir', 'LTF', ...
    'cB', 1,  ...
    'CDir', 'LTF', ...
    'fill', 1, ...
    'trim', 1);

%%%
% whittle the arguments
%%%
N = nargin;
lArgin = varargin;

while N >= 2

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('a property must be specified using a string')
    end

    switch lower(propi)

        case 'rb'
            if ~(isscalar(vali) && isreal(vali))
                error('rB must be a real scalar')
            elseif (vali <= 0 || vali > R)
                error(['rB must lie between 1 and ' num2str(R)])
            else
                PVP.rB = lower(vali);
            end

        case 'rdir'
            if ~ischar(vali)
                error('RDir must a be a string')
            end
            vali = upper(vali);
            if ~any(strcmpi(vali, {'LTF', 'FTL'}))
                error('invalid RDir')
            end
            PVP.RDir = vali;

        case 'cb'
            if ~(isscalar(vali) && isreal(vali))
                error('cB must be a real scalar')
            elseif (vali <= 0 || vali > C)
                error(['cB must lie between 1 and ' num2str(C)])
            else
                PVP.cB = lower(vali);
            end

        case 'cdir'
            if ~ischar(vali)
                error('CDir must a be a string')
            end
            vali = upper(vali);
            if ~any(strcmpi(vali, {'LTF', 'FTL'}))
                error('invalid CDir')
            end
            PVP.CDir = vali;

        case 'fill'
            if ~(isscalar(vali) && isreal(vali))
                error('fill must be 0 or 1')
            end
            if eq(vali, 0) || eq(vali, 1)
                PVP.trim = vali;
            end

        case 'trim'
            if ~(isscalar(vali) && isreal(vali))
                error('trim must be 0 or 1')
            end
            if eq(vali, 0) || eq(vali, 1)
                PVP.trim = vali;
            end


        otherwise
    end

    % setup for the next pair
    lArgin = lArgin(3:end);
    N = numel(lArgin);
    if eq(N, 1)
        error('the last property has no matching value');
    end

end

end