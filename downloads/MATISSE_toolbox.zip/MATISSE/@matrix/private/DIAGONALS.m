function T = DIAGONALS(M)
% Diagonals of a matrix.

% Crucial to get the arrangement we want - same as tbl/diagonals

% calculate a 'relocation matrix'
[R, C] = size(M);
RC = R*C;
D = R + C - 1;

reloc = zeros(RC, 2);

rc = 0;
% run through the values of original in vec order
for c0 = 1:C
    for r0 = 1:R

        rc = rc + 1;

        d0 = c0 - r0 + R;

        reloc(rc, :) = [r0 d0];

    end
end

r1 = reloc(:, 1);
l1 = (reloc(:, 2) - 1)*R + r1;

% Method 1 - brute force
% RELOC = zeros(R*K, R*C);
% for i = 1:R*C
%     RELOC(l1(i), i) = 1;
% end

% Method 2 - sparse
J = ones(RC, 1);
S = (1:RC)';
RELOC = sparse(l1, S, J, R*D, RC);

%%%
% COV of the rearranged data
%%%
switch M.type
    case 0
        COV = 0;
    case 1
        COV = M.COV * (RELOC * RELOC');
    case 2
        COV = RELOC * spdiags(M.COV(:), 0, RC, RC) * RELOC';
    case 3
        COV = RELOC * M.COV * RELOC';
end

T = matrix(...
    'data', diagonals(M.data), ...
    'COV', COV, ...
    'x', 1:D, ...
    'y', M.y, ...
    'Alpha', M.Alpha);