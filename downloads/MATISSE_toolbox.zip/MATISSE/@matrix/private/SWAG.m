function [D, BCL] = SWAG(M)
% SWAG Scaled first differences of rowS Within diAGonals of matrix object M.

[R, C] = size(M);

% Both R and C must be >= 2
if (R < 2) || (C < 2)
    D = [];
    return
end

dy = M.y(2) - M.y(1);
k = 1;

bL = kron(ones(C-k, 1), (1:1:(R-k))') + ...
    R*kron((1:1:(C-k))' - 1, ones(R-k, 1));
% Perhaps we find a more efficient way to calculate
BL = zeros((R-k)*(C-k), R*C);
for i = 1:(R-k)*(C-k)
    BL(i, bL(i)) = 1;
end

bU = k * (R + 1) + bL;
BU = zeros((R-k)*(C-k), R*C);
for i = 1:(R-k)*(C-k)
    BU(i, bU(i)) = 1;
end

D_RC = (1/dy) * (BU - BL);

[d, BCL] = contrasts(D_RC, vec(M));

R0 = R - 1;
C0 = C - 1;
DAT = tbl(...
    'data', reshape(d.data.data, R0, C0), ...
    'fullname', [M.data.fullname ' (swag)'], ...
    'row_labels', M.data.row_labels(2:R), ...
    'col_labels', M.data.col_labels(2:C));

switch d.type
    case {0,1,3}
        COV = d.COV;
    case 2
        R0C0 = R0*C0;
        COV = spdiags(d.COV(:), 0, R0C0, R0C0);
end

D = matrix(...
    'data', DAT, ...
    'y', M.y(2:R), ...
    'x', M.x(2:C), ...
    'COV', COV, ...
    'Alpha', d.Alpha);

end