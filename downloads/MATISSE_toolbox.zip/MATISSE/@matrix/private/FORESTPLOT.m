function FORESTPLOT(M, col, pvp)
% forest plot of matrix data in a column

DATA = M.curves{col};
data = DATA.data;
R = size(DATA, 1);
% x-values need not be 1, 2, ..., R but we want to plot DATA versus
% sequence number 1, 2, ..., R
data(:, 1) = (1:R)';

% coMpute Actual SpecifiCAtions fRom go vAlues
PVP = mascara(R, pvp);

switch PVP.orientation
    case 'horizontal'
        % R separate line objects, each with one data point
        PT = line([data(:, 2)'; data(:, 2)'], [data(:, 1)'; data(:, 1)'], 'Marker', 'o');
    case 'vertical'
        PT = line([data(:, 1)'; data(:, 1)'], [data(:, 2)'; data(:, 2)'], 'Marker', 'o');
end

%%%
% set the properties of each point in PT
%%%

% Marker
[PT.Marker_I] = deal(PVP.mk0{PVP.Marker(:)});

% MarkerSize
TMP1 = num2cell(PVP.MarkerSize);
[PT.MarkerSize_I] = deal(TMP1{:});

% MarkerFaceColor
TMP2 = num2cell(PVP.MAP, 2);
[PT.MarkerFaceColor_I] = deal(TMP2{:});

% MarkerEdgeColor
TMP3 = num2cell(PVP.MarkerEdgeColorMAP, 2);
[PT.MarkerEdgeColor_I] = deal(TMP3{:});

if ne(M.type, 0)

    %%%
    % set the properties of each confidence interval in CI
    %%%
    
    % R separate line objects, each with two points, LL and UL
    switch PVP.orientation
        case 'horizontal'
            CI = line([data(:, 3)'; data(:, 4)'], [data(:, 1)'; data(:, 1)'], ...
                'Marker', 'none', 'LineStyle', '-');
        case 'vertical'
            CI = line([data(:, 1)'; data(:, 1)'], [data(:, 3)'; data(:, 4)'], ...
                'Marker', 'none', 'LineStyle', '-');
    end

    % MarkerFaceColor can be set this way (even if 'marker' is none)
    [CI.MarkerFaceColor_I] = deal(TMP2{:});

    % LineWidth
    TMP3 = num2cell(PVP.LineWidth);
    [CI.LineWidth_I] = deal(TMP3{:});

    % LineStyle
    [CI.LineStyle_I] = deal(PVP.ls0{PVP.LineStyle(:)});

    % Color - we tried to do this without the loop, but it wasn't working
    for i = 1:R
        CI(i).Color = PVP.MAP(i, :);
    end

end

set_forest_axis(gca, 'forestplot', M, col, PVP)

end