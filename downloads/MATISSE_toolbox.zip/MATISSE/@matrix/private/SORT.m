function [S, si] = SORT(M, col, direction)
% Sort a matrix by the values in a column.

% precheck
if ~ismember(col, 1:size(M, 2))
    error('col is invalid column')
end
if ~ismember(direction, {'ascend', 'descend', 'precision'})
    error('invalid direction')
end
if eq(M.type, 0) && strcmp(direction, 'precision')
    S = M;
    return
end

[R, C] = size(M);
RC = R*C;

% compute sort index
switch direction
    case 'ascend'
        vals = M.data.data(:, col);
        [~, si] = sort(vals, 'ascend');
    case 'descend'
        vals = M.data.data(:, col);
        [~, si] = sort(vals, 'descend');
    case 'precision'
        vals = M.curves{col}.data(:, 4) - M.curves{col}.data(:, 3);
        [~, si] = sort(vals, 'descend');
end

% construct permutation matrix
IR = speye(R);
% for any given column, we are sorting rows
pm = IR(si, :);
% for all columns
PM = kron(speye(C), pm);

sdat = reshape(PM*M.data.data(:), R, C);

SDAT = tbl(...
    'data', sdat, ...
    'fullname', M.data.fullname, ...
    'labels', M.data.labels, ...
    'row_labels', M.data.row_labels(si), ...
    'col_labels', M.data.col_labels);

switch M.type
    case 0
        SCOV = 0;
    case 1
        SCOV = M.COV; % because PM * PM' = IRC
    case 2
        SCOV = PM * spdiags(M.COV(:), 0, RC, RC) * PM';

    case 3
        SCOV = PM * sparse(M.COV) * PM';
end

%%%
% output matrix
%%%
S = matrix('data', SDAT, 'COV', SCOV);


end

%%%%
