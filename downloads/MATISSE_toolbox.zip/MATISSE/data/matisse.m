function matisse(varargin)
% MATISSE - a <strong>MA</strong>tlab <strong>T</strong>oolbox for v<strong>I</strong>tal rate<strong>S</strong> <strong>S</strong>urveillanc<strong>E</strong>
%
% MATISSE
% MATISSE('map') will show you a map of the toolbox
%
% See https://pubmed.ncbi.nlm.nih.gov/38406174/ for an overview.
%
% Version 1.0
%
% Author: Philip S Rosenberg PhD
%
% See also epiphany, apc, capricorn, rates, sift, sage.



if nargin > 0
    if eq(varargin{1}, 'map')
        CurrentDir = pwd;

        TMP = which('ratesdata.m');
        ExampleDir = TMP(1:end-11);

        cd(ExampleDir)

        figure(...
            'Name', 'MATISSE Map', ...
            'Theme', 'light', ...
            'toolbar', 'none', ...
            'menubar', 'none', ...
            'Position', [583 393 978 1022]);
        imshow('MATISSE_map.png', 'Border', 'tight')

        cd(CurrentDir)
    end
else
    help matisse
end

end
