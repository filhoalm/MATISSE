function varargout = ratesdata(varargin)
% RATESDATA - Example rates objects.
%
% R = RATESDATA(<example numbers from 1 through 10>)
%
% example  Sex  Cancer Site   Demographic                   A, P    Bins 
%    1      F    ER+ breast   non-Hispanic black (NHB)     50, 27   1x1
%    2      F    ER+ breast   non-Hispanic white (NHW)     50, 27   1x1
%    3      F    ER- breast   NHB                          50, 27   1x1
%    4      F    ER- breast   NHW                          50, 27   1x1
%    5      F    colon        NHB                          50, 27   1x1
%    6      F    colon        NHW                          50, 27   1x1
%    7      M    thyroid      Asian and Pacific Islander   50, 27   1x1
%    8      M    thyroid      Hispanic                     50, 27   1x1
%    9      M    thyroid      NHB                          50, 27   1x1
%   10      M    thyroid      NHW                          50, 27   1x1
%   11      MF   colon        NHW                          50, 29   1x1
%   12      F    ER- breast   NHW                          50, 29   1x1
%   13      M    liver        NHW                          50, 29   1x1
%   14      F    lung         NHW                          50, 29   1x1
%   15      M    lung         NHW                          50, 29   1x1
%   16      F    melanoma     NHW                          50, 29   1x1
%
%    R - a rates object or cell array of rates objects 
%    A - number of age groups  
%    P - number of calendar periods
% Bins - number of single years of age per age group and single calendar
%        years per calendar period
%
% see also rates.

examples = {...
    'F ER+ breast NHB.csv', ...
    'F ER+ breast NHW.csv', ...
    'F ER- breast NHB.csv', ...
    'F ER- breast NHW.csv', ...
    'F colon NHB.csv', ...
    'F colon NHW.csv', ...
    'M thyroid API.csv', ...
    'M thyroid HIS.csv', ...
    'M thyroid NHB.csv', ...
    'M thyroid NHW.csv', ...
    'colon  MF  NHW.csv', ...
    'brcaer  F  NHW  ER-.csv', ...
    'liver  M  NHW.csv', ...
    'lung  F  NHW.csv', ...
    'lung  M  NHW.csv', ...
    'melanoma  F  NHW.csv', ...
    ''};

switch nargin
    case 0
        help ratesdata
        return

    case 1
        vali = varargin{1};

        if ~(isnumeric(vali) && isreal(vali))
            error('example number or numbers must be an integer or integers between 1 through 10')
        else
            if all(ismember(vali, 1:16))
                % OK
            else
                error('example number or numbers must be an integer or integers between 1 through 10')
            end
        end

    otherwise
        error('too many inputs')
end

CurrentDir = pwd;

TMP = which('ratesdata.m');
ExampleDir = TMP(1:end-11);
disp('switching to data directory . . .')

cd(ExampleDir)

N = numel(vali);

DATA = cell(1, N);
for i = 1:N
    exi = vali(i);
    DATA{i} = csv2rates(examples{exi});
end

switch nargout
    case 0
    otherwise
        switch N
            case 1
                varargout{1} = DATA{1};
            otherwise
                varargout{1} = DATA;
        end

end

disp('                   . . . and back')
cd(CurrentDir)
end

%[appendix]{"version":"1.0"}
%---
