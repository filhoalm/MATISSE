function PLOT(J, varargin)
% JOINPOINT/PLOT

K = numel(J.PLS);

switch nargin
    case 1
        rnksel = 1;
        seg = J.Summary.AICc.data(1, 1);
        pvp1 = [];

    case 2
        rnksel = varargin{1};
        if ~ismember(rnksel, 1:K)
            error('invalid rnk')
        end
        seg = J.Summary.Bests.data(rnksel, 1);
        pvp1 = [];

    case 3
        rnksel = varargin{1};
        if ~ismember(rnksel, 1:K)
            error('invalid rnk')
        end
        seg = J.Summary.Bests.data(rnksel, 1);
        pvp1 = varargin{2};

    otherwise
        error('too many inputs')
end

if isempty(pvp1)
    pvp1 = ego('class', 'joinpoint', 'method', 'plot');
end

pvp2 = go(...
    'FaceAlpha', 0.10, ...
    'EdgeAlpha', 0.0, ...
    'marker', 16, ...
    'Width', pvp1.Width, ...
    'Grid', pvp1.Grid, ...
    'LineColor', 12, ...
    'LineStyle', 3, ...
    'LineWidth', 2, ...
    'Legend', 0, ...
    'FontSize', pvp1.FontSize, ...
    'labels', [0 0 0]);

[a,~] = sort(J.Summary.AICc.data(:, 1));
[~,d] = ismember(seg, a);

PLS = J.PLS(d);
knots = J.Summary.Bests.data(rnksel, 6:(5+seg+1));

ax = gca;
yyaxis(ax, 'right')

hband(J, rnksel, pvp2)
set(ax, 'XTick', knots, 'XTickLabelRotation', -40)
YLr = get(gca, 'YLim');
B = PLS.B(2:end, 1);
C = cumsum(B);
c = C.data.data;
xm = knots(1:end-1) + 0.5 * (knots(2:end) - knots(1:end-1));
text(xm, repmat(YLr(2), 1, seg), cellstr(num2str(c, '%6.2f')), ...
    'HorizontalAlignment', 'right', 'Rotation', -60, ...
    'FontSize', pvp2.FontSize(1));

yyaxis(ax, 'left')

plot(horzcat(J.Y, PLS.U, J.Y.data.fullname), pvp1)

% clean up
ax.YAxis(1).Color = [0 0 0];
ax.YAxis(2).Color = [0 0 0];
if pvp1.labels(2)
    ax.YAxis(2).Label.String = 'Slopes';
    ax.YAxis(2).FontSize = pvp1.FontSize(2);
    ax.YAxis(2).Label.Rotation = -90;
end

end