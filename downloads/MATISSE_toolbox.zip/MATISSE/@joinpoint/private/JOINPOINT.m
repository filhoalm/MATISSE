function [Summary, PLS] = JOINPOINT(D)
% computational engine for joinpoint regression

%%%
% unpack for parfor
%%%

Y = D.M.data.data;
W = D.W;
SQRTW = D.SQRTW;
G = size(D.P.RIC, 1);
mink = D.P.mink;
maxk = D.P.maxk;
NK = maxk - mink + 1;

R = size(D.M, 1);
od = D.opts.overdispersion;
X = D.X;

SG = (1:1:G)';
DEV = [SG, NaN(G, 2)];

%%%
% STEP 1: Calculate deviance and s2HAT for all G possible models
%%%
short = 1;
parfor g = 1:G
    Mg = WLSc(Y, W, SQRTW, X(g), od, short);
    DEV(g, 2:3) = [Mg.DEV, Mg.s2HAT];
end


%%%
% STEP 2: Identify best-fit models conditional on k and compute AICc
%%%

% bests - details
bests = NaN(NK, 5 + maxk + 1);
k = 0;
for s = mink:maxk
    k = k + 1;
    INCs = (D.P.k == s);
    Ds = DEV(logical(INCs.data), :);
    [bestD, I] = min(Ds(:, 2));
    bsts2 = Ds(I, 3);
    bestI = Ds(I, 1);
    bests(k, :) = [s, sum(INCs.data), bestD, bsts2, bestI, ...
        D.X(bestI).joinpoints, NaN(1, maxk - s)];
end

% two steps make the column labels
cl = [str('data', {'Segments', 'Candidates', 'Deviance', 's2HAT', 'Index'}); ...
    ['knot ' str('data', num2str((0:maxk)'))]];

Bests = tbl(...
    'data', bests, ...
    'fullname', ['Best Fit Models (' num2str(G) ' candidates)'], ...
    'col_labels', cl.data);

% Use our best most complicated model to estimate the od
if od
    s2HAT = bests(NK, 4);
else
    s2HAT = 1;
end

% Incorporate s2HAT (or not) depending on od
s2HATi = 1./s2HAT;
W = s2HATi*W;
SQRTW = sqrt(s2HATi)*SQRTW;

% AICc - bias-corrected AIC
mdf = 2*((mink:maxk)' - 1) + 2;
edf = mdf + (mdf.^2 + mdf)./(R - mdf - 1);
dev = bests(:, 3);
% DEV in aic is scaled by s2HATi
aic = s2HATi*dev + 2*edf;
[~, rnk] = sort(aic);
[~, irnk] = ismember((1:NK)', rnk);
DELTA = aic - aic(rnk(1));
DATA = [(mink:maxk)' irnk mdf edf dev aic DELTA ];
AICc = tbl(...
    'data', DATA(rnk, :), ...
    'fullname', 'AIC', ...
    'col_labels', ...
    {'Segments', 'rank', 'mdf', 'edf', 'DEV', 'AICc', 'DELTA'});

% resort Bests so the 'best' model is always the first model
Bests = Bests(rnk, :);

%%%
% STEP 3: Fit the best piecwise linear splines conditional on the number of segments
%         * Set od flag to 0 because W and SQRTW are scaled by nps2i
%%%
Mc = cell(1, NK);
gI = bests(:, 5);
Xg = X(gI);
k = 0;
for g = mink:maxk
    k = k + 1;
    Mc{k} = WLSc(Y, W, SQRTW, Xg(k), 0,  0);
end


%%%
% STEP 4: Remove continuity constraints at the knots ('General Model') to
% estimate an unconditional variance-covariance matrices accounting for
% estimation of knot locations using Lerman's method JRSS-C 1989 Vol 29, No
% 1 pp 77-84.
%%%
GMD = gmd(bests, Xg, D.M.y(:));
Mu = cell(1, NK);
Vu = cell(1, NK);
RPg = cell(1, NK);
k = 0;
for g = mink:maxk
    k = k + 1;
    Mu{k} = WLSu(Y, W, SQRTW, GMD(k).X, 0);
    % convert variance from general form (4) to standard form (1)
    RPg{k} = rewire(Xg(k).joinpoints);
    Vu{k} = RPg{k}.C41 * Mu{k}.V * RPg{k}.C41';
end

%%%
% Step 5: Package outputs
%%%

%%%
% Beta coefficients are a composite:
%  * B coefficients conditional on continuity constraints             (from Mg)
%  * Variance-Covariance matrix estimated *without* those constraints (from Mu)
%%%
B = cell(1, NK);
k = 0;
for g = mink:maxk
    k = k + 1;
    DATA = tbl(...
        'data', Mc{k}.B, ...
        'fullname', D.M.data.fullname, ...
        'col_labels', D.M.data.col_labels, ...
        'labels', D.M.data.labels);
    B{k} = matrix(...
        'data', DATA, ...
        'COV', Vu{k}, ...
        'Alpha', D.opts.Alpha);
end

%%%
% Fitted values are also a composite
%%%
U = cell(1, NK);
k = 0;
for g = mink:maxk
    k = k + 1;
    DATA = tbl(...
        'data', Xg(k).X*Mc{k}.B, ...
        'fullname', D.M.data.fullname, ...
        'row_labels', D.M.data.row_labels, ...
        'col_labels', D.M.data.col_labels, ...
        'labels', D.M.data.labels);

    U{k} = matrix(...
        'data', DATA, ...
        'COV', Xg(k).X*Vu{k}*Xg(k).X', ...
        'y', D.M.y, ...
        'x', D.M.x, ...
        'Alpha', D.opts.Alpha);

end

%%%
% Slopes
%  * convert from form (1) to form (2)
%  * leave off the intercept
%  * enhance the metadata
%
%%%
S = cell(1, NK);
k = 0;
for g = mink:maxk
    k = k + 1;
    TMPk = contrasts(B{k}, RPg{k}.C12(2:end, :));
    % enhance
    dat = TMPk.data;
    KNOTS = RPg{k}.KNOTS';
    numKnots = numel(KNOTS);
    rl = [str('data', num2str(KNOTS(1:numKnots - 1), '%g')) ' - ' ...
        str('data', num2str(KNOTS(2:numKnots), '%g'))];
    dat.row_labels = rl.data;
    lb = dat.labels;
    lb{1} = 'Slopes';
    dat.labels = lb;
    % repack
    TMPk.data = dat;
    TMPk.y = KNOTS(1:numKnots - 1) + ...
        (KNOTS(2:numKnots) - KNOTS(1:numKnots - 1))/2;
    S{k} = TMPk;

end

Summary = struct('AICc', AICc, 'Bests', Bests, 's2HAT', s2HAT);
PLS = struct('B', B, 'U', U, 'Slopes', S);

end

%%%%%%

function M = WLSc(Y, W, SQRTW, X, od, short)
% Weighted least squares (WLS) allowing for correlated errors conditional
% on the number and location of the knots.
%
% short is a 0/1 flag - 1 means return after you have the DEV
%
% X is an element of D.X that contains pre-calculated IXWXWXT and IXWX.
%
% OUTPUTS in M:
%
% Always:
%
%          B - regression coefficients
%          u - fitted values
%        DEV - deviance, weighted sum of squared errors
%      s2HAT - estimated variance of the errors
%
% Add if short is false:
%
%     resids - residuals
%          V - unscaled variance-covariance matrix

M.B = X.IXWXWXT*Y;
M.u = X.X*M.B;
d = Y - M.u;
M.DEV = d'*W*d;
if od
    M.s2HAT = M.DEV./(size(X.X, 1) - size(X.X, 2));
else
    M.s2HAT = 1;
end

if ~short
    M.resids = SQRTW*d;
    M.V = X.IXWX;

end

end

function M = WLSu(Y, W, SQRTW, X, od)
% Weighted least squares allowing for correlated errors - general model

warning off
WX = W*X;
M.B = (X'*WX)\(WX'*Y);

CPM = full(X'*WX);
if rank(CPM)==size(CPM,1)
    M.V = inv(CPM);
else
    M.V = pinv(CPM);
end
warning on

M.u = X*M.B;
d = Y - M.u;
DEV = d'*W*d;
M.resids = SQRTW*d;
M.DEV = sum(DEV);
if od
    M.SIGMAHAT = sqrt(M.DEV/(size(X,1)-size(X,2)));
else
    M.SIGMAHAT = 1;
end

end

function GMD = gmd(bests, X, x0values)
% Setup X matrices to fit General Model with no continuity constraints at knots.

K = size(bests, 1);

GMD = struct('X', []);

for k = 1:K

    X0 = X(k).X;
    C0 = size(X0, 2);
    xp = X0(:, 2:C0) > 0;
    x0 = [xp(:, 1:end-1) - xp(:, 2:end) xp(:, end)];
    x1 = kron(x0values, ones(1, C0-1)).*x0;
    XG = [x0, x1];
    GMD(k).X = XG;

end

end
