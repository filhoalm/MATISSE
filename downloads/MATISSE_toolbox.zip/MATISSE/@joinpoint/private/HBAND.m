function [h1, h2] = HBAND(J, rnk, pvp)
% stair plot of slopes

K = numel(J.PLS);
if ~ismember(rnk, 1:K)
    error('invalid rnk')
end

seg = J.Summary.Bests.data(rnk, 1);

[a,~] = sort(J.Summary.AICc.data(:, 1));
[~,d] = ismember(seg, a);

PLS = J.PLS(d);
knots = J.Summary.Bests.data(rnk, 6:(5+seg+1));
S = PLS.Slopes;

hbandData = tbl(...
    'data', [knots(1:seg)', knots(2:seg+1)', S.curves{1}.data(:, 2:4)], ...
    'fullname', S.data.fullname, ...
    'row_labels', S.data.row_labels, ...
    'labels', S.data.labels);

if pvp.Plot
    PVP = mascara(seg, pvp);
    [h1, h2] = hband(hbandData, PVP);
else
    h1 = hbandData;
    h2 = [];
end
