classdef joinpoint
    % JOINPOINT joinpoint objects contain a joinpoint regression analysis.
    %
    % A JOINPOINT regression is a piecewise linear spline fitted to an
    % evenly-spaced time-series using an algorithm that estimates the
    % number and location of the knots from all feasible models with at
    % least mink and at most maxk segments, each segment containing at
    % least a points and at most b points.
    % 
    % JOINPOINT regression is applied to a target column of a matrix
    % object.
    %
    % The target column is pre-processed using the matrix method jpx. 
    %
    % This implementation follows the classic paper
    % https://pubmed.ncbi.nlm.nih.gov/10649300/ except the best-fit model
    % is selected using bias-corrected AIC rather than permutation tests.
    %
    % This method may not provide identical results to the popular
    % joinpoint program included in the SEER*Stat software available at
    % https://seer.cancer.gov/data-software/.
    %
    % See also matrix/jpx, joinpoint/joinpoint.

    properties
        Y matrix = matrix;            % matrix object 
        Summary struct = struct;      % model selection results
        PLS struct = struct;          % best-fitting splines

    end

    methods

        function J = joinpoint(D)
            % JOINPOINT Joinpoint regression of a target column in a matrix object.
            %
            % Target data are pre-processed using the jpx function before
            % fitting joinpoint models:
            %
            % D = jpx(M, col, 'maxk', maxk, 'a', a, ...
            %         'mink', mink, 'b', b, 'Alpha', Alpha, 'overdispersion', od)
            %
            % J = joinpoint(D)
            %
            % or
            %
            % J = joinpoint(jpx(M, col, 'maxk', maxk, ...))
            %
            % * JOINPOINT identifies the best-fitting knots for segments
            %   k = mink, ..., maxk (K = maxk - mink + 1 segments in all)
            %
            % * jpx and joinpoint use parfor (when available). Even so:
            %   + many interesting combinations of mink, maxk, a and b are
            %     not computationally feasible.
            %
            %   + when in doubt use jdoriccount to determine the
            %     size of the proposed ensemble. Different machines can
            %     handle different problem sizes. You can determine this for 
            %     your machine by trial and error.
            %
            % * JOINPOINT outputs:
            %
            % * J.Y       - target column
            %
            % * J.Summary - tbl objects with K rows
            %   + AICc    - bias-corrected AIC values (AICc)
            %   + Bests   - best-fit joinpoints
            %   + s2HAT   - overdispersion (from best-fit model with maxk segments)
            %
            % * J.PLS     - 1 x K structure array with 3 matrix objects:
            %   + B       - beta coefficients in standard form
            %   + U       - fitted values
            %   + Slopes  - segment-specific slopes
            %
            % * The optimal number of segments minimizes AICc.
            %
            % * Variance-covariance matrices in J.PLS account
            %   for uncertainty from joint estimation of knot
            %   locations and segment-specific slopes.
            %
            % See also matrix/jpx, jdoriccount, rewire, hband.

            if nargin == 0
                % Contents of an empty joinpoint
                J.Y = matrix;
                J.Summary = struct('AICc', [], 'Bests', [], 's2HAT', []);
                J.PLS = struct;
                return
            end

            if isa(D, 'joinpoint')
                J = D;
                return
            end

            [Summary, PLS] = JOINPOINT(D);

            J.Y = D.M;
            J.Summary = Summary;
            J.PLS = PLS;

        end

        function varargout = hband(J, varargin)
            % HBAND Stair plot of joinpoint slopes.
            %
            % HBAND(J, rnk)
            % [h1, h2] = HBAND(J, rnk, go(...))
            %
            % * rnk is AICc rank( default 1).
            %
            % See also joinpoint/joinpoint, plot.

            pvp0 = ego('class', 'joinpoint', 'method', 'hband');
            switch nargin
                case 1
                    k = 1;
                    pvp = pvp0;
                case 2
                    k = varargin{1};
                    pvp = pvp0;
                case 3
                    k = varargin{1};
                    pvp = varargin{2};
                otherwise
                    error('too many inputs')
            end

            [h1, h2] = HBAND(J, k, pvp);

            switch nargout
                case 0
                case 1
                    varargout{1} = h1;
                case 2
                    varargout{1} = h1;
                    varargout{2} = h2;
                otherwise
                    error('too many outputs')
            end

        end

        function varargout = plot(J, varargin)
            % PLOT Plot a joinpoint spline.
            %
            % PLOT(J)
            % PLOT(J, rnk)
            % PLOT(J, rnk, go(...))
            %
            % * rnk is the AICc rank (default 1).
            % * Preset or user-specified go values for the left axis:
            %   + Data Y and piecewise linear spline PLS
            % * Preset go values for the right axis:
            %   + Slopes 
            %
            % see also joinpoint/joinpoint, hband.

            Nl = numel(varargin);
            switch Nl
                case 0
                    rnk = 1;
                    PVP = [];
                case 1
                    rnk = varargin{1};
                    PVP = [];
                case 2
                    rnk = varargin{1};
                    PVP = varargin{2};
                otherwise
                    error('too many inputs')
            end

            PLOT(J, rnk, PVP);

            switch nargout
                case 1
                    varargout{1} = F;
                otherwise
            end

        end

    end

end


