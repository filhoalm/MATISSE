classdef str
    % STR str objects contain text.
    %
    % * STR objects should never be confused with MATLAB string arrays!
    %
    % A STR object is a lightweight container used by MATISSE. 
    %
    % See also str/str.

    properties

        data (:, 1) {mustBeText} = {};     % text data
        fullname (1, :) {mustBeText} = ''; % scientific name for the text

    end

    methods

        function S = str(varargin)
            % STR class constructor.
            %
            % S = STR('data', TEXT, 'fullname', 'string');
            %
            % TEXT can be a character matrix or a cell array of strings.
            %
            % The strings in TEXT are coerced to a column vector in S.
            % Empty strings are considered to be missing data.
            %
            % Example:
            %
            % S = str('data', {'', ' ', 'Tom', 'Dick', 'Harry '}, 'fullname', 'Names');
            %
            % The first case is missing, the second is blank, and trailing
            % spaces after 'Harry' are retained.

            if nargin == 0
                % Contents of an empty str
                S.data = {};
                S.fullname = '';

                return
            end

            if isa(varargin{1}, 'str')
                S = varargin{1};
                return
            end

            % Contents of an empty categoric
            S.data = {};
            S.fullname = '';

            N = numel(varargin);

            if N == 0
                return
            end

            %%%
            % whittle the arguments
            %%%
            lArgin = varargin;

            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};
                if ~ischar(propi)
                    error('a property must be specified using a string')
                end

                switch lower(propi)

                    case 'data'
                        % data must be a simple string, a cell array of strings, or an n x k character matrix
                        if ~(ischar(vali) || iscellstr(vali) || isstring(vali)) %#ok<ISCLSTR>
                            error('data be a simple string, a cell array of strings, or a character matrix');
                        end

                        if ischar(vali) || isstring(vali)
                            vali = cellstr(vali);
                        end

                        S.data = vali(:);

                    case 'fullname'
                        if ischar(vali)
                            S.fullname = vali;
                        else
                            error('fullname must be a string')
                        end

                    otherwise

                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('the last property has no matching value');
                end

            end

        end

        function disp(v, varargin)
            % command window disp of a str object.
            %
            % DISP(S)
            % DISP(S, RowNumbers)
            %
            % Display of the fullname and row numbers are suppressed if RowNumbers==0.

            if nargin==0
                RowNumbers = 0;
            else
                RowNumbers = 1;
            end

            if ~isempty(v.fullname) && RowNumbers
                disp(' ')
                disp(v.fullname)
                disp(' ')
            end

            % if variable is empty, just say so
            if isempty(v)
                disp('empty str');
                return;
            end

            % create list of all indices
            nc = length(v.data);

            inddbl = double(1:nc);
            indt = transpose(inddbl);

            % this loop insures that empty string data '' will display correctly
            empty = 0;
            vals = v.data;
            for i = 1:length(vals)
                if isempty(vals{i})
                    empty = empty + 1;
                    vals{i} = ' ';
                end
            end
            vals = char(vals);

            inds = num2str(indt);
            inds = strjust(inds, 'right');

            if RowNumbers
                list = [repmat('[', length(inds), 1) inds repmat(']   ', length(inds), 1) vals];
                disp(list);
                disp(' ')

                % use correct english to describe the number of cases
                if eq(numel(v.data), 1)
                    if (empty == 0)
                        thisline = '1 case, not empty';
                    else
                        thisline = '1 case, empty';
                    end
                else
                    thisline = [num2str(numel(v.data)) ' cases, ' num2str(empty) ' empty' ];
                end

                disp(thisline);
            else
                list = vals;
                disp(list);

            end
        end


        function r = end(g, k, ~)
            % END end method for str objects.

            switch k
                case 1
                    r = size(g, 1);
                case 2
                    r = size(g, 2);
                otherwise
            end

        end

        function U = subsref(T, S)
            % SUBSREF subscripted referencing for str objects.

            if length(S) > 1

                DEPTH = numel(S);
                for d = 1:DEPTH
                    if d == 1
                        U = subsref(T, S(1));
                    else
                        q = numArgumentsFromSubscript(U, S(d), ...
                            matlab.mixin.util.IndexingContext.Statement);
                        if q > 1
                            warning('only one output was captured')
                        end
                        U = subsref(U, S(d));
                    end
                end

            else

                switch S.type

                    case '.'

                        switch S.subs

                            case 'data'
                                U = T.data;
                            case 'fullname'
                                U = T.fullname;

                            otherwise

                        end

                    case '()'
                        % if it's a boolean, replace S.subs{1} with indices
                        if isa(S.subs{1}, 'boolean')
                            S.subs{1} = find(S.subs{1}.data == 1);
                        end
                        NI = numel(S.subs);
                        switch NI
                            case 1
                                SUBS = cell(1, 2);
                                SUBS{1} = S.subs{1};
                                SUBS{2} = ':';
                            case 2
                                SUBS = S.subs;
                            otherwise
                                SUBS = S.subs{1:2};
                        end

                        DATA = T.data(SUBS{1}(:)', SUBS{2}(:)');

                        U = str('data', DATA, ...
                            'fullname', T.fullname);

                    case '{}'

                        % do nothing
                        U = T;

                end

            end

        end

        function G = subsasgn(T, S, V)
            % SUBSASGN subscripted assignment for str objects.

            if length(S) > 1
                DEPTH = numel(S);
                error('index expression has depth %g, cannot be > 1', DEPTH)
            end

            switch S.type

                case '.'

                    switch S.subs
                        case 'data'
                            G = str(...
                                'data', V, ... ...
                                'fullname', T.fullname);

                        case 'fullname'
                            G = T;
                            G.fullname = V;

                        otherwise

                    end

                case '()'
                    warning('parentheses indexing is undefined')

                case '{}'
                    warning('brace indexing is undefined')

                otherwise

            end

        end

        function l = length(S)
            % LENGTH length of a str object.

            l = length(S.data);

        end

        function varargout = size(varargin)
            % SIZE size of a str object.

            switch nargin
                % for only 1 input argument, return all available size data

                case 1
                    varargout = cell(1, nargout);
                    S = varargin{1};
                    switch nargout
                        % if all output is requested in 1 variable, concatenate size
                        case {0,1}
                            varargout{1} = [size(S.data,1), size(S.data,2)];
                            % if output is requested in more than 1 variable, return each dimension as its own variable
                        case 2
                            varargout{1} = size(S.data,1);
                            varargout{2} = size(S.data,2);
                        otherwise
                            varargout{1} = size(S.data,1);
                            varargout{2} = size(S.data,2);
                            % any other requested dimensions are 1; do this so that size works the same
                            % as for doubles
                            for i = 3:nargout
                                varargout{i} = 1;
                            end

                    end

                    % for 2 input arguements, the first is the variable and the second is the dimension for which size is requested
                case 2
                    switch nargout
                        case {0,1}
                            S = varargin{1};
                            d = varargin{2};
                            % user can request d>2, and this will return 1 as long as d is nonnegative integer
                            varargout{1} = size(S.data, d);
                        otherwise
                            error('unknown command option')
                    end

            end

        end

        function B = eq(S1, S2)
            % EQ (equal to, ==) for str objects.
            %
            % B = EQ(S1, S2)
            % B = S1 == S2
            %
            % Either S1 or S2 can be a string. Returns boolean B.
            % 
            % See also ne

            switch class(S1)
                case 'str'
                    v = S1;
                case 'char'
                    if size(S1, 1) == 1
                        vfn = ['''' S1 ''''];
                    else
                        vfn = 'char';
                    end
                    v = str('data', S1, 'fullname', vfn);
                case 'cell'
                    v = str('data', S1, 'fullname', 'cellstr');

                otherwise
                    error('invalid argument')
            end

            switch class(S2)
                case 'str'
                    w = S2;
                case 'char'
                    if size(S2, 1) == 1
                        wfn = ['''' S2 ''''];
                    else
                        wfn = 'char';
                    end
                    w = str('data', S2, 'fullname', wfn);
                case 'cell'
                    w = str('data', S2, 'fullname', 'cellstr');

                otherwise
                    error('invalid argument')
            end

            if (isempty(v)) && (~isempty(w))
                B = boolean('data', [], 'fullname', ['( == ' w.fullname ')']);
                return
            elseif (isempty(w)) && (~isempty(v))
                B = boolean('data', [], ['(' v.fullname ' == )']);
                return
            elseif (isempty(v)) && (isempty(w))
                B = boolean;
                return
            end

            lvdat = length(v.data);
            lwdat = length(w.data);

            nameo = ['('    v.fullname     ' == '     w.fullname    ')'];

            % lengths must be the same, or one length must be 1; determine which
            cl = ...
                1*(lvdat==lwdat) + ...
                2*(lvdat==1 & lwdat>1) + ...
                3*(lvdat>1 & lwdat==1) + ...
                4*((lvdat>1 & lwdat>1) & (lvdat~=lwdat));

            switch cl
                case 1
                    booldat = zeros(lvdat, 1);
                    % data to be compared are the same length - proceed
                    for i = 1:lvdat
                        booldat(i) = strcmp(v.data(i), w.data(i));
                    end

                    B = boolean('data', booldat, 'fullname', nameo);

                case 2
                    booldat = zeros(lwdat, 1);
                    % first input is a simple text string, second is a str - proceed
                    for i = 1:lwdat
                        booldat(i) = strcmp(v.data, w.data(i));
                    end

                    B = boolean('data', booldat, 'fullname', nameo);

                case 3
                    % first input is a str, second input is a simple text string - proceed
                    booldat = zeros(lvdat, 1);
                    for i = 1:lvdat
                        booldat(i) = strcmp(v.data(i), w.data);
                    end

                    B = boolean('data', booldat, 'fullname', nameo);

                case 4
                    % oops
                    error('str variables must have the same length');

                otherwise
                    error('logic error');
            end

        end

        function B = ne(S1, S2)
            % NE (not equal to, ~=) for str variables.
            %
            % B = NE(S1, S2)
            % B = S1 ~= S2
            %
            % Either S1 or S2 can be a string. Returns boolean B.
            %
            % See also eq

            B = ~eq(S1, S2);

        end

        function B = strfind(S, txt)
            % find occurrences of a string in a str object.
            %
            % B = STRFIND(str, 'string')
            %
            % Returns boolean B.

            N = length(S);

            booldat = zeros(N, 1);
            f = strfind(S.data, txt);

            for i = 1:N

                if eq(f{i}, 1)
                    booldat(i) = 1;
                end

            end

            bname = [S.fullname ' containing ''' txt ''''];
            B = boolean('data', booldat, 'fullname', bname);

        end

        function B = strcmp(S1, S2)
            % STRCMP strcmp for str objects.
            %
            % B = STRCMP(V, W)
            %
            % S1 or S2 can be a string. Returns boolean B.
            %
            % See also strncmp

            B = EQ(S1, S2);

        end

        function B = strncmp(S1, S2, n)
            % STRNCMP strncmp for str objects.
            %
            % B = STRNCMP(S1, S2)
            %
            % S1 or S2 can be a string. Returns boolean B.
            %
            % See also strcmp

            switch class(S1)
                case 'str'
                    v = S1;
                case 'char'
                    if size(S1, 1) == 1
                        vfn = ['''' S1 ''''];
                    else
                        vfn = 'char';
                    end
                    v = str('data', S1, 'fullname', vfn);
                case 'cell'
                    v = str('data', S1, 'fullname', 'cellstr');

                otherwise
                    error('invalid argument')
            end

            switch class(S2)
                case 'str'
                    w = S2;
                case 'char'
                    if size(S2, 1) == 1
                        wfn = ['''' S2 ''''];
                    else
                        wfn = 'char';
                    end
                    w = str('data', S2, 'fullname', wfn);
                case 'cell'
                    w = str('data', S2, 'fullname', 'cellstr');

                otherwise
                    error('invalid argument')
            end

            if (isempty(v)) && (~isempty(w))
                B = boolean('data', [], 'fullname', ['( == ' w.fullname ')']);
                return
            elseif (isempty(w)) && (~isempty(v))
                B = boolean('data', [], ['(' v.fullname ' == )']);
                return
            elseif (isempty(v)) && (isempty(w))
                B = boolean;
                return
            end

            lvdat = length(v.data);
            lwdat = length(w.data);

            nameo = ['('    v.fullname     ' == '     w.fullname    ')'];

            % lengths must be the same, or one length must be 1; determine which
            cl = ...
                1*(lvdat==lwdat) + ...
                2*(lvdat==1 & lwdat>1) + ...
                3*(lvdat>1 & lwdat==1) + ...
                4*((lvdat>1 & lwdat>1) & (lvdat~=lwdat));

            switch cl
                case 1
                    booldat = zeros(lvdat, 1);
                    % data to be compared are the same length - proceed
                    for i = 1:lvdat
                        booldat(i) = strncmp(v.data(i), w.data(i), n);
                    end

                    B = boolean('data', booldat, 'fullname', nameo);

                case 2
                    booldat = zeros(lwdat, 1);
                    % first input is a simple text string, second is a str - proceed
                    for i = 1:lwdat
                        booldat(i) = strncmp(v.data, w.data(i), n);
                    end

                    B = boolean('data', booldat, 'fullname', nameo);

                case 3
                    % first input is a str, second input is a simple text string - proceed
                    booldat = zeros(lvdat, 1);
                    for i = 1:lvdat
                        booldat(i) = strncmp(v.data(i), w.data, n);
                    end

                    B = boolean('data', booldat, 'fullname', nameo);

                case 4
                    % oops
                    error('str variables must have the same length');

                otherwise
                    error('logic error');
            end


        end

        function S2 = strrep(S1, string1, string2)
            % STRREP strrep for str objects.
            %
            % S2 = STRREP(S1, string1, string2)
            %
            % Every occurrence of string1 is replaced with string2.

            if ~ischar(string1)
                error('string1 must be a simple string')
            end

            if ~ischar(string2)
                error('string2 must be a simple string')
            end

            s2data = strrep(S1.data, string1, string2);

            S2 = str('data', s2data, 'fullname', S1.fullname);

        end

        function s = horzcat(varargin)
            % HORZCAT horzcat for str objects.
            %
            % h = HORZCAT(S1, S2)
            % h = [S1, S2]
            %
            % Works if S1 or S2 is a string.

            switch nargin
                case 1
                    s = varargin{1};

                case 2
                    v = varargin{1};
                    w = varargin{2};

                    % v is char and w is str
                    if isa(v, 'char')
                        vrep = repmat(v, length(w), 1);
                        s = str('data', [vrep, char(w.data)], 'fullname', w.fullname);

                        % v is char and w is str
                    elseif isa(w, 'char')
                        wrep = repmat(w, length(v), 1);
                        s = str('data', [char(v.data), wrep], 'fullname', v.fullname);

                        % v is str and w is str
                    elseif isa(v, 'str') && isa(w, 'str')
                        s = str('data', [char(v.data), char(w.data)], 'fullname', [v.fullname ', ' w.fullname]);

                        % error
                    else
                        error('string variables can only be joined with char matrices or other str variables');
                    end

                otherwise

                    v = varargin{1};
                    q = varargin{nargin};
                    for i = nargin-1:-1:2
                        w = varargin{i};
                        q = horzcat(w, q); %#ok<AGROW>
                    end
                    s = horzcat(v, q);

            end

        end

        function s = vertcat(varargin)
            % VERTCAT vertcat for str objects.
            %
            % U = VERTCAT(S, T)
            % U = [S; T]
            %
            % One of the two arguments can be a char.
            %
            % See also horzcat

            switch nargin
                case 1
                    s = varargin{1};

                case 2
                    v = varargin{1};
                    w = varargin{2};

                    % v is char and w is str
                    if isa(v,'char')
                        s = str('data', char(v, char(w.data)), 'fullname', w.fullname);

                        % v is char and w is str
                    elseif isa(w, 'char')
                        s = str('data', char(char(v.data), w), 'fullname', v.fullname);

                        % v is str and w is str
                    elseif isa(v,'str') && isa(w,'str')
                        s = str('data', char([v.data; w.data]), 'fullname', [v.fullname '; ' w.fullname]);

                        % error
                    else
                        error('str variables can only be joined with char matrices or other str variables');
                    end

                otherwise

                    v = varargin{1};
                    q = varargin{nargin};
                    for i = nargin-1:-1:2
                        w = varargin{i};
                        q = vertcat(w,q); %#ok<AGROW>
                    end
                    s = vertcat(v,q);

            end

        end

        function z = isempty(S)
            % ISEMPTY isempty for str objects.

            z = isempty(S.data);

        end

        function LCS = lower(S)
            % convert str data to lower case.
            %
            % LCS = LOWER(S)
            %
            % See also upper

            LCS = str('data', lower(S.data), 'fullname', S.fullname);

        end

        function UCS = upper(S)
            % convert str data to upper case.
            %
            % UCS = UPPER(S)
            %
            % See also lower

            UCS = str('data', upper(S.data), 'fullname', S.fullname);

        end

        function C = str2cat(S)
            % convert str object to a categoric object.
            %
            % C = STR2CAT(S)
            %
            % * data values and labels in C correspond to unique strings in S
            % * empty strings are converted to NaN

            % initialize variables
            N = length(S);
            catlabs = {};

            % set up missing values as the default
            catdata = NaN(N, 1);
            indlist = 1:N;

            % while there are any indices left unused, create new values and labels for them
            catval = 1;

            while (~isempty(indlist))
                catlabs{end + 1} = char(S.data(indlist(1))); %#ok<AGROW>
                inds = find(strcmp(S.data(indlist), S.data{indlist(1)}));
                catdata(indlist(inds)) = catval;
                indlist(inds) = [];
                catval = catval + 1;
            end

            C = categoric('data', catdata, ...
                'fullname', S.fullname, ...
                'values', 1:catval-1, ...
                'labels', catlabs, ...
                'rval', 1);

        end

    end

end

