classdef categoric
    % CATEGORIC categoric objects contain categoric data.
    %
    % * CATEGORIC object should never be confused with MATLAB's
    %   categorical class!
    % 
    % A CATEGORIC object is a lightweight container used by MATISSE.
    %
    % See also categoric/categoric continuous

    properties

        data (:, 1) {mustBeNumeric} = [];        % a numeric array (coerced to a vector)
        fullname (1, :) {mustBeTextScalar} = ''; % scientific name for the vector
        values (1, :) {mustBeNumeric} = [];      % unique values that occur in the data except NaN
        labels (1, :) {mustBeText} = {''};       % corresponding value labels 

    end

    methods

        %%%
        % housekeeping
        %%%

        function F = categoric(varargin)
            % categoric object class contstructor.
            %
            % F = CATEGORIC(...
            %         'data', <numeric vector with R unique non-missing values>, ...
            %         'fullname', 'string', ...
            %         'values', [v1, v2, ..., vR]
            %         'labels', {'r 1, 'r 2', ..., 'r R'})
            %
            % data     - numeric vector containing R unique non-missing values
            % fullname - string
            % values   - R-vector of unique non-missing values
            % labels   - 1xR cell array of value labels or {''}
            % rval     - a member of values. If rval is not a member of
            %            values, it is set to the first value.

            if nargin == 0
                % Contents of an empty tbl
                F.data = [];
                F.fullname = '';
                F.values = [];
                F.labels = {''};

                return
            end

            if isa(varargin{1}, 'categoric')
                F = varargin{1};
                return
            end

            % Contents of an empty categoric
            F.data = [];
            F.fullname = '';
            F.values = [];
            F.labels = {''};

            N = numel(varargin);

            if N == 0
                return
            end

            %%%
            % whittle the arguments
            %%%
            lArgin = varargin;

            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};

                if ~ischar(propi)
                    error('a property must be specified using a string')
                end

                switch lower(propi)

                    case 'data'
                        if ismatrix(vali) && isreal(vali)
                            % coerce logical to numeric
                            if islogical(vali)
                                vali = +vali;
                            end
                            F.data = vali(:);
                        else
                            error('categoric data must be a matrix')
                        end

                    case 'fullname'
                        if ischar(vali)
                            F.fullname = vali;
                        else
                            error('fullname must be a string')
                        end

                    case 'values'
                        % must be a real scalar or vector
                        if ~isreal(vali)
                            error('invalid values')
                        end

                        F.values = vali(:);

                    case 'labels'
                        if ~iscellstr(vali) %#ok<ISCLSTR>
                            error('labels must be a cellstr')
                        else
                            F.labels = vali;
                        end

                    otherwise

                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('the last property has no matching value');
                end

            end

            if isempty(F.values)

                TMP1 = unique(F.data);
                F.values = TMP1(~isnan(TMP1));

            else

                if any(isnan(F.values))
                    error('NaN is not a valid category value');
                end

                UV = unique(F.values);

                if numel(F.values) ~= numel(UV)
                    error('duplicate category values');
                end

                TMP2 = unique(F.data);
                TMP3 = TMP2(~isnan(TMP2));
                TMP4 = setdiff(TMP3, F.values);

                if ~isempty(TMP4)
                    error('undeclared values')
                end

            end

            if eq(numel(F.labels), 1) && isempty(F.labels{1})
                F.labels = cellstr(num2str(F.values'));
            else
                if numel(F.labels) ~= numel(F.values)
                    error('wrong number of labels')
                end
            end

        end

        function varargout = disp(C)
            % DISP command window disp of a categoric object.

            % anything to display?
            if isempty(C.data)
                disp('empty categoric')
                if nargout > 0
                    disp('empty categoric')
                    varargout{1} = {};
                end
                return
            end

            nmiss = sum(isnan(C.data));
            clabs = {'value', 'freq', 'percent'};
            R = size(C.data, 1);

            if eq(nmiss, R)

                FTAB = tbl(...
                    'data', [NaN, R, 100], ...
                    'fullname', C.fullname, ...
                    'row_labels', {'Missing'}, ...
                    'col_labels', clabs);

            else

                DATA = C.data;

                % Construct frequency table.
                nv = length(C.values)+1;
                f = zeros(nv,1);
                for i = 1:nv-1
                    f(i) = length(find(DATA==C.values(i)));
                end
                f(nv) = nmiss;
                vals = [C.values, NaN];

                rlabs = C.labels;
                rlabs{end+1} = '(Missing)';
                FTAB = tbl(...
                    'data', [vals', f, 100*f./((sum(f)==0)+sum(f))], ...
                    'fullname', C.fullname, ...
                    'row_labels', rlabs, ...
                    'col_labels', clabs);

            end

            if nargout == 0
                disp(FTAB)
                disp(' ')
            else
                varargout{1} = FTAB;
            end

        end

        function U = subsref(F, S)
            % SUBSREF subscripted referencing for categoric objects.

            if length(S) > 1

                DEPTH = numel(S);
                for d = 1:DEPTH
                    if d == 1
                        U = subsref(F, S(1));
                    else
                        U = subsref(U, S(d));
                    end
                end

            else

                switch S.type

                    case '.'

                        switch S.subs

                            case 'data'
                                U = F.data;
                            case 'fullname'
                                U = F.fullname;
                            case 'values'
                                U = F.values;
                            case 'labels'
                                U = F.labels;

                            otherwise

                        end

                    case '()'
                        if isa(S.subs{1}, 'boolean')
                            S.subs = find(S.subs{1}.data == 1);
                            S.subs = {S.subs};
                        elseif isa(S.subs{1}, 'logical')
                            S.subs = S.subs{1};
                            S.subs = {S.subs};
                        else
                            % let MATLAB handle any errors
                        end
                        NI = numel(S.subs);
                        switch NI
                            case {0, 1}
                                SUBS = cell(1, 2);
                                SUBS{1} = S.subs{1};
                                SUBS{2} = ':';
                            case 2
                                SUBS = S.subs;
                            otherwise

                        end

                        DATA = F.data(SUBS{1}(:), SUBS{2});

                        U = categoric('data', DATA, ...
                            'fullname', F.fullname, ...
                            'values', F.values, ...
                            'labels', F.labels);

                    case '{}'

                        % do nothing
                        U = F;

                end

            end

        end

        function G = subsasgn(F, S, V)
            % SUBSASGN subscripted assignment for categoric objects.

            if length(S) > 1
                DEPTH = numel(S);
                error('index expression has depth %g, cannot be > 1', DEPTH)
            end

            switch S.type

                case '.'

                    switch S.subs
                        case 'data'
                            G = categoric(...
                                'data', V, ... ...
                                'fullname', F.fullname, ...
                                'values', F.values, ...
                                'labels', F.labels);

                        case 'fullname'
                            G = F;
                            G.fullname = V;

                        case 'values'
                            G = categoric(...
                                'data', F.data, ... ...
                                'fullname', F.fullname, ...
                                'values', V);

                        case 'labels'
                            G = categoric(...
                                'data', F.data, ... ...
                                'fullname', F.fullname, ...
                                'values', F.values, ...
                                'labels', V);

                        otherwise

                    end

                case '()'
                    warning('parentheses indexing is undefined')

                case '{}'
                    warning('brace indexing is undefined')

                otherwise

            end

        end

        function r = end(g, k, ~)
            % END end method for categoric objects.

            switch k
                case 1
                    r = size(g, 1);
                case 2
                    r = size(g, 2);
                otherwise
            end

        end

        function S = isempty(F)
            % ISEMPTY isempty for categoric objects.
            %
            % S = ISEMPTY(F)
            %
            % S is logical true or false
            %
            % See also length, size.

            S = isempty(F.data);

        end

        function varargout = size(F, varargin)
            % SIZE size of a categoric object.
            %
            % [R, C] = SIZE(F)
            % R = SIZE(F, 1)
            % C = SIZE(F, 2)
            %
            % Number of rows R and columns C of F.
            %
            % See also length, isempty.

            switch nargin
                case 1
                    switch nargout
                        case {0, 1}
                            varargout{1} = [size(F.data, 1), size(F.data, 2)];
                        case 2
                            varargout{1} = size(F.data, 1);
                            varargout{2} = size(F.data, 2);
                        otherwise
                            error('too many outputs')
                    end

                case 2
                    d = varargin{1};
                    switch nargout
                        case {0, 1}
                            varargout{1} = size(F.data, d(1));
                        case 2
                            varargout{1} = size(F.data, d(1));
                            varargout{2} = size(F.data, d(2));
                        otherwise
                            error('too many outputs')
                    end
            end
        end

        function L = length(F)
            % LENGTH length of a categoric object.
            %
            % L = LENGTH(F)
            %
            % See also size, isempty.

            L = size(F.data, 1);

        end

        %%%
        % recoding
        %%%

        function R = recode(F, NewValues)
            % replace old values in a categoric with new values.
            %
            % R = RECODE(F, NewValues)
            %
            % Example:
            %
            % sex = categoric([1 1 2 1 2 1 1], 'Sex', [1 2], {'Male', 'Female'})
            % sex = recode(sex, [0 1]) % Change 1 to 0 and 2 to 1
            %
            % See also reorder, squeeze.

            N = length(F);
            P = length(F.values);

            if length(NewValues)~=P
                error('wrong number of new values')
            end
            if any(isnan(NewValues))
                error('NaN is not a valid value')
            end

            OLDDATA = F.data;
            OldValues = F.values;
            NEWDATA = NaN*ones(N, 1);
            for i = 1:P
                I = (OLDDATA == OldValues(i));
                NEWDATA(I) = NewValues(i);
            end

            R = categoric('data', NEWDATA, ...
                'fullname', F.fullname, ...
                'values', NewValues, ...
                'labels', F.labels);

        end

        function R = reorder(F, ReorderedValues)
            % REORDER reorder values in a categoric object.
            %
            % R = REORDER(F, ReorderedValues)
            %
            % Reorder values in F with corresponding ReorderedValues.
            %
            % Example:
            %
            % % value 1 is listed first, then value 2:
            %  sex = categoric([1 1 2 1 2 1 1], 'Sex', [1 2], {'Male', 'Female'})
            %
            % % now value 2 is listed first, then value 1:
            %  sex = reorder(sex, [2 1])
            %
            % See also recode, squeeze.

            if ~all(ismember(ReorderedValues, F.values))
                error('Invalid OrderedValues list.')
            end
            [~, LOC] = ismember(ReorderedValues, F.values);

            R = categoric('data', F.data, ...
                'fullname', F.fullname, ...
                'values', ReorderedValues, ...
                'labels', F.labels(LOC));

        end

        function [S, OUT] = squeeze(F)
            % remove categories with zero frequency.
            %
            % S = SQUEEZE(F);
            % [S, OUT] = SQUEEZE(F);
            %
            % Remove categories in F that have 0 frequency in the data.
            % OUT is the number of deleted categories.
            %
            % See also recode, reorder.

            nvals = length(F.values);
            DATA = F.data(~isnan(F.data));
            nvals0 = length(unique(DATA));
            if nvals0 == nvals
                OUT = 0;
                S = F;
                return
            end

            OUT = nvals - nvals0;

            % frequency table
            nv = length(F.values);
            f = zeros(nv,1);
            for i = 1:nv
                f(i) = length(find(F.data == F.values(i)));
            end

            newvalues = F.values(f>0);
            newlabels = F.labels(f>0);

            %%%
            % Return squeezed version of F
            %%%
            S = categoric('data', F.data, ...
                'fullname', F.fullname, ...
                'values', newvalues, ...
                'labels', newlabels);

        end

        function C1 = nan2value(C0, varargin)
            % convert missing data in a categoric to a category.
            %
            % C1 = NAN2VALUE(C0)
            % C1 = NAN2VALUE(C0, label)
            %
            % Convert NaNs in C0 to a category with default label 'Unknown'
            % and value equal to 1 plus the largest existing value.
            %
            % See also value2nan.

            if ~any(isnan(C0.data))
                C1 = C0;
                return
            end

            B0 = isnan(C0);

            DATA = C0.data;
            nanval = max(C0.values) + 1;
            DATA(logical(B0.data)) = nanval;
            if nargin >= 2
                Label = varargin{1};
                if ~(ischar(Label) && size(Label, 1) == 1)
                    error('label must be a string')
                end
            else
                Label = 'Unknown';
            end

            LABELS = C0.labels;
            LABELS{end+1} = Label;

            C1 = categoric('data', DATA, ...
                'fullname', C0.fullname, ...
                'values', [C0.values nanval], ...
                'labels', LABELS);

        end

        function F1 = value2nan(F0, values)
            % convert one or more categoric values to NaN.
            %
            % F1 = VALUE2NAN(F0, values)
            %
            % See also nan2value, combcat.

            values = values(:)';
            if ~isnumeric(values)
                error('values must be a scalar or vector.')
            end

            P = length(values);
            F1 = F0;
            for i = 1:P
                F1 = val2nan(F1, values(i));
            end

            function F2 = val2nan(F1, value)

                B0 = (F1.data == value);
                if sum(B0) == 0
                    F2 = F1;
                    return
                end

                DATA = F1.data;
                DATA(B0 == 1) = NaN;
                [~, LOC] = ismember(F1.values, value);
                LOC = find(LOC);
                VALS = F1.values;
                VALS(LOC) = [];
                LABS = F1.labels;
                LABS(LOC) = [];

                if isempty(VALS)
                    % F1 had only one value, and the user set it to NaN.
                    F2 = categoric('data', DATA, 'fullname', F1.fullname);
                else
                    F2 = categoric('data', DATA, ...
                        'fullname', F1.fullname, ...
                        'values', VALS, ...
                        'labels', LABS);
                end

            end
        end

        function M = combcat(F, VALS)
            % merge one or more categories in a categoric.
            %
            % M = COMBCAT(F, VALS);
            %
            % See also commcat.

            % all VALS are real numbers?
            if ~(isreal(VALS) && isnumeric(VALS))
                error('VALS must be numeric')
            end

            % no NaN values
            if any(isnan(VALS))
                error('NaN is not a valid category value');
            end

            % no duplicates
            n0 = numel(VALS);
            n1 = numel(unique(VALS));
            if ne(n0, n1)
                error('VALS contains duplicates')
            end

            % trivial case
            if eq(numel(VALS), 1)
                M = F;
                return
            end

            % all VALS contained in the data?
            z = setdiff(VALS, F.values);
            if ~isempty(z)
                error('VALS contains invalid values')
            end

            % original properties
            org_data = F.data;
            org_values = F.values;
            org_labels = F.labels;

            % new data
            new_data = org_data;
            nv = numel(VALS);
            comb_value = VALS(1);
            for i = 1:nv
                new_data(org_data == VALS(i)) = comb_value;
            end

            % new values
            new_values = [comb_value, setdiff(org_values, VALS)];

            % combo label
            comb_label = '';
            for i = 1:nv
                ii = find(org_values == VALS(i));
                if i==1
                    comb_label = org_labels{ii};
                else
                    comb_label = [comb_label, ' & ' org_labels{ii}]; %#ok<AGROW>
                end
            end

            % new labels
            nc = length(new_values);
            new_labels = cell(1, nc);
            for i = 1:nc
                ii = find(org_values == new_values(i));
                if new_values(i) == comb_value
                    new_labels{i} = comb_label;
                else
                    new_labels{i} = org_labels{ii}; %#ok<FNDSB>
                end
            end

            M = categoric('data', new_data, ...
                'fullname', F.fullname, ...
                'values', new_values, ...
                'labels', new_labels);

        end

        function C = commcat(A, f)
            % merge values in a categoric with frequencies below a threshold.
            %
            % C = COMMCAT(A, f)
            %
            % Merge values in A that occur with frequency percent less than f.
            %
            % See also combcat.

            C = COMMCAT(A, f);

        end

        %%%
        % binary comparison operators
        %%%

        function B = eq(F1, F2)
            % EQ (equal to) comparison operator for categorics.
            %
            % B = F1 == F2
            % B = EQ(F2, F2)
            %
            % One argument can be a double or scalar. The output B is boolean.
            %
            % If F1 or F2 is NaN, the output matches isnan.
            %
            % See also isnan, ne, ge, gt, le, lt.

            % S for share / all the binary comparisons share code
            S = binary_comps_setup(F1, F2);

            if S.trivial
                B = boolean;
                return
            end

            switch S.cl
                case 1
                    nameo = ['('    S.namev     ' == '     S.namew    ')'];
                    B = boolean('data', S.vdat == S.wdat, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat) | isnan(S.wdat)) = NaN;

                case 2
                    nameo = ['('    S.namev     ' == '     S.namew    ')'];
                    DATA = S.vdat == S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.wdat)) = NaN;

                case 3
                    nameo = ['('    S.namev     ' == '     S.namew    ')'];
                    DATA = S.vdat == S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat)) = NaN;

            end

        end

        function B = isnan(F)
            % ISNAN isnan for categoric objects.
            %
            % B = isnan(F)
            %
            % boolean B is true for NaN data in F.

            B = eq(F, NaN);

        end

        function B = ne(F1, F2)
            % NE (not equal to) comparison operator for categorics.
            %
            % B = F1 ~= F2
            % B = NE(F1, F2)
            %
            % One argument can be a double or scalar. The output B is boolean.
            %
            % See also eq, ge, gt, le, lt.

            % S for share / all the binary comparisons share code
            S = binary_comps_setup(F1, F2);

            if S.trivial
                B = boolean;
                return
            end

            switch S.cl
                case 1
                    nameo = ['('    S.namev     ' ~= '     S.namew    ')'];
                    B = boolean('data', S.vdat ~= S.wdat, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat) | isnan(S.wdat)) = NaN;

                case 2
                    nameo = ['('    S.namev     ' ~= '     S.namew    ')'];
                    DATA = S.vdat ~= S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.wdat)) = NaN;

                case 3
                    nameo = ['('    S.namev     ' ~= '     S.namew    ')'];
                    DATA = S.vdat ~= S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat)) = NaN;

            end


        end

        function B = gt(F1, F2)
            % GT (greater than) comparison operator for categorics.
            %
            % B = F1 > F2
            % B = GT(F1, F1)
            %
            % The data values are compared. One argument can be a double or scalar. The
            % output B is boolean.
            %
            % See also eq, ne, ge, le, lt.

            % S for share / all the binary comparisons share code
            S = binary_comps_setup(F1, F2);

            if S.trivial
                B = boolean;
                return
            end

            switch S.cl
                case 1
                    nameo = ['('    S.namev     ' > '     S.namew    ')'];
                    B = boolean('data', S.vdat > S.wdat, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat) | isnan(S.wdat)) = NaN;

                case 2
                    nameo = ['('    S.namev     ' > '     S.namew    ')'];
                    DATA = S.vdat > S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.wdat)) = NaN;

                case 3
                    nameo = ['('    S.namev     ' > '     S.namew    ')'];
                    DATA = S.vdat > S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat)) = NaN;

            end

        end

        function B = ge(F1, F2)
            % GE (greater than or equal to) comparison operator for categorics.
            %
            % B = F1 >= F2
            % B = GE(F1, F2)
            %
            % The data values are compared. One argument can be a double or scalar. The
            % output B is boolean.
            %
            % See also eq, ne, gt, le, lt.

            % S for share / all the binary comparisons share code
            S = binary_comps_setup(F1, F2);

            if S.trivial
                B = boolean;
                return
            end

            switch S.cl
                case 1
                    nameo = ['('    S.namev     ' >= '     S.namew    ')'];
                    B = boolean('data', S.vdat >= S.wdat, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat) | isnan(S.wdat)) = NaN;

                case 2
                    nameo = ['('    S.namev     ' >= '     S.namew    ')'];
                    DATA = S.vdat >= S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.wdat)) = NaN;

                case 3
                    nameo = ['('    S.namev     ' >= '     S.namew    ')'];
                    DATA = S.vdat >= S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat)) = NaN;

            end


        end

        function B = lt(F1, F2)
            % LT (less than) comparison operator for categorics.
            %
            % B = F1 < F2
            % B = LT(F1, F2)
            %
            % One argument can be a double or scalar. The output B is boolean.
            %
            % See also eq, ne, ge, gt, le.

            % S for share / all the binary comparisons share code
            S = binary_comps_setup(F1, F2);

            if S.trivial
                B = boolean;
                return
            end

            switch S.cl
                case 1
                    nameo = ['('    S.namev     ' < '     S.namew    ')'];
                    B = boolean('data', S.vdat < S.wdat, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat) | isnan(S.wdat)) = NaN;

                case 2
                    nameo = ['('    S.namev     ' < '     S.namew    ')'];
                    DATA = S.vdat < S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.wdat)) = NaN;

                case 3
                    nameo = ['('    S.namev     ' < '     S.namew    ')'];
                    DATA = S.vdat < S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat)) = NaN;

            end

        end

        function B = le(F1, F2)
            % LE (less than or equal to) comparison operator for categorics.
            %
            % B = F1 <= F2
            % B = LE(F1, F2)
            %
            % The data values are compared. One argument can be a double or scalar. The
            % output B is boolean.
            %
            % See also eq, ne, ge, gt, lt.

            % S for share / all the binary comparisons share code
            S = binary_comps_setup(F1, F2);

            if S.trivial
                B = boolean;
                return
            end

            switch S.cl
                case 1
                    nameo = ['('    S.namev     ' <= '     S.namew    ')'];
                    B = boolean('data', S.vdat <= S.wdat, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat) | isnan(S.wdat)) = NaN;

                case 2
                    nameo = ['('    S.namev     ' <= '     S.namew    ')'];
                    DATA = S.vdat <= S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.wdat)) = NaN;

                case 3
                    nameo = ['('    S.namev     ' <= '     S.namew    ')'];
                    DATA = S.vdat <= S.wdat;
                    B = boolean('data' , DATA, 'fullname', nameo);
                    % reset pre-existing NaNs
                    B(isnan(S.vdat)) = NaN;

            end

        end

        %%%
        % unary operators
        %%%
        function varargout = sort(F, varargin)
            % SORT sort the data in a categoric object.
            %
            % S = SORT(F)
            % S = SORT(F, ...)
            % [S, I] = SORT(F, ...)
            %
            % help sort

            [F.data, I] = sort(F.data, varargin{:});

            switch nargout
                case {0, 1}
                    varargout{1} = F;
                case 2
                    varargout{1} = F;
                    varargout{2} = I;
                otherwise
                    error('too many outputs')
            end

        end

        %%%
        % binary operators
        %%%

        function M = mtimes(V, W)
            % categoric with all combinations of values in two categorics.
            %
            % M = MTIMES(V, W)
            % M = V*W
            %
            % M is categoric with a level for each combination of values of V and W.
            % Empty combinations are excluded.

            if length(V.data)~=length(W.data)
                error('length mismatch');
            end

            if isa(V, 'boolean')
                V = bool2cat(V);
            end
            if isa(W, 'boolean')
                W = bool2cat(W);
            end

            N = length(V.data);
            p1 = numel(V.values);
            p2 = numel(W.values);

            if ~(isa(V,'categoric') && isa(W,'categoric'))
                error('one argument is not categoric or boolean')

            end

            FULLNAME = ['(' V.fullname ') * (' W.fullname ')'];

            %%%
            % recode v and w = category 2 as 0, 1, ...
            %%%
            v_0 = sparse(N, 1);
            flagnan = logical(isnan(V.data));

            if any(flagnan)
                v_0(flagnan) = NaN;
            end

            for i = 1:p1
                v_0 = v_0 + (i-1)*(V.data == V.values(i));
            end

            w_0 = sparse(N, 1);
            flagnan = logical(isnan(W.data));

            if any(flagnan)
                w_0(flagnan)=NaN;
            end

            for i = 1:p2
                w_0 = w_0 + (i-1)*(W.data == W.values(i));
            end

            %%%
            % find the BASE of the coding scheme to cross categories v and w
            %%%
            BASE = max(p1, p2);

            %%%
            % define the new category
            %%%

            % data
            DATA = w_0*BASE^1 + v_0*BASE^0;

            % values
            VALUES = unique(DATA(~isnan(DATA)));
            p = numel(VALUES);
            % labels
            LABS = {};
            for i = 1:p
                groupi = VALUES(i);
                i2 = floor(groupi/BASE);
                i1 = groupi-i2*BASE;
                LABS{end+1} = [V.labels{i1+1} ' & ' W.labels{i2+1}]; %#ok<AGROW>
            end

            % instantiate
            M = categoric(...
                'data', DATA, ...
                'fullname', FULLNAME, ...
                'values', VALUES, ...
                'labels', LABS);

            % our coding scheme gives us unique sorted values, but there
            % are skips - recode to 1, 2, ...

            M = recode(M, 1:p);

        end

        %%%
        % statistics
        %%%
        function T = crosstab(C1, C2, varargin)
            % chi-square test of homogeneity/independence between two categorics.
            %
            % T = CROSSTAB(C1, C2, <property-value pairs>)
            %
            % Property-value pairs:
            %
            %      'B' - number of permutation samples, default is 0
            % 'Engine' - computational engine
            %            * 'stats' for the Statistics Toolbox (preferred)
            %            * 'statlab' for a stand-alone function
            %
            % * C1 is an obligate categoric
            % * C2 can be boolean, str, continuous, or double

            T = CROSSTAB(C1, C2, varargin{:});
        end

        %%%
        % visualization
        %%%

        function varargout = bar(varargin)
            % BAR bar plot of a categoric.
            %
            % BAR(Y)
            % BAR(Y, <property-value pairs>)
            % BAR(Y, C)
            % BAR(Y, C, <property-value pairs>)
            % [BarHandles, ChiSquareTest] = BAR(...)
            %
            % Property-value pairs:
            %
            % 'PVAL'      - 0 (false, default) or 1 (true) perform Chi-Square test
            % 'B'         - scalar (default 0), number of permutation samples for Chi-Square test
            % 'style'     - 'grouped' (default), 'stacked', 'hist', or 'histc'
            % 'Normalize' - 0/'off' (default), 1/'rows' or 2/'cols' or 3/'both'
            % 'pvp', 'go' - output from the go function

            [BH, X] = BAR(varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = BH;
                case 2
                    varargout{1} = BH;
                    varargout{2} = X;
                otherwise
            end

        end

    end

end

%%%
% Local Functions
%%%

function S = binary_comps_setup(F1, F2)
% All the binary comparison operators share code
% S is for 'share'

if isa(F1, 'numeric')
    S.vdat = F1;
    S.lv = numel(S.vdat);
    if eq(S.lv, 1)
        F1 = categoric('data', S.vdat, 'fullname', num2str(S.vdat));
    else
        F1 = categoric('data', S.vdat, 'fullname', 'numeric');
    end
    S.wdat = F2.data;
    S.lw = numel(S.wdat);
elseif isa(F2, 'numeric')
    S.wdat = F2;
    S.lw = numel(S.wdat);
    if eq(S.lw, 1)
        F2 = categoric('data', S.wdat, 'fullname', num2str(S.wdat));
    else
        F2 = categoric('data', S.wdat, 'fullname', 'numeric');
    end
    S.vdat = F1.data;
    S.lv = numel(S.vdat);
else
    S.vdat = F1.data;
    S.lv = numel(S.vdat);
    S.wdat = F2.data;
    S.lw = numel(S.wdat);
end

if ((S.lv == 0) && (S.lw ~= 0)) || ((S.lw == 0) && (S.lv ~= 0)) || ((S.lv == 0) && (S.lw == 0))
    S.trivial = 1;
else
    S.trivial = 0;
end

% lengths must be the same, or one length must be 1; determine case
S.cl = ...
    1*(S.lv==S.lw) + ...
    2*(S.lv==1 & S.lw>1) + ...
    3*(S.lv>1 & S.lw==1) + ...
    4*((S.lv>1 & S.lw>1) & (S.lv~=S.lw));

if eq(S.cl, 4)
    error('length mismatch in categoric comparison')
end

S.namev = F1.fullname;
S.namew = F2.fullname;


end