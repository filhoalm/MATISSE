function T = CROSSTAB(C1, C2, varargin)
% CATEGORIC/CROSSTAB Chi-Square test.

PVP = checkPVPAIRS(C1, C2, varargin{:});

switch PVP.Engine
    case 'stats'
        [t0, x0, p0] = crosstab(PVP.C1.data, PVP.C2.data);
    case 'statlab'
        [t0, x0, p0] = crosstab_helper(PVP.C1, PVP.C2);
end

T.TEST = 'crosstab';
if length(C2.values)>1
    fn = [C1.fullname ' x ' C2.fullname];
else
    fn = C1.fullname;
end
T.DATA = tbl(...
    'data', t0, ...
    'fullname', fn, ...
    'row_labels', PVP.C1.labels, ...
    'col_labels', PVP.C2.labels);

T.CHI2 = x0;
[R, C] = size(T.DATA);
T.df = (R-1)*(C-1);
T.PVAL0 = p0;

if PVP.B > 0

    X2BOOT = zeros(1+PVP.B, 1);
    X2BOOT(1) = T.CHI2;
    N = length(PVP.C1);

    for b = 1:PVP.B
        switch PVP.Engine
            case 'stats'
                [~, X2BOOT(b+1), ~] = crosstab(PVP.C1.data, PVP.C2.data(randperm(N)));
            case 'statlab'
                I.type = '()';
                I.subs = {randperm(N)};
                c2star = subsref(PVP.C2, I);
                [~, X2BOOT(b+1), ~] = crosstab_helper(PVP.C1, c2star);
        end
    end

    T.X2BOOT = continuous('data', X2BOOT, 'fullname', 'Permutation Distribution');
    T.PPVAL = mean(T.CHI2<=T.X2BOOT.data);

else

    T.X2BOOT = continuous;
    T.PPVAL = NaN;

end

end

function [PVP] = checkPVPAIRS(C1, C2, varargin)
% Helper function. Validate property value pairs.

PVP = struct('C1', [], 'C2', [], 'B', 0, 'Engine', 'statlab');

PVP.C1 = C1;

switch class(C2)
    case 'categoric'
        PVP.C2 = C2;
    case 'boolean'
        PVP.C2 = bool2cat(C2);
    case 'str'
        PVP.C2 = str2cat(C2);
    case 'continuous'
        PVP.C2 = categoric('data', C2.data, 'fullname', C2.fullname);
    case 'double'
        PVP.C2 = categoric('data', C2, 'fullname', 'Column Category');
    otherwise
        error('invalid class for variable C2')
end
if length(PVP.C1)~=length(PVP.C2)
    error('Length mismatch.')
end

lArgin = varargin;
nlA = numel(lArgin);

if eq(nlA, 1)
    error('incomplete property/value pair');
end

while nlA >= 2
    propi = lArgin{1};
    vali = lArgin{2};

    switch lower(propi)

        case 'b'
            if ~(isscalar(vali) && isreal(vali))
                error('B must be a real scalar')
            else
                if vali < 0
                    error('B must be nonnegative')
                else
                    PVP.B = vali;
                end
            end

        case 'engine'
            % must be string
            if ~ischar(vali)
                error('Engine property value must be a string.')
            end
            if size(vali, 1)>1
                error('Engine property value must be a string, not a character matrix.')
            end
            vali = lower(vali);
            if ~strcmp(vali, {'stats','statlab'})
                error('Engine property value must be ''stats'' or ''statlab''.')
            end
            PVP.Engine = vali;

        otherwise
    end

    lArgin = lArgin(3:end);
    nlA = numel(lArgin);

end

% * Exclude cases with any missing data
% * squeeze out categories with 0 observations

INC = ~isnan(PVP.C1.data) & ~isnan(PVP.C2.data);


DATA1 = PVP.C1.data;
TMP1 = categoric(...
    'data', DATA1(INC), ...
    'fullname', PVP.C1.fullname, ...
    'values', PVP.C1.values, ...
    'labels', PVP.C1.labels);
PVP.C1 = squeeze(TMP1);

DATA2 = PVP.C2.data;
TMP2 = categoric(...
    'data', DATA2(INC), ...
    'fullname', PVP.C2.fullname, ...
    'values', PVP.C2.values, ...
    'labels', PVP.C2.labels);
PVP.C2 = squeeze(TMP2);

% statistics toolbox crosstab function is going to create a table ordered
% from lowest to highest value. reorder values in input so that labels will
% still match.
PVP.C1 = reorder(PVP.C1, sort(PVP.C1.values));
PVP.C2 = reorder(PVP.C2, sort(PVP.C2.values));

end

function [t0, x0, p0] = crosstab_helper(C1, C2)
% Helper function.
R = length(C1.values);
C = length(C2.values);
t0 = NaN(R, C);
for r = 1:R
    for c = 1:C
        t0(r, c) = sum((C1.data == C1.values(r)) & (C2.data == C2.values(c)));
    end
end
e0 = sum(t0, 2)*sum(t0, 1)./sum(t0(:));
E = e0(:);
O = t0(:);
x0 = sum((O - E).^2./E);
[R, C] = size(t0);
df = (R-1)*(C-1);
p0 = 1 - chi2cdf(x0, df);

end