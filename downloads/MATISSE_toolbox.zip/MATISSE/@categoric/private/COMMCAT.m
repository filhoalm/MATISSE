function C = COMMCAT(A, f)
% CATEGORIC/COMMCAT Merge categories with frequencies below a threshold.
%
% C = commcat(A, f)
%
% Merge categories in A that occur with frequency percent less than f.
%
% See also combcat.

% Validate f
if ~(isscalar(f) && isreal(f))
    error('f must be a scalar')
else
    if f < 0 || f > 1
        error('f must lie between 0 and 1 inclusive')
    end
end

% identify categories that occur with frequency <= f
nv = length(A.values);
INC = ~isnan(A.data);
nc = numel(INC);
if nc==0
    C = A;
    return
end

%%%
% Compute the frequency of each category.
%%%
freqs = zeros(nv, 1);
for i = 1:nv
    freqs(i) = length(find(A.data==A.values(i)));
end
freqs = freqs./nc;

% determine list of categories to be merged. 
% * make a sequential list of the non-merged values and labels
%%%
KEEP = [];
COMB = [];
LABS = {};
for i = 1:nv
    if freqs(i)<=f
        COMB = [COMB, A.values(i)]; %#ok<AGROW>
    else
        KEEP = [KEEP, A.values(i)]; %#ok<AGROW>
        LABS{end+1} = A.labels{i}; %#ok<AGROW>
    end
end

% error out if there are no common categories
if isempty(KEEP)
    disp('all categories occur at a frequency below the threshold value')
    C = categoric;
    return
end

% set the combined value equal to the maximum of KEEP values plus 1
% set the combined label to 'Other'
LABS{end+1} = 'Other';
VALS = [KEEP, max(KEEP)+1];

% Anthing to combine?
if isempty(COMB)
    C = A;
    return
end

% replace COMB values with common value.
TF = ismember(A.data, COMB);
CDATA = A.data;
CDATA(TF) = VALS(end);

C = categoric(...
    'data', CDATA, ...
    'fullname', [A.fullname ', f>= ' num2str(f)], ...
    'values', VALS, ...
    'labels', LABS);

end

