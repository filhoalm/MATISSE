function [BH, X] = BAR(varargin)
% CATEGORIC/BAR BAR plot.

INPUTS = BAR_OPTIONS(varargin{:});

[NB, NSTRATA] = size(INPUTS.X.DATA);

switch INPUTS.style
    case 'grouped'
        BH = bar(INPUTS.X.DATA.data, 'grouped');

    case 'stacked'
        BH = bar(INPUTS.X.DATA.data, 'stacked');
        CumSumYData = zeros(1, NB);

    case 'hist'
        BH = bar(INPUTS.X.DATA.data, 'hist');

    case 'histc'
        BH = bar(INPUTS.X.DATA.data, 'histc');

end

if NSTRATA > 1
    haha = {'left', 'right'};
    vava = {'top', 'bottom'};
else
    haha = {'left', 'left'};
    vava = {'middle', 'middle'};
end


for i = 1:NSTRATA

    set(BH(i), ...
        'FaceColor', INPUTS.PVP.MAP(i, :), ...
        'LineStyle', INPUTS.PVP.ls0{INPUTS.PVP.LineStyle(i)}, ...
        'FaceAlpha', INPUTS.PVP.FaceAlpha, ...
        'EdgeAlpha', INPUTS.PVP.EdgeAlpha)

    if INPUTS.PVP.Text
        switch INPUTS.style
            case 'stacked'
                XDatai = BH(i).XData;
                YDatai = BH(i).YData;
                CumSumYData = CumSumYData + YDatai;
                txt = cellstr(num2str(YDatai', INPUTS.PVP.formatSpec))';
                text(XDatai, CumSumYData, txt, ...
                    'Color', INPUTS.PVP.MAP(i, :), ...
                    'BackgroundColor', [1 1 1], ...
                    'EdgeColor', INPUTS.PVP.MAP(i, :), ...
                    'Margin', 1, ...
                    'HorizontalAlignment', haha{1 + rem(i, 2)}, ...
                    'VerticalAlignment', vava{1 + rem(i, 2)}, ...
                    'FontSize', INPUTS.PVP.FontSize(1));

            case 'grouped'
                XDatai = BH(i).XEndPoints;
                YDatai = BH(i).YData;
                txt = cellstr(num2str(YDatai', INPUTS.PVP.formatSpec))';
                text(XDatai, YDatai, txt, ...
                    'Color', INPUTS.PVP.MAP(i, :), ...
                    'BackgroundColor', [1 1 1], ...
                    'EdgeColor', INPUTS.PVP.MAP(i, :), ...
                    'Margin', 1, ...
                    'HorizontalAlignment', 'left', ...
                    'VerticalAlignment', vava{2 - rem(i, 2)}, ...
                    'FontSize', INPUTS.PVP.FontSize(1));

            case {'hist', 'histc'}
                XDatai = mean(BH(i).XData, 1);
                YDatai = BH(i).YData(2, :);
                txt = cellstr(num2str(YDatai', INPUTS.PVP.formatSpec))';
                text(XDatai, YDatai, txt, ...
                    'Color', INPUTS.PVP.MAP(i, :), ...
                    'BackgroundColor', [1 1 1], ...
                    'EdgeColor', INPUTS.PVP.MAP(i, :), ...
                    'Margin', 1, ...
                    'HorizontalAlignment', 'left', ...
                    'VerticalAlignment', 'middle', ... % vava{2 - rem(i, 2)}, ...
                    'FontSize', INPUTS.PVP.FontSize(1));

        end

    end

end

switch INPUTS.Normalize
    case 0
        ylabel('Frequency Count', 'FontSize', INPUTS.PVP.FontSize(2))
    case {1, 2}
        ylabel('Percent', 'FontSize', INPUTS.PVP.FontSize(2))
end

if INPUTS.PVP.labels(3)
    title(INPUTS.X.DATA.fullname, 'FontSize', INPUTS.PVP.FontSize(3))
end

if ~isempty(INPUTS.PVP.YLim)
    YL = INPUTS.YLim;
else
    YL = get(gca, 'YLim');
    % Make some space at the top.
    YL(2) = 1.05*YL(2);
end

ax = gca;
set(ax, ...
    'XTick', 1:1:size(INPUTS.X.DATA, 1), ...
    'XTickLabel', INPUTS.X.DATA.row_labels, ...
    'XTickLabelRotation', INPUTS.PVP.TextRot, ...
    'YLim', YL, ...
    'YGrid', 'on', ...
    'XGrid', 'off', ...
    'Box', 'off', ...
    'TickDir', 'out', ...
    'PlotBoxAspectRatio', [INPUTS.PVP.Width 1 1])
ax.XRuler.FontSize = INPUTS.PVP.FontSize(1);
ax.YRuler.FontSize = INPUTS.PVP.FontSize(2);

% Add a legend
if INPUTS.PVP.Legend
    lh = legend(BH, INPUTS.X.DATA.col_labels, 'Location', 'best');
    set(lh, 'box', 'off', 'FontSize', INPUTS.PVP.FontSize(1))
    if INPUTS.PVAL
        PVAL = ['\rm{P = ' num2str(INPUTS.X.P) '}'];
        ts = {INPUTS.C.fullname, PVAL};
    else
        ts = INPUTS.C.fullname;
    end
    set(get(lh, 'Title'), 'String', ts, 'Visible', 'on', 'FontSize', INPUTS.PVP.FontSize(1))
end

X = INPUTS.X;

end

function INPUTS = BAR_OPTIONS(varargin)
% Validate and process inputs for main procedure.

% default values
INPUTS = struct(...
    'Y', [], ...
    'C', [], ...
    'PVP', [], ...
    'data', [], ...
    'style', 'grouped', ...
    'Normalize', 0, ...
    'PVAL', 0, ...
    'B', 0, ...
    'BarWidth', 0.8, ...
    'X', []);

INPUTS.Y = varargin{1};
N = length(INPUTS.Y);

switch nargin
    case 1
        INPUTS.C = categoric('data', ones(N, 1), 'fullname', '1');
        lArgin = {};

    otherwise

        TMP1 = varargin{2};

        switch class(TMP1)
            case 'categoric'
                C = TMP1;
            case 'boolean'
                C = bool2cat(TMP1);
            case 'str'
                C = str2cat(TMP1);
            case 'continuous'
                C = categoric('data', TMP1.data, 'fullname', C2.fullname);
            case 'double'
                C = categoric('data', TMP1, 'fullname', 'Column Category');
            otherwise
                C = [];

        end

        if isempty(C)
            lArgin = varargin(2:end);
            INPUTS.C = categoric('data', ones(N, 1), 'fullname', '1');
        else
            lArgin = varargin(3:end);
            INPUTS.C = C;
        end

end

if size(INPUTS.C, 1) > 0 && size(INPUTS.C, 1)~=N
    error('length mismatch between first categoric and stratification variable')
end

nlA = numel(lArgin);
if eq(nlA, 1)
    error('a property has no value');
end

while ge(nlA, 2)

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('property must be specified using a string')
    end
    switch lower(propi)

        case {'pvp', 'go'}
            if ~isa(vali, 'struct')
                error('''pvp''/''go'' must be a struct')
            end
            INPUTS.PVP = vali;

        case 'style'
            % validate
            if ~ischar(vali)
                error('''style'' must be ''grouped'', ''stacked'', ''hist'' or ''histc''')
            end
            if size(vali, 1)>1
                error('''style'' must be a string, not a character matrix')
            end
            vali = lower(vali);
            I = strcmp({'grouped', 'stacked', 'hist', 'histc'}, vali);
            if ~any(I)
                error(['''' vali ''' is invalid, must be ''grouped'', ''stacked'', ''hist'' or ''histc'''])
            end
            INPUTS.style = vali;

        case 'normalize'

            if vali(1)==0 || strcmpi(vali, 'off')
                INPUTS.Normalize = 0;
            elseif vali(1)==1 || strcmpi(vali, 'rows')
                INPUTS.Normalize = 1;
            elseif vali(1)==2 || strcmpi(vali, 'cols')
                INPUTS.Normalize = 2;
            elseif vali(1)==3 || strcmpi(vali, 'both')
                INPUTS.Normalize = 3;
            else
                error('''Normalize'' must be 0/''off'' 1/''rows'' 2/''cols'' or 3/''both''')
            end

        case 'pval'
            if ~(isscalar(vali) && isreal(vali))
                error('Legend must be a real scalar')
            else
                if ismember(vali, [0 1])
                    INPUTS.PVAL = vali;
                else
                    error('PVAL must be 0 or 1')
                end
            end

        case 'b'
            if ~(isscalar(vali) && isreal(vali))
                error('B must be a real scalar')
            else
                if vali <= 0
                    error('B must be nonnegative')
                else
                    INPUTS.B = vali;
                end
            end

        otherwise

    end

    lArgin = lArgin(3:end);
    nlA = numel(lArgin);

end

%%%
% cross-tabulate
%%%

if gt(INPUTS.B, 0) && eq(INPUTS.PVAL, 0)
    % resolve the contradiction
    INPUTS.PVAL = 1;
end

X = crosstab(INPUTS.Y, INPUTS.C, 'B', INPUTS.B);
DATA = X.DATA.data;
switch INPUTS.Normalize
    case 0
    case 1
        DATA = 100*DATA./(kron(sum(DATA,1), ones(size(DATA,1),1)));
        X.DATA.data = DATA;
        X.DATA.fullname = ['Percent ' INPUTS.Y.fullname ' within levels of ' INPUTS.C.fullname];
    case 2
        DATA = 100*DATA./(kron(sum(DATA,2), ones(1,size(DATA,2))));
        X.DATA.data = DATA;
        X.DATA.fullname = ['Percent ' INPUTS.C.fullname ' within levels of ' INPUTS.Y.fullname];
    case 3
        DATA = 100*DATA/sum(DATA(:));
        X.DATA.data = DATA;
        X.DATA.fullname = ['Percent ' INPUTS.Y.fullname ' x ' INPUTS.C.fullname];
end

INPUTS.X = X;
if INPUTS.B > 0
    INPUTS.X.P = INPUTS.X.PPVAL;
else
    INPUTS.X.P = INPUTS.X.PVAL0;
end

%%%
% resolve PVP
%%%
NSTRATA = size(INPUTS.X.DATA, 2);
if isempty(INPUTS.PVP)
    pvp = ego('class', 'categoric', 'method', 'bar');
    INPUTS.PVP = mascara(NSTRATA, pvp);   
else
    INPUTS.PVP = mascara(NSTRATA, INPUTS.PVP);
end

% No need to display a legend if C is missing
if eq(numel(INPUTS.C.values), 1)
    INPUTS.PVP.Legend = 0;
end

end