classdef sage
    % SAGE sage obects contain a semiparametric apc analysis.
    %
    % SAGE is a two-step approach that denoises an observed rates object
    % using sift, and then fits the New APC Model to the smoothed rates.
    %
    % Estimable Functions (EFs) from SAGE are smoother than EFs from the
    % standard model. SAGE is especially valuable when cell counts are
    % modest.
    %
    % Other useful outputs from SAGE include lack-of-fit and summary
    % curves.
    %
    % See also sage/sage, sift, apc.

    properties

        R rates = rates; % input rates object
        G struct = struct; % age-period-cohort design matrix
        opts struct = struct('overdispersion', [], 'min_edf', [], 'max_edf', []); % a few options for tuning
        S sift = sift; % sift analysis
        B matrix = matrix; % beta coefficients
        D struct = struct; % decomposition of the rates into model components, lack-of-fit, and pure error

    end

    methods

        function A = sage(R, varargin)
            % SAGE Semiparametric age-period-cohort analysis.
            %
            % A = SAGE(R)
            % A = SAGE(R, P)
            % A = SAGE(R, P, opts)
            %
            % * R is a rates object
            %
            % * P is a panel of kernel operators for R
            %
            % * opts is a structure with fields
            %
            %   overdispersion - 1 (true, default) or 0 (false)
            %   min_edf        - smallest edf for sift (default 1)
            %   max_edf        - largest edf <= numel(R.Events) - 2 (default)
            %
            % SAGE is a two-step procedure:
            %
            %  (1) sift R using P and opts yielding S
            %  (2) fit the New APC Model to S yielding A
            %
            % NOTES:
            %
            % * fill zeros in R because SAGE sifts the log rates
            % * construct P with 'svd' equal to 1 (default)
            %
            % See also panko, sift, apc.

            if nargin == 0
                % Contents of an empty sage
                A.R = rates;
                A.G = struct;
                A.opts = struct('overdispersion', [], 'min_edf', [], 'max_edf', []);
                A.S = sift;
                A.B = matrix;
                A.D = struct;
                return
            end

            if isa(R, 'sage')
                A = varargin{1};
                return
            end

            % Contents of an empty sage object
            A.R = rates;
            A.G = struct;
            A.opts = struct('overdispersion', [], 'min_edf', [], 'max_edf', []);
            A.S = sift;
            A.D = struct;
            A.B = matrix;

            A.R = R;
            A.G = geode(A.R);

            % convert rates object R to analysis matrix M
            M = rates2matrix(A.R, 'scale', 'lr1');

            optsDefault = struct('overdispersion', 1, ...
                'min_edf', 1, ...
                'max_edf', numel(A.R.Events) - 2);

            switch nargin
                case 1
                    PK = panko('x', M.x, 'y', M.y, 'k', 3, 'k2', 3, 'shape', 'boxcar');
                    A.opts = optsDefault;
                case 2
                    PK = varargin{1};
                    A.opts = optsDefault;
                case 3
                    PK = varargin{1};
                    A.opts = varargin{2};
                otherwise
                    error('too many inputs')
            end

            if isempty(A.R)
                return
            end

            f = SAGE(M, A.R, PK, A.opts);
            A.S = f.S;
            A.B = f.B;
            A.D = f.D;

        end

        %%%
        % sage methods
        %%%

        function aic(A, varargin)
            % AIC Plot AIC values and Akaike weights from a SAGE analysis.
            %
            % AIC(A)
            % AIC(A, 'Threshold', value)
            %
            % * AIC from the embedded sift analysis.
            %
            % See also sift/aic.

            aic(A.S, varargin{:})
        end

        function varargout = ef(A, varargin)
            % EF Estimable Functions from sage analysis.
            %
            % F = EF(A, 'comp', <value>, 'RVals', <value>, 'Alpha', <value>, 'Plot', <value>)
            % [F, PVP] = EF(A, ...)
            %
            % F is a matrix. PVP contains the RVals.
            %
            % EFs for a sage model are identical to those for a standard apc model.
            %
            % See also apc/ef, plot.

            [F, PVP] = macaroons(A, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                case 2
                    varargout{1} = F;
                    varargout{2} = PVP;
                otherwise
                    error('too many outputs')
            end

        end

        %%%
        % Visualization
        %%%

        function thumbnail(A, varargin)
            % THUMBNAIL Thumbnail plots of a sage decomposition.
            %
            % THUMBNAIL(A)
            % THUMBNAIL(A, go(...))
            %
            % Panels:
            %
            % Obs, APC (Key), APC (HI-Ord), APC (Full), LOF, SAGE
            %
            % See also vistagram.

            THUMBNAIL(A, varargin{:})

        end

        function vistagram(A, varargin)
            % VISTAGRAM Surface plots of a sage decomposition.
            %
            % VISTAGRAM(A)
            % VISTAGRAM(A, go(...))
            %
            % Panels:
            %
            % Obs, APC (Key), APC (HI-Ord), APC (Full), LOF, SAGE
            %
            % See also depth, thumbnail.

            VISTAGRAM(A, varargin{:})

        end

        function varargout = plot(A, varargin)
            % PLOT Line plots of SAGE-based APC Estimable Functions.
            %
            % PLOT(A)
            % F = PLOT(A, 'RVals', <value>, 'Plot', <true or false>)
            %
            % PLOT produces a 2 x 3 array of EFs using preset go values:
            %
            %      (1,1) FTT, (1,2) FCP, (1,3) LD
            %      (2,1) LAC, (2,2) CAC, (2,3) GS
            %
            % 'RVals' - 3-vector age, period and cohort referent values
            % 'Plot'  - true or false
            %
            % * F contains the plotted functions in matrix objects.
            %
            % See also ef, deviations.

            F = leonardo(A, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                otherwise
                    error('too many outputs')
            end

        end


        function varargout = deviations(M, varargin)
            % DEVIATIONS Plot SAGE-based APC deviations.
            %
            % DEVIATIONS(M)
            % F = DEVIATIONS(M, 'Plot', <true or false>)
            %
            % DEVIATIONS produces a 1 x 3 array of deviations using preset go values:
            %
            %      (1,1) ad, ad2, adh (1,2) pd, pd2, pdh (1,3) cd, cd2, cdh
            %
            % 'Plot'  - true or false
            %
            % F contains six 3 sets of 3 ef for age, period, and cohort, respectively.
            %
            % See also ef, plot.

            F = tapioca(M, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                otherwise
                    error('too many outputs')
            end

        end


        function varargout = line(S, varargin)
            % LINE Summary curves from a SAGE object.
            %
            % LINE(S)
            % LINE(S, curve)
            % LINE(S, curve, go(...))
            % F = LINE(...)
            %
            % * Provides the same functionality as the rates/line method.
            %
            % See also sierra, rates/line, rates/sierra.

            Nl = numel(varargin);
            switch Nl
                case 0
                    curve = 'mpc';
                    PVP = [];
                case 1
                    curve = varargin{1};
                    PVP = [];
                case 2
                    curve = varargin{1};
                    PVP = varargin{2};
                otherwise
                    error('too many inputs')
            end

            F = paragon(S, curve, PVP);

            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                otherwise
                    error('too many outputs')
            end


        end

        function varargout = salsa(S, varargin)
            % SALSA StAndard pLots from SAge outputs.
            %
            % SALSA(S)
            % SALSA(S, StandardPlot)
            % SALSA(S, StandardPlot, BlockSize)
            % SALSA(S, StandardPlot, BlockSize, go(...))
            % T = SALSA(...)
            %
            % StandardPlot  - 'rpa' age-specific rates by period (default)
            %                 'rap' period-specific rates by age
            %                 'rac' age-specific rates by cohort
            %                 'rca' cohort-specific rates by age
            %
            % BlockSize     - number of age groups and calendar periods
            %                 to combine, scalar or 2-vector, [1 1] default
            %
            % * The y-axis scale is log with absolute-value labels
            %
            % See also ftp, go.

            T = SALSA(S, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = T;
                otherwise
                    error('too many outputs')
            end

        end


        function varargout = ftp(S, varargin)
            % FTP Four sTandard Plots of a SAGE object.
            %
            % FTP(S)
            % FTP(S, BlockSize)
            % FTP(S, BlockSize, go(...))
            % T = FTP(...)
            %
            % BlockSize  - number of age groups and calendar periods
            %              to combine, scalar or 2-vector, [1 1] default
            %
            % See also salsa, go.

            T = FTP(S, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = T;
                otherwise
                    error('too many outputs')
            end

        end

        function varargout = sierra(S, varargin)
            % SIERRA Plot summary curves and gradients of a sage object.
            %
            % SIERRA(S)
            % F = SIERRA(S, 'plot', <1 (default) or 0>)
            %
            % SIERRA generates a 2 x 3 array of graphs using preset go values:
            %
            %     (1,1) mpc/dmpc, (1,2) mcc/dmcc, (1,3) lpa
            %     (2,1) dac/ddac, (2,2) mac/dmac, (2,3) lap
            %
            % F is a cell array containing summary curves and gradients:
            %   * F{1}   mpc, dmpc
            %   * F{2}   mcc, dmcc
            %   * F{3}   lpa, dlpa
            %   * F{4}   dac, ddac
            %   * F{5}   mac, dmac
            %   * F{6}   lap, dlap
            %
            % See also scan.

            F = florence(S, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                otherwise
                    error('too many outputs')
            end
        end

        function varargout = scan(S)
            % SCAN Plot Summary Curves and estimAble fuNctions of a sage object.
            %
            % SCAN(S)
            % [EF, F] = SCAN(S)
            %
            % See also line, rates/scan, apc/scan.

            [EF, F] = kandinsky(S);

            switch nargout
                case 0
                case 1
                    varargout{1} = EF;
                case 2
                    varargout{1} = EF;
                    varargout{2} = F;
                otherwise
                    error('too many outputs')
            end

        end

    end

end


