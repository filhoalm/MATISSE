function f = SAGE(M, R, PK, opts)
% SAGE semiparametric age-period-cohort analysis.

f.G = geode(R);

f.S = sift(M, PK, opts);
[A, P] = size(R);
AP = A * P;
df = 6 + (A - 3) + (P - 3) + (A + P - 1 - 3);

%%%
% 29 March 2025: sift output is already adjusted for over-dispersion
% or not depending on user specification up front. No need to multiply
% covariance matrices by f.S.F.s2hat.
%%%

% OBS
%%%
nu_OBS = tbl('data', f.S.M.data.data, ...
    'fullname', 'OBS');
% no need to adjust variance for overdispersion
V_nu_OBS = f.S.M.COV;
OBS = matrix('data', nu_OBS, 'COV', V_nu_OBS, 'x', M.x, 'y', M.y);

%%%
% SAGE 
%%%
nu_HAT = tbl('data', f.S.F.TMA.data.data, ...
    'fullname', 'SAGE');
% no need to adjust variance for overdispersion
V_nu_HAT = f.S.F.TMA.COV;
SAGE = matrix('data', nu_HAT, 'COV', V_nu_HAT, 'x', M.x, 'y', M.y);

K = f.S.F.K;
IMK = speye(AP) - K;

%%%
% PE
%%%
pe = tbl('data', nu_OBS - nu_HAT, ...
    'fullname', 'Pure Error');
Vpe = IMK * V_nu_OBS * IMK';
PE = matrix('data', pe, 'COV', Vpe, 'x', M.x, 'y', M.y);

%%%
% beta coefficents
%%%
X = f.G.X;
Q = (X'*X)\X';
b = tbl('data', Q * nu_HAT.data(:), ...
    'fullname', 'coefficients');
V_b = Q * V_nu_HAT * Q';
f.B = matrix('data', b, 'COV', V_b);

%%%
% APC, fitted values from full APC
%%%
H = X*Q;
fv = tbl('data', reshape(H*nu_HAT.data(:), A, P), ...
    'fullname', 'APC (Full)');
V_fv = H * V_nu_HAT * H';
APC = matrix('data', fv, 'COV', V_fv, 'x', M.x, 'y', M.y);

% KEY, fittede values from key parameters only 
X6 = X(:, 1:6);
H6 = X6*((X6'*X6)\X6');
key = tbl('data', reshape(H6*nu_HAT.data(:), A, P), ...
    'fullname', 'APC (Key)');
V_key = H6 * V_nu_HAT * H6';
KEY = matrix('data', key, 'COV', V_key, 'x', M.x, 'y', M.y);

% HIO, contribution to FV from the higher-order parameters
Xhio = X(:, 7:df);
Hhio = Xhio*((Xhio'*Xhio)\Xhio');
hio = tbl('data', reshape(Hhio * nu_HAT.data(:), A, P), ...
    'fullname', 'APC (Hi-Ord)');
V_hio = Hhio * V_nu_HAT * Hhio';
HIO = matrix('data', hio, 'COV', V_hio, 'x', M.x, 'y', M.y);

% LOF
Xlof = speye(AP) - H;
lof = tbl('data', reshape(Xlof * nu_HAT.data(:), A, P), ...
    'fullname', 'LOF');
V_lof = Xlof * V_nu_HAT * Xlof';
LOF = matrix('data', lof, 'COV', V_lof, 'x', M.x, 'y', M.y);

f.D = struct(...
    'OBS', OBS, ...
    'SAGE', SAGE, ...
    'APC', APC, ...
    'KEY', KEY, ...
    'HIO', HIO, ...
    'LOF', LOF, ...
    'PE', PE);

end
