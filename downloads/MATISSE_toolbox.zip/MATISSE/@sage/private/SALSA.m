function Mplt = SALSA(S, varargin)
% SAGE/SALSA standard plots from a SAGE object.

%%%
% openers
%%%
if isempty(S.R)
    error('no data to plot')
end

%%%
% setup
%%%
Nl = numel(varargin);

switch Nl
    case 0
        StandardPlot = 'rpa';
        BlockSize = [1 1];
        PVP = [];
    case 1
        StandardPlot = varargin{1};
        BlockSize = [1 1];
        PVP = [];
    case 2
        StandardPlot = varargin{1};
        BlockSize = varargin{2};
        switch numel(BlockSize)
            case 1
                BlockSize = floor([BlockSize BlockSize]);
            case 2
                % good
            otherwise
                error('BlockSize must be a scalar or 2-vector')
        end
        PVP = [];
    case 3
        StandardPlot = varargin{1};
        BlockSize = varargin{2};
        switch numel(BlockSize)
            case 1
                BlockSize = floor([BlockSize BlockSize]);
            case 2
                % good
            otherwise
                error('BlockSize must be a scalar or 2-vector')
        end
        PVP = varargin{3};
    otherwise
        error('too many inputs')
end

if ~(ischar(StandardPlot) && ismember(StandardPlot, {'rpa', 'rap', 'rca', 'rac'}))
    error('invalid plot type')
end

if eq(BlockSize(1), BlockSize(2))
    SQUARE = 1;
else
    SQUARE = 0;
end

if ~SQUARE
    if strcmpi(StandardPlot, 'rca') || strcmpi(StandardPlot', 'rca')
        Mplt = [];
        disp('not done, age and period intervals must be equal')
        return
    end
end

%%%
% to block or not to block
%%%
TMP = S.S.F.TMA;
data = (TMP.data + log(S.R.offset_tick));
data.fullname = S.R.fullname;
TMP.data = data;
if (BlockSize(1) > 1 || BlockSize(2) > 1)
    M0 = blast(TMP, 'rb', BlockSize(1), 'cb', BlockSize(2), ...
        'RDir', 'LTF', 'CDir', 'LTF', 'fill', 1);
    % restore our metadata
    R0 = chunk(S.R, 'AgeBlock', BlockSize(1), 'PerBlock', BlockSize(2));
    TMP2 = M0.data;
    TMP2.row_labels = R0.age_labels;
    TMP2.col_labels = R0.per_labels;
    TMP2.fullname = R0.fullname;
    M0.data = TMP2;
    M0.y = R0.a;
    M0.x = R0.p;
else
    M0 = TMP;
    R0 = S.R;
end

pvp0 = ego('class', 'sage', 'method', 'salsa');

switch StandardPlot
    case 'rap'
        if isempty(PVP)
            PVP = pvp0;
        end
        Mplt = M0;
        if PVP.Plot
            plot(Mplt, PVP)
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))
        end

    case 'rpa'
        Mplt = M0';
        if isempty(PVP)
            PVP = pvp0;
            PVP.Width = 0.5;
        end
        if PVP.Plot
            plot(Mplt, PVP)
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

            if PVP.Legend
                h = findobj(gcf, 'Type', 'legend');
                set(h(1), 'Location', 'southeast', 'NumColumns', 2)
            end

        end

    case 'rac'
        Mplt = diagonals(M0);
        c = type(R0, 'comp', 'c');
        data = Mplt.data;
        data.col_labels = c.row_labels;
        data.labels = {'Age', 'Cohort'};
        Mplt.data = data;
        if isempty(PVP)
            PVP = pvp0;
        end
        if PVP.Plot
            plot(Mplt, PVP)
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))
        end

    case 'rca'
        TMP = diagonals(M0);
        c = type(R0, 'comp', 'c');
        Mplt = TMP';
        data = Mplt.data;
        data.row_labels = c.row_labels;
        data.labels = {'Cohort', 'Age'};
        Mplt.data = data;
        Mplt.y = c.data;

        if isempty(PVP)
            PVP = pvp0;
        end

        if PVP.Plot
            plot(Mplt, PVP)
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))
            if PVP.labels(1)
                xlabel('Cohort', 'FontSize', PVP.FontSize(1))
            end
            if PVP.labels(2)
                ylabel('Rate', 'FontSize', PVP.FontSize(2))
            end
        end

    otherwise
        error('unsupported graph type')
end

if PVP.Plot && PVP.labels(2)
    ylabel(S.R.chromacode, 'FontSize', PVP.FontSize(2))
end

end

