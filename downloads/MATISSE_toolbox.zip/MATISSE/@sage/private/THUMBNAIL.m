function THUMBNAIL(A, varargin)
% SAGE/THUMBNAIL thumbnail plots of SAGE decomposition

if eq(nargin, 1)
    PVP = ego('class', 'sage', 'method', 'thumbnail');
else
    PVP = varargin{1};
end

figure('Position', [180 180 1500 700])

m = mean(A.D.SAGE.data.data(:));

f0 = A.S.M.data.data - m;
f0 = tbl('data', f0, 'fullname', 'Obs');

f1 = A.D.KEY.data.data - m;
f1 = tbl('data', f1, 'fullname', 'APC (KEY)');

f2 = A.D.HIO.data.data;
f2 = tbl('data', f2, 'fullname', 'APC (HI-Ord)');

f3 = A.D.APC.data.data - m;
f3 = tbl('data', f3, 'fullname', 'APC (Full)');

f4 = A.D.LOF.data.data;
f4 = tbl('data', f4, 'fullname', 'LOF');

f5 = A.D.SAGE.data.data - m;
f5 = tbl('data', f5, 'fullname', 'SIFT');

f6 = A.D.PE.data.data;
f6 = tbl('data', f6, 'fullname', 'Pure Error');

thumbnail({f0, f1, f2, f3, f4, f5, f6}, PVP);

title(A.R.chromacode, 'FontSize', PVP.FontSize(3))
xlabel('(values are centered)')

