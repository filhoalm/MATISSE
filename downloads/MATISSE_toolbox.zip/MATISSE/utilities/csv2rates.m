function R = csv2rates(FILE)
% CSV2RATES Convert a CSV rates file to a rates object.
%
% R = CSV2RATES(FILE)
%
% The csv file named FILE includes header lines and paired columns of
% events and offsets by age (rows) and periods (columns). See 
% https://analysistools.nci.nih.gov/apc/help.html for details.
%
% See also rates2csv.

% this call to readmatrix will probably discard the header lines but - this
% is infuriating - sometimes it may not! After we figure out how many
% header lines there are, we can discard leading rows of NaNs if they exist

N = readmatrix(FILE);

% Defaults
StartYear = 0;
StartAge = 0;
fullname = 'Rates';
description = {};
AgeInterval = [];
PerInterval = [];
Interval = [];

% call to readcell will interogate the first six rows
T = readcell(FILE, 'Range', '1:6');
T = T(:, 1);

% Hopefully the meta-data fields start in column 1. But sometimes they do
% not. strfind returns the starting index of the key word if that is found,
% otherwise [].

HeaderLines = 0;
for t = 1:length(T)
    Tt = T{t};
    f = strfind(Tt, 'Title:');
    d = strfind(Tt, 'Description:');
    p = strfind(Tt, 'Start Year:');
    a = strfind(Tt, 'Start Age:');
    j = strfind(Tt, 'Age Bin (Years):');
    k = strfind(Tt, 'Period Bin (Years):');
    i = strfind(Tt, 'Interval (Years):');

    if f
        fullname = strtrim(Tt((f-1+7):end));
        HeaderLines = HeaderLines + 1;
    end
    
    if d
        description = {strrep(Tt((d-1+13):end), '"', '')};
        HeaderLines = HeaderLines + 1;
    end
    
    if p
        StartYear = floor(str2double(Tt((p-1+12):end)));
        HeaderLines = HeaderLines + 1;
    end
    
    if a
        StartAge = floor(str2double(Tt((a-1+11):end)));
        HeaderLines = HeaderLines + 1;
    end
    
    if j
        AgeInterval = str2double(Tt((j-1+17):end));
        HeaderLines = HeaderLines + 1;
    end
    
    if k
        PerInterval = str2double(Tt((k-1+20):end));
        HeaderLines = HeaderLines + 1;
    end
   
    if i
        Interval = str2double(Tt((i-1+18):end));
        HeaderLines = HeaderLines + 1;
    end

end


%%%
% Now that we know how many header lines we had, we need to see if the
% header lines were or were not omitted from N
%%%
hasJunk = all(isnan(N(1:HeaderLines, :)));

if hasJunk
    N = N(HeaderLines+1:end, :);
end

C = size(N, 2);
E = N(:, 1:2:C-1);
O = N(:, 2:2:C);
[A, P] = size(E);

if (isempty(AgeInterval) && isempty(PerInterval))
    R = rates(...
        'Events', E, ...
        'Offset', O, ...
        'fullname', fullname, ...
        'label', fullname, ...
        'description', description, ...
        'lexis', [StartAge StartYear Interval Interval]);

elseif ~isempty(AgeInterval) && ~isempty(PerInterval)

    ages = StartAge + AgeInterval.*(0:1:A);
    periods = StartYear + PerInterval.*(0:1:P);
    R = rates(...
        'Events', E, 'Offset', O, ...
        'fullname', fullname, ...
        'label', fullname, ...
        'description', description, ...
        'ages', ages, ...
        'periods', periods);

else

    error('specify both an age and a period interval')

end

end
