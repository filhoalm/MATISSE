function varargout = macaroons(M, varargin)
% MACAROONS EstiMAble funCtions from Age peRiod cOhOrt aNalySis.
%
% F = macaroons(M, ...
%      'Comp',  <value>, ...
%      'RVals', <value>, ...
%      'Alpha', <value>, ...
%      'Plot',  <false (default) or true>)
%
% [F, PVP, C] = macaroons(M, ...)
%
% * M is an apc or sage model.
% * F is a matrix object
% * PVP is a structure including a description of the RVals
%
% * structure C contains X, PtX, and lot s.t. F = X * M.B.data(PtX) + lot 
%
% see also apc/ef, apc/plot, sage/plot.

PVP = checkPVPAIRS(M, varargin{:});

R = M.R;
G = M.G;
log_offset_tick = log(R.offset_tick);

switch class(M)
    case 'apc'
        B = M.B.B;
        V = M.B.s2VAR;
        fn = R.chromacode;

        if PVP.Plot
            opts = go('Marker', 1, 'FaceAlpha', 0.10, 'EdgeAlpha', 0, ...
                'LineWidth', 1, 'Legend', 0, 'labels', [1 1 0], ...
                'Grid', 1, 'Width', 1);
        end

    case 'sage'
        B = M.B.data.data;
        V = M.B.COV;
        fn = M.R.chromacode;

        if PVP.Plot
            opts = go('Marker', 16, 'FaceAlpha', 0.10, 'EdgeAlpha', 0, ...
                'LineWidth', 2, 'Legend', 0, 'labels', [1 1 0], 'Grid', 1, 'Width', 1);
        end

    otherwise
        error('input must be an apc or sage model')
end

switch PVP.Comp

    %%%
    % Block 1: 'lac', 'cac', 'ftt', 'fcp', 'ld', 'gs'
    %%%

    case 'lac'

        J = ones(G.APC(1), 1);
        crefLOC = PVP.rVals(3);

        XA = G.X(G.INCa, [4, G.Pt{7}]);
        XCref = G.X(G.INCc(crefLOC), [6, G.Pt{9}]);

        astar = G.AGE.values';
        abar = mean(astar);

        cref = G.COH.values(crefLOC);
        cbar = mean(G.COH.values);

        X = [J (astar - abar) J*(cref - cbar) XA J*XCref];

        PtX = [1, 2, 3, 4, G.Pt{7}, 6, G.Pt{9}]';

        y = G.AGE.values(:);
        l = G.AGE.labels;
        rll = 'Age';
        cll = ['LAC (' num2str(cref) ')'];

        lot = log_offset_tick;
        opts.LineColor = 9;

    case 'cac'

        J = ones(G.APC(1), 1);
        prefLOC = PVP.rVals(2);

        XA = G.X(G.INCa, [4, G.Pt{7}]);
        XPref = G.X(G.INCp(prefLOC), [5, G.Pt{8}]);

        astar = G.AGE.values';
        abar = mean(astar);

        pref = G.PER.values(prefLOC);
        pbar = mean(G.PER.values);

        X = [J (astar - abar) (J*(pref - pbar) -1*(astar - abar)) XA J*XPref];

        PtX = [1, 2, 3, 4, G.Pt{7}, 5, G.Pt{8}]';

        y = G.AGE.values(:);
        l = G.AGE.labels;
        rll = 'Age';
        cll = ['CAC (' num2str(pref) ')'];

        lot = log_offset_tick;
        opts.LineColor = 7;

    case 'ftt'

        J = ones(G.APC(2), 1);
        arefLOC = PVP.rVals(1);

        XP = G.X(G.INCp, [5, G.Pt{8}]);
        XAref = G.X(G.INCa(arefLOC), [4, G.Pt{7}]);

        pstar = G.PER.values';
        pbar = mean(pstar);

        aref = G.AGE.values(arefLOC);
        abar = mean(G.AGE.values);

        X = [J J*(aref - abar) ((pstar - pbar) - J*(aref - abar)) XP J*XAref];

        PtX = [1, 2, 3, 5, G.Pt{8}, 4, G.Pt{7}]';

        y = G.PER.values(:);
        l = G.PER.labels;
        rll = 'Period';
        cll = ['FTT (' num2str(aref) ')'];

        lot = log_offset_tick;
        opts.LineColor = 1;

    case 'fcp'

        J = ones(G.APC(3), 1);
        arefLOC = PVP.rVals(1);

        XC = G.X(G.INCc, [6, G.Pt{9}]);
        XAref = G.X(G.INCa(arefLOC), [4, G.Pt{7}]);

        cstar = G.COH.values';
        cbar = mean(cstar);

        aref = G.AGE.values(arefLOC);
        abar = mean(G.AGE.values);

        X = [J J*(aref - abar) (cstar - cbar) XC J*XAref];

        PtX = [1, 2, 3, 6, G.Pt{9}, 4, G.Pt{7}]';

        y = G.COH.values(:);
        l = G.COH.labels;
        rll = 'Cohort';
        cll = ['FCP (' num2str(aref) ')'];

        lot = log_offset_tick;
        opts.LineColor = 10;

    case 'ld'

        A = G.APC(1);
        P = G.APC(2);
        C = G.APC(3);

        DELTA = G.AGE.values(2) - G.AGE.values(1);

        XC = G.X(G.INCc, [6, G.Pt{9}]);

        % contrast matrix to extract slopes of cohort deviations using a
        % sliding window with bandwidth P.
        JP = ones(P, 1);
        SP = (1:P)';
        pbars = (P+1)/2;
        DP = (12/(DELTA*(P-1)*P*(P+1)))*(SP - pbars*JP)';
        KAC = zeros(A, C);
        for ag = 1:A
            % starting at the first age group, you have the most recent set
            % of P cohorts
            i0 = 1+A-ag;
            i1 = 1+A-ag+P-1;
            KAC(ag, i0:i1) = DP;
        end

        JA = ones(A, 1);
        X = [KAC*XC JA];
        PtX = [6, G.Pt{9}, 3];

        y = G.AGE.values(:);
        l = G.AGE.labels;
        rll = 'Age';
        cll = 'Local Drifts';

        lot = 0;
        opts.LineColor = 12;

    case 'gs'

        DELTA = G.PER.values(2) - G.PER.values(1);
        A = G.APC(1);
        P = G.APC(2);
        C = G.APC(3);
        JA = ones(A, 1);
        SA = (1:A)';
        abars = (A+1)/2;

        DA = (12/(DELTA*(A-1)*A*(A+1)))*(SA - abars*JA)';

        KPC = NaN(P, C);
        for pk = 1:P
            for ck = 1:C
                if ck >= 1 && ck < pk
                    KPC(pk, ck) = 0;
                elseif ck >= pk && ck <= pk+A-1
                    % Values are loaded in sequence {A, A-1, ..., 1}
                    KPC(pk, ck) = -DA(pk-ck+A);
                else
                    KPC(pk, ck) = 0;
                end
            end
        end

        JP = ones(P, 1);
        XC = G.X(G.INCc, [6, G.Pt{9}]);

        X = [-KPC*XC JP -JP];
        PtX = [6, G.Pt{9}, 2, 3];

        y = G.PER.values(:);
        l = G.PER.labels;
        rll = 'Period';
        cll = 'Gradient Shifts';

        lot = 0;
        opts.LineColor = 23;

        %%%
        % Block 2: 'lac2', 'cac2', 'ftt2', 'fcp2', 'ld2', 'gs2'
        %%%

    case 'lac2'

        J = ones(G.APC(1), 1);
        crefLOC = PVP.rVals(3);

        XA = G.X(G.INCa, 4);
        XCref = G.X(G.INCc(crefLOC), [6, G.Pt{9}]);

        astar = G.AGE.values';
        abar = mean(astar);

        cref = G.COH.values(crefLOC);
        cbar = mean(G.COH.values);

        X = [J (astar - abar) J*(cref - cbar) XA J*XCref];

        PtX = [1, 2, 3, 4, 6, G.Pt{9}]';

        y = G.AGE.values(:);
        l = G.AGE.labels;
        rll = 'Age';
        cll = ['LAC (' num2str(cref) ')'];

        lot = log_offset_tick;
        opts.LineColor = 9;
        opts.Marker = {'none'};

    case 'cac2'

        J = ones(G.APC(1), 1);
        prefLOC = PVP.rVals(2);

        XA = G.X(G.INCa, 4);
        XPref = G.X(G.INCp(prefLOC), [5, G.Pt{8}]);

        astar = G.AGE.values';
        abar = mean(astar);

        pref = G.PER.values(prefLOC);
        pbar = mean(G.PER.values);

        X = [J (astar - abar) (J*(pref - pbar) -1*(astar - abar)) XA J*XPref];

        PtX = [1, 2, 3, 4, 5, G.Pt{8}]';

        y = G.AGE.values(:);
        l = G.AGE.labels;
        rll = 'Age';
        cll = ['CAC (' num2str(pref) ')'];

        lot = log_offset_tick;
        opts.LineColor = 7;
        opts.Marker = {'none'};

    case 'ftt2'

        J = ones(G.APC(2), 1);
        arefLOC = PVP.rVals(1);

        XP = G.X(G.INCp, 5);
        XAref = G.X(G.INCa(arefLOC), [4, G.Pt{7}]);

        pstar = G.PER.values';
        pbar = mean(pstar);

        aref = G.AGE.values(arefLOC);
        abar = mean(G.AGE.values);

        X = [J J*(aref - abar) ((pstar - pbar) - J*(aref - abar)) XP J*XAref];

        PtX = [1, 2, 3, 5, 4, G.Pt{7}]';

        y = G.PER.values(:);
        l = G.PER.labels;
        rll = 'Period';
        cll = ['FTT (' num2str(aref) ')'];

        lot = log_offset_tick;
        opts.LineColor = 1;
        opts.Marker = {'none'};

    case 'fcp2'

        J = ones(G.APC(3), 1);
        arefLOC = PVP.rVals(1);

        XC = G.X(G.INCc, 6);
        XAref = G.X(G.INCa(arefLOC), [4, G.Pt{7}]);

        cstar = G.COH.values';
        cbar = mean(cstar);

        aref = G.AGE.values(arefLOC);
        abar = mean(G.AGE.values);

        X = [J J*(aref - abar) (cstar - cbar) XC J*XAref];

        PtX = [1, 2, 3, 6, 4, G.Pt{7}]';

        y = G.COH.values(:);
        l = G.COH.labels;
        rll = 'Cohort';
        cll = ['FCP (' num2str(aref) ')'];

        lot = log_offset_tick;
        opts.LineColor = 10;
        opts.Marker = {'none'};

    case 'ld2'

        A = G.APC(1);
        P = G.APC(2);
        C = G.APC(3);

        DELTA = G.AGE.values(2) - G.AGE.values(1);

        XC = G.X(G.INCc, 6);

        % contrast matrix to extract slopes of cohort deviations using a
        % sliding window with bandwidth P.
        JP = ones(P, 1);
        SP = (1:P)';
        pbars = (P+1)/2;
        DP = (12/(DELTA*(P-1)*P*(P+1)))*(SP - pbars*JP)';
        KAC = zeros(A, C);
        for ag = 1:A
            % starting at the first age group, you have the most recent set
            % of P cohorts
            i0 = 1+A-ag;
            i1 = 1+A-ag+P-1;
            KAC(ag, i0:i1) = DP;
        end

        JA = ones(A, 1);
        X = [KAC*XC JA];
        PtX = [6, 3];

        y = G.AGE.values(:);
        l = G.AGE.labels;
        rll = 'Age';
        cll = 'Local Drifts';

        lot = 0;
        opts.LineColor = 12;
        opts.Marker = {'none'};

    case 'gs2'

        DELTA = G.PER.values(2) - G.PER.values(1);
        A = G.APC(1);
        P = G.APC(2);
        C = G.APC(3);
        JA = ones(A, 1);
        SA = (1:A)';
        abars = (A+1)/2;

        DA = (12/(DELTA*(A-1)*A*(A+1)))*(SA - abars*JA)';

        KPC = NaN(P, C);
        for pk = 1:P
            for ck = 1:C
                if ck >= 1 && ck < pk
                    KPC(pk, ck) = 0;
                elseif ck >= pk && ck <= pk+A-1
                    % Values are loaded in sequence {A, A-1, ..., 1}
                    KPC(pk, ck) = -DA(pk-ck+A);
                else
                    KPC(pk, ck) = 0;
                end
            end
        end

        JP = ones(P, 1);
        XC = G.X(G.INCc, 6);

        X = [-KPC*XC JP -JP];
        PtX = [6, 2, 3];

        y = G.PER.values(:);
        l = G.PER.labels;
        rll = 'Period';
        cll = 'Gradient Shifts';

        lot = 0;
        opts.LineColor = 23;
        opts.Marker = {'none'};

        %%%
        % Block 3: 'ad', 'ad2', 'adh', 'pd', 'pd2', 'pdh', 'cd', 'cd2', 'cdh'
        %%%

    case 'ad'

        PtX = [G.Pt{4}, G.Pt{7}]';
        X = G.X(G.INCa, PtX);

        y = G.AGE.values(:);
        l = G.AGE.labels;
        rll = 'Age';
        cll = 'Age Deviations';

        lot = 0;
        opts.LineColor = 9;

    case 'ad2'
        PtX = [G.Pt{4}]';
        X = G.X(G.INCa, PtX);

        y = G.AGE.values(:);
        l = G.AGE.labels;
        rll = 'Age';
        cll = 'Quadratic Age Deviations';

        lot = 0;
        opts.LineColor = 9;
        opts.Marker = {'none'};

    case 'adh'

        PtX = [G.Pt{7}]';
        X = G.X(G.INCa, PtX);

        y = G.AGE.values(:);
        l = G.AGE.labels;
        rll = 'Age';
        cll = 'Hi-Ord Age Deviations';

        lot = 0;
        opts.LineColor = 9;

    case 'pd'

        PtX = [G.Pt{5}, G.Pt{8}]';
        X = G.X(G.INCp, PtX);

        y = G.PER.values(:);
        l = G.PER.labels;
        rll = 'Period';
        cll = 'Period Deviations';

        lot = 0;
        opts.LineColor = 9;


    case 'pd2'

        PtX = [G.Pt{5}]';
        X = G.X(G.INCp, PtX);

        y = G.PER.values(:);
        l = G.PER.labels;
        rll = 'Period';
        cll = 'Quadratic Period Deviations';

        lot = 0;
        opts.LineColor = 1;
        opts.Marker = {'none'};

    case 'pdh'

        PtX = [G.Pt{8}]';
        X = G.X(G.INCp, PtX);

        y = G.PER.values(:);
        l = G.PER.labels;
        rll = 'Period';
        cll = 'Hi-Ord Period Deviations';

        lot = 0;
        opts.LineColor = 1;

    case 'cd'

        PtX = [G.Pt{6}, G.Pt{9}]';
        X = G.X(G.INCc, PtX);

        y = G.COH.values(:);
        l = G.COH.labels;
        rll = 'Cohort';
        cll = 'Cohort Deviations';

        lot = 0;
        opts.LineColor = 10;

    case 'cd2'

        PtX = [G.Pt{6}]';
        X = G.X(G.INCc, PtX);

        y = G.COH.values(:);
        l = G.COH.labels;
        rll = 'Cohort';
        cll = 'Quadratic Cohort Deviations';

        lot = 0;
        opts.LineColor = 10;
        opts.Marker = 16;
        opts.Marker = {'none'};

    case 'cdh'

        PtX = [G.Pt{9}]';
        X = G.X(G.INCc, PtX);

        y = G.COH.values(:);
        l = G.COH.labels;
        rll = 'Cohort';
        cll = 'Hi-Ord Cohort Deviations';

        lot = 0;
        opts.LineColor = 10;

        %%%
        % Block 4: crr, prr, xarr, larr
        %%%

    case 'crr'

        C = G.APC(3);
        crefLOC = PVP.rVals(3);
        TMP = zeros(C, C);
        TMP(:, crefLOC) = 1;
        CRR = eye(C) - TMP;
        PtX = [3 6 G.Pt{9}];
        X = CRR*G.X(G.INCc, PtX);

        y = G.COH.values(:);
        cref = y(crefLOC);
        l = G.COH.labels;
        rll = 'Cohort';
        cll = ['CRR (' num2str(cref) ')'];

        lot = 0;
        opts.LineColor = 10;

    case 'prr'

        P = G.APC(2);
        prefLOC = PVP.rVals(2);
        TMP = zeros(P, P);
        TMP(:, prefLOC) = 1;
        PRR = eye(P) - TMP;
        PtX = [3 5 G.Pt{8}];
        X = PRR*G.X(G.INCp, PtX);

        y = G.PER.values(:);
        pref = y(prefLOC);
        l = G.PER.labels;
        rll = 'Period';
        cll = ['PRR (' num2str(pref) ')'];

        lot = 0;
        opts.LineColor = 1;

    case 'xarr'

        A = G.APC(1);
        arefLOC = PVP.rVals(1);
        TMP = zeros(A, A);
        TMP(:, arefLOC) = 1;
        ARR = eye(A) - TMP;
        PtX = [1, 2, 3, 4, G.Pt{7}, 5, G.Pt{8}]';
        X = ARR*G.X(G.INCa, PtX);
        y = G.AGE.values(:);
        aref = y(arefLOC);
        l = G.AGE.labels;
        rll = 'Age';
        cll = ['XARR (' num2str(aref) ')'];

        lot = 0;
        opts.LineColor = 7;

    case 'larr'

        A = G.APC(1);
        J = ones(A, 1);
        arefLOC = PVP.rVals(1);
        crefLOC = PVP.rVals(3);
      
        XA = G.X(G.INCa, [4, G.Pt{7}]);
        XCref = G.X(G.INCc(crefLOC), [6, G.Pt{9}]);

        astar = G.AGE.values';
        abar = mean(astar);

        cref = G.COH.values(crefLOC);
        cbar = mean(G.COH.values);

        Xlac = [J (astar - abar) J*(cref - cbar) XA J*XCref];
        TMP = zeros(A, A);
        TMP(:, arefLOC) = 1;
        ARR = eye(A) - TMP;
        PtX = [1, 2, 3, 4, G.Pt{7}, 6, G.Pt{9}]';
        X = ARR * Xlac;
        y = G.AGE.values(:);
        aref = y(arefLOC);
        l = G.AGE.labels;
        rll = 'Age';
        cll = ['LARR (' num2str(aref) ')'];
        lot = 0;
        opts.LineColor = 9;

        %%%
        % Block 5: key parameters
        %%%

    case 'key'
        X = [...
            1  0  0  0  0  0;...   % Intercept
            0  1  0  0  0  0;...   % LAT
            0  0  1  0  0  0;...   % NetDrift
            0  1 -1  0  0  0;...   % CAT
            0  0  0  1  0  0;...   % THETAa
            0  0  0  0  1  0;...   % THETAp
            0  0  0  0  0  1];     % THETAc

        PtX = 1:6;
        y = (1:7)';
        l = {'Intercept', 'LAT', 'NetDrift', 'CAT', 'THETAa', 'THETAp', 'THETAc'};
        rll = 'Key Parameters';
        cll = 'Coefficient';
        lot = 0;
        opts.LineColor = [12 9 1 7 9 1 10];

        %%%
        % Block 6: 'mpc', 'mac'
        %%%

    case 'mpc'

        pstar = G.PER.values(:);
        pbar = mean(pstar);
        A = G.APC(1);
        P = G.APC(2);
        C = G.APC(3);

        XPQ = G.X(G.INCp, 5);
        XPD = G.X(G.INCp, G.Pt{8});
        XCD = G.X(G.INCc, G.Pt{9});

        %%%
        % 'slider' S(1/A * J_A, C)
        % apply to C-vector of high-order cohort deviations
        % pieces of the operator
        % T(C, C-A+1) = T(C, P)
        % J_(C-A)
        % w = (1/A) * ones(A, 1)
        % O_(C-A+1) = O(P, 1)
        %%%%

        TM = TransposeMatrix(C, P);
        J = ones(C-A, 1);
        W = (1/A) * ones(A, 1);
        O = zeros(P, 1);
        TMP1 = [kron(J, [W; O]); W];
        TMP2 = reshape(TMP1, C, P);
        TMP3 = TM * TMP2(:);
        SLIDER = reshape(TMP3, P, C);

        PtX = [1, 3, 5, 6, G.Pt{8}, G.Pt{9}]';
        X = [ones(P, 1) (pstar - pbar) XPQ XPQ XPD SLIDER * XCD];

        y = G.PER.values(:);
        l = G.PER.labels;
        rll = 'Period';
        cll = 'MPC';

        lot = log_offset_tick;
        opts.LineColor = 1;

    case 'mac'

        astar = G.AGE.values(:);
        abar = mean(astar);
        A = G.APC(1);
        P = G.APC(2);
        C = G.APC(3);

        XAQ = G.X(G.INCa, 4);
        XAD = G.X(G.INCa, G.Pt{7});
        XCD = G.X(G.INCc, G.Pt{9});

        %%%
        % 'slider' S(1/P * J_P, C)
        % 'exchange matrix E(C)
        % apply to C-vector of high-order cohort deviations
        % pieces of the operator
        % T(C, C-P+1) = T(C, A)
        % J_(C-P)
        % w = (1/P) * ones(P, 1)
        % O_(C-P+1) = O(A, 1)
        %%%%
        EC = eye(C);
        EC = EC(C:-1:1, :);
        TM = TransposeMatrix(C, A);
        J = ones(C-P, 1);
        W = (1/P) * ones(P, 1);
        O = zeros(A, 1);
        TMP1 = [kron(J, [W; O]); W];
        TMP2 = reshape(TMP1, C, A);
        TMP3 = TM * TMP2(:);
        SLIDER = reshape(TMP3, A, C);

        X = [ones(A, 1) (astar - abar) -1*(astar - abar) XAQ XAQ XAD SLIDER * EC * XCD];

        PtX = [1, 2, 3, 4, 6, G.Pt{7}, G.Pt{9}]';

        y = G.AGE.values(:);
        l = G.AGE.labels;
        rll = 'Age';
        cll = 'MAC';

        lot = log_offset_tick;
        opts.LineColor = 7;

        %%%
        % Block 7: 'dlac', 'dcac', 'dftt', 'dfcp', 'dmpc', 'dmac'
        %%%

    case 'dlac'

        A = G.APC(1);
        DELTA = G.AGE.values(2) - G.AGE.values(1);
        % Gradient Operator
        dA = (1/DELTA)*[eye(A-1), zeros(A-1, 1)]* ...
            ( diag(-1*ones(A, 1)) + diag(ones(A-1, 1), 1) );

        XA = G.X(G.INCa, G.Pt{7});

        dJ = ones(A - 1, 1);
        astar0 = G.AGE.values(2:A)';
        abar0 = mean(astar0);
        X = [dJ 2*(astar0 - abar0) dA*XA ];

        PtX = [2, 4, G.Pt{7}]';

        y = astar0;
        l = G.AGE.labels(2:A);
        rll = 'Age';
        cll = 'dLAC';

        lot = 0;
        opts.LineColor = 12;
        opts.LineWidth = 1;
        opts.Marker = {'none'};

    case 'dcac'

        A = G.APC(1);
        DELTA = G.AGE.values(2) - G.AGE.values(1);
        % Gradient Operator
        dA = (1/DELTA)*[eye(A-1), zeros(A-1, 1)]* ...
            ( diag(-1*ones(A, 1)) + diag(ones(A-1, 1), 1) );

        XA = G.X(G.INCa, G.Pt{7});

        dJ = ones(A - 1, 1);
        astar0 = G.AGE.values(2:A)';
        abar0 = mean(astar0);
        X = [dJ -dJ 2*(astar0 - abar0) dA*XA ];

        PtX = [2, 3, 4, G.Pt{7}]';

        y = astar0;
        l = G.AGE.labels(2:A);
        rll = 'Age';
        cll = 'dCAC';

        lot = 0;
        opts.LineColor = 12;
        opts.LineWidth = 1;
        opts.Marker = {'none'};

    case 'dftt'

        P = G.APC(2);
        DELTA = G.PER.values(2) - G.PER.values(1);
        % Gradient Operator
        dP = (1/DELTA)*[eye(P-1), zeros(P-1, 1)]* ...
            ( diag(-1*ones(P, 1)) + diag(ones(P-1, 1), 1) );

        XP = G.X(G.INCp, G.Pt{8});

        dJ = ones(P - 1, 1);
        pstar0 = G.PER.values(2:P)';
        pbar0 = mean(pstar0);
        X = [dJ 2*(pstar0 - pbar0) dP*XP ];

        PtX = [3, 5, G.Pt{8}]';

        y = pstar0;
        l = G.PER.labels(2:P);
        rll = 'Period';
        cll = 'dFTT';

        lot = 0;
        opts.LineColor = 12;
        opts.LineWidth = 1;
        opts.Marker = {'none'};

    case 'dfcp'

        C = G.APC(3);
        DELTA = G.COH.values(2) - G.COH.values(1);
        % Gradient Operator
        dC = (1/DELTA)*[eye(C-1), zeros(C-1, 1)]* ...
            ( diag(-1*ones(C, 1)) + diag(ones(C-1, 1), 1) );

        XC = G.X(G.INCc, G.Pt{9});

        dJ = ones(C - 1, 1);
        cstar0 = G.COH.values(2:C)';
        cbar0 = mean(cstar0);
        X = [dJ 2*(cstar0 - cbar0) dC*XC ];

        PtX = [3, 6, G.Pt{9}]';

        y = cstar0;
        l = G.COH.labels(2:C);
        rll = 'Cohort';
        cll = 'dFCP';

        lot = 0;
        opts.LineColor = 12;
        opts.LineWidth = 1;
        opts.Marker = {'none'};

    case 'dmpc'

        A = G.APC(1);
        P = G.APC(2);
        C = G.APC(3);
        DELTA = G.PER.values(2) - G.PER.values(1);

        XPD = G.X(G.INCp, G.Pt{8});
        XCD = G.X(G.INCc, G.Pt{9});

        %%%
        % 'slider' S(1/A * J_A, C)
        % apply to C-vector of high-order cohort deviations
        % pieces of the operator
        % T(C, C-A+1) = T(C, P)
        % J_(C-A)
        % w = (1/A) * ones(A, 1)
        % O_(C-A+1) = O(P, 1)
        %%%%

        TM = TransposeMatrix(C, P);
        J = ones(C-A, 1);
        W = (1/A) * ones(A, 1);
        O = zeros(P, 1);
        TMP1 = [kron(J, [W; O]); W];
        TMP2 = reshape(TMP1, C, P);
        TMP3 = TM * TMP2(:);
        SLIDER = reshape(TMP3, P, C);

        % Gradient Operator
        dP = (1/DELTA)*[eye(P-1), zeros(P-1, 1)]* ...
            ( diag(-1*ones(P, 1)) + diag(ones(P-1, 1), 1) );

        dJ = ones(P-1, 1);
        pstar0 = G.PER.values(2:P)';
        pbar0 = mean(pstar0);

        X = [dJ 2*(pstar0 - pbar0) 2*(pstar0 - pbar0) dP * XPD dP * SLIDER * XCD];
        PtX = [3, 5, 6, G.Pt{8}, G.Pt{9}]';

        y = G.PER.values(2:P)';
        l = G.PER.labels(2:P);
        rll = 'Period';
        cll = 'dMPC';

        lot = 0;
        opts.LineColor = 12;
        opts.LineWidth = 1;
        opts.Marker = {'none'};

    case 'dmac'

        A = G.APC(1);
        P = G.APC(2);
        C = G.APC(3);
        DELTA = G.AGE.values(2) - G.AGE.values(1);

        XAD = G.X(G.INCa, G.Pt{7});
        XCD = G.X(G.INCc, G.Pt{9});

        %%%
        % 'slider' S(1/P * J_P, C)
        % 'exchange matrix E(C)
        % apply to C-vector of high-order cohort deviations
        % pieces of the operator
        % T(C, C-P+1) = T(C, A)
        % J_(C-P)
        % w = (1/P) * ones(P, 1)
        % O_(C-P+1) = O(A, 1)
        %%%%
        EC = eye(C);
        EC = EC(C:-1:1, :);
        TM = TransposeMatrix(C, A);
        J = ones(C-P, 1);
        W = (1/P) * ones(P, 1);
        O = zeros(A, 1);
        TMP1 = [kron(J, [W; O]); W];
        TMP2 = reshape(TMP1, C, A);
        TMP3 = TM * TMP2(:);
        SLIDER = reshape(TMP3, A, C);

        % Gradient Operator
        dA = (1/DELTA)*[eye(A-1), zeros(A-1, 1)]* ...
            ( diag(-1*ones(A, 1)) + diag(ones(A-1, 1), 1) );

        dJ = ones(A-1, 1);
        astar0 = G.AGE.values(2:A)';
        abar0 = mean(astar0);

        X = [dJ -dJ 2*(astar0 - abar0) 2*(astar0 - abar0) dA * XAD dA * SLIDER * EC * XCD];
        PtX = [2, 3, 4, 6, G.Pt{7}, G.Pt{9}]';

        y = G.AGE.values(2:A)';
        l = G.AGE.labels(2:A);
        rll = 'Age';
        cll = 'dMAC';

        lot = 0;
        opts.LineColor = 12;
        opts.LineWidth = 1;
        opts.Marker = {'none'};

    otherwise

end

%%%
% Build the EF
%%%

ef = lot + X * B(PtX);
% Annotate
T_ef = tbl(...
    'data', ef, ...
    'fullname', R.fullname, ...
    'labels', {rll, cll}, ...
    'row_labels', l, ...
    'col_labels', {fn});

% Delta method variance
V_ef = X * V(PtX, PtX) * X';

F = matrix(...
    'data', T_ef, ...
    'x', 1, ...
    'y', y, ...
    'COV', V_ef, ...
    'Alpha', PVP.Alpha);

if PVP.Plot

    %%%
    % choice of scaling
    %%%
    switch PVP.Comp
        case {'ld', 'gs', 'ld2', 'gs2', 'dftt', ...
                'dlac', 'dfcp', 'dmpc', 'dmac', 'dcac'}

            F = pc(F);
            plot(F, opts)
            ax = gca;
            ax.YAxis(end).TickLabelFormat = '%g\%';
            ax.YColor = [0 0 0];

        otherwise

            plot(F, opts)
    end


end

switch nargout
    case 0
    case 1
        varargout{1} = F;
    case 2
        varargout{1} = F;
        varargout{2} = PVP;
    case 3
        varargout{1} = F;
        varargout{2} = PVP;
        varargout{3} = struct('X', X, 'PtX', PtX, 'lot', lot);
    otherwise
        error('too many outputs')
end

end

%%%%%%%

function PVP = checkPVPAIRS(M, varargin)
% Helper function. Supply validated inputs to main procedure.

% default values
PVP = struct(...
    'Comp', 'ld', ...
    'Alpha', 0.05, ...
    'RVals', [], ...
    'rVals', [], ...
    'Default_RVals', 1, ...
    'Plot', 0);

lArgin = varargin(1:end);
Nl = numel(lArgin);
while Nl >= 1
    if Nl == 1
        error('The last property has no matching value.');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('A property must be specified using a string.')
    end
    switch lower(propi)

        case 'comp'
            if ~ischar(vali)
                error('unrecognized component')
            end
            if size(vali, 1)>1
                error('component must be a string')
            end

            % supported components
            vals = {...
                'lac', 'cac', 'ftt', 'fcp', 'ld', 'gs', ...       % 'Block 1'
                'lac2', 'cac2', 'ftt2', 'fcp2', 'ld2', 'gs2', ... % 'Block 2'
                'ad', 'ad2', 'adh', 'pd', 'pd2', 'pdh', ...       % 'Block 3'
                'cd', 'cd2', 'cdh', ...
                'crr', 'prr', 'xarr', 'larr', ...                 % 'Block 4'
                'key', ...                                        % 'Block 5'
                'mpc', 'mac', ...                                 % 'Block 6'
                'dlac', 'dcac', 'dftt', 'dfcp', 'dmpc', 'dmac'};  % 'Block 7'

            I = strcmpi(vali, vals);
            if ~any(I)
                error([vali ' is an unrecognized component'])
            end
            PVP.Comp = lower(vali);

        case 'rvals'
            RVals = vali;
            if ~(isreal(RVals) && isnumeric(RVals))
                error('RVals must be numeric.');
            end
            % rule of 3
            if length(RVals)~=3
                error('You must specify a 3-vector of reference values for age, period, and cohort.');
            end
            PVP.RVals = RVals;

        case 'alpha'
            if ~(isscalar(vali) && isreal(vali))
                error('Alpha must be a real scalar')
            elseif (vali < 0 || vali > 1)
                error('Alpha must lie between 0 and 1')
            else
                PVP.Alpha = vali;
            end

        case 'plot'
            if ~(isscalar(vali) && isnumeric(vali))
                error('Plot must be a real scalar')
            else
                if ismember(vali, [0 1])
                    PVP.Plot = vali;
                else
                    error('Plot must be 0 or 1')
                end
            end


    end
end

if isempty(PVP.RVals) % DEFAULT

    A = M.G.APC(1);
    P = M.G.APC(2);
    % Floor function insures reference values occur in AGE, PER, and COH.
    aREF = floor((A+1)/2);
    pREF = floor((P+1)/2);
    cREF = pREF - aREF + A;
    ageref = M.G.AGE.values(aREF);
    perref = M.G.PER.values(pREF);
    cohref = M.G.COH.values(cREF);
    PVP.RVals = [ageref perref cohref];
    PVP.rVals = [aREF, pREF, cREF];

    PVP.Default_RVals = 1;

else

    [TA, aREF] = ismember(PVP.RVals(1), M.G.AGE.values);

    [TB, pREF] = ismember(PVP.RVals(2), M.G.PER.values);

    [TC, cREF] = ismember(PVP.RVals(3), M.G.COH.values);

    if TA && TB && TC

        PVP.rVals = [aREF, pREF, cREF];
        PVP.Default_RVals = 0;

    else

        msg1 = '';
        msg2 = '';
        msg3 = '';
        if ~TA
            msg1 = 'Invalid referent age. ';
        end
        if ~TB
            msg2 = 'Invalid referent period. ';
        end
        if ~TC
            msg3 = 'Invalid referent cohort. ';
        end
        error([msg1, msg2, msg3])

    end
end

end


