function RANGE = excela1(ROW1, COL1, ROW2, COL2)
% EXCELA1 Express a numeric range in Excel 'A1' notation.
%
% RANGE = excela1(ROW1, COL1, ROW2, COL2)
%
% RANGE is the string expression describing the location of cells from
% (ROW1, COL1) through (ROW2, COL2).

c1 = excelcol(COL1);
c2 = excelcol(COL2);

RANGE = [c1 num2str(ROW1, '%5.0f') ':' c2 num2str(ROW2,'%5.0f')];

%%%%

function c = excelcol(COL)
% Helper function. Excel 'A1' notation for column COL. 

a = cellstr(char('A', 'B', 'C', 'D', 'E', 'F', ...
    'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', ...
    'P', 'Q', 'R', 'S', 'T', 'U', 'V', ...
    'W', 'X', 'Y', 'Z'));

if COL <= 26
    % Column header from 'A' to 'Z'.
    
    % Read out the single 'digit' label.
    c = a{COL};
    
elseif COL <=702
    % Column header from 'AA' to 'ZZ'.
    
    % Offset by 26, since we are in 'double digits'.
    x = COL - 26;
    
    % Array the labels in a 'page' as follows:
    % AA AB ... AZ
    % BA BB ... BZ
    % ...
    % ZA ZB ... ZZ
    
    % Row index.
    R = 1 + floor((x-1)/26);
    % Col index.
    C = 1 + mod(x-1, 26);
    
    % Read out the 'double digit' label.
    c = [a{R},a{C}];

elseif COL <= 702+17576
    % Column header from 'AAA' to 'ZZZ'.
    
    % Offset by 702, since we are in 'triple digits'.
    x = COL - 702;
    
    % Array the labels in 'pages' of a 'book':
    % page A            page B                page Z
    % AAA AAB ... AAZ   BAA BAB ... BAZ       ZAA ZAB ... ZAZ
    % ABA ABB ... ABZ   BBA ABB ... BBZ ...   ZBA ZBB ... ZBZ
    % ...               ...                   ...
    % AZA AZB ... AZZ   BZA BZB ... BZZ       ZZA ZZB ... ZZZ
    
    % Page index.
    P = 1 + floor((x-1)/676); % 676 = 26*26.
    
    % Subtract page to access sheet.
    y = x - 676*(P-1);
    
    % Row index in sheet.
    R = 1 + floor((y-1)/26);
    % Col index in sheet.
    C = 1 + mod(y-1, 26);
    
    % Read out the 'triple digit' label.
    c = [a{P},a{R},a{C}];
    
elseif COL <= 702+17576+456976
    % Column headers from 'AAAA' to 'ZZZZ' - 'books' in 'series'.
    
    % Offset by 702+17576 since we are quadruple digits.
    x = COL - (702+17576);
    
    % Book index.
    B = 1 + floor((x-1)/17576); % 17576 = 26*26*26.
    
    % Subtract book to access page.
    y = x - 17576*(B-1);
    
    % Page index.
    P = 1 + floor((y-1)/676);
    
    % Subtract page to access sheet.
    z = y - 676*(P-1);
    % Row index in sheet.
    R = 1 + floor((z-1)/26);
    % Col index in sheet.
    C = 1 + mod(z-1, 26);
    
    % Read out the '4-digit' label.
    c = [a{B},a{P},a{R},a{C}];
      
else
    error('STATLAB:UTILITIES:excela1', 'Column limit exceeds the supported limits.')
end
