classdef epiphany
    % EPIPHANY epiphany objects contain an exploratory comparative apc analysis. 
    %
    % See https://pubmed.ncbi.nlm.nih.gov/37853346/ for details.
    %
    % Given K stratum-specific rates objects R1, ..., RK, EPIPHANY
    % identifies the best-fitting partition of the rates into proportional
    % subsets and non-proportional singletons.
    %
    % These results allow Estimable Functions (EFs) to be grouped into
    % subsets with equal, parallel, or unequal values.
    %
    % See also epiphany/epiphany, capricorn. 

    properties

        Inputs struct = struct;     % set up
        Capricorn cell = cell(0);   % capricorn analysis, subsets
        Tests struct = struct;      % homogeneity and composite tests, subsets
        sAIC struct = struct;       % AICc values, subsets
        pAIC struct = struct;       % AICc values, parititions

    end

    methods

        function S = epiphany(varargin)
            % EPIPHANY Exploratory comParatIve age Period coHort ANalYsis
            %
            % S = EPIPHANY(R1, R2, ..., RK, <property-value pairs>)
            %
            % R1, ..., RK are rates objects defined over the same Lexis Diagram.
            %
            % S is a structure array including hypothesis test results and AIC values for
            % comparative analyses of subsets of input rates.
            %
            % Property-value pairs:
            %
            % Fitted models will be determined based on k1 and k2 
            %
            % 'k1'         - minimum set size (default 1)
            % 'k2'         - maximum set size (default K)
            %  
            % 'letters'    - length K string of unique letters (default 'ABC...')
            %                excluding 'c', 'o', 'l', 'r', 's', '1', '2', ... '9'
            %
            % 'CapColors'  - K-vector of LineColor values 1 - 54 (1:K default)
            %
            % See also aic, plot.

            if nargin == 0
                % contents of an empty epiphany analysis
                S.Inputs = struct;
                S.Capricorn = cell(0);
                S.Tests = struct;
                S.sAIC = struct;
                S.pAIC = struct;
                return
            end

            if isa(varargin{1}, 'epiphany')
                S = varargin{1};
                return
            end

            % Contents of an empty epiphany analysis
            S.Inputs = struct(...
                'APC', [], ...
                'Title', '', ...
                'Label', '', ...
                'G', [], ...
                'k1', [], ...
                'k2', [], ...
                'Subsets', [], ...
                'Partitions', [], ...
                'letters', '', ...
                'CapColors', []);
            S.Capricorn = cell(0);
            S.Tests = struct('Homogeneity', [], 'Composite', []);
            S.sAIC = struct('DELTA', [], 'Cut', [], 'CutPoints', [], 'Data', []);
            S.pAIC = struct('DELTA', [], 'Mods', [], 'SAP', tbl, 'nph', logical([]));
            N = numel(varargin);

            if N == 0
                return
            end

            % analyze the data . . .
            s = EPIPHANY(varargin{:});
            S.Inputs = s.Inputs;
            S.Capricorn = s.Capricorn;
            S.Tests = s.Tests;
            S.sAIC = s.sAIC;
            S.pAIC = s.pAIC;

        end

        function tile(S, varargin)
            % TILE Tile plot of partitions versus subsets.
            % 
            % TILE(S)
            %
            % See also aic, pcolor.

            TILE(S)

        end

        function aic(S, varargin)
            % AIC Forestplot of bias-corrected aic values over partitions.
            %
            % AIC(S)
            % AIC(S, 'Threshold', value)
            %
            % 'Threshold' - XAxis cutoff (default none)
            %  
            % NOTE: AIC uses preset go values.
            %
            % See also tile, pcolor.

            AIC(S, varargin{:})

        end

        function pcolor(S, varargin)
            % PCOLOR Heat map of homogeneity and composite test results over subsets.
            %
            % PCOLOR(S)
            % PCOLOR(S, go(...))
            %            
            % See also aic, pcolor.
            
            PCOLOR(S, varargin{:})

        end

        function varargout = plot(S, varargin)
            % PLOT Plots of estimable functions for a partition.
            %
            % PLOT(S)
            % PLOT(S, ParitionNumber)
            % F = PLOT(...)
            %
            % Estimable Functions:
            %
            %      ftt, fcp, ld (top row)
            %      lac, cac, gs (bottom row)
            %
            % * F contains the data plotted
            %
            % NOTE: PLOT uses preset go values.
            %
            % see also motif, grade.

            P = size(S.pAIC.Mods, 1);

            if eq(nargin, 2)
                p = varargin{1};
                if ~ismember(p, 0:P)
                    error('invalid partition')
                end
            else
                p = 0;
            end

            if eq(p, 0)
                % 0 for best
                [~, p] = min(S.pAIC.DELTA.data(:, 5));
            end

            % read off our subset-specific models
            TMP1 = S.pAIC.Mods.data(p, :);
            ModelNumbers = TMP1(isfinite(TMP1));
            N = numel(ModelNumbers);
            % convert model numbers to model labels
            ModelLabels = {'PHL', 'PHT', 'PHX', 'PHA', 'NPH'};
            Models = ModelLabels(ModelNumbers);
            % corresonding subsets of partition p
            [~, b, c] = find(S.pAIC.SAP.Order.data(p, :));

            Subsets = NaN(1, N);
            for j = 1:N
                Subsets(c(j)) = b(j);
            end

            % good to go
            F = motif(S.Capricorn{Subsets}, Models);
            
            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                otherwise
                    error('too many outputs')
            end
            
        end

        function varargout = grade(S, varargin)
            % GRADE Plots of gradients of estimable functions for a partition.
            %
            % GRADE(S)
            % GRADE(S, ParitionNumber)
            % G = GRADE(...)
            %
            % Gradients of Estimable Functions:
            %
            %      ftt, fcp (top row)
            %      lac, cac (bottom row)
            %
            % * GRADE uses preset go values
            % * G contains the data plotted
            %
            % see also paganinni.

            P = size(S.pAIC.Mods, 1);

            if eq(nargin, 2)
                p = varargin{1};
                if ~ismember(p, 0:P)
                    error('invalid partition')
                end
            else
                p = 0;
            end

            if eq(p, 0)
                % 0 for best
                [~, p] = min(S.pAIC.DELTA.data(:, 5));
            end

            % read off our subset-specific models
            TMP1 = S.pAIC.Mods.data(p, :);
            ModelNumbers = TMP1(isfinite(TMP1));
            N = numel(ModelNumbers);
            % convert model numbers to model labels
            ModelLabels = {'PHL', 'PHT', 'PHX', 'PHA', 'NPH'};
            Models = ModelLabels(ModelNumbers);
            % corresonding subsets of partition p
            [~, b, c] = find(S.pAIC.SAP.Order.data(p, :));

            Subsets = NaN(1, N);
            for j = 1:N
                Subsets(c(j)) = b(j);
            end

            % good to go
            G = paganinni(S.Capricorn{Subsets}, Models);

            switch nargout
                case 0
                case 1
                    varargout{1} = G;
                otherwise
                    error('too many outputs')
            end

        end

        % end methods
    end
    % end classdef
end