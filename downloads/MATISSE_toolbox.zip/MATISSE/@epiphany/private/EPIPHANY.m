function S = EPIPHANY(varargin)
% EPIPHANY Exploratory ComParatIve Age Period CoHort ANalYsis

Q = length(varargin);
FIRSTPVP = 0;
for i = 1:Q
    if isa(varargin{i}, 'char') && FIRSTPVP == 0
        FIRSTPVP = i;
    end
end
if FIRSTPVP == 0
    G = Q;
else
    G = FIRSTPVP - 1;
end

% All the variables must be rates objects
R = varargin(1:G);
for c = 1:G
    if ~(isa(R{c}, 'rates'))
        error(['Input variable ' num2str(c) ' has class ' class(R{c}) ...
            ', must be a rates object.'])
    end
end

% All the rates objects must have the same dimensions as the first
[A, P] = size(R{1});

for i = 1:G
    [a, p] = size(R{i});
    if ~(A==a && P==p)
        error(['Input variable ' num2str(c) ' has size ' ...
            num2str(a) ' x ' num2str(p), ...
            ' must be ' num2str(A) ' x ' num2str(P) '.'])
    end
end

%%%
% Title and Label for this analysis
%%%
fn = cell(1, G);
lb = cell(1, G);
lb{1} = R{1}.chromacode;
fn{1} = R{1}.fullname;
switch G
    case 2
        fn{2} = [' & ', R{2}.fullname];
        lb{2} = [' & ', R{2}.chromacode];
    otherwise
        for g = 2:G
            fn{g} = [' & ', R{g}.fullname];
            lb{g} = [' & ', R{g}.chromacode];
        end
end
fn = [fn{:}];
lb = [lb{:}];

%%%
% Property-Value pairs
%%%
PVPAIRS = varargin((G+1):Q);
PVP = checkPVPAIRS(G, PVPAIRS{:});
N = length(PVP.Subsets);

warning off

% Pre-index to avoid broadcasting entire array of data to all workers
%%%
TMP = cell(1,N);
CapColors = cell(1, N);
for k = 1:N
    TMPk = {R(PVP.Subsets{k})};
    TMP(k) = TMPk;
    CapColors{k} = PVP.CapColors(PVP.Subsets{k});
end

%%%
% Run capricorn on each set
%%%
CAP = cell(1, N);
parfor kk = 1:N 

    CAP{kk} = capricorn(TMP{kk}{:}, CapColors{kk});

end

warning on

%%%
% Extract Homogeneity P, Composite P, and AIC values
%%%

P_H = NaN(N, 9);
P_C = NaN(N, 8);

MDF = NaN(N, 5); % model df
CDF = NaN(N, 5); % bias-corrected df
DEV = NaN(N, 5); % model deviance
AIC = NaN(N, 5); % bias-corrected AIC
DEL = NaN(N, 5); % DELTA values - AIC - min(AIC)

rl = cell(1, N);

for i = 1:N
    TMPi = CAP{i}.Tests.Homogeneity.data(:, 3)';

    P_H(i, :) = TMPi(9:-1:1);

    P_C(i, :) = CAP{i}.Tests.Composite.data(:, 3)';

    MDF(i, :) = CAP{i}.AIC.data(:, 1)';

    CDF(i, :) = CAP{i}.AIC.data(:, 2)';

    DEV(i, :) = CAP{i}.AIC.data(:, 3)';

    AIC(i, :) = CAP{i}.AIC.data(:, 4)';

    DEL(i, :) = CAP{i}.AIC.data(:, 5)';

    rl{i} = CAP{i}.Inputs.Title;

end

% Column labels for Homogeneity Tests
cl1 = {...
    '\color[rgb]{1.000  0.000  0.0000}Quad-Age', ...
    '\color[rgb]{1.000  0.000  0.0000}HiOrd-Age', ...
    '\color[rgb]{1.000  0.000  0.0000}LAT', ...
    '\color[rgb]{0      0.000  1.0000}Quad-Per', ...
    '\color[rgb]{0      0.000  1.0000}HiOrd-Per', ...
    '\color[rgb]{0      0.447  0.7410}NetDrift', ...
    '\color[rgb]{0      0.500  0.0000}Quad-Coh', ...
    '\color[rgb]{0      0.500  0.0000}HiOrd-Coh', ...
    '\color[rgb]{0.9216 0.4706 0.2784}CAT'};

% Column labels for Composite Tests
cl2 = {...
    '\color[rgb]{1.000  0.000  0.0000}PH-L', ...
    '\color[rgb]{0.000  0.000  1.0000}PH-T', ...
    '\color[rgb]{0.9216 0.4706 0.2784}PH-X', ...
    '\color[rgb]{0.494  0.184  0.5560}PH-A', ...
    '\color[rgb]{1.000  0.000  0.0000}\itPar-LAC', ...
    '\color[rgb]{0.9216 0.4706 0.2784}\itPar-CAC', ...
    '\color[rgb]{0      0.447  0.7410}\itPar-FTT', ...
    '\color[rgb]{0      0.500  0.0000}\itPar-FCP'};

% Column labels for AIC
cl3 = [cl2(1:4), ...
    '\color[rgb]{0      0      0     }N-PH'];

P_H(P_H==0) = 1E-10;
P_C(P_C==0) = 1E-10;

P_H = tbl(...
    'data', P_H, ...
    'fullname', 'Homogeneity Tests (Subsets)', ...
    'row_labels', rl, ...
    'col_labels', cl1);

P_C = tbl(...
    'data', P_C, ...
    'fullname', 'Composite Tests (Subsets)', ...
    'row_labels', rl, ...
    'col_labels', cl2);

DEL = tbl(...
    'data', DEL, ...
    'fullname', 'AIC Delta Vaues (Subsets)', ...
    'row_labels', rl, ...
    'col_labels', cl3);

S = struct(...
    'Inputs', [], ...
    'Capricorn', [], ...
    'Tests', [], ...
    'sAIC', [], ...
    'pAIC', []);

S.Inputs = struct(...
    'APC', [A P A+P-1], ...
    'Title', fn, ...
    'Label', lb, ...
    'G', G, ...
    'k1', PVP.k1, ...
    'k2', PVP.k2, ...
    'Subsets', [], ... % must initialize to empty
    'letters', PVP.letters, ...
    'CapColors', PVP.CapColors);

S.Inputs.Subsets = PVP.Subsets;

S.Capricorn = CAP;

S.Tests = struct('Homogeneity', P_H, 'Composite', P_C);

S.sAIC = struct('DELTA', DEL);

S.sAIC.Data = struct(...
    'DEV', DEV, ...
    'AIC', AIC, ...
    'mdf', MDF, ...
    'cdf', CDF);
    S.pAIC = sonata(PVP, S);

end

% Helper Functions

function pAIC = sonata(PVP, S)
% SONATA partionS, mOdels aNd biAs-correcTed Aic

%%%
% TRUSS - partitions from subsets
%%%
sAIC = S.sAIC;

T = truss(PVP.G, PVP.k1, PVP.k2, PVP.letters, PVP.CapColors);

%%%
% Cherry-pick the best model for each subset
%%%
[PRT, SUB] = size(T.Size);
S_SUB = 1:SUB;
S_5 = 1:5;

[~, rnk] = sort(sAIC.DELTA.data, 2);

irnk = NaN(SUB, 5);
for i = 1:SUB
    [~, irnk(i,:)] = ismember((1:5)', rnk(i, :));
end

LocBestModelPerSubset = (irnk == 1);

BestModelPerSubset = NaN(SUB, 1);
for j = 1:SUB

    BestModelPerSubset(j) = S_5(LocBestModelPerSubset(j, :));

end

NumSubsetsPerPartition = sum(T.Order.data > 0, 2);
MaxSubsetsPerPartion = max(NumSubsetsPerPartition);

%%%
% Calculate AIC for each partition
% You have to recalculate the bias-corrected df
%%%

Mods = NaN(PRT, MaxSubsetsPerPartion);
Trivial = zeros(PRT, 1); % keep track of all the ways we wind up with all NPH

sdev = sAIC.Data.DEV;
smdf = sAIC.Data.mdf;

pDEV = NaN(PRT, MaxSubsetsPerPartion);
pMDF = NaN(PRT, MaxSubsetsPerPartion);
bc_cdf = NaN(PRT, 1);

for j = 1:PRT

    Sj = S_SUB(T.Order.data(j, :) > 0);
    Bestj = BestModelPerSubset(Sj)';
    if all(Bestj == 5)
        Trivial(j) = 1;
    end

    ORDj = (T.Order.data(j, Sj));

    Mods(j, ORDj) = Bestj;

    devj = zeros(1, NumSubsetsPerPartition(j));
    mdfj = zeros(1, NumSubsetsPerPartition(j));

    for k = 1:NumSubsetsPerPartition(j)

        devj(k) = sdev(Sj(k), Bestj(k));
        mdfj(k) = smdf(Sj(k), Bestj(k));

    end

    alt_mdfj = sum(mdfj);
    AP = S.Inputs.APC(1) * S.Inputs.APC(2);
    bc_cdf(j) = alt_mdfj + (alt_mdfj.*(alt_mdfj+1))./(AP*PVP.G - alt_mdfj - 1);

    pDEV(j, ORDj) = devj;
    pMDF(j, ORDj) = mdfj;

end

%%%
% Rescaled AIC
%%%
p_dev = sum(pDEV, 2, 'omitnan');
p_mdf = sum(pMDF, 2, 'omitnan');
p_cdf = bc_cdf;

p_aic = p_dev + 2 * p_cdf;
[~, rnk] = sort(p_aic);
[~, irnk] = ismember((1:PRT)', rnk);

delta = p_aic - p_aic(rnk(1));
DATA = [p_mdf p_dev p_aic delta irnk (1:PRT)'];
DELTA = tbl(...
    'data', DATA, ...
    'fullname', 'AIC Delta Values (Partitions)', ...
    'row_labels', T.Order.row_labels, ...
    'col_labels', {'mdf', 'DEV', 'pAIC', 'DELTA', 'rank', 'partition'});

%%%
% Best models within each partition
%%%
cl = cellstr(num2str((1:MaxSubsetsPerPartion)', '#%g'))';

TMP4 = continuous('data', Mods(:), 'fullname', 'Model');
cddat = bin(TMP4, 0.5:1:5.5);
warning off
cddat = squeeze(cddat);
warning on
CDDAT = reshape(cddat.data, PRT, MaxSubsetsPerPartion);
CDDAT(isnan(CDDAT)) = -Inf;

MODS = tbl(...
    'data', CDDAT, ...
    'fullname', 'Models & Partitions', ...
    'row_labels', T.Order.row_labels, ...
    'col_labels', cl);

pAIC = struct(...
    'DELTA', DELTA, ...
    'Mods', MODS, ...
    'SAP', T, ...
    'nph', logical(Trivial));

end

function PVP = checkPVPAIRS(G, varargin)
% property-value pairs

PVP = struct(...
    'G', G, ...
    'k1', [], ...
    'k2', [], ...
    'Subsets', []);

if G == 1
    PVP.k1 = 1;
    PVP.k2 = 1;
    PVP.Subsets = {1};
else
    PVP.k1 = 1;
    PVP.k2 = G;
end

default_letters = 'ABCDEFGHIJKLMNOPQRTSUVWXYZ';

PVP.letters = default_letters(1:G);
PVP.CapColors = 1:G;

lArgin = varargin;
Nl = numel(lArgin);
if eq(Nl, 1)
    error('Incomplete property/value pair.');
end

while Nl >= 2
    propi = lArgin{1};
    vali = lArgin{2};

    switch lower(propi)

        case 'capcolors'
            % first see if this is a real G-vector
            if ~(eq(numel(vali), G) && isreal(vali) && isnumeric(vali))
                error(['specify ' num2str(G) ' values']);
            end

            % now check whether every value is between 1 and 54
            if ~all(ismember(vali, 1:54))
                error('''Capcolors'' values must be integers from 1 - 54');
            end

            PVP.CapColors = vali;

        case 'letters'
            if ~(ischar(vali) && length(vali) == G)
                error('invalid ''letters''')
            end

            % for stupid reasons do not include lower case letters in
            % 'colors' or the numerals 0-9
            if any(ismember(vali, 'colors0123456789'))
                error(['''letters'' must exclude ' ...
                    '''c'', ''o'', ''l'', ''r'', ''s'', ' ...
                    '''0'', ''1'', ''2'', ''3'', ''4'', ''5'', ''6'', ''7'', ''8'', ''9'' '])
            end
            PVP.letters = vali;

        case 'k1'
            % first see if this is a real scalar
            if ~(isscalar(vali) && isreal(vali) && isnumeric(vali))
                error('k1 must be a scalar')
            end
            vali = floor(vali);

            if (vali < 1 || vali > G)
                error(['k1 must lie between 1 and ' num2str(G)])
            end
            PVP.k1 = vali;

        case 'k2'
            % first see if this is a real vector
            if ~(isscalar(vali) && isreal(vali) && isnumeric(vali))
                error('k2 must be a scalar')
            end
            if (vali < 1 || vali > G)
                error(['k2 must lie between 1 and ' num2str(G)])
            end

            PVP.k2 = vali;

        otherwise

    end

    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

end

if ~(PVP.k1 <= PVP.k2)
    error('k1 must be less than or equal to k2')
end

if isempty(PVP.Subsets)

    %%%
    % Subsets arranged by number of elements
    %%%
    Nk = PVP.k2 - PVP.k1 + 1;
    N = 0;
    SUBSETS = cell(1, Nk);
    k = 0;
    for i = Nk:-1:1
        SUBSETS{i} = nchoosek(1:G, PVP.k1 + k);
        N = N + size(SUBSETS{i}, 1);
        k = k + 1;
    end

    %%%
    % Flatten the array for parfor
    %%%
    Subsets = cell(1, N);
    k = 0;
    for i = 1:1:Nk % Nk:-1:1
        TMPi = SUBSETS{i};
        Ni = size(TMPi, 1);
        for j = 1:Ni
            k = k + 1;
            Subsets{k} = TMPi(j, :);
        end
    end

    PVP.Subsets = Subsets;

end


end
