function AIC(S, varargin)
% AIC values from epiphany analysis

PVP = AIC_INPUTS(varargin{:});

%%%
% Threshold
%%%
if isfinite(PVP.Threshold)

    INC = S.pAIC.DELTA.data(:, 4) <= PVP.Threshold;
    DELTA = S.pAIC.DELTA(INC, :);
    DELTA.fullname = S.Inputs.Label;
    mods = S.pAIC.Mods.data(INC, :);
    subs = S.pAIC.SAP.Order.data(INC, :);

else

    DELTA = S.pAIC.DELTA;
    DELTA.fullname = S.Inputs.Label;
    mods = S.pAIC.Mods.data;
    subs = S.pAIC.SAP.Order.data;

end

%%%
% create ragged right tbl of subsets
%%%
[a,b,c] = find(subs);
d = sortrows([a(:) b(:) c(:)], [1 3]);
x1 = continuous('data', d(:, 1));
x2 = continuous('data', d(:, 2));
x3 = continuous('data', d(:, 3));
T = align(x2, x1, x3);

%%%
% Create model descriptors
%%%

% model labels
mlabs = {...
    '\color[rgb]{1.000  0.000  0.0000}\bf{L}\rm', ...
    '\color[rgb]{0.000  0.000  1.0000}\bf{T}\rm', ...
    '\color[rgb]{0.9216 0.4706 0.2784}\bf{X}\rm', ...
    '\color[rgb]{0.494  0.184  0.5560}\bf{A}\rm', ...
    '\color[rgb]{0      0      0     }\rm{N}'};

% rank order of the partitions
a = DELTA.data(:, 5);

% partition numbers
b = DELTA.data(:, 6);

% partition numbers in ranked order
j = (1:numel(a))';
[~, c] = ismember(j, a);

% partition numbers in ranked order
p = b(c);

% models for the ranked partitions
mods = mods(c, :);

% df fo the ranked partitions
df = DELTA.data(:, 1);
df = df(c);

% subsets for the ranked partitions
T = T(c, :);

N = sum(isfinite(mods), 2);
M = length(p);
mLAB = cell(1, M);

for i = 1:M
    TMPi = ['^{' num2str(p(i)) '}'];
    for j = 1:1:N(i)
        TMPi = [TMPi, ...
            '\color[rgb]{0 0 0}\{\bf{' mlabs{mods(i, j)}  '}\rm\color[rgb]{0 0 0}\}', ...
            '_{' num2str(T.data(i, j)) '}']; %#ok<AGROW>

    end

    TMPi = [TMPi '^{\rm\bf\it' num2str(df(i)) '}']; %#ok<AGROW>
    mLAB{i} = TMPi;
end

% set up annotated data
DAT = tbl(...
    'data', DELTA.data(c, 4), ...
    'fullname', DELTA.fullname, ...
    'labels', ...
    {'\Delta = AIC_{c} - \rm{min }\it{AIC_{c}}', ...
    '^{Partition}\{\{Model\}_{subset}\} ^{\it\bfdf}'}, ...
    'row_labels', mLAB);
mDAT = matrix('data', DAT, 'COV', 0);
mDAT = sort(mDAT, 1, 'ascend');

figure('Position', [150 150 1000 1000])

PVP = go('Width', 1, 'Legend', 0, 'FontSize', [12 12 12], ...
    'Text', 0, 'MarkerSize', 16, 'Grid', 1, 'labels', [1 0 0]);

forestplot(mDAT, 1, PVP)

% annotation
ax = gca;

v1PVP = go('Width', 1, 'Legend', 0, ...
    'LineColor', 10, 'LineStyle', 5, 'FaceAlpha', 0.10, 'EdgeAlpha', 0);
vband([ax.YLim 1 0.01 2], v1PVP)

v2PVP = go('Width', 1, 'Legend', 0, ...
    'LineColor', 17, 'LineStyle', 5, 'FaceAlpha', 0.10, 'EdgeAlpha', 0);
vband([ax.YLim 3 2 4], v2PVP)

v3PVP = go('Width', 1, 'Legend', 0, ...
    'LineColor', 17, 'LineStyle', 5, 'FaceAlpha', 0.05, 'EdgeAlpha', 0);
vband([ax.YLim 5.5 4 7], v3PVP)

end

%%%% helper functions

function PVP = AIC_INPUTS(varargin)
% Helper

PVP = struct('Threshold', Inf);

%%%
% process
%%%
if length(varargin) > 1
    lArgin = varargin(1:end);
else
    lArgin = [];
end

Nl = numel(lArgin);
if eq(Nl, 1)
    error('The property you specified has no matching value.');
end

while ge(Nl, 1)
    if eq(Nl, 1)
        error('The last property has no matching value.');
    end

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('A property must be specified using a string.')
    end

    switch lower(propi)

        case 'threshold'
            % first see if this is a real scalar
            if ~(isscalar(vali) && isreal(vali))
                error('Threshold must be a scalar');
            end
            if vali <= 0
                error('Threshold must be positive')
            end
            PVP.Threshold = vali;

        otherwise

    end

    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

end

end

