function T = truss(G, varargin)
% TRUSS parTitions fRom SUbSetS
%
% Helper function for epiphany
%
% T = truss(G)
% T = truss(G, k1)
% T = truss(G, k1, k2)
% T = truss(G, k1, k2, letters)
% T = truss(G, k1, k2, letters, colors)
%
% Outputs:
%
% * T.Order: A tbl of integers that maps partitions (rows) into subsets (columns)
% * T.Size:  A tbl of integers that maps the number of elements per
% subset (columns) for each partition (rows).
%
% G             - number of elements in the target set
% k1            - minimum number of elements per subset,  1 <= k1 <= G
% k2            - maximum number of elements per subset, k1 <= k2 <= G
% letters       - length G string: element labels
% colors        - length G vector: clarinet colors for chromacoding
%
% Examples:
%
% T = truss(4, 1, 4, 'ABCD')
% T = truss(8, 2, 4, 'ABCDEFGH')
% T = truss(4, 1, 4, 'WXYZ', [9 8 11 12])
%
% NOTES:
%  * complexity increases exponentially with G
%  * labels are formatted for the 'tex' interpreter
%
% See also: epiphany


% Set up
default_letters = 'ABCDEFGHIJKLMNOPQRTSU';

switch numel(varargin)
    case 0
        k1 = 1;
        k2 = G;
        letters = default_letters(1:G);
        colors = 1:G;

    case 1
        k1 = varargin{1};
        k2 = G;
        letters = default_letters(1:G);
        colors = 1:G;

    case 2
        k1 = varargin{1};
        k2 = varargin{2};
        letters = default_letters(1:G);
        colors = 1:G;

    case 3
        k1 = varargin{1};
        k2 = varargin{2};
        letters = varargin{3};
        colors = 1:G;

    case 4
        k1 = varargin{1};
        k2 = varargin{2};
        letters = varargin{3};
        colors = varargin{4};

end

% subset counts
N = 0;
Nj = NaN(1, k2-k1+1);
for j = k2:-1:k1
    Nj(j) = nchoosek(G, j);
    N = N + Nj(j);
end

% subsets
s = cell(1, N);
n_s = NaN(1, N);
l1 = 1;
for j = k2:-1:k1
    l2 = l1 + Nj(j) - 1;
    sj = cellstr(nchoosek(letters, j));
    s(l1:l2) = sj;
    n_s(l1:l2) = j;
    l1 = l2+1;
end

% subset labels
sLAB = cell(1, N);

fn1 = 'Partitions and Subsets: Order';
fn2 = 'Partitions and Subsets: Size';
for j = 1:N
    sLAB{j} = ['\{' s{j} '\}'];
end

% partition letters
q = partitions(letters);

% partition colors
partition_colors = partitions(colors);

% partition labels
qLAB = cell(1, length(q));

for ii = length(q):-1:1
    TMPii = '';
    for jj = 1:1:length(q{ii})
        TMPii = [TMPii, '\{' sprintf('%s',q{ii}{jj}) '\}']; %#ok<AGROW>
    end
    qLAB{ii} = TMPii;
end

% location matrix / sparse matrix code
Nq = numel(q);
Ns = numel(s);
IsPart = zeros(Nq, 1);

LOC = cell(1, Nq);
tVAL = cell(1, Nq);
sVAL = cell(1, Nq);
rJ = cell(1, Nq);

for i = 1:Nq
    [TFi, LOCi] = ismember(q{i}, s);
    if all(TFi)
        Ni = numel(LOCi);
        rJ{i} = i * ones(1, Ni); 
        LOC{i} = LOCi;
        tVAL{i} = 1:Ni;
        sVAL{i} = n_s(LOCi);
        IsPart(i) = 1;
    else
        IsPart(i) = 0;   
    end
end

rLOC = [rJ{:}];
cLOC = [LOC{:}];
Tdat = sparse(rLOC, cLOC, [tVAL{:}], Nq, Ns);
Sdat = sparse(rLOC, cLOC, [sVAL{:}], Nq, Ns);

IsPart = logical(IsPart);

Tdat0 = Tdat(IsPart, :);

Sdat0 = Sdat(IsPart, :);

qLAB0 = qLAB(IsPart);

%%%
% Chromacoded Version
%%%
cc_qLAB0 = chromacode(qLAB0, letters, colors);
cc_sLAB = chromacode(sLAB, letters, colors);

T.Order = tbl(...
    'data', Tdat0, ...
    'fullname', fn1, ...
    'row_labels', cc_qLAB0, ...
    'col_labels', cc_sLAB, ...
    'labels', {'partitions', 'subsets'});

T.Size = tbl(...
    'data', Sdat0, ...
    'fullname', fn2, ...
    'row_labels', cc_qLAB0, ...
    'col_labels', cc_sLAB, ...
    'labels', {'partitions', 'subsets'});

T.partion_colors = partition_colors;

end

%%%
% Helper Function
%%%
function clbs = chromacode(lbs, letters, colors)
% Chromacode labels lbs using clarinet colors

N = length(lbs);
G = length(letters);

map = clarinet(54);
MAP = num2str(map(colors, :));

clbs = cell(1, N);
for i = 1:N

    TMPi = ['\color[]{0 0 0}^{' num2str(i)  '}' lbs{i}];
    for j = 1:G

        TMPi = strrep(TMPi, letters(j), ['\color[]{' MAP(j,:) '}' letters(j) '\color[]{0 0 0}']);

    end

    clbs{i} = TMPi;

end

clbs = strrep(clbs, '[]', '[rgb]');

end