function PCOLOR(S, varargin)
% PCOLOR PCOLOR plot of homogeneity and composite test results over subsets.

if eq(nargin, 1)
    PVP = ego('class', 'epiphany', 'method', 'pcolor');

else
    % user supplied PVP, but we need to override m, clim and reversemap
    PVP = varargin{1};
    PVP.m = 10;
    PVP.clim = [0 10];
    PVP.reversemap = false;
end

G = S.Inputs.G;
N = numel(S.Inputs.Subsets);

if eq(S.Inputs.k1, 1)
    INC = 1:N-G;
else
    INC = 1:N;
end

V1 = matrix('data', S.Tests.Homogeneity(INC, :));
V2 = matrix('data', S.Tests.Composite(INC, :));
V = [pad(V1, 'cols', 1, 'cpos', 'right', 'fill', 0), V2];
P = scale(log10(V), -1);

% Interesting cutpoints
p = [1  0.1 0.05 0.025 10^-2 10^-3 10^-4 10^-5 10^-6 10^-7 10^-8 10^-9 10^-10]';

T = P.data;
% threshold at 10^-10
T = min(T, 10);

T.fullname = S.Inputs.Label;
T.row_labels = S.pAIC.SAP.Size.col_labels(INC);
T.labels = {'', ''};

figure('Position', [150 150 1200 800])

pcolor(T, PVP)

h = get(gca, 'colorbar');
set(h, ...
    'TickDirection', 'out', ...
    'Direction', 'normal', ...
    'Ticks', -log10(p), ...
    'Limits', [0 10], ...
    'TickLabels', cellstr(num2str(p)), ...
    'FontSize', 8)
h.Label.String = 'P-Values';

end