classdef boolean
    % BOOLEAN boolean objects contain logical data.
    %
    % * BOOLEAN objects should never be confused with MATLAB's
    %   logical class!
    %
    % Unlike logical objects, boolean objects treat NaN values as missing
    % data. BOOLEAN logical comparisons with NaNs always evaluate to NaNs,
    % not to logical 0s. 
    %
    % BOOLEAN objects are used by MATISSE for subscripted referencing,
    % subscripted assignment, and case selection.
    %
    % See also boolean/boolean, logical

    properties

        data (:, 1) {mustBeNumeric} = [];          % array of 0s, 1s, and NaNs (coerced to a vector)
        fullname (1, :) {mustBeTextScalar} = '';   % scientific name of the array

    end

    methods

        %%%
        % housekeeping
        %%%

        function B = boolean(varargin)
            % A BOOLEAN object is a container for logical data. 
            %
            % B = BOOLEAN('data', <vector of 0s, 1s, and NaNs>, ...
            % 'fullname', 'string');
            %
            % Unlike logical objects, boolean objects treat NaN values as
            % missing data.
            %
            % See also logical.

            if nargin == 0
                % Contents of an empty tbl
                B.data = [];
                B.fullname = '';
                return
            end

            if isa(varargin{1}, 'boolean')
                B = varargin{1};
                return
            end

            % Contents of an empty boolean
            B.data = [];
            B.fullname = '';

            N = numel(varargin);

            if N == 0
                return
            end

            %%%
            % whittle the arguments
            %%%
            lArgin = varargin;

            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};

                if ~ischar(propi)
                    error('a property must be specified using a string')
                end

                switch lower(propi)

                    case 'data'
                        if ~(ismatrix(vali) && isreal(vali))
                            error('boolean data must be a matrix')
                        end

                        if any((vali ~= 0) & (vali ~= 1) & ~isnan(vali))
                            error('boolean data must all be 0, 1, or NaN');
                        end
                        B.data = +vali; % coerce logical to numeric

                    case 'fullname'
                        if ischar(vali)
                            B.fullname = vali;
                        else
                            error('fullname must be a string')
                        end

                    otherwise

                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('the last property has no matching value');
                end

            end
        end

        function U = subsref(B, S)
            % SUBSREF subscripted reference for boolean objects.

            if length(S) > 1

                DEPTH = numel(S);
                for d = 1:DEPTH
                    if d == 1
                        U = subsref(B, S(1));
                    else
                        q = numArgumentsFromSubscript(U, S(d), ...
                            matlab.mixin.util.IndexingContext.Statement);
                        if q > 1
                            warning('only one output was captured')
                        end
                        U = subsref(U, S(d));
                    end
                end

            else

                switch S.type

                    case '.'

                        switch S.subs

                            case 'data'
                                U = B.data;
                            case 'fullname'
                                U = B.fullname;

                            otherwise

                        end

                    case '()'
                        if isa(S.subs{1}, 'boolean')
                            S.subs = find(S.subs{1}.data == 1);
                            S.subs = {S.subs};
                        elseif isa(S.subs{1}, 'logical')
                            S.subs = S.subs{1};
                            S.subs = {S.subs};
                        else
                            % let MATLAB handle any errors
                        end
                        NI = numel(S.subs);
                        switch NI
                            case {0, 1}
                                SUBS = cell(1, 2);
                                SUBS{1} = S.subs{1};
                                SUBS{2} = ':';
                            case 2
                                SUBS = S.subs;
                            otherwise

                        end

                        DATA = B.data(SUBS{1}(:), SUBS{2});

                        U = boolean('data', DATA, ...
                            'fullname', B.fullname);

                    case '{}'

                        % do nothing
                        U = B;

                end

            end

        end

        function G = subsasgn(F, S, V)
            % SUBSASGN subscripted assignment for boolean objects.

            if length(S) > 1
                DEPTH = numel(S);
                error('index expression has depth %g, cannot be > 1', DEPTH)
            end

            switch S.type

                case '.'

                    switch S.subs
                        case 'data'
                            G = boolean(...
                                'data', +V, ...
                                'fullname', F.fullname);

                        case 'fullname'
                            G = F;
                            G.fullname = V;

                        otherwise

                    end

                case '()'
                    % if it's a boolean, replace S.subs{1} with indices
                    if isa(S.subs{1}, 'boolean')
                        S.subs{1} = find(S.subs{1}.data == 1);
                    end
                    NI = numel(S.subs);
                    switch NI
                        case 1
                            SUBS = cell(1, 2);
                            SUBS{1} = S.subs{1};
                            SUBS{2} = ':';
                        case 2
                            SUBS = S.subs;
                        otherwise
                            SUBS = S.subs{1:2};
                    end

                    DATA = F.data;
                    DATA(SUBS{1}(:)', SUBS{2}(:)') = V;

                    G = boolean('data', DATA, ...
                        'fullname', F.fullname);

                case '{}'
                    warning('brace indexing is undefined')

                otherwise

            end

        end

        function r = end(g, k, ~)
            % END end method for boolean objects.

            switch k
                case 1
                    r = size(g, 1);
                case 2
                    r = size(g, 2);
                otherwise
            end

        end

        function S = isempty(B)
            % ISEMPTY isempty for boolean objects.
            %
            % S = ISEMPTY(B)
            %
            % S is logical true or false
            %
            % See also size.

            S = isempty(B.data);

        end

        function varargout = size(B, varargin)
            % SIZE size of a boolean object
            %
            % [R, C] = size(B)
            % R = size(B, 1)
            % C = size(B, 2)
            %
            % Number of rows R and columns C of B. C is always 1.
            %
            % See also isempty.

            switch nargin
                case 1
                    switch nargout
                        case {0, 1}
                            varargout{1} = [size(B.data, 1), size(B.data, 2)];
                        case 2
                            varargout{1} = size(B.data, 1);
                            varargout{2} = size(B.data, 2);
                        otherwise
                            error('too many outputs')
                    end

                case 2
                    d = varargin{1};
                    switch nargout
                        case {0, 1}
                            varargout{1} = size(B.data, d(1));
                        case 2
                            varargout{1} = size(B.data, d(1));
                            varargout{2} = size(B.data, d(2));
                        otherwise
                            error('too many outputs')
                    end
            end
        end

        function varargout = disp(B, varargin)
            % DISP command window disp of a boolean object.
            %
            % DISP(B)
            % s = DISP(B)

            % anything to display?
            if isempty(B.data)
                disp('empty boolean')
                if nargout > 0
                    disp('empty boolean')
                    varargout{1} = {};
                end
                return
            end

            nmiss = sum(isnan(B.data));

            DATA = B.data;

            % frequency table
            f(1) = length(find(DATA==0));
            f(2) = length(find(DATA==1));
            f(3) = nmiss;
            vals = [0, 1, NaN];
            f = f';

            rlabs = {'false', 'true', '(missing)'};
            clabs = {'value', 'freq', 'percent'};
            FTAB = tbl(...
                'data', [vals', f, 100*f./((sum(f)==0)+sum(f))], ...
                'fullname', B.fullname, ...
                'row_labels', rlabs, ...
                'col_labels', clabs);

            if nargout == 0
                disp(FTAB)
                disp(' ')
            else
                varargout{1} = FTAB;
            end

        end

        function l = length(B)
            % LENGTH length of a boolean object.
            %
            % L = LENGTH(B)

            l = length(B.data);

        end

        %%%
        % elementary operations
        %%%

        function B = and(v, w)
            % AND and logical operator for boolean objects.
            %
            % B = V & W
            % B = AND(V, W)
            %
            % B(i) is NaN whenever V(i) or W(i) is NaN.
            %
            % See also or.

            if ~(isa(v, 'boolean') && isa(w, 'boolean'))
                error('both input arguments must be boolean');
            end

            vdat = v.data;
            wdat = w.data;
            lv = length(vdat);
            lw = length(wdat);

            % lengths must be the same, or one length must be 1; determine case
            if (isempty(vdat) || isempty(wdat))
                error('One argument is empty.');
            elseif ((lv == lw) || (lv == 1) || (lw == 1))
                % data vectors are the same length, or one is a scalar - proceed

                % v6.5 compliant method
                l = vdat.*wdat;

                fn = [v.fullname ' & ' w.fullname];
                B = boolean('data', l, 'fullname', fn);
            else
                % oops
                error('Boolean variables being compared must have the same length.');
            end

        end

        function A = all(B)
            % ALL all logical operator for a boolean object.
            %
            % r = ALL(V)
            %
            % r is a logical 1 (true) if all elements of V are 1, logical 0
            % (false) otherwise.
            %
            % See also any.

            A = all(B.data == 1);

        end

        function A = any(B)
            % ANY any logical operator for boolean objects.
            %
            % r = ANY(V)
            %
            % r is a logical 1 (true) if any element of V is 1, logical 0
            % (false) otherwise.
            %
            % See also all.

            A = any(B.data == 1);

        end

        %%%
        % comparison operators
        %%%

        function B = eq(v, w)
            % EQ (equal than) operator for boolean objects.
            %
            % B = V == W
            % B = eq(V, W)
            %
            % B(i) is NaN whenever V(i) or W(i) is NaN.
            % 
            % See also ne, ge, gt, le, lt.

            if isa(v, 'numeric')
                if eq(numel(v), 1)
                    % catch expressions like x+3
                    v = boolean('data', v, 'fullname', num2str(v));
                else
                    v = boolean('data', v, 'fullname', 'numeric');
                end
            else
                v = boolean(v);
            end

            if isa(w, 'numeric')
                if eq(numel(w), 1)
                    w = boolean('data', w, 'fullname', num2str(w));
                else
                    w = boolean('data', w, 'fullname', 'numeric');
                end
            else
                w = boolean(w);
            end

            vdat = v.data;
            wdat = w.data;
            lv = length(vdat);
            lw = length(wdat);

            % lengths must be the same, or one length must be 1; determine case
            if (isempty(vdat) || isempty(wdat))
                error('one argument is empty');
            elseif ((lv == lw) || (lv == 1) || (lw == 1))
                % data vectors are the same length, or one is a scalar - proceed
                l = 1 - abs(vdat - wdat);
                fn = [v.fullname ' == ' w.fullname];
                B = boolean('data', l, 'fullname', fn);
            else
                % oops
                error('boolean variables being compared must have the same length');
            end

        end

        function N = isnan(B)
            % ISNAN isnan for boolean objects.
            %
            % B = ISNAN(V)
            %
            % B(i) is NaN whenever V(i) or W(i) is NaN.

            N = boolean('data', isnan(B.data), 'fullname', [B.fullname ' is NAN']);

        end

        function B = ge(v, w)
            % GE (greater than or equal to) operator for boolean objects.
            %
            % B = V >= W
            % B = GE(V, W)
            %
            % B(i) is NaN whenever V(i) or W(i) is NaN.
            %
            % See also eq, ne, gt, le, lt.


            if isa(v, 'numeric')
                if eq(numel(v), 1)
                    % catch expressions like x+3
                    v = boolean('data', v, 'fullname', num2str(v));
                else
                    v = boolean('data', v, 'fullname', 'numeric');
                end
            else
                v = boolean(v);
            end

            if isa(w, 'numeric')
                if eq(numel(w), 1)
                    w = boolean('data', w, 'fullname', num2str(w));
                else
                    w = boolean('data', w, 'fullname', 'numeric');
                end
            else
                w = boolean(w);
            end

            vdat = v.data;
            wdat = w.data;
            lv = length(vdat);
            lw = length(wdat);

            % lengths must be the same, or one length must be 1; determine case
            if (isempty(vdat) || isempty(wdat))
                error('one argument is empty');
            elseif ((lv == lw) || (lv == 1) || (lw == 1))
                % data vectors are the same length, or one is a scalar - proceed
                % NOTE: the max function ignores the missings, but the abs function does not
                l = 1 - abs(vdat - wdat) + max(0, vdat - wdat);
                fn = [v.fullname ' >= ' w.fullname];
                B = boolean('data', l, 'fullname', fn);
            else
                % oops
                error('boolean variables being compared must have the same length');
            end

        end

        function B = gt(v, w)
            % GT (greater than) operator for boolean objects.
            %
            % B = V > W
            % B = gt(V, W)
            % 
            % B(i) is NaN whenever V(i) or W(i) is NaN.
            %
            % See also eq, ne, ge, le, lt.

            if isa(v, 'numeric')
                if eq(numel(v), 1)
                    % catch expressions like x+3
                    v = boolean('data', v,'fullname', num2str(v));
                else
                    v = boolean('data', v, 'fullname', 'numeric');
                end
            else
                v = boolean(v);
            end

            if isa(w, 'numeric')
                if eq(numel(w), 1)
                    w = boolean('data', w, 'fullname', num2str(w));
                else
                    w = boolean('data', w, 'fullname', 'numeric');
                end
            else
                w = boolean(w);
            end

            vdat = v.data;
            wdat = w.data;
            lv = length(vdat);
            lw = length(wdat);

            % lengths must be the same, or one length must be 1; determine case
            if (isempty(vdat) || isempty(wdat))
                error('one argument is empty');
            elseif ((lv == lw) || (lv == 1) || (lw == 1))
                % data vectors are the same length, or one is a scalar - proceed

                % do it this way to accomodate NaN values: greater than is greater than or
                % equal to minus equal to
                l = 1 - abs(vdat - wdat) + max(0, vdat - wdat) - (1 - abs(vdat - wdat));
                fn = [v.fullname ' > ' w.fullname];
                B = boolean('data', l, 'fullname', fn);
            else
                % oops
                error('boolean variables being compared must have the same length');
            end

        end

        function B = le(v, w)
            % LE (less than or equal to) operator for boolean objects.
            %
            % B = V <= W
            % B = LE(V, W)
            %
            % B(i) is NaN whenever V(i) or W(i) is NaN.
            %
            % See also eq, ne, ge, gt, lt.

            if isa(v, 'numeric')
                if eq(numel(v), 1)
                    % catch expressions like x+3
                    v = boolean('data', v, 'fullname', num2str(v));
                else
                    v = boolean('data', v, 'fullname', 'numeric');
                end
            else
                v = boolean(v);
            end

            if isa(w, 'numeric')
                if eq(numel(w), 1)
                    w = boolean('data', w, 'fullname', num2str(w));
                else
                    w = boolean('data', w, 'fullname', 'numeric');
                end
            else
                w = boolean(w);
            end

            vdat = v.data;
            wdat = w.data;
            lv = length(vdat);
            lw = length(wdat);

            % lengths must be the same, or one length must be 1; determine case
            if (isempty(vdat) || isempty(wdat))
                error('one argument is empty');
            elseif ((lv == lw) || (lv == 1) || (lw == 1))

                % NOTE: the max function ignores the missings, but the abs function does not
                l = 1 - abs(vdat - wdat) + max(0, wdat - vdat);
                fn = [v.fullname ' <= ' w.fullname];
                B = boolean('data', l, 'fullname', fn);
            else
                % oops
                error('boolean variables being compared must have the same length');
            end

        end

        function B = lt(v,w)
            % LT (less than) operator for boolean objects.
            %
            % B = V < W
            % B = LT(V, W)
            %
            % B(i) is NaN whenever V(i) or W(i) is NaN.
            %
            % See also eq, ne, ge, gt, le.

            if isa(v, 'numeric')
                if eq(numel(v), 1)
                    % catch expressions like x+3
                    v = boolean('data', v, 'fullname', num2str(v));
                else
                    v = boolean('data', v, 'fullname', 'numeric');
                end
            else
                v = boolean(v);
            end

            if isa(w, 'numeric')
                if eq(numel(w), 1)
                    w = boolean('data', w, 'fullname', num2str(w));
                else
                    w = boolean('data', w, 'fullname', 'numeric');
                end
            else
                w = boolean(w);
            end

            vdat = v.data;
            wdat = w.data;
            lv = length(vdat);
            lw = length(wdat);

            % lengths must be the same, or one length must be 1; determine case
            if (isempty(vdat) || isempty(wdat))
                error('one argument is empty');
            elseif ((lv == lw) || (lv == 1) || (lw == 1))
                % data vectors are the same length, or one is a scalar - proceed
                % do it this way to accomodate NaN values: less than is less than or
                % equal to minus equal to
                l = 1 - abs(vdat - wdat) + max(0, wdat - vdat) - (1 - abs(vdat - wdat));
                fn = [v.fullname ' < ' w.fullname];
                B = boolean('data', l, 'fullname', fn);
            else
                % oops
                error('boolean variables being compared must have the same length');
            end

        end

        function B = ne(v, w)
            % NE (not equal to) operator for boolean objects.
            %
            % B = V ~= W
            % B = NE(V, W)
            %
            % B(i) is NaN whenever V(i) or W(i) is NaN.
            %
            % See also eq, ge, gt, le, lt.

            if isa(v, 'numeric')
                if eq(numel(v), 1)
                    % catch expressions like x+3
                    v = boolean('data', v, 'fullname', num2str(v));
                else
                    v = boolean('data', v, 'fullname', 'numeric');
                end
            else
                v = boolean(v);
            end

            if isa(w, 'numeric')
                if eq(numel(w), 1)
                    w = boolean('data', w, 'fullname', num2str(w));
                else
                    w = boolean('data', w, 'fullname', 'numeric');
                end
            else
                w = boolean(w);
            end

            vdat = v.data;
            wdat = w.data;
            lv = length(vdat);
            lw = length(wdat);

            % lengths must be the same, or one length must be 1; determine case
            if (isempty(vdat) || isempty(wdat))
                error('one argument is empty');
            elseif ((lv == lw) || (lv == 1) || (lw == 1))
                % data vectors are the same length, or one is a scalar - proceed

                l = abs(vdat - wdat);
                fn = [v.fullname ' ~= ' w.fullname];
                B = boolean('data', l, 'fullname', fn);
            else
                % oops
                error('boolean variables being compared must have the same length');
            end

        end

        function B = not(v)
            % NOT logical not for boolean objects.
            %
            % B =  ~V
            % B = NOT(V)
            %
            % B(i) is NaN whenever V(i) or W(i) is NaN.

            vdat = v.data;

            l = (1 - vdat);

            fn = ['~(' v.fullname ')'];
            B = boolean('data', l, 'fullname', fn);

        end

        function b = or(v, w)
            % OR logical or for boolean objects.
            %
            % B = V | W
            % B = OR(V, W)
            %
            % B(i) is NaN whenever V(i) or W(i) is NaN.
            %
            % See also boolean/and.

            if ~(isa(v, 'boolean') && isa(w, 'boolean'))
                error('both input arguments must be boolean');
            end

            vdat = v.data;
            wdat = w.data;
            lv = length(vdat);
            lw = length(wdat);

            % lengths must be the same, or one length must be 1; determine case
            if (isempty(vdat) || isempty(wdat))
                error('one argument is empty');
            elseif ((lv == lw) || (lv == 1) || (lw == 1))
                % data vectors are the same length, or one is a scalar - proceed

                % v6.5 compliant method
                l = (vdat + wdat) - vdat.*wdat;
                fn = [v.fullname ' | ' w.fullname];
                b = boolean('data', l, 'fullname', fn);
            else
                % oops
                error('boolean variables being compared must have the same length.');
            end

        end

        function B = xor(v, w)
            % XOR exclusive or for boolean objects.
            %
            % B = XOR(V, W)
            %
            % B(i) is NaN whenever V(i) or W(i) is NaN.
            %
            % See also or.

            if ~(isa(v, 'boolean') && isa(w, 'boolean'))
                error('input arguments must both be boolean');
            end

            vdat = v.data;
            wdat = w.data;
            lv = length(vdat);
            lw = length(wdat);

            % lengths must be the same, or one length must be 1; determine case
            if (isempty(vdat) || isempty(wdat))
                error('one argument is empty');
            elseif ((lv == lw) || (lv == 1) || (lw == 1))
                % data vectors are the same length, or one is a scalar - proceed

                % l = xor(vdat, wdat);
                % crucial to reset existing NaN's
                %l(isnan(vdat) | isnan(wdat)) = NaN;

                l = (vdat + wdat).*(1 - vdat.*wdat);

                fn = [v.fullname ' xor ' w.fullname];
                B = boolean('data', l, 'fullname', fn);
            else
                % oops
                error('boolean variables being compared must have the same length');
            end

        end

        function c = bool2cat(v)
            % BOOL2CAT - convert a boolean object to a categoric object.
            %
            % C = BOOL2CAT(B);
            %
            % The values of C are 0 and 1 with labels 'False' and 'True', respectively.

            c = categoric(...
                'data', v.data, ...
                'fullname', v.fullname, ...
                'values', [0 1], ...
                'labels', {'False', 'True'}, ...
                'rval', 1);

        end

    end

end


