function X = pmfrnd(varargin)
% PMFRND Random draws from a discrete probability distribution.
%
% X = PMFRND(x, p, N)
% X = PMFRND(x, p, N, M)
%
% Random draws X from the discrete probability mass function with
% probability p(i) on x(i). X is an Nx1 or NxM matrix of random draws.
% The values in x are arbitrary. The probabilities in p must sum to 1. 
%
% Example:
%
% X = PMFRND([1 2 3 4], [0.5 0.2 0.2 0.1], 10000)

inputs = options(varargin{:});

NM = inputs.N*inputs.M;

U = unifrnd(0, 1, 1, NM);
X = inputs.x(1)*ones(1, NM);
cdfp = cumsum(inputs.p);

lp = length(inputs.p);

for i = 1:lp-1
    X(U > cdfp(i) & U < cdfp(i + 1)) = inputs.x(i+1);
end

X = reshape(X, inputs.N, inputs.M);

%%%%
function inputs = options(varargin)
% helper function validates x, p, N, M input arguments

switch nargin
    case 2
        N = 1;
        M = 1;
    case 3
        N = varargin{3};
        M = 1;
    case 4
        N = varargin{3};
        M = varargin{4};
    otherwise
        error('Invalid number of input arguments.')
end

x = varargin{1};
p = varargin{2};

%%%
% validate x
%%%
if ~all(isreal(x) & isnumeric(x))
    error('x values must be numeric');
end
x = x(:);

%%%
% validate p
%%%
if ~all(isreal(p) & isnumeric(p))
    error('probabilities p must be numeric');
end
% values must lie between 0 and 1
if ~all(p>=0 & p<=1)
    error('probabilities p must lie between 0 and 1.0.');
end

p = p(:);
% values must sum to 1
if ~isapprox(sum(p), 1)
    error('The probability values p must sum to 1.0.');
end

if length(p)~=length(x)
    error('Length mismatch between x and p.');
end

%%%
% check N
%%%
if ~(isscalar(N) && isnumeric(N))
   error('N must be an integer')
end
if N<=0
    error('N must be a positive integer')
end
N = round(N);

%%%
% check M
%%%
if ~(isscalar(M) && isnumeric(M))
   error('M must be an integer')
end
if M<=0
    error('M must be a positive integer')
end
M = round(M);

%%%
% if you are here you are good to go
%%%
inputs = struct('x', x, 'p', p, 'N', N, 'M', M);

