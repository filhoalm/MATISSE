function RIC = jdoric(n, mink, maxk, a, b)
% JDORIC Unrestricted and restricted integer compositions of a target integer n.
%
% P = JDORIC(n, mink, maxk, a, b)
%
% n    - target integer
% mink - smallest number of partitions
% maxk - largest number of partitions
% a    - minimum number of summands
% b    - maximum number of summands


[~, m] = jdoriccomp(n, mink, maxk, a, b);
RIC = struct('n', n, 'mink', mink, 'maxk', maxk, 'a', a, 'b', b, ...
    'k', categoric('data', sum(~isnan(m), 2), 'fullname', 'Partitions'), ...
    'RIC', m);
