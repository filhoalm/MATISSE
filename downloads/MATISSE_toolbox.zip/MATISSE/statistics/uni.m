function S = uni(X)
% UNI Descriptive statistics for a vector or matrix by column.
%
% S = UNI(X)
%
% X can be double, tbl, or continuous.
%
% S is a tbl containing descriptive statistics by column.

switch class(X)
    case 'double'
        if isempty(inputname(1))
            X = tbl('data', X, 'fullname', 'numeric');
        else
            X = tbl('data', X, 'fullname', inputname(1));
        end

    case 'tbl'
        % good-to-go

    case 'continuous'
        if isempty(inputname(1))
            X = tbl('data', X.data, 'fullname', 'numeric');
        else
            X = tbl('data', X.data, 'fullname', X.fullname);
        end

    otherwise

        S = tbl;
        return
end

C = size(X.data, 2);
stats = zeros(11, C);
for c = 1:C
    stats(:, c) = uniStats(X.data(:, c));
end
rl = {'n', 'miss', 'mean', 'SD', 'SE', 'min', ...
    'q1', 'median', 'q2', 'max', 'sum'};

S = tbl(...
    'data', stats, ...
    'fullname', ['Univariate Statistics: ' X.fullname], ...
    'row_labels', rl, ...
    'col_labels', X.col_labels, ...
    'labels', X.labels);

%%%%%%%%%% helper function

function [stats] = uniStats(x)
% Helper function. Basic descriptive statistics for the data in vector x.

x = x(:);
N = length(x);
nmiss = sum(isnan(x));
n = N - nmiss;
sd = std(x, 'omitnan');
se = sd./sqrt(n);
stats = NaN*ones(11, 1);
stats([1 2], 1) = [n; nmiss];
if stats(1) > 0
    q = prctile(x,[25 75]);
    stats(3:11, 1) = [...
        mean(x, 'omitnan'); ...
        sd; ...
        se; ...
        min(x, [], 'omitnan'); ...
        q(1); ...
        median(x, 'omitnan'); ...
        q(2); ...
        max(x, [], 'omitnan'); ...
        sum(x, [], 'omitnan')];
end