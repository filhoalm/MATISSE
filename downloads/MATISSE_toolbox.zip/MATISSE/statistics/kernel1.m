function F = kernel1(varargin)
% KERNEL1 Univariate kernel operator for an evenly-spaced sequence of length N.
%
% F = KERNEL1(...)
%
% Property-value pairs:
%
% 'x'       - sequence of N equally-spaced values
% 'k'       - span for interior cells 3, 4, ..., N-3, N-2:
%                   odd integer >= 3 (default 3)
% 'k2'      - span for exterior cells 1, 2, N-1, N:
%                   odd integer >= 3 (default 'k')
% 'shape'   - 'boxcar' (default), 'epanechnikov', 'triangle', 'triweight'
% 'svd'     - compute SVD, 0/'off' (default) or 1/'on'
% 'inverse' - compute inv, 0/'off' (default) or 1/'on' (sets 'svd' to 1)
%
% Notes:
%
%    *  N >= 3
%    *  N >= 'k'
%    *  N >= 'k2'
%
% F is a structure array containing the kernel filter and related quantities.
%
% See also matrix/contrasts.

F = INPUTS(varargin{:});

N = F.N;

% Convert 'x' values to the standard sequence
%%%
XN = (F.x - F.x(1))/F.Delta;
xN = single(XN(:));


% tuned-up way to compute the distance^2 between every pair of cells
dr = single(repmat(xN, 1, N) - repmat(xN', N, 1));
F.EuclidD2 = (dr.^2);

% Identify the West and East outside neighbors of each cell that lie at a distance of
% exactly F.Lambda when F.Lambda =(F.k+1)/2. These cells get 0 weight. This is built into kernels
% that put zero weight on the boundary cells, e.g. the epanechnikov, but for the boxcar kernel we
% need to zero out the weights for these cells, because otherwise they would be included.
if F.equalk
    WE = (abs(dr)==F.Lambda);
else
    WE2 = (abs(dr)==F.LambdaOuter);
    WE1 = (abs(dr)==F.LambdaInner);
end

switch F.equalk

    case 1

        [k0, l0, ~] = find(F.EuclidD2 <= F.Lambda^2 & ~WE);
        linkl0 = k0 + (l0 - 1)*(F.N);
        s02 = double(F.EuclidD2(linkl0));

        switch F.shape

            case 'epanechnikov'
                v0 = (2/pi)*(1/F.Lambda)*(1/F.Lambda)*(1 - (s02./(F.Lambda.^2)));

            case 'boxcar'
                v0 = (1/F.Lambda)*(1/F.Lambda)*1;

            case 'triangle'
                v0 = (3/pi)*(1/F.Lambda)*(1/F.Lambda)*(1 - sqrt(s02)./F.Lambda);

            case 'triweight'
                v0 = (4/pi)*(1/F.Lambda)*(1/F.Lambda)*(1 - (s02./(F.Lambda.^2))).^3;

            otherwise
                % error
        end
        Kvals = sparse(k0, l0, v0, N, N);

    case 0

        [k0, l0, ~] = find(F.EuclidD2 <= F.LambdaOuter^2 & ~WE2);
        [k1, l1, ~] = find(F.EuclidD2 <= F.LambdaInner^2 & ~WE1);

        linkl0 = k0(:) + (l0(:) - 1)*N;
        linkl1 = k1(:) + (l1(:) - 1)*N;

        s02 = double(F.EuclidD2(linkl0));
        s12 = double(F.EuclidD2(linkl1));

        switch F.shape

            case 'epanechnikov'
                v0 = (2/pi)*(1/F.LambdaOuter)*(1/F.LambdaOuter)*(1 - (s02./(F.LambdaOuter.^2)));
                v1 = (2/pi)*(1/F.LambdaInner)*(1/F.LambdaInner)*(1 - (s12./(F.LambdaInner.^2)));

            case 'boxcar'
                v0 = (1/F.LambdaOuter)*(1/F.LambdaOuter)*ones(size(s02));
                v1 = (1/F.LambdaInner)*(1/F.LambdaInner)*ones(size(s12));

            case 'triangle'
                v0 = (3/pi)*(1/F.LambdaOuter)*(1/F.LambdaOuter)*(1 - sqrt(s02)./F.LambdaOuter);
                v1 = (3/pi)*(1/F.LambdaInner)*(1/F.LambdaInner)*(1 - sqrt(s12)./F.LambdaInner);

            case 'triweight'
                v0 = (4/pi)*(1/F.LambdaOuter)*(1/F.LambdaOuter)*(1 - (s02./(F.LambdaOuter.^2))).^3;
                v1 = (4/pi)*(1/F.LambdaInner)*(1/F.LambdaInner)*(1 - (s12./(F.LambdaInner.^2))).^3;


            otherwise
                % error
        end

        Kvals0 = sparse(k0, l0, v0, N, N);
        Kvals1 = sparse(k1, l1, v1, N, N);

        Kvals = spalloc(N, N, length(v0) + length(v1));
        Kvals([F.A1, F.A2], :) = Kvals0([F.A1, F.A2], :);
        Kvals(F.A3, :) = Kvals1(F.A3, :);

end

%%%
% Normalize kernel values over observations (rows)
%%%
SumKvals = sum(Kvals, 2);
F.K = Kvals.*repmat(1./SumKvals, 1, N);

if F.CalculateSVD
    [F.U, F.L, F.V] = svd(full(F.K));
    F.L = diag(F.L);
else
    F.U = NaN;
    F.L = NaN;
    F.V = NaN;
end

if F.CalculateInverse
    % if this is true, we have already calculated the SVD
    F.Rank = rank(full(F.K));
    F.Cond = cond(full(F.K));
    if F.Cond < 1E6
        F.iK = F.V*diag(1./F.L)*F.U';
    else
        F.iK = NaN;

    end
else
    F.Rank = NaN;
    F.Cond = NaN;
    F.iK = [];
end

end

function F = INPUTS(varargin)
% Helper. Process input variables and property-value pairs.

% default values
F = struct(...
    'parent', 'kernel1', ...
    'fullname', '', ...
    'N', [], ...
    'R', [], ...
    'C', 1, ...
    'x', 1, ...
    'xlabel', 'x', ...
    'x0', NaN, ...
    'Delta', NaN, ...
    'shape', 'boxcar', ...
    'shapeAbbr', 'box', ...
    'NumberAnnuliInGrid', NaN, ...
    'A1', NaN, ...
    'N1', NaN, ...
    'A2', NaN, ...
    'N2', NaN, ...
    'A3', NaN, ...
    'N3', NaN, ...
    'kMax', NaN, ...
    'k2', NaN, ...
    'k', 3, ...
    'equalk', NaN, ...
    'Lambda', NaN, ...
    'LambdaOuter', NaN, ...
    'LambdaInner', NaN, ...
    'EuclidD2', NaN, ...
    'K', NaN, ...
    'CalculateInverse', 0, ...
    'Rank', NaN, ...
    'Cond', NaN, ...
    'iK', [], ...
    'CalculateSVD', 0, ...
    'U', NaN, ...
    'L', NaN, ...
    'V', NaN);

lArgin = varargin(1:end);

Nl = numel(lArgin);

if eq(Nl, 1)
    error('The property you specified has no matching value.');
end

while Nl >= 1
    if eq(Nl, 1)
        error('a property has no matching value');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('a property must be specified by a string')
    end

    switch lower(propi)

        case 'x'
            switch class(vali)
                case 'double'
                    x = vali(:);
                    F.xlabel = 'x';
                case 'continuous'
                    x = vali.data;
                    F.xlabel = vali.fullname;
                otherwise
                    error('x must be a double or continuous.')
            end

            F.N = length(x);
            % x must be a non-decreasing evenly-spaced sequence
            if ~issorted(x)
                error('x must be a non-decreasing sequence')
            end

            F.x0 = x(1);
            F.x = x(:)';

        case 'shape'
            if ~ischar(vali)
                error('The Shape property-value must be a string.')
            end
            if size(vali, 1)>1
                error('The Shape property-value must be a string, not a character matrix.')
            end
            vals = {'epanechnikov', 'boxcar', 'triangle', 'triweight'};
            s = strcmpi(vali, vals);
            if ~any(s)
                error([vali ' is an unrecognized property-value.'])
            end
            F.shape = lower(vali);

            Abbr = {'Epan', 'box', 'trg', 'triwt'};
            F.shapeAbbr = Abbr{s};

        case 'k'
            % first see if this is a real scalar
            if ~(isscalar(vali) && isnumeric(vali))
                error('k must be a scalar > 0')
            end
            if vali < 0
                error('k must be > 0')
            end
            if rem(vali, 2)~=1
                error('k must be an odd integer')
            end
            F.k = vali;

        case 'k2'
            % first see if this is a real scalar
            if ~(isscalar(vali) && isnumeric(vali))
                error('k2 must be a scalar')
            end
            if vali < 0
                error('k2 must be > 0')
            end
            if rem(vali, 2)~=1
                error('k2 must be an odd integer')
            end
            F.k2 = vali;

        case 'inverse'
            if ~isscalar(vali)
                error('inverse must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('inverse must be 0 or 1')
            end
            F.CalculateInverse = vali;

        case 'svd'
             if ~isscalar(vali)
                error('svd must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('svd must be 0 or 1')
            end
            F.CalculateSVD = vali;

        otherwise

    end
end

% fill in k2 value if necessary
if isnan(F.k2)
    F.k2 = F.k;
end

% Make sure that F.N is greater than or equal to 3
if F.N < 3
    error('you must have 3 or more x-values')
end

F.Delta = F.x(2) - F.x(1);

if ~(F.N >= F.k)
    error(['grid is too small to support a ' num2str(F.k)  '-point bandwidth'])
end

if ~(F.N >= F.k2)
    error(['grid is too small to support a ' num2str(F.k2)  ...
        '-point bandwidth for the outer two values'])
end

% Calculate number of annuli in the grid.
F.NumberAnnuliInGrid = ceil((F.N)/2);

% F.kMax is the maximum span in terms of indices.
F.kMax = 2*F.NumberAnnuliInGrid - 1;

% Indices of outer annulus of the grid
F.A1 = [1 F.N];
F.N1 = 2;

% Indices of second and second-to-last
if F.N==3

    F.A2 = 2;
    F.N2 = 1;
    F.A3 = [];
    F.N3 = 0;

elseif F.N==4

    F.A2 = [2 3];
    F.N2 = 2;
    F.A3 = [];
    F.N3 = 0;

else

    F.A2 = [2 F.N-1];
    F.N2 = 2;
    F.A3 = 3 : F.N-2;
    F.N3 = F.N - 4;

end

% * F.k and F.k2 are the spans in terms of indices.
% * F.lambdaInner and F.LambdaOuter equal the spans in terms of index
%   values.
% * To find the corresponding spans in terms of the original units,
%   multiply the index span values by F.Delta

if F.k ~= F.k2
    F.equalk = 0;
    F.LambdaInner = (F.k+1)/2;
    F.LambdaOuter = (F.k2+1)/2;
    F.Lambda = NaN;
else
    F.equalk = 1;
    F.LambdaInner = (F.k+1)/2;
    F.LambdaOuter = (F.k2+1)/2;
    F.Lambda = (F.k+1)/2;
end

F.fullname = [num2str(F.k2) '-' num2str(F.k) '-' F.shape];

% If F.CalculateInverse is true, force F.CalculateSVD to be true, because
% the SVD is the best way to calculate the inverse
if F.CalculateInverse
    F.CalculateSVD = 1;
end

% for compatibility for now
F.R = F.N;

end

