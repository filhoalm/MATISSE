function D = rewire(KNOTS) 
% REWIRE - Reparameterize piEceWise lIneaR splinEs.
%
% A piecewise linear spline can be parameterized 4 ways:
%
% (1) standard:     spline value at 0, slope of segment 1, 
%                   slope of segment 2 minus slope of segment 1, etc.
%                   up to slope of segment K minus slope of segment K-1
% (2) value-slopes: spline value at 0, slope of segment 1, 
%                   slope of segment 2, etc., up to slope of segment K
% (3) values:       value of spline at x_(0), value of spline at x_(1),
%                   etc., up to value of spline at x_(K)
% (4) general:      K intercepts (value at 0 of segment 1, segment 2, etc.)
%                   followed by K slopes (slope of segment 1, segment 2, etc.)
% 
% You can go back and forth between forms using the contrast matrices in D: 
%
%      C12, C13, C14
%      C21, C23, C24
%      C31, C32, C34
%      C41, C42, C43
%
% where, Cij transforms from form (i) to form (j) 
%
% See also joinpoint/joinpoint.

KNOTS = unique(KNOTS(~isnan(KNOTS)));
K = length(KNOTS) - 1;
DELTA = KNOTS(2:end)-KNOTS(1:end-1);

% C12  standard to value-slopes
C12 = blkdiag(1, tril(ones(K)));

% C21 value-slopes to standard
C21 = blkdiag(1, diag(ones(K, 1), 0) - diag(ones(K-1, 1), -1));

% C23 - value-slopes to values
C23 = [ones(K+1, 1), KNOTS(1)*ones(K+1, 1), zeros(K+1, K-1)] + tril(ones(K+1, K+1)) * diag([0 DELTA]);

% C32 values to value-slopes
C32 = [ ...
    [1 + KNOTS(1)./DELTA(1), -KNOTS(1)./DELTA(1), zeros(1, K-1)]; ...                       % 1 intercept
    diag(1./DELTA) * (spdiags(ones(1, K), +1, K, K+1) - spdiags(ones(1, K), 0, K, K+1)) ... % K slopes
    ];

% C13 standard to values
C13 = C23*C12;

% C31 values to standard
C31 = C21*C32;

% C14 standard to general 
C14 = [ ...
    spdiags(ones(1, K), 0, K, K+1)*C13 - diag(KNOTS(1:K))*spdiags(ones(1, K), +1, K, K+1)*C12  % K intercepts
    spdiags(ones(1, K), +1, K, K+1)*C12 ...                                                    % K slopes
    ];

% C42 general to value-slopes
C42 = [[1, zeros(1, 2*K - 1)]; [zeros(K, K), eye(K, K)]];

% C41 general to standard
C41 = C21*C42;

% C24 value-slopes to general
C24 = C14*C21;

% C34 values to general
C34 = C14*C31;

% C43 general to values
C43 = C13*C41;

% Output all ways to transfrom between (1), (2), (3), and (4).

D = struct('KNOTS', KNOTS, ...
    'C12', C12, 'C13', C13, 'C14', C14, ...
    'C21', C21, 'C23', C23, 'C24', C24, ...
    'C31', C31, 'C32', C32, 'C34', C34, ...
    'C41', C41, 'C42', C42, 'C43', C43);

end
