function K = kernel(varargin)
% KERNEL Bivariate kernel operator for data sampled over a Cartesian grid.
% 
% K = kernel(...)
%
% 'y'       - R equally-spaced values along the y-axis
% 'x'       - C equally-spaced values along the x-axis
% 'k'       - span for interior cells: an odd integer >= 3 (default)
% 'k2'      - span for exterior cells: an odd interger >= 3 (default 'k')
% 'shape'   - 'boxcar' (default), 'epanechnikov', 'triangle', 'triweight'
% 'svd'     - compute SVD, 0 (false) or 1 (true, default)
% 'inv'     - compute inv, 0 (false, default) or 1 (true, also sets 'svd' to 1)
%
%    *  Spacing along the y and x axes must be the same
%    *  R and C must be >= 3
%    *  R and C must be >= all values of 'k' and 'k2'.
%
% See also panko.

K = INPUTS(varargin{:});

R = K.R;
C = K.C;
RC = R*C;

%%%
% Function fails when Delta ~= 1. x and y are just scores,
% not OK to just plug into meshgrid, because we need to work on the
% standard Cartesian grid. Fix: convert to the standard grid.
%%%
x0 = (K.x - K.x(1))/K.Delta;
y0 = (K.y - K.y(1))/K.Delta;

[XC, XR] = meshgrid(x0, y0);
xR = single(XR(:));
xC = single(XC(:));

% tuned-up way to compute the distance^2 between every pair of cells
dr = single(repmat(xR, 1, RC) - repmat(xR', RC, 1));
dc = single(repmat(xC, 1, RC) - repmat(xC', RC, 1));
K.EuclidD2 = (dr.^2 + dc.^2);

% Identify the North, South, West, and East outside neighbors of each cell that lie at a distance of
% exactly S.Lambda when S.Lambda =(S.k+1)/2. These cells get 0 weight. This is built into kernels
% that put zero weight on the boundary cells, e.g. the epanechnikov, but for the boxcar kernel we
% need to zero out the weights for these cells, because otherwise they would be included.
if K.equalk
    NSWE = (dr==0 & abs(dc)==K.Lambda) | (abs(dr)==K.Lambda & dc==0);
else
    NSWE2 = (dr==0 & abs(dc)==K.LambdaOuter) | (abs(dr)==K.LambdaOuter & dc==0);
    NSWE1 = (dr==0 & abs(dc)==K.LambdaInner) | (abs(dr)==K.LambdaInner & dc==0);
end

switch K.equalk

    case 1

        [k0, l0, ~] = find(K.EuclidD2 <= K.Lambda^2 & ~NSWE);
        linkl0 = k0 + (l0 - 1)*(R*C);
        s02 = double(K.EuclidD2(linkl0));

        switch K.shape

            case 'epanechnikov'
                v0 = (2/pi)*(1/K.Lambda)*(1/K.Lambda)*(1 - (s02./(K.Lambda.^2)));

            case 'boxcar'
                v0 = (1/K.Lambda)*(1/K.Lambda)*1;

            case 'triangle'
                v0 = (3/pi)*(1/K.Lambda)*(1/K.Lambda)*(1 - sqrt(s02)./K.Lambda);

            case 'triweight'
                v0 = (4/pi)*(1/K.Lambda)*(1/K.Lambda)*(1 - (s02./(K.Lambda.^2))).^3;

            otherwise

        end

        Kvals = sparse(k0, l0, v0, RC, RC);

    case 0

        [k0, l0, ~] = find(K.EuclidD2 <= K.LambdaOuter^2 & ~NSWE2);
        [k1, l1, ~] = find(K.EuclidD2 <= K.LambdaInner^2 & ~NSWE1);

        linkl0 = k0(:) + (l0(:) - 1)*(RC);
        linkl1 = k1(:) + (l1(:) - 1)*(RC);

        s02 = double(K.EuclidD2(linkl0));
        s12 = double(K.EuclidD2(linkl1));

        switch K.shape

            case 'epanechnikov'
                v0 = (2/pi)*(1/K.LambdaOuter)*(1/K.LambdaOuter)*(1 - (s02./(K.LambdaOuter.^2)));
                v1 = (2/pi)*(1/K.LambdaInner)*(1/K.LambdaInner)*(1 - (s12./(K.LambdaInner.^2)));

            case 'boxcar'
                v0 = (1/K.LambdaOuter)*(1/K.LambdaOuter)*ones(size(s02));
                v1 = (1/K.LambdaInner)*(1/K.LambdaInner)*ones(size(s12));

            case 'triangle'
                v0 = (3/pi)*(1/K.LambdaOuter)*(1/K.LambdaOuter)*(1 - sqrt(s02)./K.LambdaOuter);
                v1 = (3/pi)*(1/K.LambdaInner)*(1/K.LambdaInner)*(1 - sqrt(s12)./K.LambdaInner);

            case 'triweight'
                v0 = (4/pi)*(1/K.LambdaOuter)*(1/K.LambdaOuter)*(1 - (s02./(K.LambdaOuter.^2))).^3;
                v1 = (4/pi)*(1/K.LambdaInner)*(1/K.LambdaInner)*(1 - (s12./(K.LambdaInner.^2))).^3;

            otherwise
                % error
        end

        Kvals0 = sparse(k0, l0, v0, RC, RC);
        Kvals1 = sparse(k1, l1, v1, RC, RC);

        Kvals = spalloc(RC, RC, length(v0) + length(v1));
        Kvals([K.A1, K.A2], :) = Kvals0([K.A1, K.A2], :);
        Kvals(K.A3, :) = Kvals1(K.A3, :);

end

%%%
% Normalize kernel values over observations (rows)
%%%
SumKvals = sum(Kvals, 2);
K.K = Kvals.*repmat(1./SumKvals, 1, RC);

if K.CalculateSVD
    [K.U, K.L, K.V] = svd(full(K.K));
    K.L = diag(K.L);
else
    K.U = NaN;
    K.L = NaN;
    K.V = NaN;
end

if K.CalculateInverse
    % if this is true, we have already calculated the SVD
    K.Rank = rank(full(K.K));
    K.Cond = cond(full(K.K));
    if K.Cond < 1E6
        K.iK = K.V*diag(1./K.L)*K.U';
    else
        K.iK = NaN;

    end
else
    K.Rank = NaN;
    K.Cond = NaN;
    K.iK = [];
end

end

function S = INPUTS(varargin)
% Property-value pairs

% default values
S = struct(...
    'fullname', '', ...
    'y', 1, ...
    'ylabel', 'y', ...
    'R', 1, ...
    'y0', NaN, ...
    'x', 1, ...
    'xlabel', 'x', ...
    'C', 1, ...
    'x0', NaN, ...
    'Delta', NaN, ...
    'shape', 'boxcar', ...
    'shapeAbbr', 'box', ...
    'NumberAnnuliInGrid', NaN, ...
    'A1', NaN, ...
    'N1', NaN, ...
    'A2', NaN, ...
    'N2', NaN, ...
    'A3', NaN, ...
    'N3', NaN, ...
    'kMax', NaN, ...
    'k2', NaN, ...
    'k', 3, ...
    'equalk', NaN, ...
    'Lambda', NaN, ...
    'LambdaOuter', NaN, ...
    'LambdaInner', NaN, ...
    'EuclidD2', NaN, ...
    'K', NaN, ...
    'CalculateInverse', 0, ...
    'Rank', NaN, ...
    'Cond', NaN, ...
    'iK', [], ...
    'CalculateSVD', 1, ...
    'U', NaN, ...
    'L', NaN, ...
    'V', NaN);

lArgin = varargin(1:end);

Nl = numel(lArgin);

if eq(Nl, 1)
    error('a property has no matching value');
end

while Nl >= 1
    if eq(Nl, 1)
        error('a property has no matching value');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('property must be specified by a string')
    end

    switch lower(propi)

        case 'x'
            switch class(vali)
                case 'double'
                    x = vali(:);
                    S.xlabel = 'x';
                case 'continuous'
                    x = vali.data;
                    S.xlabel = vali.fullname;
                case 'tbl'
                    x = vali.data(:);
                    S.xlabel = vali.fullname;
                otherwise
                    error('x must be double, continuous, or tbl')
            end

            S.C = length(x);
            % x must be a non-decreasing evenly-spaced sequence
            if ~issorted(x)
                error('x must be a non-decreasing sequence')
            end
            if S.C > 1
                Deltax = uniquetol(diff(x), 1E-10);
                if length(Deltax)~=1
                    error('x must be an evenly-spaced sequence')
                end
            else
                Deltax = 1;
            end

            S.x0 = x(1);
            S.x = x(:)';

        case 'y'
            switch class(vali)
                case 'double'
                    y = vali(:);
                    S.ylabel = 'y';
                case 'continuous'
                    y = vali.data;
                    S.ylabel = vali.fullname;
                case 'tbl'
                    y = vali.data(:);
                    S.ylabel = vali.fullname;
                otherwise
                    error('y must be a double, continuous, or tbl')
            end

            S.R = length(y);

            % y must be a non-decreasing evenly-spaced sequence
            if ~issorted(y)
                error('y must be a non-decreasing sequence')
            end
            if S.R > 1
                Deltay = uniquetol(diff(y));
                if length(Deltay)~=1
                    error('y must be an evenly-spaced sequence')
                end
            else
                Deltay = 1;
            end

            S.y0 = y(1);
            S.y = y(:)';

        case 'shape'
            if ~ischar(vali)
                error('Shape property-value must be a string.')
            end
            if size(vali, 1)>1
                error('The Shape property-value must be a string, not a character matrix.')
            end
            vals = {'epanechnikov', 'boxcar', 'triangle', 'triweight'};
            s = strcmpi(vali, vals);
            if ~any(s)
                error([vali ' is an unrecognized property-value.'])
            end

            S.shape = lower(vali);
            Abbr = {'Epan', 'box', 'trg', 'triwt'};
            S.shapeAbbr = Abbr{s};

        case 'k'
            % first see if this is a real scalar
            if ~(isscalar(vali) && isnumeric(vali))
                error('k must be a scalar > 0')
            end
            if vali < 0
                error('k must be > 0')
            end
            if rem(vali, 2)~=1
                error('k must be an odd integer')
            end
            S.k = vali;

        case 'k2'
            % first see if this is a real scalar
            if ~(isscalar(vali) && isnumeric(vali))
                error('k2 must be a scalar')
            end
            if vali < 0
                error('k2 must be > 0')
            end
            if rem(vali, 2)~=1
                error('k2 must be an odd integer')
            end
            S.k2 = vali;


        case {'inv', 'inverse'}
            if ~isscalar(vali)
                error('inverse must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('inverse must be 0 or 1')
            end
            S.CalculateInverse = vali;


        case 'svd'
            if ~isscalar(vali)
                error('svd must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('svd must be 0 or 1')
            end
            S.CalculateSVD = vali;

        otherwise

    end
end

% fill in k2 value if necessary
if isnan(S.k2)
    S.k2 = S.k;
end

% Check that S.C and S.R are >=3, & Deltax and Deltay are equal
if S.C < 3
    error('you must have 3 or more x-values')
end
if S.R < 3
    error('you must have 3 or more y-values')
end

if ~(abs(Deltax - Deltay) <= 1E-6)
    error('increments along the x- and y-axes must be equal')
else
    S.Delta = Deltax;
end

if ~(S.R >= S.k && S.C >= S.k)
    error(['grid is too small to support a ' num2str(S.k)  '-point bandwidth'])
end

if ~(S.R >= S.k2 && S.C >= S.k2)
    error(['grid is too small to support a ' num2str(S.k2)  ...
        '-point bandwidth for the outer two annuli'])
end

% Calculate number of annuli in the grid.
S.NumberAnnuliInGrid = ceil(min(S.C, S.R)/2);

% S.kMax is the maximum span in terms of indices.
S.kMax = 2*S.NumberAnnuliInGrid - 1;

% Indices of outer annulus of the grid
S.A1 = [...
    1: 1: S.R, ...                                  % first column
    (S.R + 1) : S.R : ((S.C - 2)*S.R + 1), ...      % inside of first row
    ((S.C - 1)*S.R + 1) : 1 : S.R*S.C, ...          % last column
    (S.C - 1)*S.R : -S.R : 2*S.R];                  % inside of last row (in reverse)
S.N1 = length(S.A1);

% Indices of second outermost annulus of the grid.
% 4 cases: 3 x 3, 3 x >3, >3 x 3, >3 x >3
d = 1*(S.C > 3) + 2*(S.R > 3);

switch d

    case 0
        % 3 x 3
        S.A2 = 5;

    case 1
        % 3 x >3
        S.A2 = (2*S.R - 1) : S.R : ((S.C - 2)*S.R + 2);

    case 2
        % >3 x 3
        S.A2 = (S.R + 2) : 1 : (2*S.R - 1);

    case 3
        % >3 x >3
        S.A2 = [...
            (S.R + 2) : 1 : (2*S.R - 1), ...
            (2*S.R + 2) : S.R : ((S.C - 3)*S.R + 2), ...
            ((S.C - 2)*S.R + 2) : 1 : ((S.C - 1)*S.R - 1), ...
            ((S.C - 2)*S.R - 1) : -S.R : (3*S.R - 1)];

end
S.N2 = length(S.A2);

S.A3 = setdiff(1 : 1: S.R*S.C, [S.A1, S.A2]);
S.N3 = length(S.A3);

% * S.k and S.k2 are the spans in terms of indices.
% * S.lambdaInner and S.LambdaOuter equal the spans in terms of index values.
% * To find the corresponding spans in terms of the original units,
%   multiply the index span values by S.Delta

if S.k ~= S.k2
    S.equalk = 0;
    S.LambdaInner = (S.k+1)/2;
    S.LambdaOuter = (S.k2+1)/2;
    S.Lambda = NaN;
else
    S.equalk = 1;
    S.LambdaInner = (S.k+1)/2;
    S.LambdaOuter = (S.k2+1)/2;
    S.Lambda = (S.k+1)/2;

end

S.fullname = [num2str(S.k2) '-' num2str(S.k) '-' S.shapeAbbr];

% If S.CalculateInverse is true, force S.CalculateSVD to be true, because
% the SVD is the best way to calculate the inverse
if S.CalculateInverse
    S.CalculateSVD = 1;
end

end