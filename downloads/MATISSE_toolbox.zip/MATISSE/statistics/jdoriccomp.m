function [RIC, mRIC] = jdoriccomp(n, mink, maxk, a, b)
% JDORICCOMP Generate restricted and unrestricted integer compositions.
%
%   n    = integer to be partitioned
%   kmin = min. no. of summands
%   kmax = max. no. of summands
%   a    = min. value of summands
%   b    = max.value of summands
%
% from : "A Unified Approach to Algorithms Generating Unrestricted
%           and Restricted Integer Compositions and Integer Partitions"
%   J. D. OPDYKE, J. Math. Modelling and Algorithms (2009) V9 N1, p.53 - 97
%
% Matlab implementation:
% Theophanes E. Raptis, DAT-NCSRD 2010
% http://cag.dat.demokritos.gr
% rtheo@dat.demokritos.gr

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global RIC mRIC K;
cell0 = [];

NMAX = jdoriccount(n, mink, maxk, a, b);

RIC = cell(NMAX, 1);
mRIC = NaN(NMAX, maxk);
K = 0;

rowdec = 0;
for i=mink:maxk
    in = n/i;
    if a>1
        rowdec = i;
    end
    if a<=in && in <= b
        N2N(n,i,a,b,n-1-rowdec,i-1,0,0,cell0);
    end
end
end



function N2N(n,i,a,b,row,col,level,cumsum,cell0)
global RIC mRIC K ;

if col~=0
    if col==1
        jmax = max(a,n-cumsum-b);
        jmin = min(b,n-cumsum-a);
        for j=jmax : jmin
            cell0(i-1) = j; cell0(i) = n-cumsum-j;
            K = K + 1;
            RIC{K} = cell0;
            mRIC(K, 1:i) = cell0;
        end
    else
        cell0(level+1) = a;
        tmp = cumsum + a;
        ntmp = round((n - tmp)/(i-level-1));
        if a <= ntmp && ntmp <= b && cell0(level+1)
            N2N(n,i,a,b,row-a+1,col-1,level+1,tmp,cell0);
        else
            for q=1:min((b-a),(row-a)-(col-1))
                cell0(level+1) = cell0(level+1)+1;
                tmp = tmp + 1;
                ntmp = round((n - tmp)/(i-level-1));
                if a <= ntmp && ntmp <= b && cell0(level+1)
                    q2 = q; q = min((b-a),(row-a)-(col-1));
                    N2N(n,i,a,b,row-a-q2+1,col-1,level+1,tmp,cell0);
                end
            end
        end
    end
else
    K = K + 1; RIC{K} = n; 
    mRIC(K, 1) = n;
end
if level>0 && row>1
    cell0(level) = cell0(level)+1;
    cumsum = cumsum + 1;
    if cell0(level)<a
        cumsum = cumsum - cell0(level) + a;
        cell0(level) = a;
        row = row + cell0(level) - a;
    end
    toploop = min(b-cell0(level),row-col-1);
    npart = round((n-cumsum)/(i-level));
    if a<=npart && npart<=b && cell0(level)<=b
        N2N(n,i,a,b,row-1,col,level,cumsum,cell0);
    else
        for p=1:toploop
            cell0(level) = cell0(level)+1;
            cumsum = cumsum + 1;
            npart = round((n-cumsum)/(i-level));
            if a<=npart && npart<=b && cell0(level)<=b
                p2 = p; p = toploop;
                N2N(n,i,a,b,row-p2,col,level,cumsum,cell0);
            end
        end
    end
end
end