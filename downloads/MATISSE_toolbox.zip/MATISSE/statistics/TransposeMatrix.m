function T_RC = TransposeMatrix(R, C)
% TransposeMatrix Transposition tensor for an R x C matrix.
%
% TM = TransposeMatrix(R, C)
%

T_RC = ...
    ( kron( kron(ones(1, C), eye(R)), ones(C, 1)) ).* ...
    ( kron( ones(R, 1), kron(eye(C), ones(1, R))) );

end