function D = jpx(x, mink, maxk, a, b, COV)
% JPX Design matrices for joinpoint regression.
%
% D = JPX(x, mink, maxk, a, b, COV)
%
% * calculate an ensemble of design matrices for joinpoint analysis
%   using standard form (1)
% * x values must all be > 0
%
% * given mink <= K <= maxk
%   + each design matrix is defined w.r.t. K+1 joinpoints (or knots) selected 
%   + from the unique values x0 of x, indexed from 0:
%             x0(0) == min(x0), x0(1), ..., x0(K) == max(x0) 
%
%   > standard form (1) is b0 = value of segment 1 at 0 (intercept)
%                          b1 = slope in segment 1
%                          d1 = slope in segment 2 - slope in segment 1
%                          d2 = slope in segment 3 - slope in segment 2
%                           :
%                          dK = slope in segment K - slope in segment K-1
%
% * pre-compute W, W*X and inv(X'*WX) for permutation testing 
%
% INPUTS:
%
%           x - abscissas for joinpoint analysis
%        mink - smallest number of segments
%        maxk - largest number of segments
%           a - minimum number of abscissa values per segment
%           b - maximum number of abscissa values per segment
%         COV - covariance matrix
%
% OUTPUTS:
%           W - partition data
%           P - inverse of COV
%           X - design matrices for each partition
% 
% See also matrix/jpx, joinpoint.

x = x(:);
x0 = unique(x);
x0 = x0(~isnan(x0));

if isempty(x0)
    error('input variable ''x'' has too few unique elements')
end

D = struct('W', [], 'SQRTW', [], 'P', [], 'X', []);

try
    W = inv(COV);
    D.SQRTW = sqrtm(W);
catch
    W = pinv(COV);
    D.SQRTW = sqrtm(W);   
end

D.W = W;

n = length(x0);
D.P = jdoric(n, mink, maxk, a, b);

M = length(D.P.k.data);
k = D.P.k.data;
%%%
% Update mink and maxk because not all values were obtainable
%%%
D.P.mink = min(k);
D.P.maxk = max(k);

RIC = D.P.RIC;

parfor m = 1:M
    X(m) = jp0(x0, x, k(m), RIC(m, :), W)
end

D.X = X;

end

function d = jp0(x0, x, k, RIC, W)
% JP0 Single design matrix for a joinpoint analysis.

d = struct(...
    'joinpoints', [], ...
    'X', [], ...
    'WX', [], ...
    'IXWX', [], ...
    'IXWXWXT', []);
   
RIC = RIC(1:k);
N = length(x);
n = length(x0);

knots = [cumsum([1 RIC(1:k-1)]), n];

J = ones(N, 1);
s = x*ones(1,k - 1) - J*x0(knots(2:k))';
s = s.*(s>=0);
s = abs(s);

d.joinpoints = x0(knots)';

d.X = [J, x, s];
d.WX = W*d.X;
warning off
try
    d.IXWX = inv(d.X'*d.WX);
catch
    d.IXWX = pinv(d.X'*d.WX);
end
d.IXWXWXT = d.IXWX*d.WX';
warning on

end
