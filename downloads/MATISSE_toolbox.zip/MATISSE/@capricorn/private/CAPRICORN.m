function S = CAPRICORN(varargin)
% CAPRICORN CompArative age-PeRIod-COhoRt aNalysis.
%
% S = CAPRICORN(R1, R2, ..., RK)
% S = CAPRICORN(R1, R2, ..., RK, CapColors)
%
% R1, ..., RK are rates objects defined over the same Lexis diagram.
%
% CapColors is a K-vector of LineColor values 1 - 54 (1:K default)
%
% S is a structure with models, hypotheses test results, and AIC values.
%
% See also saffron, triptych, analects.

g = nargin;
if isa(varargin{g}, 'numeric')
    CapColors = varargin{g};
    G = g - 1;
    if ~(all(ismember(CapColors, 1:54)) && eq(numel(CapColors), G))
        error('invalid CapColor')
    end
else
    G = g;
    CapColors = 1:G;
end

% All the variables must be rates objects
R = varargin(1:G);
for c = 1:G
    if ~(isa(R{c}, 'rates'))
        error(['Input variable ' num2str(c) ' has class ' class(R{c}) ...
            ', must be a rates object.'])
    end
end

% All the rates objects must have the same dimensions as the first
[A, P] = size(R{1});

for i = 1:G
    [a, p] = size(R{i});
    if ~(A==a && P==p)
        error(['Input variable ' num2str(c) ' has size ' ...
            num2str(a) ' x ' num2str(p), ...
            ', must be ' num2str(A) ' x ' num2str(P) '.'])
    end

end

%%%
% Set up for the APC fits
%%%
D = vec(R{:});
L = geode(R{1});

%%%
% Joint Fits, PH Models
%%%

% Number of cells per Lexis Diagram
A = L.APC(1);
P = L.APC(2);
N = A*P;

% Number of strata modelled
G = length(D.strata.values);
I_G = eye(G);
J_G = ones(G, 1);

% fullname & labels for this analysis (use chromacodes)
fn = cell(1, G);
lb = cell(1, G);
lb{1} = R{1}.chromacode;
fn{1} = R{1}.chromacode;
for g = 2:G
        fn{g} = [' & ', R{g}.chromacode];
        lb{g} = R{g}.chromacode;
end
fn = [fn{:}];

%%%
% Separate APC models, full output, using Poisson regression for
% consistency between models.
%%%
apcM = cell(1, G);
for g = 1:G
    apcM{g} = apc(R{g}, 'Method', 'Poisson');
end

%%%
% NPH:
% * Separate models, joint fit
% * Equal components
%   -> none
% * Free components
%   -> all
%%%
X_N_F = kron(I_G, L.X);

%%%
% PH-L:
% * Cohort-specific age-specific rates are parallel
%   -> (i.e., diagonal slices of Lexis Diagrams)
% * LAT, age deviations, and period deviations are all equal
% * RR depends on NetDrift and cohort deviations
% * Equal components
%   -> 2, 4, 5, 7, 8
% * Free components
%   -> 1, 3, 6, 9
%%%
X_L_E = kron( J_G, L.X(:,[L.Pt{[2, 4, 5, 7, 8]}]) );
X_L_F = kron( I_G, L.X(:,[L.Pt{[1, 3, 6, 9   ]}]) );

%%%
% PH-T:
% * Age-specific rates over time are parallel
%   -> (i.e. horizontal slices of Lexis Diagrams)
% * NetDrift, period deviations, and cohort deviations are all equal
% * RR depends on LAT and age deviations
% * Equal components
%   -> 3, 5, 6, 8, 9
% * Free components
%   -> 1, 2, 4, 7
X_T_E = kron( J_G, L.X(:,[L.Pt{[3, 5, 6, 8, 9]}]) );
X_T_F = kron( I_G, L.X(:,[L.Pt{[1, 2, 4, 7   ]}]) );

%%%
% PH-X:
% * Cross-sectional age curves for each period are parallel
%   -> (i.e. vertical slices of Lexis Diagrams)
% * CAT, age deviations, and cohort deviations are all equal
% * RR depends on NetDrift and period deviations
% * Equal components
%   -> 2-3, 4, 6, 7, 9
% * Free components
%   -> 1, 2+3, 5 8
X_X_E = kron( J_G, [L.X(:, 2) - L.X(:, 3), L.X(:,[L.Pt{[4, 6, 7, 9]}])] );
X_X_F = kron( I_G, [L.X(:, 1), L.X(:, 2) + L.X(:, 3), L.X(:, [L.Pt{[ 5 8]}])] );

%%%
% PH-A
% * Cell-specific rates are parallel
%   -> (i.e. entire Lexis Diagrams)
% * All parameters are equal except for the intercept
% * Equal components
%   -> 2, 3, 4, 5, 6, 7, 8, 9
% * Free components
%   -> 1
X_A_E = kron( J_G, L.X(:,[L.Pt{[2, 3, 4, 5, 6, 7, 8, 9]}]) );
X_A_F = kron( I_G, L.X(:,1) );

warning off

%%%
% N-PH Model
%%%
[b_N, DEV_N, V_N, RESIDS_N, FV_N] = poisson(D.E, D.O, X_N_F);
p_N = length(b_N);

%%%
% PH Models
%%%
[b_L, DEV_L, V_L, RESIDS_L, FV_L] = poisson(D.E, D.O, [X_L_E, X_L_F]);
[b_T, DEV_T, V_T, RESIDS_T, FV_T] = poisson(D.E, D.O, [X_T_E, X_T_F]);
[b_X, DEV_X, V_X, RESIDS_X, FV_X] = poisson(D.E, D.O, [X_X_E, X_X_F]);
[b_A, DEV_A, V_A, RESIDS_A, FV_A] = poisson(D.E, D.O, [X_A_E, X_A_F]);

p_L = length(b_L);
p_T = length(b_T);
p_X = length(b_X);
p_A = length(b_A);

%%%
% Convention: The expanded order of the beta coefficients stacks full
% sets of APC coefficients, one full set per stratum
%%%
CM = tofu(A, P, G);

%%%
% NPH
%%%
Outputs.NPH = struct(...
    'eta', reshape(FV_N, A, P, G), ...
    'resids', reshape(RESIDS_N, A, P, G), ...
    'B', b_N, 'V', V_N, 'DEV', DEV_N);

%%%
% PH-L
%%%
Outputs.PHL = struct(...
    'eta', reshape(FV_L, A, P, G), ...
    'resids', reshape(RESIDS_L, A, P, G), ...
    'B', CM.L2N*b_L, 'V', CM.L2N*V_L*CM.L2N', 'DEV', DEV_L);

%%%
% PH-T
%%%
Outputs.PHT = struct(...
    'eta', reshape(FV_T, A, P, G), ...
    'resids', reshape(RESIDS_T, A, P, G), ...
    'B', CM.T2N*b_T, 'V', CM.T2N*V_T*CM.T2N', 'DEV', DEV_T);

%%%
% PH-X
%%%
Outputs.PHX = struct(...
    'eta',  reshape(FV_X, A, P, G), ...
    'resids', reshape(RESIDS_X, A, P, G), ...
    'B', CM.X2N*b_X, 'V', CM.X2N*V_X*CM.X2N', 'DEV', DEV_X);

%%%
% PH-A
%%%
Outputs.PHA = struct(...
    'eta', reshape(FV_A, A, P, G), ...
    'resids', reshape(RESIDS_A, A, P, G), ...
    'B', CM.A2N*b_A, 'V', CM.A2N*V_A*CM.A2N', 'DEV', DEV_A);

%%%
% Global PH Tests
% PH-L (G-1)*(A+P-3) df
% PH-T (G-1)*(A+2*P-4) df
% PH-X (G-1)*(2*A+P-4) df
% PH-A (G-1)*(2*(A+P)-5) df
%%%
tGLOBAL = [...
    DEV_L - DEV_N, p_N - p_L; ...
    DEV_T - DEV_N, p_N - p_T; ...
    DEV_X - DEV_N, p_N - p_X; ...
    DEV_A - DEV_N, p_N - p_A];
pGLOBAL = chi2cdf(tGLOBAL(:, 1), tGLOBAL(:, 2), 'upper');
PH_Global = tbl(...
    'data', [tGLOBAL, pGLOBAL], ...
    'fullname', 'PH Tests (Global)', ...
    'row_labels', {'PH-L', 'PH-T', 'PH-X', 'PH-A'}, ...
    'col_labels', {'Test', 'df', 'PVAL'});

%%%
% Raw and Corrected AIC
%%%
BIG = 10^10;
if G==1
    DEV = [BIG;     BIG;   BIG;   BIG; DEV_N];
else
    DEV = [DEV_L; DEV_T; DEV_X; DEV_A; DEV_N];
end

model_number = (1:5)';

model_df = [p_L; p_T; p_X; p_A; p_N];
bc_df = model_df + (model_df.*(model_df+1))./(N*G - model_df - 1);
aicc = DEV + 2*bc_df;

[~, rnk] = sort(aicc);
[~, irnk] = ismember((1:5)', rnk);

%%%
% Rescaled AIC
%%%
DELTA = aicc - aicc(rnk(1));
DATA = [model_df bc_df DEV aicc DELTA irnk model_number];
AIC = tbl(...
    'data', DATA, ...
    'fullname', 'AIC', ...
    'row_labels', {'PH-L', 'PH-T', 'PH-X', 'PH-A', 'N-PH'}, ...
    'col_labels', ...
    {'mdf', 'bcdf', 'DEV', 'AICc', 'DELTA', 'rank', 'model number'});

% Composite PH Tests

%%%
% PH-L:
% * Cohort-specific age-specific rates are parallel
%   -> (i.e., diagonal slices of Lexis Diagrams)
% * LAT, age deviations, and period deviations are all equal
% * RR depends on NetDrift and cohort deviations
% * Equal components
%   -> 2, 4, 5, 7, 8
%%%

X_a_F = kron(I_G, L.X);

x_2_E = kron(J_G, L.X(:, 2));
x_2_F = kron(I_G, L.X(:,[L.Pt{[ 1, 3, 4, 5, 6, 7, 8, 9 ]}]) );

x_4_E = kron(J_G, L.X(:, 4));
x_4_F = kron(I_G, L.X(:,[L.Pt{[ 1, 2, 3, 5, 6, 7, 8, 9 ]}]) );

x_5_E = kron(J_G, L.X(:, 5));
x_5_F = kron(I_G, L.X(:,[L.Pt{[ 1, 2, 3, 4, 6, 7, 8, 9 ]}]) );

x_7_E = kron(J_G, L.X(:, [L.Pt{ 7 }]) );
x_7_F = kron(I_G, L.X(:,[L.Pt{[ 1, 2, 3, 4, 5, 6, 8, 9 ]}]) );

x_8_E = kron(J_G, L.X(:, [L.Pt{ 8 }]) );
x_8_F = kron(I_G, L.X(:,[L.Pt{[ 1, 2, 3, 4, 5, 6, 7, 9 ]}]) );

%%%
% PH-T:
% * Age-specific rates over time are parallel
%   -> (i.e. horizontal slices of Lexis Diagrams)
% * NetDrift, period deviations, and cohort deviations are all equal
% * RR depends on LAT and age deviations
% * Equal components
%   -> 3, 5, 6, 8, 9
%%%

x_3_E = kron(J_G, L.X(:, 3));
x_3_F = kron(I_G, L.X(:,[L.Pt{[ 1, 2, 4, 5, 6, 7, 8, 9 ]}]) );

x_6_E = kron(J_G, L.X(:, 6));
x_6_F = kron(I_G, L.X(:,[L.Pt{[ 1, 2, 3, 4, 5, 7, 8, 9 ]}]) );

x_9_E = kron(J_G, L.X(:, [L.Pt{ 9 }]) );
x_9_F = kron(I_G, L.X(:,[L.Pt{[ 1, 2, 3, 4, 5, 6, 7, 8 ]}]) );

%%%
% PH-X:
% * Cross-sectional age curves for each period are parallel
%   -> (i.e. vertical slices of Lexis Diagrams)
% * CAT, age deviations, and cohort deviations are all equal
% * RR depends on NetDrift and period deviations
% * Equal components
%   -> 2-3, 4, 6, 7, 9
%%%

% Scores for the Cross-Sectional Age Trend (CAT)
x_2m3_E = kron( J_G, L.X(:, 2) - L.X(:, 3) );

% Added July 12 2018:
% Cross-sectional model includes period linear trend and not cohort linear trend
PLT = L.X(:, 2) + L.X(:, 3);
x_2m3_F = kron( I_G, [ L.X(:, 1), PLT, ...
    L.X(:,[L.Pt{[ 4, 5, 6, 7, 8, 9 ]}]) ] );

%%%
% Fit models
%%%
[b_a, DEV_a, ~, ~] = poisson(D.E, D.O, X_a_F);
p_a = length(b_a);

[b_2, DEV_2, ~, ~] = poisson(D.E, D.O, [x_2_E, x_2_F]);
p_2 = length(b_2);

[b_4, DEV_4, ~, ~] = poisson(D.E, D.O, [x_4_E, x_4_F]);
p_4 = length(b_4);

[b_5, DEV_5, ~, ~] = poisson(D.E, D.O, [x_5_E, x_5_F]);
p_5 = length(b_5);

[b_7, DEV_7, ~, ~] = poisson(D.E, D.O, [x_7_E, x_7_F]);
p_7 = length(b_7);

[b_8, DEV_8, ~, ~] = poisson(D.E, D.O, [x_8_E, x_8_F]);
p_8 = length(b_8);

[b_3, DEV_3, ~, ~] = poisson(D.E, D.O, [x_3_E, x_3_F]);
p_3 = length(b_3);

[b_6, DEV_6, ~, ~] = poisson(D.E, D.O, [x_6_E, x_6_F]);
p_6 = length(b_6);

[b_9, DEV_9, ~, ~] = poisson(D.E, D.O, [x_9_E, x_9_F]);
p_9 = length(b_9);

[b_2m3, DEV_2m3, ~, ~] = poisson(D.E, D.O, [x_2m3_E, x_2m3_F]);
p_2m3 = length(b_2m3);

warning on

%%%
% Composite Test: Components of PH-L
%%%
DV_PHL_2 = DEV_2 - DEV_a;
df_PHL_2 = p_a - p_2;
P_PHL_2 = chi2cdf(DV_PHL_2, df_PHL_2, 'upper');

DV_PHL_4 = DEV_4 - DEV_a;
df_PHL_4 = p_a - p_4;
P_PHL_4 = chi2cdf(DV_PHL_4, df_PHL_4, 'upper');

DV_PHL_5 = DEV_5 - DEV_a;
df_PHL_5 = p_a - p_5;
P_PHL_5 = chi2cdf(DV_PHL_5, df_PHL_5, 'upper');

DV_PHL_7 = DEV_7 - DEV_a;
df_PHL_7 = p_a - p_7;
P_PHL_7 = chi2cdf(DV_PHL_7, df_PHL_7, 'upper');

DV_PHL_8 = DEV_8 - DEV_a;
df_PHL_8 = p_a - p_8;
P_PHL_8 = chi2cdf(DV_PHL_8, df_PHL_8, 'upper');

%%%
% Composite Test: Components of PH-T
%%%
DV_PHT_3 = DEV_3 - DEV_a;
df_PHT_3 = p_a - p_3;
P_PHT_3 = chi2cdf(DV_PHT_3, df_PHT_3, 'upper');

DV_PHT_6 = DEV_6 - DEV_a;
df_PHT_6 = p_a - p_6;
P_PHT_6 = chi2cdf(DV_PHT_6, df_PHT_6, 'upper');

DV_PHT_9 = DEV_9 - DEV_a;
df_PHT_9 = p_a - p_9;
P_PHT_9 = chi2cdf(DV_PHT_9, df_PHT_9, 'upper');

%%%
% Composite Test: Components of PH-X
%%%
DV_PHX_2m3 = DEV_2m3 - DEV_a;
df_PHX_2m3 = p_a - p_2m3;
P_PHX_2m3 = chi2cdf(DV_PHX_2m3, df_PHX_2m3, 'upper');

%%%
% Put the pieces together
%%%
P_COMP_PHL = min(min(6*[P_PHL_2, P_PHL_4, P_PHL_5, ...
    P_PHL_7, P_PHL_8, pGLOBAL(1)]), 1);

P_COMP_PHT = min(min(6*[P_PHT_3, P_PHT_6, P_PHT_9, ...
    P_PHL_5, P_PHL_8, pGLOBAL(2)]), 1);

P_COMP_PHX = min(min(6*[P_PHX_2m3, P_PHL_4, P_PHL_7, ...
    P_PHT_6, P_PHT_9, pGLOBAL(3)]), 1);

P_COMP_PHA = min(min(10*[P_PHL_2, P_PHL_4, P_PHL_5, P_PHL_7, P_PHL_8, ...
    P_PHT_3, P_PHT_6, P_PHT_9, P_PHX_2m3, pGLOBAL(4)]), 1);

%%%
% PH Composite Tests
%%%
phcomptests = [...
    P_COMP_PHL 1 P_COMP_PHL; ...
    P_COMP_PHT 1 P_COMP_PHT; ...
    P_COMP_PHX 1 P_COMP_PHX; ...
    P_COMP_PHA 1 P_COMP_PHA];
%%%
% Parallel EF - Composite Tests
%%%
P_COMP_Par_LAC = min(min(3*[P_PHL_2, P_PHL_4, P_PHL_7]), 1);
P_COMP_Par_CAC = min(min(3*[P_PHX_2m3, P_PHL_4, P_PHL_7]), 1);
P_COMP_Par_FTT = min(min(3*[P_PHT_3, P_PHL_5, P_PHL_8]), 1);
P_COMP_Par_FCP = min(min(3*[P_PHT_3, P_PHT_6, P_PHT_9]), 1);

parcomptests = [...
    P_COMP_Par_LAC 1 P_COMP_Par_LAC; ...
    P_COMP_Par_CAC 1 P_COMP_Par_CAC; ...
    P_COMP_Par_FTT 1 P_COMP_Par_FTT; ...
    P_COMP_Par_FCP 1 P_COMP_Par_FCP];

Composite = tbl(...
    'data', [phcomptests; parcomptests], ...
    'fullname', 'Composite Tests', ...
    'row_labels', ...
    {'PH-L', 'PH-T', 'PH-X', 'PH-A', ...
    'Par-LAC', 'Par-CAC', 'Par-FTT', 'Par-FCP'}, ...
    'col_labels', {'Test', 'df', 'PVAL'});

%%%
% Homogeneity Tests
%%%
DEV = [...
    DEV_2; ...   LAT
    DEV_4; ...   theta_a
    DEV_5; ...   theta_p
    DEV_7; ...   Hi_a
    DEV_8; ...   Hi_p
    DEV_3; ...   Drift
    DEV_6; ...   theta_c
    DEV_9; ...   Hi_c
    DEV_2m3];  % CAT

model_df = ...
    [...
    p_2; ...
    p_4; ...
    p_5; ...
    p_7; ...
    p_8; ...
    p_3; ...
    p_6; ...
    p_9; ...
    p_2m3];

PVL = chi2cdf(DEV - DEV_a, p_a - model_df, 'upper');
DATA = [DEV-DEV_a p_a-model_df PVL];
Homogeneity = tbl(...
    'data', DATA, ...
    'fullname', 'Homogeneity Tests', ...
    'row_labels', {...
    '\color[rgb]{1.000  0.000  0.0000}LAT', ...
    '\color[rgb]{1.000  0.000  0.0000}Quad-Age', ...
    '\color[rgb]{0      0.000  1.0000}Quad-Per', ...
    '\color[rgb]{1.000  0.000  0.0000}HiOrd-Age', ...
    '\color[rgb]{0      0.000  1.0000}HiOrd-Per', ...
    '\color[rgb]{0      0.447  0.7410}NetDrift', ...
    '\color[rgb]{0      0.500  0.0000}Quad-Coh', ...
    '\color[rgb]{0      0.500  0.0000}HiOrd-Coh', ...
    '\color[rgb]{0.9216 0.4706 0.2784}CAT'}, ...
    'col_labels', {'DEV', 'df', 'PVAL'});
% Re-Order
Homogeneity = Homogeneity([9 8 7 6 5 3 1 4 2], :);

S = struct(...
    'Inputs', [], ...
    'Outputs', [], ...
    'Tests', [], ...
    'AIC', []);

S.Inputs = struct(...
    'APC', [A P A+P-1], ...
    'G', G, ...
    'CapColors', CapColors, ...
    'Title', [], ...
    'labels', [], ...
    'geode', L, ...
    'R', [], ...
    'apcM', []);

S.Inputs.Title = fn;
S.Inputs.labels = lb;
S.Inputs.apcM = apcM;
S.Inputs.R = R;

S.Outputs = Outputs;

S.Tests = struct(...
    'Homogeneity', Homogeneity, ...
    'Composite', Composite, ...
    'PH_Global', PH_Global);

S.AIC = AIC;

end

%%%
% Helper Functions
%%%

function [B, DEV, V, resids, ETA] = poisson(Y, O, X)
% Poisson regression.
%
% [B, DEV, V, resids, ETA] = poisson(Y, O, X)

[n, p0] = size(X);

% If X is rank deficient - perhaps the model is overparameterized? -
% issue and warning, remove aliased columns, force the corresponding
% beta coefficients, variances, and covariances to 0.

[~, UTFM, perm] = qr(full(X), 0);

rankX = sum(abs(diag(UTFM)) > abs(UTFM(1))*max(n, p0)*eps(class(UTFM)));
if rankX < p0
    warning('X is ill conditioned or the model is overparameterized')
    perm = perm(1:rankX);
    X0 = X(:, perm);
else
    X0 = X;
    perm = 1:p0;
end

r0 = Y./O;
B0 = X0\log(r0+0.1*(r0==0)); % changed from 0.5
DEV = Inf;
cycles = 1;
cnvg = 0;
maxiter = 40;

while cnvg==0 && cycles<=maxiter

    B00 = B0;

    DEV0 = DEV;

    cycle = glmcycle(B0, Y, O, X0);
    DEV = sum(cycle.devres);
    z = cycle.eta + (1./cycle.D).*(Y - cycle.u);
    % Weighted Regression
    WX0 = (cycle.W*ones(1,rankX)).*X0;
    B0 = (X0'*WX0)\(WX0'*z);
    if abs(DEV0 - DEV) <= 1E-10 || max(abs(B00 - B0)) < 1E-10
        cnvg = 1;
    end

    cycles = cycles + 1;

end

B = zeros(p0, 1);
B(perm, 1) = B0;

resids = sqrt(abs(cycle.devres)).*sign(Y - cycle.u);

V0 = inv(X0'*WX0);
V = zeros(p0, p0);
V(perm, perm) = V0;

ETA = cycle.eta;

end

function cycle = glmcycle(beta, Y, O, X)
% one iteration of weighted least squares algorithm for Poisson regression

eta = log(O) + X*beta;
u = exp(eta);
cycle.D = u;
cycle.V = u;
cycle.devres = 2*((Y.*log((Y+(Y==0))./(u+(u==0))) - (Y-u)));

% The generic GLM formula W = W.*(1./cycle.V).*cycle.D.^2 is prone to
% round-off errors: The specific formula for Poisson regression is not.
cycle.W = u;

cycle.u = u;
cycle.eta = (eta - log(O));

end

function CM = tofu(A, P, G)
% TOFU - Expand PH beta coefficients TO FUll form
%
% CM = tofu(A, P, G)
%
% A is number of age groups, P is number of calendar periods, G is number
% of strata.

M = 2*(A+P) - 4;

Pt_M = {1, 2, 3, 4, 5, 6, 7:(A+3), (A+4):(A+P), (A+P+1):M};

J_G = ones(G, 1);
I_G = eye(G);
S_M = (1:M)';

CM = struct('L2N', [], 'T2N', [], 'X2N', [], 'A2N', [], 'N2N', []);

%%%
% N-PH
%%%
CM.N2N = kron(J_G, speye(M));

%%%
% PH-L
%%%
Pt_E_PHL = [Pt_M{2}, Pt_M{4}, Pt_M{5}, Pt_M{7}, Pt_M{8}];
Pt_F_PHL = [Pt_M{1}, Pt_M{3}, Pt_M{6}, Pt_M{9}];

% Find Pt_E_PHL in S_M
E_PHL = zeros(M, A+P-3);
for i = 1:M
    for j = 1:(A+P-3)

        if S_M(i) == Pt_E_PHL(j)
            E_PHL(i, j) = 1;
        end


    end
end

% Find Pt_F_PHL in S_M
F_PHL = zeros(M, A+P-1);
for i = 1:M
    for j = 1:(A+P-1)

        if S_M(i) == Pt_F_PHL(j)
            F_PHL(i, j) = 1;
        end

    end
end

CM.L2N = [kron(J_G, E_PHL), kron(I_G, F_PHL)];

%%%
% PH-T
%%%
Pt_E_PHT = [Pt_M{3}, Pt_M{5}, Pt_M{6}, Pt_M{8}, Pt_M{9}];
Pt_F_PHT = [Pt_M{1}, Pt_M{2}, Pt_M{4}, Pt_M{7}];

% Find Pt_E_PHT in S_M
E_PHT = zeros(M, A+2*(P-2));
for i = 1:M
    for j = 1:(A+2*(P-2))

        if S_M(i) == Pt_E_PHT(j)
            E_PHT(i, j) = 1;
        end

    end
end

% Find Pt_F_PHT in S_M
F_PHT = zeros(M, A);
for i = 1:M
    for j = 1:A

        if S_M(i) == Pt_F_PHT(j)
            F_PHT(i, j) = 1;
        end

    end
end

CM.T2N = [kron(J_G, E_PHT), kron(I_G, F_PHT)];

%%%
% PH-X
%%%
% We must include Pt{2} and Pt{3} in each set
Pt_E_PHX = [Pt_M{2}, Pt_M{3}, Pt_M{4}, Pt_M{6}, Pt_M{7}, Pt_M{9}];
Pt_F_PHX = [Pt_M{1}, Pt_M{2}, Pt_M{3}, Pt_M{5}, Pt_M{8}];

% Find Pt_E_PHX in S_M
E_PHX = zeros(M, 2*A+P-3);
for i = 1:M
    for j = 1:(2*A+P-3)

        if S_M(i) == Pt_E_PHX(j)
            E_PHX(i, j) = 1;
        end


    end
end

% Find Pt_F_PHX in S_M
F_PHX = zeros(M, P + 1);
for i = 1:M
    for j = 1:(P+1)

        if S_M(i) == Pt_F_PHX(j)
            F_PHX(i, j) = 1;
        end


    end
end

%%%%
% Mirror the PHX design matrix
%%%%
E_PHX = [E_PHX(:, 1) - E_PHX(:, 2), E_PHX(:, 3:end)];
F_PHX = [F_PHX(:, 1), F_PHX(:, 2) + F_PHX(:, 3), F_PHX(:, 4:end)];

CM.X2N = [kron(J_G, E_PHX), kron(I_G, F_PHX)];

%%%
% PH-A
%%%
Pt_E_PHA = [Pt_M{2}, Pt_M{3}, Pt_M{4}, Pt_M{5}, Pt_M{6}, Pt_M{7}, Pt_M{8}, Pt_M{9}];
Pt_F_PHA = [Pt_M{1}];

% Find Pt_E_PHA in S_M
E_PHA = zeros(M, 2*(A+P)-5);
for i = 1:M
    for j = 1:(2*(A+P)-5)

        if S_M(i) == Pt_E_PHA(j)
            E_PHA(i, j) = 1;
        end

    end
end

% Find Pt_F_PHA in S_M
F_PHA = zeros(M, 1);
for i = 1:M
    for j = 1:1

        if S_M(i) == Pt_F_PHA(j)
            F_PHA(i, j) = 1;
        end

    end
end

CM.A2N = [kron(J_G, E_PHA), kron(I_G, F_PHA)];


end

