function G = GRADE(varargin)
% Plot gradients of Estimable Functions from comparative age-period-cohort analysis

pvp0 = ego('class', 'capricorn', 'method', 'grade');

switch nargin

    case 1
        S = varargin{1};
        Model = 'NPH';
        PVP = pvp0; 
        PVP.LineColor = S.Inputs.CapColors;

    case 2
        S = varargin{1};
        Model = upper(varargin{2});
        PVP = pvp0; 
        PVP.LineColor = S.Inputs.CapColors;
 
    case 3
        S = varargin{1};
        Model = upper(varargin{2});
        PVP = varargin{3};
        PVP.LineColor = S.Inputs.CapColors;
 
    otherwise
        error('too many inputs')
end

PVP = mascara(S.Inputs.G, PVP);

% compute six key EF
G.dftt = ef(S, 'comp', 'dftt', 'Model', Model);
G.dfcp = ef(S, 'comp', 'dfcp', 'Model', Model);
G.dlac = ef(S, 'comp', 'dlac', 'Model', Model);
G.dcac = ef(S, 'comp', 'dcac', 'Model', Model);

switch Model
    case 'PHL'
        Mod = '\bf{\color{red}PH-L:\color[rgb]{0 0 0}}\rm';
    case 'PHT'
        Mod = '\bf{\color{blue}PH-T:\color[rgb]{0 0 0}}\rm';
    case 'PHX'
        Mod = '\bf{\color[rgb]{0.9216 0.4706 0.2784}PH-X:\color[rgb]{0 0 0}}\rm';
    case 'PHA'
        Mod = '\bf{\color[rgb]{0.494  0.184  0.556}PH-A:\color[rgb]{0 0 0}}\rm';
    case 'NPH'
        Mod = '\bf{N-PH:}\rm';
end

figure('Position', [150 150 1000 750])

% force 'Legend' to true for the first panel
PVP.Legend = 1;

subplot(2, 2, 1)
plot(G.dftt, PVP)
set(gca, 'YGrid', 'on')

lh = findobj(gcf, 'Type', 'legend');
lh.Title.String = Mod;
lh.FontSize = PVP.FontSize(1);
lh.Box = 'off';
lh.Location = 'northeast';
OPOS = lh.Position;
NPOS = OPOS;
NPOS(2) = 1.05 * OPOS(2);
lh.Position = NPOS;

% force 'Legend' to false for all the remaining panels
PVP.Legend = 0;

subplot(2, 2, 2)
plot(G.dfcp, PVP)
set(gca, 'YGrid', 'on')

subplot(2, 2, 3)
plot(G.dlac, PVP)
set(gca, 'YGrid', 'on')

subplot(2, 2, 4)
plot(G.dcac, PVP)
set(gca, 'YGrid', 'on')

harmony(S.Inputs.geode)

end

%%% helper functions

function harmony(G)
% Harmonize axis limits across panels

ROT = -60;

for pan = 1:4
    subplot(2, 2, pan)
    switch pan
        case 1
            YL1 = get(gca, 'YLim');
        case 2
            YL2 = get(gca, 'YLim');
        case 3
            YL3 = get(gca, 'YLim');
        case 4
            YL4 = get(gca, 'YLim');
        otherwise
    end
end

% common y-axis limits for panels (1,2) and (3,4)
cYL12 = [min([ YL1(1), YL2(1)]), max([ YL1(2), YL2(2)])];
cYL34 = [min([ YL3(1), YL4(1)]), max([ YL3(2), YL4(2)])];

XL = G.XL([2 3 1 1]);
XT = G.XT([2 3 1 1]);

for pan = 1:4
    switch pan
        case {1, 2}
            subplot(2, 2, pan)
            set(gca, 'YLim', cYL12, ...
                'XLim', XL{pan}, ...
                'XTick', XT{pan}, ...
                'XTickLabelRotation', ROT)
        case {3, 4}
            subplot(2, 2, pan)
            set(gca, 'YLim', cYL34, ...
                'XLim', XL{pan}, ...
                'XTick', XT{pan}, ...
                'XTickLabelRotation', ROT)
        otherwise
    end
end

end

