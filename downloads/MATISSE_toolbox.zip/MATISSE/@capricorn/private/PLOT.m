function F = PLOT(varargin)
% Plot Estimable Functions from comparative age-period-cohort analysis

pvp0 = ego('class', 'capricorn', 'method', 'plot');

switch nargin

    case 1
        S = varargin{1};
        Model = 'NPH';
        PVP = pvp0; 
        PVP.LineColor = S.Inputs.CapColors;

    case 2
        S = varargin{1};
        Model = upper(varargin{2});
        PVP = pvp0;
        PVP.LineColor = S.Inputs.CapColors;

    case 3
        S = varargin{1};
        Model = upper(varargin{2});
        PVP = varargin{3};
        PVP.LineColor = S.Inputs.CapColors;

    otherwise
        error('too many inputs')
end

PVP = mascara(S.Inputs.G, PVP);

% compute six key EF
F.ftt = ef(S, 'comp', 'ftt', 'Model', Model);
F.fcp = ef(S, 'comp', 'fcp', 'Model', Model);
F.ld  = ef(S, 'comp', 'ld', 'Model', Model);
F.lac = ef(S, 'comp', 'lac', 'Model', Model);
F.cac = ef(S, 'comp', 'cac', 'Model', Model);
F.gs  = ef(S, 'comp', 'gs', 'Model', Model);

switch Model
    case 'PHL'
        Mod = '\bf{\color{red}PH-L:\color[rgb]{0 0 0}}\rm';
    case 'PHT'
        Mod = '\bf{\color{blue}PH-T:\color[rgb]{0 0 0}}\rm';
    case 'PHX'
        Mod = '\bf{\color[rgb]{0.9216 0.4706 0.2784}PH-X:\color[rgb]{0 0 0}}\rm';
    case 'PHA'
        Mod = '\bf{\color[rgb]{0.494  0.184  0.556}PH-A:\color[rgb]{0 0 0}}\rm';
    case 'NPH'
        Mod = '\bf{N-PH:}\rm';
end

% force 'Legend' to false until panel 4
PVP.Legend = 0;

figure('Position', [160 160 1000 750])

subplot(2, 3, 1)
plot(F.ftt, PVP)
set(gca, 'YGrid', 'on')

% force 'Legend' to false for all the remaining panels
PVP.Legend = 0;

subplot(2, 3, 2)
plot(F.fcp, PVP)
set(gca, 'YGrid', 'on')

subplot(2, 3, 3)
ax = gca;
plot(pc(F.ld), PVP)
ylabel('Local Drifts')
set(ax, 'YGrid', 'on')
ax.YAxis.TickLabelFormat = '%g\%';

subplot(2, 3, 4)
plot(F.lac, PVP)
set(gca, 'YGrid', 'on')

subplot(2, 3, 5)
plot(F.cac, PVP)
set(gca, 'YGrid', 'on')

PVP.Legend = 1;
subplot(2, 3, 6)
ax = gca;
plot(pc(F.gs), PVP)
ylabel('Gradient Shifts')
set(ax, 'YGrid', 'on')
ax.YAxis.TickLabelFormat = '%g\%';

lh = findobj(gcf, 'Type', 'legend');
lh.Title.String = Mod;
lh.FontSize = PVP.FontSize(1);
lh.Box = 'off';
lh.Location = 'east';
OPOS = lh.Position;
NPOS = OPOS;
NPOS(2) = 1.75 * OPOS(2);
lh.Position = NPOS;

harmony(S.Inputs.geode)

end

%%% helper functions

function harmony(G)
% Harmonize axis limits across panels

ROT = -60;

for i = 1:6
    subplot(2, 3, i)
    switch i
        case 1
            YL1 = get(gca, 'YLim');
        case 2
            YL2 = get(gca, 'YLim');
        case 4
            YL4 = get(gca, 'YLim');
        case 5
            YL5 = get(gca, 'YLim');
        otherwise
    end
end

cYL12 = [... % common y-axis limits for panels 1, 2
    min([ YL1(1), YL2(1)]), ...
    max([ YL1(2), YL2(2)])];
cYL45 = [... % common y-axis limits for panels 4, 5
    min([ YL4(1), YL5(1)]), ...
    max([ YL4(2), YL5(2)])];

XL = G.XL([2 3 1 1 1 2]);
XT = G.XT([2 3 1 1 1 2]);

for i = 1:6
    switch i
        case {1, 2}
            subplot(2, 3, i)
            set(gca, 'YLim', cYL12, ...
                'XLim', XL{i}, ...
                'XTick', XT{i}, ...
                'XTickLabelRotation', ROT)
            TMP = unique(log(max(1, unique(round(exp(get(gca, 'YTick')))))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

        case {4, 5}
            subplot(2, 3, i)
            set(gca, 'YLim', cYL45, ...
                'XLim', XL{i}, ...
                'XTick', XT{i}, ...
                'XTickLabelRotation', ROT)
            TMP = unique(log(max(1, unique(round(exp(get(gca, 'YTick')))))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

        case {3, 6}
            subplot(2, 3, i)
            set(gca, ...
                'XLim', XL{i}, ...
                'XTick', XT{i}, ...
                'XTickLabelRotation', ROT)
    
        otherwise
    end
end

end

