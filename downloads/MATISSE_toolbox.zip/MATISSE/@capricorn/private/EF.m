function [EF, DEF] = EF(S, varargin)
% EF - Estimable Functions from capricorn analysis.

L = S.Inputs.geode;
PVP = checkPVPAIRS(L, varargin{:});

A = L.APC(1);
P = L.APC(2);
G = S.Inputs.G;

N_APC = 2*(A+P)-4;
S_APC = (1:N_APC)';
I_G = speye(G);

% offset (log scale)
log_offset_tick = log(S.Inputs.R{1}.offset_tick);

switch PVP.Model

    case 'NPH'
        B = S.Outputs.NPH.B;
        V = S.Outputs.NPH.V;

    case 'PHL'
        B = S.Outputs.PHL.B;
        V = S.Outputs.PHL.V;

    case 'PHT'
        B = S.Outputs.PHT.B;
        V = S.Outputs.PHT.V;

    case 'PHX'
        B = S.Outputs.PHX.B;
        V = S.Outputs.PHX.V;

    case 'PHA'
        B = S.Outputs.PHA.B;
        V = S.Outputs.PHA.V;

end

%%%
% Compute X matrix for a single stratum
%%%
[X, PtX, y, l, rll, cll, lot] = calc(PVP, L, log_offset_tick);
N_PtX = numel(PtX);
N_X = size(X, 1);

%%%
% Extract EF within each strata
%%%

% find PtX in S_APC: this is the pattern for each Lexis diagram
Eg = zeros(N_APC, N_PtX);
for i = 1:N_APC
    for j = 1:N_PtX
        if S_APC(i) == PtX(j)
            Eg(i, j) = 1;
        end
    end
end

% G Lexis diagrams in all
E = kron(I_G, Eg');

GX = kron(I_G, X);

% Select B coefficients, then calculate the EF
GXE = GX * E;

% Convert from the vec of the stacked EF to a matrix of EF values, one
% column per stratum
ef = lot + GXE * B;
EF = reshape(ef, N_X, G);
% Annotate
T_EF = tbl(...
    'data', EF, ...
    'fullname', [PVP.Comp ' (' PVP.Model ')'], ...
    'labels', {rll, cll}, ...
    'row_labels', l, ...
    'col_labels', S.Inputs.labels);

% Delta method variance
V_EF = GXE * V * GXE';

% EF outputs consolidated in a matrix object
EF = matrix(...
    'data', T_EF, ...
    'COV', V_EF, ...
    'y', y, ...
    'x', 1:G, ...
    'Alpha', PVP.Alpha);

% Always the LAST strata is the baseline strata
D_G = [eye(G - 1), -ones(G - 1, 1)];
D_G_N = kron(D_G, eye(N_X));
def = D_G_N * ef;
DEF = reshape(def, N_X, G - 1);

%%%
% Special Case when PVP.Model is 'PHX' and PVP.Comp is 'gs'
%%%
if strcmp(PVP.Model, 'PHX') && strcmp(PVP.Comp, 'gs')
    DEF = zeros(N_X, G - 1);
end

%%%
% Special Case when PVP.Model is 'PHT' and PVP.Comp is 'ld'
%%%
if strcmp(PVP.Model, 'PHT') && strcmp(PVP.Comp, 'ld')
    DEF = zeros(N_X, G - 1);
end

% Annotate
dl = cell(1, G - 1);
for g = 1:G - 1
    dl{g} = [S.Inputs.labels{g} ' vs ' S.Inputs.labels{G}];
end
T_DEF = tbl(...
    'data', DEF, ...
    'fullname', [PVP.Comp ' (' PVP.Model ')'], ...
    'labels', {rll, cll}, ...
    'row_labels', l, ...
    'col_labels', dl);

V_DEF = D_G_N * V_EF * D_G_N';

% DEF outputs consolidated in a matrix object
DEF = matrix(...
    'data', T_DEF, ...
    'COV', V_DEF, ...
    'y', y, ...
    'x', 1:G-1);

end

%%%%%%%

function PVP = checkPVPAIRS(L, varargin)
% Helper function. Supply validated inputs to main procedure.

% default values
PVP = struct('Model', 'NPH', 'Comp', 'ld', 'RVals', [], 'Alpha', 0.05);

lArgin = varargin(1:end);
Nl = numel(lArgin);

while Nl >= 1
    if eq(Nl, 1)
        error('The last property has no matching value.');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('A property must be specified using a string.')
    end
    switch lower(propi)

        case 'model'
            if ~ischar(vali)
                error(['The Model property-value must be a string ' ...
                    'equal to ''NPH'', ''PHL'', ''PHT'', ''PHX'' or ''PHA''.'])
            end
            if size(vali, 1)>1
                error('The Model property-value must be a string, not a character matrix.')
            end

            % all the models
            vals = {'nph', 'phl', 'pht', 'phx', 'pha'};

            I = strcmpi(vali, vals);
            if ~any(I)
                error([vali ' is an unrecognized value.'])
            end
            PVP.Model = upper(vali);

        case 'comp'
            if ~ischar(vali)
                error('unrecognized component')
            end
            if size(vali, 1)>1
                error('component must be a string')
            end

            % supported components
            vals = {...
                'lac', 'cac', 'ftt', 'fcp', 'ld', 'gs', ...       % 'Block 1'
                'lac2', 'cac2', 'ftt2', 'fcp2', 'ld2', 'gs2', ... % 'Block 2'
                'ad', 'adh', 'ad2', ...                           % 'Block 3'
                'pd', 'pdh', 'pd2', ...                           %    "
                'cd', 'cdh', 'cd2' ...                            %    "
                'crr', 'prr', ...                                 % 'Block 4'
                'key', ...                                        % 'Block 5'
                'mpc', 'mac', ...                                 % 'Block 6'
                'dlac', 'dcac', 'dftt', 'dfcp', 'dmpc', 'dmac'};  % 'Block 7'

            I = strcmpi(vali, vals);
            if ~any(I)
                error([vali ' is an unrecognized component'])
            end
            PVP.Comp = lower(vali);

        case 'rvals'
            RVals = vali;
            if ~(isreal(RVals) && isnumeric(RVals))
                error('RVals must be numeric.');
            end
            % rule of 3
            if length(RVals)~=3
                error('You must specify a 3-vector of reference values for age, period, and cohort.');
            end
            PVP.RVals = RVals;

        case 'alpha'
            if ~(isscalar(vali) && isreal(vali))
                error('Alpha must be a real scalar')
            elseif (vali < 0 || vali > 1)
                error('Alpha must lie between 0 and 1')
            else
                PVP.Alpha = vali;
            end

        otherwise

    end

    if isempty(PVP.RVals) % DEFAULT

        A = L.APC(1);
        P = L.APC(2);
        % Floor function insures reference values occur in AGE, PER, and COH.
        aREF = floor((A+1)/2);
        pREF = floor((P+1)/2);
        cREF = pREF - aREF + A;
        ageref = L.AGE.values(aREF);
        perref = L.PER.values(pREF);
        cohref = L.COH.values(cREF);
        PVP.RVals = [ageref perref cohref];
        PVP.rVals = [aREF, pREF, cREF];

        PVP.Default_RVals = 1;

    else

        [TA, aREF] = ismember(PVP.RVals(1), L.AGE.values);

        [TB, pREF] = ismember(PVP.RVals(2), L.PER.values);

        [TC, cREF] = ismember(PVP.RVals(3), L.COH.values);

        if TA && TB && TC

            PVP.rVals = [aREF, pREF, cREF];
            PVP.Default_RVals = 0;

        else

            msg1 = '';
            msg2 = '';
            msg3 = '';
            if ~TA
                msg1 = 'Invalid referent age. ';
            end
            if ~TB
                msg2 = 'Invalid referent period. ';
            end
            if ~TC
                msg3 = 'Invalid referent cohort. ';
            end
            error([msg1, msg2, msg3])

        end
    end

end

end

function T_RC = TransposeMatrix(R, C)
% transposition tensor for an R x C matrix

T_RC = ...
    ( kron( kron(ones(1, C), speye(R)), ones(C, 1)) ).* ...
    ( kron( ones(R, 1), kron(speye(C), ones(1, R))) );

end

function [X, PtX, y, l, rll, cll, lot] = calc(PVP, L, log_offset_tick)
% contrast matrix and metadata for a single stratum

switch PVP.Comp

    %%%
    % Block 1: 'lac', 'cac', 'ftt', 'fcp', 'ld', 'gs'
    %%%

    case 'lac'

        J = ones(L.APC(1), 1);
        crefLOC = PVP.rVals(3);

        XA = L.X(L.INCa, [4, L.Pt{7}]);
        XCref = L.X(L.INCc(crefLOC), [6, L.Pt{9}]);

        astar = L.AGE.values';
        abar = mean(astar);

        cref = L.COH.values(crefLOC);
        cbar = mean(L.COH.values);

        X = [J (astar - abar) J*(cref - cbar) XA J*XCref];

        PtX = [1, 2, 3, 4, L.Pt{7}, 6, L.Pt{9}]';

        y = L.AGE.values(:);
        l = L.AGE.labels;
        rll = 'Age';
        cll = ['LAC (' num2str(cref) ')'];

        lot = log_offset_tick;

    case 'cac'

        J = ones(L.APC(1), 1);
        prefLOC = PVP.rVals(2);

        XA = L.X(L.INCa, [4, L.Pt{7}]);
        XPref = L.X(L.INCp(prefLOC), [5, L.Pt{8}]);

        astar = L.AGE.values';
        abar = mean(astar);

        pref = L.PER.values(prefLOC);
        pbar = mean(L.PER.values);

        X = [J (astar - abar) (J*(pref - pbar) -1*(astar - abar)) XA J*XPref];

        PtX = [1, 2, 3, 4, L.Pt{7}, 5, L.Pt{8}]';

        y = L.AGE.values(:);
        l = L.AGE.labels;
        rll = 'Age';
        cll = ['CAC (' num2str(pref) ')'];

        lot = log_offset_tick;

    case 'ftt'

        J = ones(L.APC(2), 1);
        arefLOC = PVP.rVals(1);

        XP = L.X(L.INCp, [5, L.Pt{8}]);
        XAref = L.X(L.INCa(arefLOC), [4, L.Pt{7}]);

        pstar = L.PER.values';
        pbar = mean(pstar);

        aref = L.AGE.values(arefLOC);
        abar = mean(L.AGE.values);

        X = [J J*(aref - abar) ((pstar - pbar) - J*(aref - abar)) XP J*XAref];

        PtX = [1, 2, 3, 5, L.Pt{8}, 4, L.Pt{7}]';

        y = L.PER.values(:);
        l = L.PER.labels;
        rll = 'Period';
        cll = ['FTT (' num2str(aref) ')'];

        lot = log_offset_tick;

    case 'fcp'

        J = ones(L.APC(3), 1);
        arefLOC = PVP.rVals(1);

        XC = L.X(L.INCc, [6, L.Pt{9}]);
        XAref = L.X(L.INCa(arefLOC), [4, L.Pt{7}]);

        cstar = L.COH.values';
        cbar = mean(cstar);

        aref = L.AGE.values(arefLOC);
        abar = mean(L.AGE.values);

        X = [J J*(aref - abar) (cstar - cbar) XC J*XAref];

        PtX = [1, 2, 3, 6, L.Pt{9}, 4, L.Pt{7}]';

        y = L.COH.values(:);
        l = L.COH.labels;
        rll = 'Cohort';
        cll = ['FCP (' num2str(aref) ')'];

        lot = log_offset_tick;

    case 'ld'

        A = L.APC(1);
        P = L.APC(2);
        C = L.APC(3);

        DELTA = L.AGE.values(2) - L.AGE.values(1);

        XC = L.X(L.INCc, [6, L.Pt{9}]);

        % contrast matrix to extract slopes of cohort deviations using a
        % sliding window with bandwidth P.
        JP = ones(P, 1);
        SP = (1:P)';
        pbars = (P+1)/2;
        DP = (12/(DELTA*(P-1)*P*(P+1)))*(SP - pbars*JP)';
        KAC = zeros(A, C);
        for ag = 1:A
            % starting at the first age group, you have the most recent set
            % of P cohorts
            i0 = 1+A-ag;
            i1 = 1+A-ag+P-1;
            KAC(ag, i0:i1) = DP;
        end

        JA = ones(A, 1);
        X = [KAC*XC JA];
        PtX = [6, L.Pt{9}, 3];

        y = L.AGE.values(:);
        l = L.AGE.labels;
        rll = 'Age';
        cll = 'Local Drifts';

        lot = 0;

    case 'gs'

        DELTA = L.PER.values(2) - L.PER.values(1);
        A = L.APC(1);
        P = L.APC(2);
        C = L.APC(3);
        JA = ones(A, 1);
        SA = (1:A)';
        abars = (A+1)/2;

        DA = (12/(DELTA*(A-1)*A*(A+1)))*(SA - abars*JA)';

        KPC = NaN(P, C);
        for pk = 1:P
            for ck = 1:C
                if ck >= 1 && ck < pk
                    KPC(pk, ck) = 0;
                elseif ck >= pk && ck <= pk+A-1
                    % Values are loaded in sequence {A, A-1, ..., 1}
                    KPC(pk, ck) = -DA(pk-ck+A);
                else
                    KPC(pk, ck) = 0;
                end
            end
        end

        JP = ones(P, 1);
        XC = L.X(L.INCc, [6, L.Pt{9}]);

        X = [-KPC*XC JP -JP];
        PtX = [6, L.Pt{9}, 2, 3];

        y = L.PER.values(:);
        l = L.PER.labels;
        rll = 'Period';
        cll = 'Gradient Shifts';

        lot = 0;

        %%%
        % Block 2: 'lac2', 'cac2', 'ftt2', 'fcp2', 'ld2', 'gs2'
        %%%

    case 'lac2'

        J = ones(L.APC(1), 1);
        crefLOC = PVP.rVals(3);

        XA = L.X(L.INCa, 4);
        XCref = L.X(L.INCc(crefLOC), [6, L.Pt{9}]);

        astar = L.AGE.values';
        abar = mean(astar);

        cref = L.COH.values(crefLOC);
        cbar = mean(L.COH.values);

        X = [J (astar - abar) J*(cref - cbar) XA J*XCref];

        PtX = [1, 2, 3, 4, 6, L.Pt{9}]';

        y = L.AGE.values(:);
        l = L.AGE.labels;
        rll = 'Age';
        cll = ['LAC (' num2str(cref) ')'];

        lot = log_offset_tick;

    case 'cac2'

        J = ones(L.APC(1), 1);
        prefLOC = PVP.rVals(2);

        XA = L.X(L.INCa, 4);
        XPref = L.X(L.INCp(prefLOC), [5, L.Pt{8}]);

        astar = L.AGE.values';
        abar = mean(astar);

        pref = L.PER.values(prefLOC);
        pbar = mean(L.PER.values);

        X = [J (astar - abar) (J*(pref - pbar) -1*(astar - abar)) XA J*XPref];

        PtX = [1, 2, 3, 4, 5, L.Pt{8}]';

        y = L.AGE.values(:);
        l = L.AGE.labels;
        rll = 'Age';
        cll = ['CAC (' num2str(pref) ')'];

        lot = log_offset_tick;

    case 'ftt2'

        J = ones(L.APC(2), 1);
        arefLOC = PVP.rVals(1);

        XP = L.X(L.INCp, 5);
        XAref = L.X(L.INCa(arefLOC), [4, L.Pt{7}]);

        pstar = L.PER.values';
        pbar = mean(pstar);

        aref = L.AGE.values(arefLOC);
        abar = mean(L.AGE.values);

        X = [J J*(aref - abar) ((pstar - pbar) - J*(aref - abar)) XP J*XAref];

        PtX = [1, 2, 3, 5, 4, L.Pt{7}]';

        y = L.PER.values(:);
        l = L.PER.labels;
        rll = 'Period';
        cll = ['FTT (' num2str(aref) ')'];

        lot = log_offset_tick;

    case 'fcp2'

        J = ones(L.APC(3), 1);
        arefLOC = PVP.rVals(1);

        XC = L.X(L.INCc, 6);
        XAref = L.X(L.INCa(arefLOC), [4, L.Pt{7}]);

        cstar = L.COH.values';
        cbar = mean(cstar);

        aref = L.AGE.values(arefLOC);
        abar = mean(L.AGE.values);

        X = [J J*(aref - abar) (cstar - cbar) XC J*XAref];

        PtX = [1, 2, 3, 6, 4, L.Pt{7}]';

        y = L.COH.values(:);
        l = L.COH.labels;
        rll = 'Cohort';
        cll = ['FCP (' num2str(aref) ')'];

        lot = log_offset_tick;

    case 'ld2'

        A = L.APC(1);
        P = L.APC(2);
        C = L.APC(3);

        DELTA = L.AGE.values(2) - L.AGE.values(1);

        XC = L.X(L.INCc, 6);

        % contrast matrix to extract slopes of cohort deviations using a
        % sliding window with bandwidth P.
        JP = ones(P, 1);
        SP = (1:P)';
        pbars = (P+1)/2;
        DP = (12/(DELTA*(P-1)*P*(P+1)))*(SP - pbars*JP)';
        KAC = zeros(A, C);
        for ag = 1:A
            % starting at the first age group, you have the most recent set
            % of P cohorts
            i0 = 1+A-ag;
            i1 = 1+A-ag+P-1;
            KAC(ag, i0:i1) = DP;
        end

        JA = ones(A, 1);
        X = [KAC*XC JA];
        PtX = [6, 3];

        y = L.AGE.values(:);
        l = L.AGE.labels;
        rll = 'Age';
        cll = 'Local Drifts';

        lot = 0;

    case 'gs2'

        DELTA = L.PER.values(2) - L.PER.values(1);
        A = L.APC(1);
        P = L.APC(2);
        C = L.APC(3);
        JA = ones(A, 1);
        SA = (1:A)';
        abars = (A+1)/2;

        DA = (12/(DELTA*(A-1)*A*(A+1)))*(SA - abars*JA)';

        KPC = NaN(P, C);
        for pk = 1:P
            for ck = 1:C
                if ck >= 1 && ck < pk
                    KPC(pk, ck) = 0;
                elseif ck >= pk && ck <= pk+A-1
                    % Values are loaded in sequence {A, A-1, ..., 1}
                    KPC(pk, ck) = -DA(pk-ck+A);
                else
                    KPC(pk, ck) = 0;
                end
            end
        end

        JP = ones(P, 1);
        XC = L.X(L.INCc, 6);

        X = [-KPC*XC JP -JP];
        PtX = [6, 2, 3];

        y = L.PER.values(:);
        l = L.PER.labels;
        rll = 'Period';
        cll = 'Gradient Shifts';

        lot = 0;

        %%%
        % Block 3: 'ad', 'adh', 'ad2', 'pd', 'pdh', 'pd2', 'cd', 'cdh', 'cd2'
        %%%

    case 'ad'

        PtX = [L.Pt{4}, L.Pt{7}]';
        X = L.X(L.INCa, PtX);

        y = L.AGE.values(:);
        l = L.AGE.labels;
        rll = 'Age';
        cll = 'Age Deviations';

        lot = 0;

    case 'adh'

        PtX = [L.Pt{7}]';
        X = L.X(L.INCa, PtX);

        y = L.AGE.values(:);
        l = L.AGE.labels;
        rll = 'Age';
        cll = 'Hi-Ord Age Deviations';

        lot = 0;

    case 'ad2'

        PtX = [L.Pt{4}]';
        X = L.X(L.INCa, PtX);

        y = L.AGE.values(:);
        l = L.AGE.labels;
        rll = 'Age';
        cll = 'Quadratic Age Deviations';

        lot = 0;


    case 'pd'

        PtX = [L.Pt{5}, L.Pt{8}]';
        X = L.X(L.INCp, PtX);

        y = L.PER.values(:);
        l = L.PER.labels;
        rll = 'Period';
        cll = 'Period Deviations';

        lot = 0;

    case 'pdh'

        PtX = [L.Pt{8}]';
        X = L.X(L.INCp, PtX);

        y = L.PER.values(:);
        l = L.PER.labels;
        rll = 'Period';
        cll = 'Hi-Ord Period Deviations';

        lot = 0;

    case 'pd2'

        PtX = [L.Pt{5}]';
        X = L.X(L.INCp, PtX);

        y = L.PER.values(:);
        l = L.PER.labels;
        rll = 'Period';
        cll = 'Quadratic Period Deviations';

        lot = 0;

    case 'cd'

        PtX = [L.Pt{6}, L.Pt{9}]';
        X = L.X(L.INCc, PtX);

        y = L.COH.values(:);
        l = L.COH.labels;
        rll = 'Cohort';
        cll = 'Cohort Deviations';

        lot = 0;

    case 'cdh'

        PtX = [L.Pt{9}]';
        X = L.X(L.INCc, PtX);

        y = L.COH.values(:);
        l = L.COH.labels;
        rll = 'Cohort';
        cll = 'Hi-Ord Cohort Deviations';

        lot = 0;

    case 'cd2'

        PtX = [L.Pt{6}]';
        X = L.X(L.INCc, PtX);
        y = L.COH.values(:);
        l = L.COH.labels;
        rll = 'Cohort';
        cll = 'Quadratic Cohort Deviations';

        lot = 0;

        %%%
        % Block 4: crr, prr
        %%%

    case 'crr'

        C = L.APC(3);
        crefLOC = PVP.rVals(3);
        TMP = zeros(C, C);
        TMP(:, crefLOC) = 1;
        CRR = eye(C) - TMP;
        PtX = [3 6 L.Pt{9}];
        X = CRR*L.X(L.INCc, PtX);

        y = L.COH.values(:);
        cref = y(crefLOC);
        l = L.COH.labels;
        rll = 'Cohort';
        cll = ['CRR (' num2str(cref) ')'];

        lot = 0;

    case 'prr'

        P = L.APC(2);
        prefLOC = PVP.rVals(2);
        TMP = zeros(P, P);
        TMP(:, prefLOC) = 1;
        PRR = eye(P) - TMP;
        PtX = [3 5 L.Pt{8}];
        X = PRR*L.X(L.INCp, PtX);

        y = L.PER.values(:);
        pref = y(prefLOC);
        l = L.PER.labels;
        rll = 'Period';
        cll = ['PRR (' num2str(pref) ')'];

        lot = 0;

        %%%
        % Block 5: key parameters
        %%%

    case 'key'
        X = [...
            1  0  0  0  0  0;...   % Intercept
            0  1  0  0  0  0;...   % LAT
            0  0  1  0  0  0;...   % NetDrift
            0  1 -1  0  0  0;...   % CAT
            0  0  0  1  0  0;...   % THETAa
            0  0  0  0  1  0;...   % THETAp
            0  0  0  0  0  1];     % THETAc

        PtX = 1:6;
        y = (1:7)';
        l = {'Intercept', 'LAT', 'NetDrift', 'CAT', 'THETAa', 'THETAp', 'THETAc'};
        rll = 'Key Parameters';
        cll = 'Coefficient';
        lot = 0;

        %%%
        % Block 6: 'mpc', 'mac'
        %%%

    case 'mpc'

        pstar = L.PER.values(:);
        pbar = mean(pstar);
        A = L.APC(1);
        P = L.APC(2);
        C = L.APC(3);

        XPQ = L.X(L.INCp, 5);
        XPD = L.X(L.INCp, L.Pt{8});
        XCD = L.X(L.INCc, L.Pt{9});

        %%%
        % 'slider' S(1/A * J_A, C)
        % apply to C-vector of high-order cohort deviations
        % pieces of the operator
        % T(C, C-A+1) = T(C, P)
        % J_(C-A)
        % w = (1/A) * ones(A, 1)
        % O_(C-A+1) = O(P, 1)
        %%%%

        TM = TransposeMatrix(C, P);
        J = ones(C-A, 1);
        W = (1/A) * ones(A, 1);
        O = zeros(P, 1);
        TMP1 = [kron(J, [W; O]); W];
        TMP2 = reshape(TMP1, C, P);
        TMP3 = TM * TMP2(:);
        SLIDER = reshape(TMP3, P, C);

        PtX = [1, 3, 5, 6, L.Pt{8}, L.Pt{9}]';
        X = [ones(P, 1) (pstar - pbar) XPQ XPQ XPD SLIDER * XCD];

        y = L.PER.values(:);
        l = L.PER.labels;
        rll = 'Period';
        cll = 'MPC';

        lot = log_offset_tick;

    case 'mac'

        astar = L.AGE.values(:);
        abar = mean(astar);
        A = L.APC(1);
        P = L.APC(2);
        C = L.APC(3);

        XAQ = L.X(L.INCa, 4);
        XAD = L.X(L.INCa, L.Pt{7});
        XCD = L.X(L.INCc, L.Pt{9});

        %%%
        % 'slider' S(1/P * J_P, C)
        % 'exchange matrix E(C)
        % apply to C-vector of high-order cohort deviations
        % pieces of the operator
        % T(C, C-P+1) = T(C, A)
        % J_(C-P)
        % w = (1/P) * ones(P, 1)
        % O_(C-P+1) = O(A, 1)
        %%%%
        EC = eye(C);
        EC = EC(C:-1:1, :);
        TM = TransposeMatrix(C, A);
        J = ones(C-P, 1);
        W = (1/P) * ones(P, 1);
        O = zeros(A, 1);
        TMP1 = [kron(J, [W; O]); W];
        TMP2 = reshape(TMP1, C, A);
        TMP3 = TM * TMP2(:);
        SLIDER = reshape(TMP3, A, C);

        X = [ones(A, 1) (astar - abar) -1*(astar - abar) XAQ XAQ XAD SLIDER * EC * XCD];

        PtX = [1, 2, 3, 4, 6, L.Pt{7}, L.Pt{9}]';

        y = L.AGE.values(:);
        l = L.AGE.labels;
        rll = 'Age';
        cll = 'MAC';

        lot = log_offset_tick;

        %%%
        % Block 7: 'dlac', 'dcac', 'dftt', 'dfcp', 'dmpc', 'dmac'
        %%%

    case 'dlac'

        A = L.APC(1);
        DELTA = L.AGE.values(2) - L.AGE.values(1);
        % Gradient Operator
        dA = (1/DELTA)*[eye(A-1), zeros(A-1, 1)]* ...
            ( diag(-1*ones(A, 1)) + diag(ones(A-1, 1), 1) );

        XA = L.X(L.INCa, L.Pt{7});

        dJ = ones(A - 1, 1);
        astar0 = L.AGE.values(2:A)';
        abar0 = mean(astar0);
        X = [dJ 2*(astar0 - abar0) dA*XA ];

        PtX = [2, 4, L.Pt{7}]';

        y = astar0;
        l = L.AGE.labels(2:A);
        rll = 'Age';
        cll = 'dLAC';

        lot = 0;

    case 'dcac'

        A = L.APC(1);
        DELTA = L.AGE.values(2) - L.AGE.values(1);
        % Gradient Operator
        dA = (1/DELTA)*[eye(A-1), zeros(A-1, 1)]* ...
            ( diag(-1*ones(A, 1)) + diag(ones(A-1, 1), 1) );

        XA = L.X(L.INCa, L.Pt{7});

        dJ = ones(A - 1, 1);
        astar0 = L.AGE.values(2:A)';
        abar0 = mean(astar0);
        X = [dJ -dJ 2*(astar0 - abar0) dA*XA ];

        PtX = [2, 3, 4, L.Pt{7}]';

        y = astar0;
        l = L.AGE.labels(2:A);
        rll = 'Age';
        cll = 'dCAC';

        lot = 0;

    case 'dftt'

        P = L.APC(2);
        DELTA = L.PER.values(2) - L.PER.values(1);
        % Gradient Operator
        dP = (1/DELTA)*[eye(P-1), zeros(P-1, 1)]* ...
            ( diag(-1*ones(P, 1)) + diag(ones(P-1, 1), 1) );

        XP = L.X(L.INCp, L.Pt{8});

        dJ = ones(P - 1, 1);
        pstar0 = L.PER.values(2:P)';
        pbar0 = mean(pstar0);
        X = [dJ 2*(pstar0 - pbar0) dP*XP ];

        PtX = [3, 5, L.Pt{8}]';

        y = pstar0;
        l = L.PER.labels(2:P);
        rll = 'Period';
        cll = 'dFTT';

        lot = 0;

    case 'dfcp'

        C = L.APC(3);
        DELTA = L.COH.values(2) - L.COH.values(1);
        % Gradient Operator
        dC = (1/DELTA)*[eye(C-1), zeros(C-1, 1)]* ...
            ( diag(-1*ones(C, 1)) + diag(ones(C-1, 1), 1) );

        XC = L.X(L.INCc, L.Pt{9});

        dJ = ones(C - 1, 1);
        cstar0 = L.COH.values(2:C)';
        cbar0 = mean(cstar0);
        X = [dJ 2*(cstar0 - cbar0) dC*XC ];

        PtX = [3, 6, L.Pt{9}]';

        y = cstar0;
        l = L.COH.labels(2:C);
        rll = 'Cohort';
        cll = 'dFCP';

        lot = 0;

    case 'dmpc'

        A = L.APC(1);
        P = L.APC(2);
        C = L.APC(3);
        DELTA = L.PER.values(2) - L.PER.values(1);

        XPD = L.X(L.INCp, L.Pt{8});
        XCD = L.X(L.INCc, L.Pt{9});

        %%%
        % 'slider' S(1/A * J_A, C)
        % apply to C-vector of high-order cohort deviations
        % pieces of the operator
        % T(C, C-A+1) = T(C, P)
        % J_(C-A)
        % w = (1/A) * ones(A, 1)
        % O_(C-A+1) = O(P, 1)
        %%%%

        TM = TransposeMatrix(C, P);
        J = ones(C-A, 1);
        W = (1/A) * ones(A, 1);
        O = zeros(P, 1);
        TMP1 = [kron(J, [W; O]); W];
        TMP2 = reshape(TMP1, C, P);
        TMP3 = TM * TMP2(:);
        SLIDER = reshape(TMP3, P, C);

        % Gradient Operator
        dP = (1/DELTA)*[eye(P-1), zeros(P-1, 1)]* ...
            ( diag(-1*ones(P, 1)) + diag(ones(P-1, 1), 1) );

        dJ = ones(P-1, 1);
        pstar0 = L.PER.values(2:P)';
        pbar0 = mean(pstar0);

        X = [dJ 2*(pstar0 - pbar0) 2*(pstar0 - pbar0) dP * XPD dP * SLIDER * XCD];
        PtX = [3, 5, 6, L.Pt{8}, L.Pt{9}]';

        y = L.PER.values(2:P)';
        l = L.PER.labels(2:P);
        rll = 'Period';
        cll = 'dMPC';

        lot = 0;

    case 'dmac'

        A = L.APC(1);
        P = L.APC(2);
        C = L.APC(3);
        DELTA = L.AGE.values(2) - L.AGE.values(1);

        XAD = L.X(L.INCa, L.Pt{7});
        XCD = L.X(L.INCc, L.Pt{9});

        %%%
        % 'slider' S(1/P * J_P, C)
        % 'exchange matrix E(C)
        % apply to C-vector of high-order cohort deviations
        % pieces of the operator
        % T(C, C-P+1) = T(C, A)
        % J_(C-P)
        % w = (1/P) * ones(P, 1)
        % O_(C-P+1) = O(A, 1)
        %%%%
        EC = eye(C);
        EC = EC(C:-1:1, :);
        TM = TransposeMatrix(C, A);
        J = ones(C-P, 1);
        W = (1/P) * ones(P, 1);
        O = zeros(A, 1);
        TMP1 = [kron(J, [W; O]); W];
        TMP2 = reshape(TMP1, C, A);
        TMP3 = TM * TMP2(:);
        SLIDER = reshape(TMP3, A, C);

        % Gradient Operator
        dA = (1/DELTA)*[eye(A-1), zeros(A-1, 1)]* ...
            ( diag(-1*ones(A, 1)) + diag(ones(A-1, 1), 1) );

        dJ = ones(A-1, 1);
        astar0 = L.AGE.values(2:A)';
        abar0 = mean(astar0);

        X = [dJ -dJ 2*(astar0 - abar0) 2*(astar0 - abar0) dA * XAD dA * SLIDER * EC * XCD];
        PtX = [2, 3, 4, 6, L.Pt{7}, L.Pt{9}]';

        y = L.AGE.values(2:A)';
        l = L.AGE.labels(2:A);
        rll = 'Age';
        cll = 'dMAC';

        lot = 0;

    otherwise

end

end


