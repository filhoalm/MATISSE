classdef capricorn
    % CAPRICORN capricorn objects contain a hypothesis-based comparative apc analysis.
    %
    % See https://pubmed.ncbi.nlm.nih.gov/37853346/ for details.
    %
    % Given K stratum-specific rates objects R1, ..., RK, CAPRICORN
    % determines whether the rates are jointly proportional by age, period,
    % or cohort.
    %
    % Proportionality imposes natural constraints on the Estimable
    % Functions (EFs). These constraints increase statistical efficiency
    % and simplify interpretation.
    % 
    % Conversely, lack of proportionality demonstrates that the rates are
    % significantly heterogeneous. 
    %
    % See also capricorn/capricorn, epiphany.

    properties

        Inputs struct = struct;      % K rates objects defined over the same Lexis diagram
        Outputs struct = struct;     % EFs with and without proportionality constraints
        Tests struct = struct;       % hypothesis tests
        AIC tbl = tbl;               % model selection results 
    
    end


    methods

        function S = capricorn(varargin)
            % CAPRICORN CompArative age-PeRIod-COhoRt aNalysis.
            %
            % S = CAPRICORN(R1, R2, ..., RK)
            % S = CAPRICORN(R1, R2, ..., RK, CapColors)
            %
            % R1, ..., RK are rates objects defined over the same Lexis diagram.
            %
            % CapColors is a K-vector of LineColor values 1 - 54 (1:K default)
            %
            % S contains Inputs, Outputs, Tests, and AIC results.
            %
            % See also: stem, ef, plot.

            if nargin == 0
                % contents of an empty capricorn analysis
                S.Inputs = struct;
                S.Outputs = struct;
                S.Tests = struct;
                S.AIC = tbl;
                return
            end

            if isa(varargin{1}, 'capricorn')
                S = varargin{1};
                return
            end

            % Contents of an empty capricorn analysis
            S.Inputs = struct(...
                'APC', [], ...
                'G', [], ...
                'CapColors', [], ...
                'Title', [], ...
                'Label', [], ...
                'labels', [], ...
                'geode', [], ...
                'R', [], ...
                'apcM', []);
            S.Outputs = struct('NPH', [], 'PHL', [], 'PHT', [], 'PHX', [], 'PHA', [], 'model', []);
            S.Tests = struct('Homogeneity', tbl, 'Composite', tbl, 'PH_Global', tbl);
            S.AIC = tbl;

            N = numel(varargin);

            if N == 0
                return
            end

            % analyze the data . . .
            s = CAPRICORN(varargin{:});
            S.Inputs = s.Inputs;
            S.Outputs = s.Outputs;
            S.Tests = s.Tests;
            S.AIC = s.AIC;

        end

        function varargout = ef(S, varargin)
            % EF - Estimable Functions from capricorn analysis.
            %
            % [F, D] = EF(S, 'Model', <value>, 'Comp', <value>, 'RVals', <value>, 'Alpha', <value>)
            %
            % Property-value pairs:
            %
            % 'Model'   -  'PHL', 'PHT', 'PHX', 'PHA', 'NPH' (default)
            %
            % 'Comp'    -   Value        Estimable Function
            %
            %                'lac'        Longitudinal Age Curve (LAC)
            %                'cac'        Cross-Sectional Age Curve (CAC)
            %                'ftt'        Fitted Temporal Trends (FTT)
            %                'fcp'        Fitted Cohort Pattern (FCP)
            %                'ld'         Local Drifts (LD)
            %                'gs'         Gradient Shifts (GS)
            %
            %                'lac2'       LAC, quadratic
            %                'cac2'       CAC, quadratic
            %                'ftt2'       FTT, quadratic
            %                'fcp2'       FCP, quadratic
            %                'ld2'        LD,  quadratic
            %                'gs2'        GS,  quadratic
            %
            %                'ad'         Age Deviations
            %                'adh'        HiOrd Age Deviations
            %                'ad2'        Quadratic Age Deviations
            %                'pd'         Period Deviations
            %                'pdh'        HiOrd Per Deviations
            %                'pd2'        Quadratic Per Deviations
            %                'cd'         Cohort Deviations
            %                'cdh'        HiOrd Coh Deviations
            %                'cd2'        Quadratic Coh Deviations
            %
            %                'crr'        Cohort Rate Ratios
            %                'prr'        Period Rate Ratios
            %
            %                'key'        key parameters
            %
            %                'mpc'        Marginal Period Curve (MPC)
            %                'mac'        Marginal Age Curve (MAC)
            %
            %                'dlac'       gradient of LAC
            %                'dcac'       gradient of CAC
            %                'dftt'       gradient of FTT
            %                'dfcp'       gradient of FCP
            %                'dmpc'       gradient of MPC
            %                'dmac'       gradient of MAC
            %
            % 'RVals'   -    3-vector (age, period, cohort)
            % 'Alpha'   -    0.05 (default)
            %
            % matrix outputs in F:
            %
            % F - estimable function (EF) values
            % D - differences of EF values for strata 1, 2, 3, ..., G-1 vs strata G
            %
            % See also plot.

            [F, D] = EF(S, varargin{:});

            switch nargout
                case {0, 1}
                    varargout{1} = F;
                case 2
                    varargout{1} = F;
                    varargout{2} = D;
                otherwise
                    error('too many outputs')
            end

        end

        function varargout = plot(S, varargin)
            % PLOT Plot Estimable Functions from capricorn analysis.
            %
            % PLOT(S)
            % PLOT(S, 'Model', go(...))
            % F = PLOT(...)
            %
            % 'Model' - 'NPH' (default), 'PHL', 'PHT', 'PHX', 'PHA'
            %
            % Six Estimable Functions are plotted
            %
            %      ftt, fcp, ld (top row)
            %      lac, cac, gs (bottom row)
            %
            % * plots use S.Inputs.CapColors as LineColor values
            % * other plot options obtain from go values
            % * F contains the data plotted
            %
            % See also ef.

            F = PLOT(S, varargin{:});
            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                otherwise
                    error('too many output variables')
            end

        end

        function varargout = star(S, varargin)
            % STAR Plot intenSiTy rAte Ratios from capricorn analysis.
            %
            % STAR(S)
            % STAR(S, 'Model')
            % STAR(S, 'Model', go(...))
            % I = STAR(...)
            %
            % 'Model' - 'NPH' (default), 'PHL', 'PHT', 'PHX', 'PHA'
            %
            % Six sets of intensity rate ratios are plotted
            %
            %      ftt, fcp, ld (top row)
            %      lac, cac, gs (bottom row)
            %
            % * plots use S.Inputs.CapColors as LineColor values
            % * other plot options obtain from go values
            % * I contains the data plotted
            %
            % See also plot.

            I = STAR(S, varargin{:});
            
            switch nargout
                case 0
                case 1
                    varargout{1} = I;
                otherwise
                    error('too many outputs')
            end

        end

        function varargout = grade(S, varargin)
            % GRADE Plot gradients of Estimable Functions from capricorn analysis.
            %
            % GRADE(S)
            % GRADE(S, 'Model')
            % GRADE(S, 'Model', go(...))
            % G = GRADE(...)
            %
            % 'Model' - 'NPH' (default), 'PHL', 'PHT', 'PHX', 'PHA'
            %
            % Four Estimable Function gradients are plotted
            %
            %      dftt, dfcp (top row)
            %      dlac, dcac (bottom row)
            %
            % * plots use S.Inputs.CapColors as LineColor values
            % * other plot options obtain from go values
            % * G contains the data plotted
            %
            % See also ef.

            G = GRADE(S, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = G;
                otherwise
                    error('too many outputs')
            end
        end

        function stem(S)
            % STEM Tests and AIC values from capricorn analysis.
            %
            % STEM(S)
            %
            % STEM produces a three-panel plot using preset go values.
            %
            % See also plot.

            STEM(S)

        end

        % end methods
    end
    % end classdef
end