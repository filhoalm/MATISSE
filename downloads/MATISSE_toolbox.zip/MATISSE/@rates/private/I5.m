function Ri5 = I5(R, varargin)
% RATES/I5 Interpolate rates for 5-year age groups down to 1-year age groups.
%
% Ri5 = I5(R)
% Ri5 = I5(R, 'Method', value)
%
% Property-value pairs:
%
% 'Method' - 'linear' (default) or 'cubic'.
%
% Interpolation is carried out separately for cumulative person-years and
% cumulative numbers of events within each period. 'linear' interpolation
% will match totals within 5 year age groups, but won't be as smooth as
% 'cubic'.

PVP = checkPVPAIRS(varargin{:});

P = size(R, 2);
a = R.ages';
sya = a(1):1:a(end);
A5 = length(sya) - 1;
ipy = NaN(A5, P);
iev = NaN(A5, P);

switch PVP.method

    case 'cubic'

        for p = 1:P
            py = R.Offset(:, p);
            ev = R.Events(:, p);
            ipypc = interp1(a, [0; cumsum(py)], sya, 'pchip');

            ipyp0 = max(0, diff(ipypc));
            ipy(:, p) = sum(py)*(ipyp0./sum(ipyp0));
            ievpc = interp1(a, [0; cumsum(ev)], sya, 'pchip');

            ievp0 = max(0, diff(ievpc));
            ievp0 = sum(ev)*(ievp0./sum(ievp0));
            iev(:, p) = ievp0;
        end

    case 'linear'

        for p = 1:P
            py = R.Offset(:, p);
            ev = R.Events(:, p);
            ipypc = interp1(a, [0; cumsum(py)], sya, 'linear');
            ipypc = max(0, ipypc);
        
            ipyp0 = max(0, diff(ipypc));
            ipy(:, p) = sum(py)*(ipyp0./sum(ipyp0));
            ievpc = interp1(a, [0; cumsum(ev)], sya, 'linear');
            ievpc = max(0, ievpc);
        
            ievp0 = max(0, diff(ievpc));
            iev(:, p) = ievp0;
        end

    otherwise
end


Ri5 = rates(...
    'Events', iev, ...
    'Offset', ipy, ...
    'fullname', R.fullname, ...
    'label', R.label, ...
    'chromacode', R.chromacode, ...
    'ages', sya, ...
    'periods', R.periods, ...
    'offset_tick', R.offset_tick, ...
    'offset_units', R.offset_units);

end

function [PVP] = checkPVPAIRS(varargin)
% Helper function. Validate property value pairs.

% code is set up if we want to add additional PVP
PVP = struct('method', 'linear');

lArgin = varargin;
Nl = numel(lArgin);

if eq(Nl, 1)
    error('incomplete property/value pair');
end

while Nl >= 2
    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    switch lower(propi)

        case 'method'
            if ~ischar(vali)
                error('''method'' must a be a string')
            end
            vali = lower(vali(1));
            switch vali
                case 'l'
                    PVP.method = 'linear';
                case 'c'
                    PVP.method = 'cubic';
                otherwise
                    error('method must be ''linear'' or ''cubic''')
            end

        otherwise
    end
end

end