function T = FTP(R, varargin)
% FTP helper for rates objects

Nl = numel(varargin);

switch Nl
    case 0
        PVP = ego('class', 'rates', 'method', 'ftp');
    case 1
        PVP = varargin{1};
    otherwise
        error('too many inputs')
end

warning off

DELa = R.a(2) - R.a(1);
DELp = R.p(2) - R.p(1);

if eq(DELa, DELp)
    SQUARE = 1;
    figure('Position', [100 200 1400 1000])
else
    SQUARE = 0;
    figure('Position', [100 200 1400 500 ])
end

switch SQUARE

    case 1

        subplot(2, 2, 1)
        T1 = salsa(R, 'rpa', PVP);
        title('\bfA\rm Rates vs Period by Age (\it{r_{p|a}}\rm)', 'FontSize', PVP.FontSize(3))

        subplot(2, 2, 2)
        T2 = salsa(R, 'rap', PVP);
        title('\bfB\rm Rates vs Age by Period (\it{r_{a|p}}\rm)', 'FontSize', PVP.FontSize(3))

        subplot(2, 2, 3)
        T3 = salsa(R, 'rca', PVP);
        title('\bfC\rm Rates vs Cohort by Age (\it{r_{c|a}}\rm)', 'FontSize', PVP.FontSize(3))

        subplot(2, 2, 4)
        T4 = salsa(R, 'rac', PVP);
        title('\bfD\rm Rates vs Age by Cohort (\it{r_{a|c}}\rm)', 'FontSize', PVP.FontSize(3))

    case 0

        subplot(1, 2, 1)
        T1 = salsa(R, 'rpa', PVP);
        title('\bfA\rm \it{r_{p|a}}', 'FontSize', PVP.FontSize(3))

        subplot(1, 2, 2)
        T2 = salsa(R, 'rap', PVP);
        title('\bfB\rm \it{r_{a|p}}', 'FontSize', PVP.FontSize(3))

        T3 = [];
        T4 = [];

end

T = {T1, T2, T3, T4};

warning on

harmony(R, SQUARE)

lh = findobj(gcf, 'Type', 'legend');
set(lh, ...
    'Location', 'eastoutside', ...
    'NumColumns', 1, ...
    'FontSize', PVP.FontSize(1))

end

function harmony(R, SQUARE)
% Harmonize axis limits across panels

G = geode(R);

A = G.APC(1);
P = G.APC(2);
C = A + P - 1;

a = G.AGE.values;
p = G.PER.values;
c = G.COH.values;

DELTAa = a(2) - a(1);
DELTAp = p(2) - p(1);
DELTAc = c(2) - c(1);

p = G.PER.values;
c = G.COH.values;
YLA = DELTAa*A;
YLP = DELTAp*P;
YLC = DELTAc*C;

dA = YLC - YLA;
dP = YLC - YLP;
dC = 0;

% tick management - hard-code as 5
XT1 = p(1) - DELTAp/2 : 5 : p(P) + DELTAp/2;
XT2 = a(1) - DELTAa/2 : 5 : a(A) + DELTAa/2;
XT3 = c(1) : 5 : c(C);
XT4 = XT2;

ROT = -60 * ones(1, 4);

switch SQUARE

    case 1

        XL = {...
            [p(1) p(P)] + [-dP, +dP]/2, ...
            [a(1) a(A)] + [-dA  +dA]/2, ...
            [c(1) c(C)] + [-dC  +dC]/2 + [-2 +2], ...
            [a(1) a(A)] + [-dA  +dA]/2};
        XT = {XT1, XT2, XT3, XT4};

        for i = 1:4
            subplot(2, 2, i)
            set(gca, ...
                'XLim', XL{i}, ...
                'XTick', XT{i}, ...
                'XTickLabelRotation', ROT(i))
        end

    case 0

        XL = {...
            [p(1) p(P)] + [-DELTAp, +DELTAp]/2, ...
            [a(1) a(A)] + [-DELTAa  +DELTAa]/2};

        r1 = range(XL{1});
        r2 = range(XL{2});
        [~, I] = max([r1 r2], [], 2);
        switch I
            case 1
                % period ranges > age ranges > adjust age ranges
                d = r1 - r2;
                XL{2} = XL{2} + [-d/2 +d/2];

            case 2
                % age ranges > period ranges > adjust period ranges
                d = r2 - r1;
                XL{1} = XL{1} + [-d/2 +d/2];
        end

        XT = {XT1, XT2};
        for i = 1:2
            subplot(1, 2, i)
            set(gca, ...
                'XLim', XL{i}, ...
                'XTick', XT{i}, ...
                'XTickLabelRotation', ROT(i))
        end

    otherwise

end


end

