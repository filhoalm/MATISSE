function G = GEODE(R)
% RATES/GEODE age-period-cohort design matrix

D = vec(R);
G = struct('APC', [], 'X', [], ...
    'Pt', [], 'INCa', [], 'INCp', [], 'INCc', [], 'nc', [], ...
    'AGE', D.AGE, 'age', D.age, 'PER', D.PER, 'per', D.per, 'COH', D.COH, 'coh', D.coh, ...
    'XT', [], ...
    'XL', []);

N = size(D, 1);
J = ones(N, 1);
eyeN = speye(N);
A = length(G.AGE.values);
P = length(G.PER.values);
C = A + P - 1;
G.APC = [A P C];

% Code contrasts for age, period, and cohort deviations

Ad = kron( ones(P, 1), speye(A) );
Pd = kron( speye(P), ones(A, 1) );

astar = G.age.data;
astarbar = mean(astar);
astar_0 = astar - astarbar;

pstar = G.per.data;
pstarbar = mean(pstar);
pstar_0 = pstar - pstarbar;

cstar = G.coh.data;
cstarbar = mean(cstar);
cstar_0 = cstar - cstarbar;

Cd = NaN(N, C);
for i = 1:C
    Cd(:, i) = (cstar == G.COH.values(i));
end

G.nc = diag(Cd'*Cd);

%%%
% Projection matrix orthogonal to intercept, linear age, and quadratic age
%%%
Delta = astar(2) - astar(1);
a00 = astar(1) - 0.5*Delta;

if A >= 3

    qa2 = astar.^2 - (Delta.*A + 2*a00).*astar + (a00 + Delta.*A./2).^2 - ((Delta.^2)./12).*(A-1).*(A+1);
    Xa2 = [ones(N, 1) astar_0 qa2];
    xtxi = (1/P)*diag( 1./[A, (Delta^2/12)*(A-1)*A*(A+1), (Delta^4/180)*(A-2)*(A-1)*A*(A+1)*(A+2)] );
    Ra2 = xtxi*Xa2';
    PA12 = Xa2*Ra2;
    XAD12 = eyeN - PA12;

else

    qa2 = zeros(N, 1);
    Xa2 = [ones(N, 1) astar_0 ];
    xtxi = (1/P)*diag( 1./[A, (Delta^2/12)*(A-1)*A*(A+1)] );
    Ra2 = xtxi*Xa2';
    PA12 = Xa2*Ra2;
    XAD12 = eyeN - PA12;

end

%%%
% Projection matrix orthogonal to intercept, linear period, and quadratic period
%%%
p00 = pstar(1) - 0.5*Delta;

if P >= 3

    qp2 = pstar.^2 - (Delta.*P + 2*p00).*pstar + (p00 + Delta.*P./2).^2 - ((Delta.^2)./12).*(P-1).*(P+1);
    Xp2 = [ones(N, 1) pstar_0 qp2];
    xtxi = (1/A)*diag( 1./[P, (Delta^2/12)*(P-1)*P*(P+1), (Delta^4/180)*(P-2)*(P-1)*P*(P+1)*(P+2)] );
    Rp2 = xtxi*Xp2';
    PP12 = Xp2*Rp2;
    XPD12 = eyeN - PP12;

else

    qp2 = zeros(N, 1);
    Xp2 = [ones(N, 1) pstar_0];
    xtxi = (1/A)*diag( 1./[P, (Delta^2/12)*(P-1)*P*(P+1)] );
    Rp2 = xtxi*Xp2';
    PP12 = Xp2*Rp2;
    XPD12 = eyeN - PP12;

end

%%%
% Projection matrix orthogonal to intercept, linear cohort, and quadratic cohort
% %%%
c00 = p00 - a00;
qc2 = cstar.^2 - (Delta.*(A+P) + 2*(c00-Delta.*A)).*cstar + ...
    (c00 - Delta.*A).^2 + (A+P).*Delta.*cstarbar - ((Delta.^2)./6).*(2.*A.^2 + 3.*A.*P + 2.*P.^2 - 1);
Xc2 = [ones(N, 1) cstar_0 qc2];
xtxi = (1/(A*P))*diag(1./[1, (Delta^2/12)*(A^2 + P^2 - 2), (Delta^4/180)*((A^2 + P^2)^2 - 10*(A^2 + P^2) + 3*A^2*P^2 + 13)]);
Rc2 = xtxi*Xc2';
PC12 = Xc2*Rc2;
XCD12 = eyeN - PC12;

%%%
% Orthogonalize the deviations
%%%
Ad0 = XAD12*sparse(Ad);
Pd0 = XPD12*sparse(Pd);
Cd0 = XCD12*sparse(Cd);

G.X = [J astar_0 cstar_0 qa2 qp2 qc2 Ad0(:, 2:A-2) Pd0(:, 2:P-2) Cd0(:, 2:C-2)];


% Pointers for Higher-Order Deviations:
%
% * For age:
%    1:(A - 3) shift forward by 6 -> (1 + 6):(A - 3 + 6) = 7:(A + 3)
% * For period:
%    1:(P - 3) shift forward by 6 + (A - 3) ->
%      (1 + 6 + A - 3):(P - 3 + 6 + A - 3) = (A + 4):(A + P)
% * For cohort:
%    1:(C - 3) shift forward by 6 + (A - 3) + (P - 3) ->
%      (1 + 6 + (A - 3) + (P - 3)):(C - 3) + 6 + (A - 3) + (P - 3) =
%      (A + P + 1):(A + P + C - 3)

Pt = {1, 2, 3, 4, 5, 6, 7:(A+3), (A+4):(A+P), (A+P+1):(A+P+C-3)};
if A==2
    % 7:(A+3) is empty, (A+4) = 6 so need to shift Pt{8} & Pt{9} by 1
    Pt{8} = 1 + Pt{8};
    Pt{9} = 1 + Pt{9};
end
if P==2
    Pt{9} = 1 + Pt{9};
end
G.Pt = Pt;

% pointers for cohort effects (last f/u, South+East edges of lexis)
G.INCc = [A*(1:P), P*A-(1:A-1)];
% pointers for age effects (South edge of lexis)
G.INCa = ((P-1)*A+1):P*A;
% pointers for period effects (East edge of lexis)
G.INCp = A*(1:P);

G.Pt = Pt;

% scaled x-axis ticks and limits for plots of age, period, and cohort effects
YLA = Delta*A;
YLP = Delta*P;
YLC = Delta*C;

dA = YLC - YLA;
dP = YLC - YLP;
dC = 0;

a = G.AGE.values;
p = G.PER.values;
c = G.COH.values;
% go with 5 ticks for now
XT1 = a(1) - Delta/2 : 5 : a(A) + Delta/2;
XT2 = p(1) - Delta/2 : 5 : p(P) + Delta/2;
XT3 = c(1) : 5 : c(C);
G.XT = {XT1, XT2, XT3};

G.XL = {...
    [a(1) a(A)] + [-dA  +dA]/2, ...
    [p(1) p(P)] + [-dP, +dP]/2, ...
    [c(1) c(C)] + [-dC  +dC]/2, ...
    };


end