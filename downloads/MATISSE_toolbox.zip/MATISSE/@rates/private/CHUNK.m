function S = CHUNK(R, varargin)
% RATES/CHUNK Aggregate cells in successive age groups and/or calendar periods.

PVP = chunkopts(R, varargin{1:end});

if PVP.AgeBlock == 1 && PVP.PerBlock == 1
    S = R;
    return
end

Events = PVP.R.Events;
Offset = PVP.R.Offset;

a0 = PVP.R.ages;
p0 = PVP.R.periods;

if PVP.AgeBlock > 1

    % Calculate # of blocks.
    b = floor(PVP.A./PVP.AgeBlock);
    r = rem(PVP.A, PVP.AgeBlock);

    if r > 0
        switch PVP.Direction
            case 'LTF'
                % Discard first r ages.
                INCa = r+1:1:size(Events, 1);

            case 'FTL'
                % Discard last r ages
                INCa = 1:1:size(Events, 1)-r+1;
        end

        Events = Events(INCa, :);
        Offset = Offset(INCa, :);
        a0 = a0(INCa);

    end

    % Pre-allocate space for chunk data.
    E = zeros(b, size(Events, 2));
    O = zeros(b, size(Events, 2));
    a = zeros(1, b+1);

    for j = 1:1:b

        % Regular block.
        INCj = (j-1)*PVP.AgeBlock+1:j*PVP.AgeBlock;

        E(j, :) = sum(Events(INCj, :), 1, 'omitnan');
        O(j, :) = sum(Offset(INCj, :), 1, 'omitnan');
        a(j) = a0(INCj(1));
    end

    if b==1
        a(b+1) = a0(end);
    else
        DELTAa = a(2) - a(1);
        a(b+1) = a(b) + DELTAa;
    end
    % update events and offset with data chunked over ages.
    Events = E;
    Offset = O;

else
    a = a0;
end

if PVP.PerBlock > 1

    % Calculate # of blocks.
    b = floor(PVP.P./PVP.PerBlock);
    r = rem(PVP.P, PVP.PerBlock);
    if r > 0

        switch PVP.Direction
            case 'LTF'
                % Discard first r periods.
                INCp = r+1:1:size(Events, 2);
            case 'FTL'
                % Discard last r periods.
                INCp = 1:1:size(Events, 2)-r+1;
        end

        Events = Events(:, INCp);
        Offset = Offset(:, INCp);
        p0 = p0(INCp);
    end
    % Pre-allocate space for chunk data.
    E = zeros(size(Events, 1), b);
    O = zeros(size(Events, 1), b);
    p = zeros(1, b+1);
    for j = 1:1:b
        % Regular block.
        INCj = (j-1)*PVP.PerBlock+1:j*PVP.PerBlock;
        E(:, j) = sum(Events(:, INCj), 2, 'omitnan');
        O(:, j) = sum(Offset(:, INCj), 2, 'omitnan');
        p(j) = p0(INCj(1));
        p(j+1) = p0(INCj(end));
    end

    if b==1
        p(b+1) = p0(end);
    else
        DELTAp = p(2) - p(1);
        p(b+1) = p(b) + DELTAp;
    end

    % update events and offset with data chunked over ages.
    Events = E;
    Offset = O;

else
    p = p0;

end

% Output new rates object.
S = rates(...
    'Events', Events, ...
    'Offset', Offset, ...
    'fullname', R.fullname, ...
    'label', R.label, ...
    'chromacode', R.chromacode, ...
    'event_label', R.event_label, ...
    'description', R.description, ...
    'offset_units', R.offset_units, ...
    'offset_tick', R.offset_tick, ...
    'ages', a, ...
    'periods', p);

%%%%%%%% Helper Function

function PVP = chunkopts(varargin)
% Validate inputs for RATES/CHUNK method.

% default values
PVP = struct('R', [], ...
    'AgeBlock', 1, ...
    'PerBlock', 1, ...
    'Direction', 'LTF', ...
    'A', [], 'P', []);

PVP.R = varargin{1};
[PVP.A, PVP.P] = size(PVP.R.Events);

% process the rest
%%%
if length(varargin) > 1
    lArgin = varargin(2:end);
else
    return
end

N_lArgin = length(lArgin);

if N_lArgin == 1
    error('The property you specified has no matching value.');
end

while N_lArgin >= 1
    if N_lArgin == 1
        error('the last property has no matching value');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lvali = length(vali);
    lArgin = lArgin(3:end);
    N_lArgin = length(lArgin);

    if ~ischar(propi)
        error('a property must be specified using a string')
    end

    switch lower(propi)

        case 'ageblock'
            % Must be a real scalar.
            if ~(lvali==1 &&  ...
                    isreal(vali) && isnumeric(vali))
                error('AgeBlock must be an integer');
            end

            % Must be >=1 & <=A.
            vali = round(vali);
            if vali>0 && vali<=PVP.A
                % this is OK; update
                PVP.AgeBlock = vali;
            else
                error('invalid AgeBlock');
            end

        case 'perblock'
            % Must be a real scalar.
            if ~(lvali==1 &&  ...
                    isreal(vali) && isnumeric(vali))
                error('PerBlock must be an integer');
            end

            % Must be >=1 & <=P.
            vali = round(vali);
            if vali>0 && vali<=PVP.P
                % this is OK; update
                PVP.PerBlock = vali;
            else
                error('Invalid PerBlock.');
            end

        case 'direction'
            % validate
            if ~ischar(vali)
                error('''Direction'' must be ''LTF''  or ''FTL''')
            end
            if size(vali, 1) > 1
                error('''Direction'' must be a string, not a character matrix')
            end
            vali = lower(vali);
            I = strncmp({'ltf', 'ftl'}, vali, 1);
            if ~any(I)
                error([vali ' is an unrecognized ''Direction'' property value, valid values are ''LTF'' or ''FTL'''])
            end

            PVP.Direction = upper(vali);

        otherwise

            error(['Unrecognized method property: ' propi])

    end
end