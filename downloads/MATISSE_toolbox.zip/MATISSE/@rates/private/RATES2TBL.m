function T = RATES2TBL(varargin)
% RATES/RATES2TBL convert rates object to a tbl with one row per cell.

% precheck
precheck(varargin{:});

K = nargin;

% use the first rates object as the template
R = varargin{1};
[A, P] = size(R);
ADATA = kron(ones(P, 1), R.a(:));
PDATA = kron(R.p(:), ones(A, 1));
CDATA = PDATA - ADATA;

AP = A*P;
L = AP*K;
E = zeros(L, 1);
O = zeros(L, 1);
G = zeros(L, 1);
fn = cell(1, K);
lb = cell(1, K);
cc = cell(1, K);

for k = 1:K
 
    r = varargin{k};

    E(AP*(k-1)+1:1:AP*k, 1) = r.Events(:);
    O(AP*(k-1)+1:1:AP*k, 1) = r.Offset(:);
    G(AP*(k-1)+1:1:AP*k, 1) = k;

    fn{k} = r.fullname;
    lb{k} = r.label;
    cc{k} = r.chromacode;

end

ADATA = kron(ones(K, 1), ADATA);

PDATA = kron(ones(K, 1), PDATA);

CDATA = kron(ones(K, 1), CDATA);

y = [E, O];

r = R.offset_tick.*E./O;

v = (R.offset_tick./O).^2.*E;

DATA = [G, ADATA, PDATA, CDATA, y, r, v];
cl = {'strata', 'age', 'per', 'coh', 'E', 'O', 'r', 'v'};
rl = lb(G);
T = tbl('data', DATA, ...
    'fullname', ['rates, ' num2str(K) ' strata from ' ...
    varargin{1}.label ' to ' varargin{K}.label], ...
    'row_labels', rl, ...
    'col_labels', cl, ...
    'labels', {'cells', mat2str(lexis(R))});

end

% helper functions

function precheck(varargin)

K = nargin;

% all inputs must be rates objects
for i = 1:K
    if ne(class(varargin{i}), 'rates')
        error('all inputs must be rates objects')
    end
end

% all rates objects must be defined over the same Lexis diagram
L = lexis(varargin{1});
for i = 2:K
    Lk = lexis(varargin{i});
    if ~(all(L == Lk))
        error('each rate object must be defined over the same Lexis diagram')
    end
end

% end preprocess
end

function L = lexis(r)
[A, P] = size(r);
a0 = r.ages(1);
p0 = r.periods(1);
DELTAa = r.ages(2) - r.ages(1);
DELTAp = r.periods(2) - r.periods(1);
L = [A P a0 p0 DELTAa DELTAp];
% end lexis
end




