function D = UNION(varargin)
% RATES/UNION Add Events and Offset across rates object with the same ages and periods.

I = precheck(varargin{:});

K = I.K;
[A, P] = size(varargin{1});

fn = cell(1, K);
lb = cell(1, K);
cc = cell(1, K);
ETOT = zeros(A, P);
OTOT = zeros(A, P);
for k = 1:K
    ETOT = ETOT + varargin{k}.Events;
    OTOT = OTOT + varargin{k}.Offset;
    if ~I.altText
        fn{k} = ['(' varargin{k}.fullname ') & '];
        lb{k} = ['(' varargin{k}.label ') & '];
        cc{k} = ['\color[rgb]{0 0 0}(' varargin{k}.chromacode '\color[rgb]{0 0 0}) & '];
    end
end

D = varargin{1};
D.Events = ETOT;
D.Offset = OTOT;

switch I.altText
    case 0
        TMP = [fn{:}];
        D.fullname = TMP(1:end-3);

        TMP = [lb{:}];
        D.label = TMP(1:end-3);

        TMP = [cc{:}];
        D.chromacode = TMP(1:end-3);
  
    case 1
        D.fullname = I.txt;
        D.label = I.txt;
        D.chromacode = I.txt;

    otherwise
end


end

% helper functions

function I = precheck(varargin)

K0 = nargin;

if ischar(varargin{K0})
    I.altText = 1;
    I.txt = varargin{K0};
    I.K = K0 - 1;
else
    I.altText = 0;
    I.txt = '';
    I.K = K0;
end


% all inputs must be rates objects
for i = 1:I.K
    if ne(class(varargin{i}), 'rates')
        error('all inputs must be rates objects')
    end
end

% all rates objects must be defined over the same Lexis diagram
L = lexis(varargin{1});
for i = 2:I.K
    Lk = lexis(varargin{i});
    if ~(all(L == Lk))
        error('each rate object must be defined over the same Lexis diagram')
    end
end

end

function L = lexis(r)
[A, P] = size(r);
a0 = r.ages(1);
p0 = r.periods(1);
DELTAa = r.ages(2) - r.ages(1);
DELTAp = r.periods(2) - r.periods(1);
L = [A P a0 p0 DELTAa DELTAp];
end




