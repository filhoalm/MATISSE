function S = UNI(varargin)
% RATES/UNIVARIATE Descriptive statistics for rates objects

Q = numel(varargin);
FIRSTPVP = 0;
for i = 1:Q
    if isa(varargin{i}, 'char') && FIRSTPVP == 0
        FIRSTPVP = i;
    end
end
if FIRSTPVP == 0
    K = Q;
else
    K = FIRSTPVP - 1;
end

PVP = options(varargin{K+1:Q});

T = cell(1, K);
for k = 1:K

    T{k} = univar(varargin{k}, PVP);

end

S = [T{:}];
S.fullname = 'Univariate Statistics';

end

%%%%%%%
function PVP = options(varargin)
% Helper function

PVP = struct('Pop', 1, 'Alpha', 0.05, 'pca', 'seer');
N = numel(varargin);
lArgin = varargin;

while N >= 2
    propi = lArgin{1};
    vali = lArgin{2};
    switch lower(propi)

        case 'pop'
            if ~isscalar(vali)
                error('Pop must be a scalar.')
            end
            if vali<1 || vali>4
                error('nvalid Pop value')
            end

            PVP.Pop = vali;

        case 'alpha'
            if ~(isscalar(vali) && isreal(vali))
                error('Alpha must be a real scalar')
            elseif (vali < 0 || vali > 1)
                error('Alpha must lie between 0 and 1')
            else
                PVP.Alpha = vali;
            end

        case 'pca'
            if ~ischar(vali)
                error('''pca must a be a string')
            end
            vali = lower(vali);
            if ~any(strcmp(vali, {'seer', 'poisson', '2pt'}))
                error('unrecognized pca')
            end
            PVP.pca = lower(vali);

        otherwise
    end

    % setup for the next pair
    lArgin = lArgin(3:end);
    N = numel(lArgin);
    if eq(N, 1)
        error('The last property has no matching value.');
    end

end

end

function T = univar(R, PVP)
% summary statistics

[A, P] = size(R);
C = A + P - 1;

nmiss = sum(isnan(R.Events(:)));
z = (R.Events(:) == 0);
nzero = sum(z);

nzero_pct = 100 * nzero/(A*P);
nmiss_pct = 100 * nmiss/(A*P);

e = R.Events(:);
o = R.Offset(:);

mine = min(e, [], 'omitnan');
meane = mean(e, 'omitnan');
maxe = max(e, [], 'omitnan');
sume = sum(e, 'omitmissing');
sumo = sum(o, 'omitmissing');

U = asr(R, 'Pop', PVP.Pop, 'Alpha', PVP.Alpha);
V = U.asr{1}.data;
asr1 = V.data(1);
asrP = V.data(P);

switch PVP.pca
    case 'seer'
        eapc = U.pca(1, :).data(1:3);
    case 'poisson'
        eapc = U.pca(2, :).data(1:3);
    case '2pt'
        eapc = U.pca(3, :).data(1:3);
end

DATA = [A P C nmiss nmiss_pct nzero nzero_pct , ...
    mine meane maxe sume sumo asr1 asrP eapc]';

rl = {...
    'A', ...
    'P', ...
    'C', ...
    'nmiss', ...
    'nmiss pct', ...
    'nz', ...
    'nz pct', ...
    'min E', ...
    'mean E', ...
    'max E', ...
    'Total E', ...
    'Total O', ...
    'ASR(1)', ...
    'ASR(P)', ...
    PVP.pca, ...
    [PVP.pca ' Lo'], ...
    [PVP.pca ' Hi']};

T = tbl(...
    'data', DATA, ...
    'fullname', '', ...
    'row_labels', rl, ...
    'col_labels', {R.label});

end
