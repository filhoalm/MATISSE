function T = TYPE(R, varargin)
% RATES/TYPE Tabular display of a rates object.

PVP = INPUTS(R, varargin{:});

E = R.Events;
O = R.Offset;
switch PVP.comp
    case 'e'
        fn = [R.fullname ' : ' R.event_label];
        T = tbl(...
            'data', E, ...
            'fullname', fn, ...
            'row_labels', R.age_labels, ...
            'col_labels', R.per_labels, ...
            'labels', {'Age', 'Period'});

    case 'o'
        fn = [R.fullname ' : ' R.offset_units];
        T = tbl(...
            'data', O, ...
            'fullname', fn, ...
            'row_labels', R.age_labels, ...
            'col_labels', R.per_labels, ...
            'labels', {'Age', 'Period'});

    case 'r'
        fn = R.fullname;
        r = R.offset_tick.*(E./O);
        T = tbl(...
            'data', r, ...
            'fullname', fn, ...
            'row_labels', R.age_labels, ...
            'col_labels', R.per_labels, ...
            'labels', {'Age', 'Period'});

    case 'lr'
        fn = R.fullname;
        lr = log(R.offset_tick.*(E./O));
        T = tbl(...
            'data', lr, ...
            'fullname', fn, ...
            'row_labels', R.age_labels, ...
            'col_labels', R.per_labels, ...
            'labels', {'Age', 'Period'});

    case 'l10r'
        fn = R.fullname;
        lr10 = log10(R.offset_tick.*(E./O));
        T = tbl(...
            'data', lr10, ...
            'fullname', fn, ...
            'row_labels', R.age_labels, ...
            'col_labels', R.per_labels, ...
            'labels', {'Age', 'Period'});

    case 'r1'
        fn = R.fullname;
        r = E./O;
        T = tbl(...
            'data', r, ...
            'fullname', fn, ...
            'row_labels', R.age_labels, ...
            'col_labels', R.per_labels, ...
            'labels', {'Age', 'Period'});

    case 'lr1'
        fn = R.fullname;
        r1 = (E./O);
        lr1 = log(r1);
        T = tbl(...
            'data', lr1, ...
            'fullname', fn, ...
            'row_labels', R.age_labels, ...
            'col_labels', R.per_labels, ...
            'labels', {'Age', 'Period'});

    case 'rci'
        r = R.offset_tick.*(E./O);
        v = (R.offset_tick.^2)*E./O.^2;
        cilo = max(0, r-PVP.Z*sqrt(v));
        cihi = r+PVP.Z*sqrt(v);

        DATA = zeros(PVP.A, 3*PVP.P);
        DATA(:, 1:3:3*PVP.P) = r;
        DATA(:, 2:3:3*PVP.P) = cilo;
        DATA(:, 3:3:3*PVP.P) = cihi;

        cl = [...
            [str('data', R.per_labels), ' Rate']; ...
            [str('data', R.per_labels), ' CI Lo']; ...
            [str('data', R.per_labels), ' CI Hi']];
        cl = reshape(cl.data, PVP.P, 3);
        cl = cl';
        cl = cl(:);

        fn = [R.fullname ', Rate per ' num2str(R.offset_tick) ' ', ...
            R.offset_units ' & ' num2str(100*(1 - PVP.Alpha)) '% CI'];

        T = tbl(...
            'data', DATA, ...
            'fullname', fn, ...
            'row_labels', R.age_labels, ...
            'col_labels', cl, ...
            'labels', {'Age', 'Period'});

    case 'eo'
        DATA = zeros(PVP.A, 2*PVP.P);
        DATA(:, 1:2:2*PVP.P) = E;
        DATA(:, 2:2:2*PVP.P) = O;
        cl = [str('data', R.per_labels), ' events'; str('data', R.per_labels), ' offset'];
        cl = reshape(cl.data, PVP.P, 2);
        cl = cl';
        cl = cl(:);
        T = tbl(...
            'data', DATA, ...
            'fullname', R.fullname, ...
            'row_labels', R.age_labels, ...
            'col_labels', cl, ...
            'labels', {'Age', 'Period'});

    case 'er'
        DATA = zeros(PVP.A, 2*PVP.P);
        DATA(:, 1:2:2*PVP.P) = E;
        r = R.offset_tick.*(E./O);
        DATA(:, 2:2:2*PVP.P) = r;
        cl = [str('data', R.per_labels), ' events'; str('data', R.per_labels), ' rate'];
        cl = reshape(cl.data, PVP.P, 2);
        cl = cl';
        cl = cl(:);
        T = tbl('data', DATA, ...
            'fullname', [R.fullname, ', Events & Rate per ', ...
            num2str(R.offset_tick) ' ' R.offset_units], ...
            'row_labels', R.age_labels, ...
            'col_labels', cl, ...
            'labels', {'Age', 'Period'});

    case 'eor'
        DATA = zeros(PVP.A, 3*PVP.P);
        DATA(:, 1:3:3*PVP.P) = E;
        DATA(:, 2:3:3*PVP.P) = O;
        r = R.offset_tick.*(E./O);
        DATA(:, 3:3:3*PVP.P) = r;
        cl = [...
            [str('data', R.per_labels), ' events']; ...
            [str('data', R.per_labels), ' offset']; ...
            [str('data', R.per_labels), ' rate']];
        cl = reshape(cl.data, PVP.P, 3);
        cl = cl';
        cl = cl(:);
        T = tbl(...
            'data', DATA, ...
            'fullname', [R.fullname ', Events & Offset & Rate per ', ...
            num2str(R.offset_tick) ' ' R.offset_units], ...
            'row_labels', R.age_labels, ...
            'col_labels', cl, ...
            'labels', {'Age', 'Period'});

    case 'v'
        T = (R.offset_tick.^2)*E./O.^2;

    case 'lv'
        T = 1./E;

    case 'c'
        [A, P] = size(R);
        a = R.a;
        p = R.p;
        ADATA = [repmat(a(A), P, 1); a(A-1:-1:1)'];
        PDATA = [p(1:P)'; repmat(p(P), A-1, 1)];
        CDATA = PDATA - ADATA;
        rl = cellstr(num2str(CDATA));
        T = tbl(...
            'data', CDATA, ...
            'fullname', 'Cohort', ...
            'row_labels', rl, ...
            'col_labels', {'cohort'});

    case 'a'
        T = tbl(...
            'data', R.a', ...
            'fullname', 'Age', ...
            'row_labels', R.age_labels, ...
            'col_labels', {'age'});

    case 'p'
        T = tbl(...
            'data', R.p', ...
            'fullname', 'Period', ...
            'row_labels', R.per_labels, ...
            'col_labels', {'period'});

    case 'lexis'
        T = tbl('data', ...
            [...
            R.ages(1), ...
            R.periods(1), ...            
            size(R, 1), ...
            size(R, 2), ...
            R.ages(2) - R.ages(1), ...
            R.periods(2) - R.periods(1)], ...
            'fullname', ['lexis: ' R.fullname], ...
            'row_labels', {''}, ...
            'col_labels', {'a0', 'p0', 'A', 'P', 'DELTAa', 'DELTAp'});

end

if ~any(strcmpi(PVP.comp, {'c', 'p', 'a'}))
    switch PVP.ages
        case 1
            if PVP.comp(1)~='v' && ~strcmpi(PVP.comp, 'lv')
                a = tbl(...
                    'data', R.a', ...
                    'fullname', '', ...
                    'row_labels', {},...
                    'col_labels', {'Age'});
                fn = T.fullname;
                T = [a, T];
                T.fullname = fn;

            end

        case 0

        otherwise

    end
end


%%%%%%%% Helper Function

function PVP = INPUTS(R, varargin)
% Validate inputs for RATES/TYPE method.

% default values
PVP = struct('A', [], 'P', [], 'ages', 0, 'comp', 'r', 'Alpha', 0.05, 'Z', NaN);

[PVP.A, PVP.P] = size(R.Events);
lArgin = varargin(1:end);

Nl = numel(lArgin);
if eq(Nl, 1)
    error('property has no matching value');
end

while length(lArgin) >= 1
    if eq(Nl, 1)
        error('last property has no matching value');
    end

    propi = lArgin{1};
    vali = lArgin{2};
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);

    if ~ischar(propi)
        error('a property must be specified using a string')
    end

    switch lower(propi)

        case 'ages'
            if ~isscalar(vali)
                error('ages must be 0 or 1');
            end
            if ~(eq(vali, 0) || eq(vali, 1))
                error('ages must be 0 or 1')
            end
            PVP.ages = vali;

        case 'comp'
            if ~ischar(vali)
                error('The ''comp'' property value must a be a string.')
            end
            vali = lower(vali);
            switch vali
                case 'e'
                    PVP.comp = 'e';
                case 'o'
                    PVP.comp = 'o';
                case 'r'
                    PVP.comp = 'r';
                case 'r1'
                    PVP.comp = 'r1';
                case 'eo'
                    PVP.comp = 'eo';
                case 'er'
                    PVP.comp = 'er';
                case 'eor'
                    PVP.comp = 'eor';
                case 'rci'
                    PVP.comp = 'rci';
                case 'v'
                    PVP.comp = 'v';
                case 'c'
                    PVP.comp = 'c';
                case 'p'
                    PVP.comp = 'p';
                case 'a'
                    PVP.comp = 'a';
                case 'lr'
                    PVP.comp = 'lr';
                case 'lr1'
                    PVP.comp = 'lr1';
                case 'l10r'
                    PVP.comp = 'l10r';
                case 'lv'
                    PVP.comp = 'lv';
                case 'lexis'
                    PVP.comp = 'lexis';
                otherwise
                    error(...
                        ['''comp'' property value must be ' ...
                        '''e'', ''o'', ''r'', ''r1'', ''rci'', ''eo'', ''er''', ...
                        '''eor'', ''v'', ''c'', ''p'', ''a''', ...
                        '''lr'', ''lr1'', ''lv'' or ''lexis''.'])
            end

        case 'alpha'
            if ~(isscalar(vali) && isreal(vali))
                error('Alpha must be a real scalar')
            elseif (vali < 0 || vali > 1)
                error('Alpha must lie between 0 and 1')
            else
                PVP.Alpha = vali;
            end
        otherwise
            error(['Unrecognized method property: ' propi])

    end
end

PVP.Z = norminv(1 - PVP.Alpha/2);
