function D = DISTRIBUTE(varargin)
% RATES/DISTRIBUTE Distribute events from a rates object.

% precheck
precheck(varargin{:});

K = nargin;
Kt = K - 1;
Rs = varargin{1};

[A, P] = size(Rs);
N = A*P;

E0 = Rs.Events(:);
Et = zeros(N, Kt);
for k = 1:Kt
    Et(:, k) = varargin{k+1}.Events(:);
end

% normalize accounting for cells where all Kt event counts are 0
TMP = sum(Et, 2, "omitmissing");
Pt = Et./(TMP + eq(TMP, 0));

% distribute
Dt = Pt.*E0;

Nt = Et + Dt;

% repack
D = cell(1, Kt);
for k = 1:Kt
    TMPk = varargin{k+1};
    TMPk.Events = reshape(Nt(:, k), A, P);
    D{k} = TMPk;
end

end

function precheck(varargin)

K = nargin;

% all inputs must be rates objects
for i = 1:K
    if ne(class(varargin{i}), 'rates')
        error('all inputs must be rates objects')
    end
end

% all rates objects must be defined over the same Lexis diagram
L = lexis(varargin{1});
for i = 2:K
    Lk = lexis(varargin{i});
    if ~(all(L == Lk))
        error('each rate object must be defined over the same Lexis diagram')
    end
end

end

function L = lexis(r)
[A, P] = size(r);
a0 = r.ages(1);
p0 = r.periods(1);
DELTAa = r.ages(2) - r.ages(1);
DELTAp = r.periods(2) - r.periods(1);
L = [A P a0 p0 DELTAa DELTAp];
end

