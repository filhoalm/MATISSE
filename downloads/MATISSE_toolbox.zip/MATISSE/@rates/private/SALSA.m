function Mplt = SALSA(R, varargin)
% RATES/SALSA Standard plots.

%%%
% openers
%%%
if isempty(R)
    error('no data to plot')
end

DELa = R.a(2) - R.a(1);
DELp = R.p(2) - R.p(1);

if eq(DELa, DELp)
    SQUARE = 1;
else
    SQUARE = 0;
end

%%%
% setup
%%%
switch numel(varargin)
    case 0

        StandardPlot = 'rpa';
        PVP = [];

    case 1

        StandardPlot = varargin{1};
        if ~(ischar(StandardPlot) && ismember(StandardPlot, ...
                {'rpa', 'rap', 'rca', 'rac'}))
            error([StandardPlot ...
                ' is not recognized, valid options are ''rpa'', ''rap'', ''rca'' or ''rac'''])
        end
        PVP = [];

    case 2

        StandardPlot = varargin{1};
        PVP = varargin{2};

    otherwise

end

if ~SQUARE
    if strcmpi(StandardPlot, 'rca') || strcmpi(StandardPlot', 'rca')
        Mplt = [];
        disp('not done, age and period intervals must be equal')
        return
    end
end

%%%
% convert log rates to matrix
%%%

M0 = matrix(...
    'data', type(R, 'comp', 'lr'), ...
    'COV', type(R, 'comp', 'lv'), ...
    'y', R.a, 'x', R.p);

pvp0 = ego('class', 'rates', 'method', 'salsa');

switch StandardPlot
    case 'rap'
        if isempty(PVP)
            PVP = pvp0;
        end
        Mplt = M0;
        if PVP.Plot
            plot(Mplt, PVP)
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))
        end

    case 'rpa'
        Mplt = M0';
        if isempty(PVP)
            PVP = pvp0;
            PVP.Width = 0.5;
        end
        if PVP.Plot
            plot(Mplt, PVP)
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))

            if PVP.Legend
                h = findobj(gcf, 'Type', 'legend');
                set(h(1), 'Location', 'southeast', 'NumColumns', 2)
            end
        end


    case 'rac'
        Mplt = diagonals(M0);
        c = type(R, 'comp', 'c');
        data = Mplt.data;
        data.col_labels = c.row_labels;
        data.labels = {'Age', 'Cohort'};
        Mplt.data = data;
        if isempty(PVP)
            PVP = pvp0;
        end
        if PVP.Plot
            plot(Mplt, PVP)
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))
        end

    case 'rca'
        TMP = diagonals(M0);
        c = type(R, 'comp', 'c');
        Mplt = TMP';
        data = Mplt.data;
        data.row_labels = c.row_labels;
        data.labels = {'Cohort', 'Age'};
        Mplt.data = data;
        Mplt.y = c.data;
        if isempty(PVP)
            PVP = pvp0;
        end
        if PVP.Plot
            plot(Mplt, PVP)
            TMP = unique(log(max(1, unique(1*round(exp(get(gca, 'YTick'))/1)))));
            set(gca, 'YTick', TMP, 'YTickLabel', cellstr(num2str(exp(TMP)')))
        end

    otherwise
        error('unsupported graph type')
end

if PVP.Plot && PVP.labels(2)
    ylabel(R.chromacode, 'FontSize', PVP.FontSize(2))
end

end



