function M = RATES2MATRIX(R, varargin)
% Convert rates object to matrix object.

PVP = inputs(varargin{:});

switch PVP.scale

    case 'lr'
        TMP = type(R, 'comp', 'lv');
        M = matrix(...
            'data', type(R, 'comp', 'lr'), ...
            'COV', diag(TMP(:)), ...
            'type', 3, ...
            'x', R.p, ...
            'y', R.a);

    case 'lr1'
        TMP = type(R, 'comp', 'lv');
        M = matrix(...
            'data', type(R, 'comp', 'lr1'), ...
            'COV', diag(TMP(:)), ...
            'type', 3, ...
            'x', R.p, ...
            'y', R.a);

    case 'r'
        TMP = type(R, 'comp', 'v');
        M = matrix(...
            'data', type(R, 'comp', 'r'), ...
            'COV', diag(TMP(:)), ...
            'type', 3, ...
            'x', R.p, ...
            'y', R.a);

    case 'r1'
        TMP = type(R, 'comp', 'v');
        M = matrix(...
            'data', type(R, 'comp', 'r1'), ...
            'COV', diag(TMP(:)), ...
            'type', 3, ...
            'x', R.p, ...
            'y', R.a);
    otherwise

end

end

%%%

function PVP = inputs(varargin)
% default values

PVP = struct('scale', 'lr');

%%%
% whittle the arguments
%%%
N = nargin;
lArgin = varargin;

while N >= 2

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('a property must be specified using a string')
    end

    switch lower(propi)

        case 'scale'
            if ~ischar(vali)
                error('scale must a be a string')
            end
            vali = lower(vali);
            if ~any(strcmpi(vali, {'r', 'r1', 'lr', 'lr1'}))
                error('invalid scale')
            end
            PVP.scale = vali;

        otherwise

    end

    % setup for the next pair
    lArgin = lArgin(3:end);
    N = numel(lArgin);
    if eq(N, 1)
        error('the last property has no matching value');
    end

end

end