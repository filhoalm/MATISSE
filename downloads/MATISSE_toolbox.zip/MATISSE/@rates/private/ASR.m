function S = ASR(R, varargin)
% RATES/ASR Age-standardized rates over calendar periods.

PVP = options(varargin{:});

P = size(R, 2);
p = R.p;
% for single-year periods OK to round down to integral year
if all(diff(p))
    p = floor(p);
end

% pop weights
w = weights(R, 'Pop', PVP.Pop);
W = w.data;

% container for raw asr data
DATA = NaN(P, 3);

% loop over years
for j = 1:P

    % Mid-year value.
    pj = p(j);
    INC = ~isnan(R.Events(:, j)) & ~isnan(R.Offset(:, j));
    Ej = R.Events(INC, j);
    Oj = R.Offset(INC, j);
    Rj = R.offset_tick.*Ej./Oj;
    % handle 0/0 case
    Rj(isnan(Rj)) = 0;
    % weighted average
    Yj = sum(W(INC).*Rj);
    % side-effect of 0/0, use nansum not sum
    Vj = sum((W(INC).^2).*(R.offset_tick.^2)./(Oj.^2).*Ej, 'omitnan');
    DATA(j,:) = [pj, Yj, Vj];

end

s0 = tbl(...
    'data', DATA(:, 2), ...
    'fullname', R.fullname, ...
    'labels', {'Period', 'ASR'}, ...
    'row_labels', R.per_labels, ...
    'col_labels', {R.chromacode}); 

m0 = matrix(...
    'data', s0, ...
    'y', p, ...
    'COV', DATA(:, 3), ...
    'Alpha', PVP.Alpha);

S.asr = m0;

eapc = LME(R, DATA, PVP.Alpha);
twopt = TWOPT(R, DATA, W, PVP.Alpha);
S.pca = tbl(...
    'data', [eapc; twopt], ...
    'fullname', R.fullname, ...
    'labels', {'Method', 'PCA'}, ...
    'col_labels', {'PCA', 'Lo', 'Hi', 'P-Value'}, ...
    'row_labels', {'SEER', 'Poisson', '2PT'});

end

% helper functions

function PVP = options(varargin)
% Helper function

PVP = struct('Pop', 1, 'Alpha', 0.05);
N = numel(varargin);
lArgin = varargin;

while N >= 2
    propi = lArgin{1};
    vali = lArgin{2};
    switch lower(propi)

        case 'pop'
            if ~isscalar(vali)
                error('Pop must be a scalar.')
            end
            if vali<1 || vali>5
                error('invalid Pop value')
            end

            PVP.Pop = vali;

        case 'alpha'
            if ~(isscalar(vali) && isreal(vali))
                error('Alpha must be a real scalar')
            elseif (vali < 0 || vali > 1)
                error('Alpha must lie between 0 and 1')
            else
                PVP.Alpha = vali;
            end


        otherwise
    end

    % setup for the next pair
    lArgin = lArgin(3:end);
    N = numel(lArgin);
    if eq(N, 1)
        error('The last property has no matching value.');
    end

end

end

function PCA = TWOPT(R, DATA, W, Alpha)
% Two-point Estimator of PCA

P = size(R, 2);

if P==1
    PCA = NaN(1, 4);
    return
end

tA = R.periods(1);
tB = R.periods(P+1);
dA = DATA(1, 2);
dB = DATA(P, 2);
vA = DATA(1, 3).^2;
vB = DATA(P, 3).^2;
nuB = 2*(dB.^2)./vB;
nuA = 2*(dA.^2)./vA;
% Calculate nuAstar
wiA = W./R.Offset(:, 1);
yiB = R.Events(:, P);
Wa = max(wiA(yiB>0));
nuAstar = (2*(dA + Wa).^2)./(vA + Wa.^2);
% Calculate nuBstar
wiB = W./R.Offset(:, P);
yiA = R.Events(:, 1);
Wb = max(wiB(yiA>0));
nuBstar = (2.*(dB + Wb).^2)./(vB + Wb.^2);
% Calculate ASR RATIO and its 95% CI
mlRATIO = dB/dA;
loRATIO = (dB./(dA + Wa)).*finv(Alpha/2, nuB, nuAstar);
hiRATIO = ((dB + Wb)./dA).*finv(1 - Alpha/2, nuBstar, nuA);
if isempty(hiRATIO)
    hiRATIO = NaN;
end
if isempty(loRATIO)
    loRATIO = NaN;
end
RATIODATA = [mlRATIO loRATIO hiRATIO];
x = 1./(tB - tA);
% Calculate p-value
if mlRATIO > 1
    p2 = min(1, 2*fcdf((dA+Wa)./dB, nuB, nuAstar));
else
    p2 = min(1, 2 - 2*fcdf(dA./(dB+Wb), nuBstar, nuA));
end
if isempty(p2)
    p2 = NaN;
end

PCA = [100 * (RATIODATA.^x - 1), p2];

end

function PCA = LME(R, DATA, Alpha)
% Linear Model Estimator with and without overdispersion

P = size(R, 2);

if P==1
    PCA = NaN(2, 4);
    return
end

Zj = log(DATA(:, 2));
VarZj = (DATA(:, 3).^2)./(DATA(:, 2).^2);
Wj = 1./VarZj;

% seerstat way
xj = DATA(:, 1);
a = sum(Wj.*xj.*Zj);
b = sum(Wj);
c = sum(Wj.*xj);
d = sum(Wj.*Zj);
e = sum(Wj.*xj.*xj);
num = (a/b) - (c/b)*(d/b);
den = (e/b) - (c/b)^2;
m = num/den;

% calc fitted values
b0 = (d - m*c)./b;
Zjhat = b0 + m*xj;

g = sum(Wj.*(Zj - Zjhat).^2);

% order fixed on 26 Feb 2025
s2_SEER = (g./(P-2))*(b./(b*e - c*c));
s2_Pois = (b./(b*e - c*c));

crit = tinv(1 - Alpha/2, P-2);

pca_SEER = [m, m - sqrt(s2_SEER)*crit, m + sqrt(s2_SEER)*crit];
pvl_SEER = 2*(1 - tcdf(abs(m/sqrt(s2_SEER)), P-2));

pca_POIS = [m, m - sqrt(s2_Pois)*crit, m + sqrt(s2_Pois)*crit];
pvl_POIS = 2*(1 - tcdf(abs(m/sqrt(s2_Pois)), P-2));

TMP1 = [100 * (exp(pca_SEER) - 1) pvl_SEER];
TMP2 = [100 * (exp(pca_POIS) - 1) pvl_POIS];
%      SEER  POIS
PCA = [TMP1; TMP2];

end
