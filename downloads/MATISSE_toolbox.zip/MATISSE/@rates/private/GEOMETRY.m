function varargout = GEOMETRY(R)
% Characteristics of the Lexis diagram of a rates object.

if isempty(R)
    fprintf(1, 'the rates object is empty\n')
    if nargout >= 1
        varargout{1} = [];
    end
    return
end

L = type(R, 'comp', 'lexis');
if ~eq(L.data(5), L.data(6))
    fprintf(1, 'the rates object must have equal bin widths\n')
    if nargout >= 1
        varargout{1} = [];
    end
    return
end

%%%
% Compute the Landmarks of the Lexis diagram of R
%%%
[A, P] = size(R);
C = A + P - 1;

nc = NaN(C, 1);
for ck = 1:C
    if ck >= 1 && ck <= min(A,P) - 1
        nc(ck) = ck;
    elseif ck >= min(A,P) && ck <= max(A,P)
        nc(ck) = min(A,P);
    else
        nc(ck) = A+P-ck;
    end
end

Landmarks = NaN(4 + 4 + 4 + 1 + 4, 3);
% the number of landmarks depends on A and P
% make space for 4 landmarks of a x p, p x c, and a x c
% we will reduce to the actual number later on
% rl = {...
%     'a x p: 1', 'a x p: 2', 'a x p: 3', 'a x p: 4', ...
%     'p x c: 1', 'p x c: 2', 'p x c: 3', 'p x c: 4', ...
%     'a x c: 1', 'a x c: 2', 'a x c: 3', 'a x c: 4', ...
%     'referent', ...
%     '(1,1)', '(1,P)', '(A,1)', '(A,P)'};
rl = {...
    'a x p', 'a x p', 'a x p', 'a x p', ...
    'p x c', 'p x c', 'p x c', 'p x c', ...
    'a x c', 'a x c', 'a x c', 'a x c', ...
    'referent', ...
    '(1,1)', '(1,P)', '(A,1)', '(A,P)'};
GROUP = [1 1 1 1 2 2 2 2 3 3 3 3 4 5 5 5 5]';

Delta = 1;
abar = (A+1)/2;
pbar = (P+1)/2;
cbar = (A+P-1+1)/2;
sda = Delta * (1/(2*sqrt(3))) * sqrt((A-1)*(A+1)) ;
sdp = Delta * (1/(2*sqrt(3))) * sqrt((P-1)*(P+1)) ;
sdc = Delta * (1/(2*sqrt(3))) * sqrt(A^2 + P^2 - 2) ;

p0 = (1:1:P)';

Landmarks(13, 1:2) = [pbar, abar];

Landmarks(14, 1:2) = [1, 1];
Landmarks(15, 1:2) = [1, A];
Landmarks(16, 1:2) = [P, 1];
Landmarks(17, 1:2) = [P, A];

pREF = [pbar - sdp,  pbar + sdp];
aREF = [abar - sda,  abar + sda];
cREF = [cbar - sdc,  cbar + sdc];

k = 0;

% 4 interesting points of intersection for age and period lines
for i = 1:2
    for j = 1:2
        k = k + 1;
        Landmarks(k, 1:2) = [pREF(i), aREF(j)];
    end
end

% 4 interesting points for period and cohort lines
for i = 1:2
    for j = 1:2
        k = k + 1;
        Landmarks(k, 1:2) = [pREF(i), pREF(i) - cREF(j) + A];
    end
end

% 4 interesting points for age and cohort lines
for i = 1:2
    for j = 1:2
        k = k + 1;
        Landmarks(k, 1:2) = [cREF(j) + aREF(i) - A, aREF(i)];
    end
end

% Round the values up
Landmarks = round(Landmarks);

% Add GROUP indicator
Landmarks = [Landmarks, GROUP];
% Calculate k
Landmarks(:, 3) = (Landmarks(:, 1) - 1)*A + Landmarks(:, 2);

% Include intersection points within the observed Lexis
INC1 = (Landmarks(:, 1) >= 1) & (Landmarks(:, 1) <= P) ...
    & (Landmarks(:, 2) >= 1) & (Landmarks(:, 2) <= A);
Landmarks = Landmarks(INC1, :);
rl = rl(INC1);

% Select the unique k values - this sorts the k values in vec order of R
[~, INC2] = unique(Landmarks(:, 3));
Landmarks = Landmarks(INC2, :);
rl = rl(INC2);

% Also sort in GROUP order
[~, so] = sort(Landmarks(:, 4));
Landmarks = tbl(...
    'data', Landmarks(so,:), ...
    'row_labels', rl(so), ...
    'col_labels', {'p', 'a', 'k', '** Landmarks'}, ...
    'labels', {['A = ' num2str(A)], ['P = ' num2str(P)]}, ...
    'fullname', ...
    '** Landmarks (1: a x p  2: p x c  3: a x c  4: referent  5: corners)');

%%%
% Plot a schematic of the Lexis diagram of R including the Landmarks
%%%

figure('Position', [100 100 1000 1000])

% FontSize
fs1 = 12;
fs2 = 8;

% radius of circles
Radius = 0.2;

% colors
MAP = clarinet(54);

if A == P
    mult = 0.8;
else
    mult = 1;
end

ah1 = axes(...
    'XLim', [0.5 P+0.5], ...
    'YLim', [0.5 A+0.5], ...
    'Xtick', 1:1:P, ...
    'YTick', 1:1:A, ...
    'PlotBoxAspectRatio', [P A 1], ...
    'YDir', 'reverse', ...
    'XAxisLocation', 'top', ...
    'XTickLabelRotation', -90,  ...
    'box', 'off', ...
    'FontSize', fs1);

set(ah1.YAxis, 'Color', MAP(7, :))
set(ah1.XAxis, 'Color', MAP(8, :))

[X1, Y1] = meshgrid(-0.5 + 1:1:(P + 1), -0.5 + 1:1:(A + 1));
[X2, Y2] = meshgrid(-0.5 + 1:1:(A + 1), -0.5 + 1:1:(P + 1));

line(X1, Y1, 'Color', MAP(53, :), 'LineWidth', 1);
line(Y2, X2, 'Color', MAP(54, :), 'LineWidth', 1);

% reference lines for a
pvp1 = go('LineColor', 9, 'LineWidth', 3, 'LineStyle', 1, 'Marker', 16);
pvp2 = go('LineColor', 9, 'LineWidth', 3, 'LineStyle', 3, 'Marker', 16);
rline(abar, 0, pvp1)
rline(abar - sda, 0, pvp2)
rline(abar + sda, 0, pvp2)

% reference lines for p
pvp3 = go('LineColor', 8, 'LineWidth', 3, 'LineStyle', 1, 'Marker', 16);
pvp4 = go('LineColor', 8, 'LineWidth', 3, 'LineStyle', 3, 'Marker', 16);
rline(pbar, Inf, pvp3)
rline(pbar - sdp, Inf, pvp4)
rline(pbar + sdp, Inf, pvp4)

% reference lines for c
p0_ = (0:0.5:P+0.5)';
ac0_ = abar + (p0_ - pbar);
ac0_c = ac0_;
pvp5 = go('LineColor', 10, 'LineWidth', 3, 'LineStyle', 1, 'Marker', 16);
pvp6 = go('LineColor', 10, 'LineWidth', 3, 'LineStyle', 2, 'Marker', 16);
pcurve([p0_, ac0_c], pvp5)

% lower means younger ages, younger cohorts
ac0_ = abar + (p0_ - pbar);
yL = ac0_ - sdc;
pcurve([p0_, yL], pvp6)
% older ages, older cohorts
yU = ac0_ + sdc;
pcurve([p0_, yU], pvp6);

XL = get(ah1, 'XLim');
YL = get(ah1, 'YLim');

% plot the 4 interesting points of intersection for age and period lines
pvp7 = go('LineColor', 8, 'FaceAlpha', 0.2, 'EdgeAlpha', 0, ...
    'XLim', XL, 'YLim', YL);

pvp8 = go('LineColor', 9, 'FaceAlpha', 0.0, 'EdgeAlpha', 1, ...
    'XLim', XL, 'YLim', YL, 'LineWidth', 2);

for i = 1:2
    for j = 1:2
        circles(pREF(i), aREF(j), Radius, pvp7)
        circles(pREF(i), aREF(j), Radius, pvp8)
    end
end

% plot the 4 interesting points for period and cohort lines
pvp9 = go('LineColor', 10, 'FaceAlpha', 0.2, 'EdgeAlpha', 0, ...
    'XLim', XL, 'YLim', YL);

pvp10 = go('LineColor', 8, 'FaceAlpha', 0.0, 'EdgeAlpha', 1, ...
    'XLim', XL, 'YLim', YL, 'LineWidth', 2);

for i = 1:2
    for j = 1:2
        circles(pREF(i), pREF(i) - cREF(j) + A, mult*Radius, pvp9)
        circles(pREF(i), pREF(i) - cREF(j) + A, mult*Radius, pvp10)
    end
end

% plot the 4 interesting points for age and cohort lines
pvp11 = go('LineColor', 9, 'FaceAlpha', 0.2, 'EdgeAlpha', 0, ...
    'XLim', XL, 'YLim', YL);

pvp12 = go('LineColor', 10, 'FaceAlpha', 0.0, 'EdgeAlpha', 1,  ...
    'XLim', XL, 'YLim', YL, 'LineWidth', 2);

for i = 1:2
    for j = 1:2
        circles(cREF(j) + aREF(i) - A, aREF(i), mult*Radius, pvp11)
        circles(cREF(j) + aREF(i) - A, aREF(i), mult*Radius, pvp12)
    end
end

% Overlap the circles of the centroid value
pvp13 = go('LineColor', 8, 'FaceAlpha', 0.2, 'EdgeAlpha', 0, ...
    'XLim', XL, 'YLim', YL);

circles(pbar, abar, Radius, pvp13)

pvp14 = go('LineColor', 9, 'FaceAlpha', 0.0, 'EdgeAlpha', 0.95, ...
    'XLim', XL, 'YLim', YL, 'LineWidth', 2);

circles(pbar, abar, 1.0*Radius, pvp14)
circles(pbar, abar, 1.5*Radius, pvp13)

pvp15 = go('LineColor', 10, 'FaceAlpha', 0.0, 'EdgeAlpha', 1, ...
    'XLim', XL, 'YLim', YL);

pvp16 = go('LineColor', 9, 'FaceAlpha', 0.2, 'EdgeAlpha', 0, ...
    'XLim', XL, 'YLim', YL);

circles(pbar, abar, 1.5*Radius, pvp15)
circles(pbar, abar, 2.0*Radius, pvp16)

pvp17 = go('LineColor', 10, 'FaceAlpha', 0.0, 'EdgeAlpha', 0.5, ...
    'XLim', XL, 'YLim', YL);

circles(pbar, abar, 2*Radius, pvp17)

% add a box around the axes
patch([0.5 P+0.5 P+0.5 0.5], [A+0.5 A+0.5 0.5 0.5], [0 0 0], ...
    'FaceAlpha', 0, 'EdgeColor', [0 0 0], 'LineWidth', 1)

%%%
% add nc as a set of circles on the south and east edge cells
%%%
x = [p0; P*ones(A - 1,1)];
y = [(A)*ones(P, 1); (A-1:-1:1)'];
circles(x, y, 0.5*nc./min(A,P), ...
    go('LineColor', 10, 'FaceAlpha', 0.05, 'EdgeAlpha', 1, ...
    'XLim', XL, 'YLim', YL))

% number of cells per cohort, and index of cohort
ncs = cellstr(num2str(nc));
cs = cellstr(num2str((1:C)'));
cs{end} = ['$$' num2str(C) ' = C$$'];

% text denoting indices of cohorts set after the trailing edge of cells
text(0.5 + x(1:P), 0.66 + y(1:P), cs(1:P), ...
    'rotation', -90, ...
    'Color', MAP(10, :), 'FontSize', fs1, 'Interpreter', 'latex')
text(0.66 + x(P+1:C), 0.5 + y(P+1:C), cs(P+1:C), ...
    'Color', MAP(10, :), 'FontSize', fs1, 'Interpreter', 'latex')

xlabel('Period', 'FontSize', fs1)
ylabel('Age', 'FontSize', fs1, 'Rotation', -90, ...
    'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'center')

x = [p0; P*ones(A-1, 1)];
y = [A*ones(P, 1); (A-1:-1:1)'];

% number of cells per cohort within the trailing edge of cells
text(x(1:P), y(1:P) , ncs(1:P), ...
    'FontSize', fs2, 'Color', MAP(10, :), 'HorizontalAlignment', 'center')

text(x(P+1:C), y(P+1:C), ncs(P+1:C), ...
    'FontSize', fs2, 'Color', MAP(10, :), 'HorizontalAlignment', 'center')

%%%
% eye candy
%%%

text(0.5, 0.5, '$$(a_0,p_0)$$', ...
    'VerticalAlignment', 'middle', ...
    'HorizontalAlignment', 'right', ...
    'Rotation', -45, ...
    'Interpreter', 'latex', 'FontSize', fs1(1))

xl = cellstr(num2str((1:P)'));
xl{end} = ['$$P = ' xl{end} '$$'];
set(ah1, 'XTickLabel', xl, 'TickLabelInterpreter', 'latex')

yl = cellstr(num2str((1:A)'));
yl{end} = ['$$A = ' yl{end} '$$'];
set(ah1, 'YTickLabel', yl, 'TickLabelInterpreter', 'latex')

xlabel('Period', 'FontSize', fs1, 'VerticalAlignment', 'cap')
ylabel('Age',    'FontSize', fs1, 'VerticalAlignment', 'bottom', ...
    'HorizontalAlignment', 'Center', 'Rotation', -90)
text(0.5, A+0.5, {' ', 'Cohort'}, ...
    'FontSize', fs1, 'VerticalAlignment', 'cap', ......
    'HorizontalAlignment', 'Center', 'Color', MAP(10, :))

a_0 = R.ages(1);
p_0 = R.periods(1);
title(['$$\mathcal{L}(a_0,p_0,A,P,\Delta) = \mathcal{L}(' ...
    num2str(a_0), ',' num2str(p_0), ',', num2str(A), ',', ...
    num2str(P), ',', num2str(Delta), ...
    ')$$'], ...
    'Interpreter', 'latex', 'verticalalignment', 'bottom')

switch nargout
    case 0
    case 1
        varargout{1} = Landmarks;
    otherwise
        error('too many outputs')
end

end



