function RATES2CSV(R, varargin)
% RATES2CSV Export a rates object to a csv file.
%
% RATES2CSV(R)
% 
% * The output csv filename is determined by the fullname
% * The csv files have 6 header lines including separate age and period
%   intervals whether these are equal or not
%
% See also csv2rates.

%%%
% Determine filename from fullname
%  * remove chromacodes
%  * remove commas: comma == separator
%%%

FN = strrep(...
    replaceBetween(R.fullname, '\color[rgb]{', '}', ''), ...
    '\color[rgb]{}', '');
FN = strrep(FN, ',', ' ');
PFN = [pwd '/' FN '.csv'];

%%%
% Open target file for writing, discard existing contents
%%%
fid = fopen(PFN, 'w');
[A, P] = size(R);
comma = ',';
% commas = comma(ones(1, P-1));
fprintf(fid, ['Title: ' FN comma '\n']);
s = cell(1, length(R.description));
for j = 1:length(R.description)
    s{j} = [R.description{j} ' '];
end
s = [s{:}];
fprintf(fid, ['"Description: ' s '"' comma '\n']);

fprintf(fid, ['Start Year: ' num2str(R.periods(1)) comma '\n']);

fprintf(fid, ['Start Age: ' num2str(R.ages(1)) comma '\n']);

fprintf(fid, ['Period Bin (Years): ' num2str(R.periods(2) - R.periods(1)) comma '\n']);

fprintf(fid, ['Age Bin (Years): ' num2str(R.ages(2) - R.ages(1)) comma '\n']);

EO = type(R, 'comp', 'eo', 'ages', 0);

FormatString = cell(1, 2*P);
k = 0;
for i = 1:P
    k1 = k+1;
    k2 = k+2;
    FormatString{1, k1} = '%f, ';
    FormatString{1, k2} = '%f, ';
    k = k+2;
end
FormatString = [FormatString{1:end}];
FormatString(end-1:end) = '\n';

for k = 1:A
    fprintf(fid, FormatString, EO.data(k, :));
end

fclose(fid);

end