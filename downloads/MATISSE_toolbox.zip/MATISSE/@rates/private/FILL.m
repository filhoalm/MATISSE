function F = FILL(R, varargin)
% Fill missing data in a rates object.

% Check inputs
PVP = f_PVP(R, varargin{:});

%%%
% Fill missing event counts
%%%

%%%
% Handle the case where we have no analyzable data
%%%
e = R.Events;
o = R.Offset;

if all(isnan(e(:)))

    e = 0.1 * ones(size(R));
    o = ones(size(R));

end

DELTA = R.ages(2) - R.ages(1);

switch PVP.zero_fill
    case 'adp'
        Ie = isnan(e) | (e==0);
        ne = sum(Ie(:));
        if ne > 0
            ZFV = tiny_value(e, DELTA);
            e(Ie) = ZFV;
        end
    otherwise
        Ie = isnan(e) | (e==0);
        ne = sum(Ie(:));
        if ne > 0
            ZFV = PVP.zero_fill;
            e(Ie) = ZFV;
        end
end

%%%
% Fill missing offset values
%%%
switch PVP.offset
    case 'neighbors'
        Io = isnan(o);
        no = sum(Io(:));
        if no > 0
            % Calculate the average of all adjacent cells
            AVG = neighbor_avg(o);
            % Set missing cell values to average of adjacent cells
            o(Io) = AVG(Io);
        end
    otherwise
        Io = isnan(o);
        no = sum(Io(:));
        if no > 0
            % Calculate the average of all adjacent cells
            VAL = PVP.offset;
            % Set missing cell values to average of adjacent cells
            o(Io) = VAL(Io);
        end
end

% Count the number of imputations
NI = ne + no;
if NI > 0
    note = ['Number of imputed cells: ' num2str(NI)];
    dt = [R.description, note];
else
    dt = R.description;
end

% Put back into rates object
F = rates(...INPU
    'Events', e, ...
    'Offset', o, ...
    'fullname', R.fullname, ...
    'label', R.label, ...
    'chromacode', R.chromacode, ...
    'event_label', R.event_label, ...
    'description', dt, ...
    'offset_units', R.offset_units, ...
    'offset_tick', R.offset_tick, ...
    'ages', R.ages, ...
    'periods', R.periods);

end

function PVP = f_PVP(R, varargin)
% property-value pairs

PVP = struct('R', R, ...
    'zero_fill', 'adp', ...
    'offset', 'neighbors');

% Check dimensions
[A, P] = size(R);
if A < 3 || P < 3
    error('rates object has too few rows or columns to fill')
end

Nl = numel(varargin);
lArgin = varargin;
if eq(Nl, 1)
    error('too few inputs');
end

while Nl >= 2

    propi = lArgin{1};
    vali = lArgin{2};

    if ~ischar(propi)
        error('a property must be specified using a string')
    end

    switch lower(propi)

        case 'zero_fill'

            if ischar(vali)

                vals = {'adp'};
                s = strcmpi(vali, vals);
                if ~any(s)
                    error([vali ' is an unrecognized fill method'])
                end
                PVP.zero_fill = vali;

            else

                % Must be a real scalar
                if ~(isscalar(vali) && isreal(vali) && isnumeric(vali))
                    error('fill must be be a scalar');
                end
                % Must be >=0
                if vali >= 0
                    % this is OK; update
                    PVP.zero_fill = vali;
                else
                    error('fill must be nonnegative');
                end

            end

        case 'offset'

            if ischar(vali)

                vals = {'neighbors'};
                s = strcmpi(vali, vals);
                if ~any(s)
                    error([vali ' is an unrecognized fill method'])
                end
                PVP.offset = vali;

            else

                % Must be a real scalar
                if ~(isscalar(vali) && isreal(vali) && isnumeric(vali))
                    error('offset must be be a scalar');
                end
                % Must be >=0
                if vali >= 0
                    % this is OK; update
                    PVP.offset = vali;
                else
                    error('offset must be nonnegative');
                end

            end
        case 'alpha'
        otherwise
    end

    % setup for the next pair
    lArgin = lArgin(3:end);
    Nl = numel(lArgin);
    if eq(Nl, 1)
        error('the last property has no matching value');
    end

end

end

function ZFV = tiny_value(e, DELTA)
% Fill value for zeros in a matrix of non-negative data.

E = unique(e(:));
u = unique(E);
U = u(u > 0);
if isempty(U)
    U = 0.1;
end
N = numel(U);
C = min(N, 5);
L_C = (12/(DELTA*(C-1)*C*(C+1))) * ((1:1:C)' - ((C+1)/2)*ones(C, 1))';
B = L_C*U(1:C);
% When DELTA = 1: halfway between the smallest value minus 1 and zero, or
% 0.5, whichever is larger
ZFV = max(0.5*(U(1) - B)/DELTA, 0.5);

end

function AVG = neighbor_avg(MAT)
% Neighbor averages for matrix with 3 or more rows and columns.
[R, C] = size(MAT);

AVG = NaN(R, C);

% NW corner:
AVG(1,1) = mean([MAT(2,1) MAT(2,2) MAT(1,2)], 'omitnan');

% SW corner:
AVG(R, 1) = mean([MAT((R-1), 1) MAT((R-1), 2) MAT(R, 2)], 'omitnan');

% NE corner:
AVG(1, C) = mean([MAT(1, (C-1)) MAT(2, (C-1)) MAT(2, C)], 'omitnan');

% SE corner:
AVG(R, C) = mean([MAT(R, (C-1)) MAT((R-1), (C-1)) MAT((R-1), C)], 'omitnan');

% Top row
for i = 2:(C-1)
    AVG(1, i) = mean([MAT(1, (i-1)) MAT(1, (i+1)) MAT(2, i) ...
        MAT(2, (i-1)) MAT(2, (i+1))], 'omitnan');
end

% Bottom row
for i = 2:(C-1)
    AVG(R, i) = mean([MAT(R, (i-1)) MAT(R, (i+1)) ...
        MAT((R-1), i) MAT((R-1), (i-1)) MAT((R-1), (i+1))], 'omitnan');
end

% First column
for i = 2:(R-1)
    AVG(i, 1) = mean([MAT((i-1), 1) MAT((i+1), 1) MAT(i, 2) ...
        MAT((i-1),2) MAT((i+1), 2)], 'omitnan');
end

% Last column
for i = 2:(R-1)
    AVG(i, C) = mean([MAT((i-1), C) MAT((i+1), C) MAT(i, (C-1)) ...
        MAT((i-1), (C-1)) MAT((i+1), (C-1))], 'omitnan');
end

% Interior cells
for i = 2:(R-1)
    for j = 2:(C-1)
        AVG(i, j) = mean([...
            MAT((i-1), (j-1)) MAT(i, (j-1)) MAT((i+1), (j-1)) ...
            MAT((i-1), j) MAT((i+1), j) MAT((i-1), (j+1)) ...
            MAT(i, (j+1)) MAT((i+1), (j+1))], 'omitnan');
    end
end


%%%
% It is possible that some cells may still be NaN. For such cells fill in
% with the overall grand average.
%%%
miss = isnan(AVG);
if any(miss(:))
    GrandAVG = mean(AVG(:), 'omitnan');
    AVG(miss) = GrandAVG;
end

end