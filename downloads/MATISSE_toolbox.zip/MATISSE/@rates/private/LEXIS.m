function LEXIS(R, varargin)
% Paired heat maps for period and cohort versus age.

% openers
if isempty(R)
    error('no data to plot')
end

switch numel(varargin)
    case 0
        Type = 'pcolor';
        pvp = ego('class', 'rates', 'method', 'lexis');

    case 1
        Type = varargin{1};
        if ~(ischar(Type) && ismember(lower(Type), {'pcolor', 'hexmap'}))
            error([Type ...
                ' is not recognized, valid options ' ...
                'are ''pcolor'' and ''hexmap'''])
        end
        pvp = ego('class', 'rates', 'method', 'lexis');

    case 2
        Type = varargin{1};
        if ~(ischar(Type) && ismember(lower(Type), {'pcolor', 'hexmap'}))
            error([Type ...
                ' is not recognized, valid options ' ...
                'are ''pcolor'' and ''hexmap'''])
        end
        pvp = varargin{2};

    otherwise
        error('too may inputs')
end

T = type(R, 'comp', 'lr');

[A, P] = size(R);
C = A + P - 1;
B = (C - P)/2;
L = floor(B);
H = ceil(B);
M = pad(...
    pad(matrix('data', T), ...
    'cols', L, 'cpos', 'left', 'fill', 0), ...
    'cols', H, 'cpos', 'right', 'fill', 0);

D = diagonals(T);

figure('Position', [0 0 1000 750])

% only one colorbar is needed
pvp0 = pvp;
pvp0.colorbar = '';

subplot(1, 2, 1)
switch Type
    case 'pcolor'
        pcolor(M', pvp0)
    case 'hexmap'
        hexmap(M', pvp0)
        set(gca, 'Color', [0.95 0.95 0.95])
end

if ~isempty(pvp.colorbar)
    ch = colorbar(gca, 'Location', pvp.colorbar);
    ch.Label.String = 'log rate';
end

xlabel('Cross-Sectional Age', 'FontSize', 12)
ylabel('Cross-Sectional Period', 'FontSize', 12)

subplot(1, 2, 2)
switch Type
    case 'pcolor'
        pcolor(D', pvp0)
    case 'hexmap'
        hexmap(D', pvp0)
        set(gca, 'Color', [0.95 0.95 0.95])

end

xlabel('Longitudinal Age', 'FontSize', 12)
ylabel('Cross-Sectional Cohort', 'FontSize', 12)
set(gca, 'YTickLabel', type(R, 'comp', 'c').data(end:-1:1))

end