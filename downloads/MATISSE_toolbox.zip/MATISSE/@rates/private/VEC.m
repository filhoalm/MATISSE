function D = VEC(varargin)
% RATES/VEC convert rates object to a table with one row per cell.

% precheck
precheck(varargin{:});

K = nargin;

% use the first rates object as the template
R = varargin{1};
[A, P] = size(R);
ADATA = kron(ones(P, 1), R.a(:));
PDATA = kron(R.p(:), ones(A, 1));
CDATA = PDATA - ADATA;

AP = A*P;
L = AP*K;
E = zeros(L, 1);
O = zeros(L, 1);
G = zeros(L, 1);
fn = cell(1, K);
lb = cell(1, K);
cc = cell(1, K);

for k = 1:K
 
    r = varargin{k};

    E(AP*(k-1)+1:1:AP*k, 1) = r.Events(:);
    O(AP*(k-1)+1:1:AP*k, 1) = r.Offset(:);
    G(AP*(k-1)+1:1:AP*k, 1) = k;

    fn{k} = r.fullname;
    lb{k} = r.label;
    cc{k} = r.chromacode;

end

ADATA = kron(ones(K, 1), ADATA);
AGE = categoric(...
    'data', ADATA, ...
    'fullname', 'Age', ...
    'values', R.a, ...
    'labels', R.age_labels); 
age = continuous('data', ADATA, 'fullname', 'Age');

PDATA = kron(ones(K, 1), PDATA);
PER = categoric(...
    'data', PDATA, ...
    'fullname', 'Period', ...
    'values', R.p, ...
    'labels', R.per_labels); 
per = continuous('data', PDATA, 'fullname', 'Period');

CDATA = kron(ones(K, 1), CDATA);
c0 = unique(CDATA);
COH = categoric(...
    'data', CDATA, ...
    'fullname', 'Cohort', ...
    'values', c0, ...
    'labels', cellstr(num2str(c0))); 
coh = continuous('data', CDATA, 'fullname', 'Cohort');

y = [E, O];

r = continuous(...
    'data', R.offset_tick.*E./O, ...
    'fullname', ['rate per ' num2str(R.offset_tick)]);

v = continuous(...
    'data', (R.offset_tick./O).^2.*E, ...
    'fullname', 'variance');

fullname = categoric(...
    'data', G, ...
    'fullname', 'fullname', ...
    'labels', fn);

label = categoric(...
    'data', G, ...
    'fullname', 'label', ...
    'labels', lb);

chromacode = categoric(...
    'data', G, ...
    'fullname', 'chromacode', ...
    'labels', cc);
strata = label;

D = table(E, O, y, r, v, ...
    AGE, age, PER, per, COH, coh, strata, ...
    fullname, label, chromacode);

% end VEC
end

% helper functions

function precheck(varargin)

K = nargin;

% all inputs must be rates objects
for i = 1:K
    if ne(class(varargin{i}), 'rates')
        error('all inputs must be rates objects')
    end
end

% all rates objects must be defined over the same Lexis diagram
L = lexis(varargin{1});
for i = 2:K
    Lk = lexis(varargin{i});
    if ~(all(L == Lk))
        error('each rate object must be defined over the same Lexis diagram')
    end
end

% end preprocess
end

function L = lexis(r)
[A, P] = size(r);
a0 = r.ages(1);
p0 = r.periods(1);
DELTAa = r.ages(2) - r.ages(1);
DELTAp = r.periods(2) - r.periods(1);
L = [A P a0 p0 DELTAa DELTAp];
% end lexis
end




