classdef rates
    % RATES rates objects contain event rates ascertained over a Lexis diagram.
    %
    % The Lexis diagram is a fundamental construct in epidemiology,
    % demography, and sociology.
    %
    % A Lexis diagram is a rectangular array of square cells with age
    % groups along one axis and calendar periods along the other.
    %
    % Each cell contains the number of events that occurred in that age
    % group and calendar period, and the corresponding units of
    % observation, e.g. person-years.
    %
    % See https://pubmed.ncbi.nlm.nih.gov/21610223/ for a discussion of
    % Lexis diagrams in age-period-cohort analysis.
    %
    % MATISSE's age-period-cohort analysis tools work with RATES objects.
    %
    % The ratesdata method provides some examples.
    %
    % See also: rates/rates, ratesdata, apc.

    properties

        Events (:, :) {mustBeMatrix} = [];           % A x P double
        Offset (:, :) {mustBeMatrix} = [];           % A x P double
        fullname (1, :) {mustBeTextScalar} = '';     % scientific name
        label (1, :) {mustBeTextScalar} = '';        % nickname used in plots
        chromacode (1, :) {mustBeTextScalar} = '';   % name with embedded color codes
        event_label (1, :) {mustBeTextScalar} = '';  % e.g. 'Cases' or 'Deaths'
        description (1, :) {mustBeText} = {''};      % sticky notes
        offset_units (1, :) {mustBeText} = '';       % e.g. 'PY'
        offset_tick (1, :) {mustBeNumeric} = [];     % defaults to 100,000
        ages (1, :) {mustBeMatrix} = [];             % A + 1 cutpoints for age
        age_labels (1, :) {mustBeText} = {''};       % labels for age groups
        a (1, :) {mustBeMatrix} = [];                % midpoints of age groups
        periods (1, :) {mustBeMatrix} = [];          % P + 1 cutpoints for period
        per_labels (1, :) {mustBeText} = {''};       % labels for calendar periods
        p (1, :) {mustBeMatrix} = [];                % midpoints of calendar periods

    end


    methods

        %%%
        % housekeeping
        %%%

        function R = rates(varargin)
            % RATES Event rates ascertained over a Lexis diagram.
            %
            % * You must include 'Events' and 'Offset' data.
            %
            % * You can characterize the underlying Lexis diagram using
            %   'ages' and 'periods' or 'lexis' property-value pairs.
            %
            % R = RATES(...
            %           'Events', <AxP numeric matrix>, ...
            %           'Offset', <AxP numeric matrix>, ...
            %           'fullname', 'string', ...
            %           'label', 'string', ...
            %           'chromacode', 'string', ...
            %           'event_label', 'string', ...
            %           'offset_units', 'string', ...
            %           'offset_tick', <scalar>, ...
            %           'ages', <A+1 cutpoints [a0, a1, ..., aA]>, ...
            %           'periods', <P+1 cutpoints [p0, p1, ..., pP>, ...
            %           'lexis', <[a0, p0, DELTAa, DELTAp]>)
            %
            % See also uni, pcolor.

            if nargin == 0
                % Contents of an empty rates objects
                R.Events = [];
                R.Offset = [];
                R.fullname = '';
                R.label = '';
                R.chromacode = '';
                R.event_label = '';
                R.description = {''};
                R.offset_units = '';
                R.offset_tick = [];
                R.ages = [];
                R.age_labels = {''};
                R.a = [];
                R.periods = [];
                R.per_labels = {''};
                R.p = [];
                return
            end

            if isa(varargin{1}, 'rates')
                R = varargin{1};
                return
            end

            % Contents of an empty rates object
            R.Events = [];
            R.Offset = [];
            R.fullname = '';
            R.label = '';
            R.chromacode = '';
            R.event_label = '';
            R.description = {''};
            R.offset_units = '';
            R.offset_tick = 100000;
            R.ages = [];
            R.age_labels = {''};
            R.a = [];
            R.periods = [];
            R.per_labels = {''};
            R.p = [];

            N = numel(varargin);

            if N == 0
                return
            end

            UserSpecLexis = 0;
            Lexis = [];

            %%%
            % whittle the arguments
            %%%
            lArgin = varargin;
            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};

                if ~ischar(propi)
                    error('A property must be specified using a string.')
                end

                switch lower(propi)

                    case 'events'
                        if ismatrix(vali) && isreal(vali)
                            if ~(any(vali(:) < 0))
                                R.Events = vali;
                            else
                                error('Events must be non-negative')
                            end
                        else
                            error('Events must be a numeric matrix')
                        end

                    case 'offset'
                        if ismatrix(vali) && isreal(vali)
                            if ~(any(vali(:) < 0))
                                R.Offset = vali;
                            else
                                error('Offset by be non-negative')
                            end
                        else
                            error('Offset must be a numeric matrix')
                        end

                    case 'fullname'
                        if ischar(vali)
                            R.fullname = vali;
                        else
                            error('fullname must be a string')
                        end

                    case 'label'
                        if ischar(vali)
                            R.label = vali;
                        else
                            error('label must be a string')
                        end

                    case 'chromacode'
                        if ischar(vali)
                            R.chromacode = vali;
                        else
                            error('chromacode must be a string')
                        end

                    case 'event_label'
                        if ischar(vali)
                            R.event_label = vali;
                        else
                            error('event_label must be a string')
                        end

                    case 'description'
                        if ~iscellstr(vali) %#ok<ISCLSTR>
                            error('description must be a cellstr')
                        else
                            R.description = vali;
                        end

                    case 'offset_units'
                        if ischar(vali)
                            R.offset_units = vali;
                        else
                            error('offset_units must be a string')
                        end

                    case 'offset_tick'
                        if ~(isscalar(vali) && isreal(vali))
                            error('offset_tick must be a real scalar')
                        else
                            if vali < 0
                                error('offset_tick must be positive')
                            else
                                R.offset_tick = vali;
                            end
                        end

                    case 'ages'
                        if ismatrix(vali) && isreal(vali)
                            R.ages = vali(:)';
                        else
                            error('ages must be a vector')
                        end

                    case 'periods'
                        if ismatrix(vali) && isreal(vali)
                            R.periods = vali(:)';
                        else
                            error('periods must be a vector')
                        end

                    case 'lexis'
                        if ismatrix(vali) && isreal(vali) && ismember(numel(vali), [3 4])
                            UserSpecLexis = 1;
                            Lexis = vali(:)';
                            if eq(numel(Lexis), 3)
                                Lexis = Lexis([1 2 3 3]);
                            end
                        else
                            error('invalid specification of the lexis')
                        end

                    otherwise

                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('the last property has no matching value');
                end
            end

            %%%
            % size validation - Events and Offset
            %%%
            [Ae, Pe] = size(R.Events);
            if isscalar(R.Offset)
                R.Offset = repmat(R.Offset, Ae, Pe);
            end
            [Ao, Po] = size(R.Offset);

            if ~(eq(Ae, Ao) && eq(Pe, Po))
                error('size mismatch between Events and Offset')
            end
            [A, P] = size(R.Events);

            switch UserSpecLexis
                case 0

                    if isempty(R.ages)
                        a0 = 0;
                        DELTAa = 1;
                        R.ages = a0:DELTAa:(a0 + DELTAa*A);
                        R.a = (a0 - 0.5*DELTAa) + DELTAa * (1:A);
                        R.age_labels = cellstr(num2str(R.ages(1:A)'))';
                    else
                        if ne(numel(R.ages), A+1)
                            error('ages has the wrong length')
                        end
                        a0 = R.ages(1);
                        DELTAa = R.ages(2) - R.ages(1);
                        R.a = (a0 - 0.5*DELTAa) + DELTAa * (1:A);
                        if eq(DELTAa, 1)
                            R.age_labels = cellstr(num2str(R.ages(1:A)'))';
                        else
                            TMP1 = cellstr(num2str(R.ages(1:A)'));
                            TMP2 = cellstr(num2str(R.ages(2:A+1)' - 1));
                            al = [str('data', TMP1) ' - ' str('data', TMP2)];
                            R.age_labels = al.data;
                        end
                    end

                    if isempty(R.periods)
                        p0 = 0;
                        DELTAp = 1;
                        R.periods = p0:DELTAp:(p0 + DELTAp*P);
                        R.p = (p0 - 0.5*DELTAp) + DELTAp * (1:P);
                        R.per_labels = cellstr(num2str(R.periods(1:P)'))';
                    else
                        if ne(numel(R.periods), P+1)
                            error('periods has the wrong length')
                        end
                        p0 = R.periods(1);
                        DELTAp = R.periods(2) - R.periods(1);
                        R.p = (p0 - 0.5*DELTAp) + DELTAp * (1:P);
                        if eq(DELTAp, 1)
                            R.per_labels = cellstr(num2str(R.periods(1:P)'))';
                        else
                            TMP1 = cellstr(num2str(R.periods(1:P)'));
                            TMP2 = cellstr(num2str(R.periods(2:P+1)' - 1));
                            pl = [str('data', TMP1) ' - ' str('data', TMP2)];
                            R.per_labels = pl.data;
                        end
                    end


                case 1

                    a0 = Lexis(1);
                    p0 = Lexis(2);
                    DELTAa = Lexis(3);
                    DELTAp = Lexis(4);
                    R.ages = a0:DELTAa:(a0 + DELTAa*A);
                    R.a = (a0 - 0.5*DELTAa) + DELTAa * (1:A);
                    R.periods = p0:DELTAp:(p0 + DELTAp*P);
                    R.p = (p0 - 0.5*DELTAp) + DELTAp * (1:P);

                    if eq(DELTAa, 1)
                        R.age_labels = cellstr(num2str(R.ages(1:A)'))';
                    else
                        TMP1 = cellstr(num2str(R.ages(1:A)'));
                        TMP2 = cellstr(num2str(R.ages(2:A+1)' - 1));
                        al = [str('data', TMP1) ' - ' str('data', TMP2)];
                        R.age_labels = al.data;
                    end

                    if eq(DELTAp, 1)
                        R.per_labels = cellstr(num2str(R.periods(1:P)'))';
                    else
                        TMP1 = cellstr(num2str(R.periods(1:P)'));
                        TMP2 = cellstr(num2str(R.periods(2:P+1)' - 1));
                        pl = [str('data', TMP1) ' - ' str('data', TMP2)];
                        R.per_labels = pl.data;
                    end

                otherwise

            end

            % hierarchical labelling
            if isempty(R.fullname)
                R.fullname = 'rates';
            end
            if isempty(R.label)
                R.label = R.fullname;
            end
            if isempty(R.chromacode)
                R.chromacode = R.label;
            end

            % more defaults
            if isempty(R.event_label)
                R.event_label = 'events';
            end

            if isempty(R.offset_units)
                R.offset_units = 'PY';
            end

            if isempty(R.offset_tick)
                R.offset_tick = 100000;
            end

        end

        function varargout = size(R, varargin)
            % SIZE Size of a rates object.
            %
            % [A, P] = size(R)
            % A = size(R, 1)
            % P = size(R, 2)
            %
            % Number of age groups A and calendar periods P in R.
            %
            % See also isempty.

            switch nargin
                case 1
                    switch nargout
                        case {0, 1}
                            varargout{1} = [size(R.Events, 1), size(R.Events, 2)];
                        case 2
                            varargout{1} = size(R.Events, 1);
                            varargout{2} = size(R.Events, 2);
                        otherwise
                            error('too many outputs')
                    end

                case 2
                    d = varargin{1};
                    switch nargout
                        case {0, 1}
                            varargout{1} = size(R.Events, d(1));
                        case 2
                            varargout{1} = size(R.Events, d(1));
                            varargout{2} = size(R.Events, d(2));
                        otherwise
                            error('too many outputs')
                    end
            end
        end

        function S = isempty(R)
            % ISEMPTY Determine whether a rates object is empty.
            %
            % S = isempty(R)
            %
            % S is logical true or false.
            %
            % See also size.

            S = isempty(R.Events);
        end

        function r = end(g, k, ~)
            % END end method for a rates object.

            switch k
                case 1
                    r = size(g, 1);
                case 2
                    r = size(g, 2);
                otherwise
            end

        end

        function disp(R)
            % DISP Command window disp of a rates object.
            %
            % DISP(R)
            %
            % See also uni.

            if isempty(R.Events)
                disp('empty rates object')
                return
            end

            disp(['<strong>' R.fullname '</strong>'])
            disp(' ')
            A = size(R, 1);
            if A > 1
                disp(['<strong>  * ' sprintf('%4.0f', A) '</strong> age groups ' R.age_labels{1} ' through ' R.age_labels{end} '.'])

            elseif A == 1
                disp(['<strong>  * ' sprintf('%4.0f', A) '</strong> age group ' R.age_labels{1} '.'])

            else % A == 0

            end

            P = size(R, 2);
            if P > 1
                disp(['<strong>  * ' sprintf('%4.0f', P), '</strong> calendar periods ' R.per_labels{1} ' through ' R.per_labels{end} '.'])

            elseif P == 1
                disp(['<strong>  * ' sprintf('%4.0f', P), '</strong> calendar period ' R.per_labels{1} '.'])
            else % P == 0

            end

            DELTAa = R.ages(2) - R.ages(1);
            DELTAp = R.periods(2) - R.periods(1);

            if eq(DELTAa, DELTAp)
                C = A + P - 1;
                c1 = R.p(1) - R.a(A);
                cC = R.p(P) - R.a(1);
                if C > 1
                    disp(['<strong>  * ' sprintf('%4.0f', C), '</strong> nominal birth cohorts ' num2str(c1) ' through ' num2str(cC) '.'])
                elseif C == 1
                    disp(['<strong>  * ' sprintf('%4.0f', C), '</strong> nominal birth cohort ' num2str(c1) '.'])
                else % C == 0

                end
            end

            nmiss = sum(isnan(R.Events(:)));
            nzero = nnz(R.Events(:)==0);
            switch nzero
                case 0
                    msg1 = '';
                case 1
                    msg1 = '  * 1 zero cell.';
                otherwise
                    msg1 = ['  * ' num2str(nzero, '%4.0f') ' zero cells. '];
            end


            e = R.Events(:);
            s = [min(e, [], 'omitnan') mean(e, 'omitnan') max(e, [], 'omitnan')];

            msg3 = ['  #   events:  ' ...
                'min <strong>' sprintf('%3.1f  ', s(1)) '</strong> '...
                'mean <strong>' sprintf('%3.1f  ', s(2)) '</strong> '...
                'max <strong>' sprintf('%3.1f  ', s(3)) '</strong> '...
                ];

            switch nmiss
                case 0
                    msg2 = '';
                case 1
                    msg2 = '  * 1 cell has missing data.';
                otherwise
                    msg2 = ['  * ' num2str(nmiss, '%4.0f') ' cells have missing data.'];
            end

            disp(msg1)
            disp(' ')
            disp(msg3)
            disp(msg2)
            disp(' ')

            E = sum(R.Events(:), 'omitnan');
            O = sum(R.Offset(:), 'omitnan');
            disp(['<strong>' num2str(E, '%15.0f') '</strong> total ' R.event_label ...
                ' in <strong>' num2str(O, '%20.0f') '</strong> ' R.offset_units '.'])

        end

        function U = subsref(R, S)
            % SUBSREF Subscripted referencing for a rates object.

            if length(S) > 1

                DEPTH = numel(S);
                for d = 1:DEPTH
                    if d == 1
                        U = subsref(R, S(1));
                    else
                        U = subsref(U, S(d));
                    end
                end

            else

                switch S.type

                    case '.'

                        switch S.subs

                            case 'Events'
                                U = R.Events;
                            case 'Offset'
                                U = R.Offset;
                            case 'fullname'
                                U = R.fullname;
                            case 'label'
                                U = R.label;
                            case 'chromacode'
                                U = R.chromacode;
                            case 'event_label'
                                U = R.event_label;
                            case 'description'
                                U = R.description;
                            case 'offset_units'
                                U = R.offset_units;
                            case 'offset_tick'
                                U = R.offset_tick;
                            case 'ages'
                                U = R.ages;
                            case 'age_labels'
                                U = R.age_labels;
                            case 'a'
                                U = R.a;
                            case 'periods'
                                U = R.periods;
                            case 'per_labels'
                                U = R.per_labels;
                            case 'p'
                                U = R.p;
                            otherwise

                        end

                    case '()'

                        NI = numel(S.subs);
                        switch NI
                            case 1
                                SUBS = cell(1, 2);
                                SUBS{1} = S.subs{1};
                                SUBS{2} = ':';
                            case 2
                                SUBS = S.subs;
                            otherwise
                                SUBS{1} = S.subs;
                                SUBS{2} = ':';
                        end


                        % if it's a boolean, replace S.subs{1} with indices
                        if isa(SUBS{1}, 'boolean')
                            SUBS{1} = find(SUBS.data == 1);
                        elseif isa(SUBS{1}, 'logical')
                            SUBS{1} = SUBS{1};
                        else
                            % let MATLAB hande any errors
                        end
                        if isa(SUBS{2}, 'boolean')
                            SUBS{2} = find(SUBS{2}.data == 1);
                        elseif isa(SUBS{2}, 'logical')
                            SUBS{2} = SUBS{2};
                        else
                            % let MATLAB handle any errors
                        end

                        EVENTS = R.Events(SUBS{1}(:), SUBS{2}(:));
                        OFFSET = R.Offset(SUBS{1}(:), SUBS{2}(:));
                        DELTAa = R.ages(2) - R.ages(1);
                        DELTAp = R.periods(2) - R.periods(1);
                        newa = R.a(SUBS{1}(:));
                        newp = R.p(SUBS{2}(:));

                        % check for contiguity
                        da = diff(newa);
                        dp = diff(newp);
                        if isempty(da)
                            ok1 = 1;
                        elseif all(eq(da, da(1)))
                            ok1 = 1;
                        else
                            ok1 = 0;
                        end
                        if isempty(dp)
                            ok2 = 1;
                        elseif all(eq(dp, dp(1)))
                            ok2 = 1;
                        else
                            ok2 = 0;
                        end
                        if ~(ok1 && ok2)
                            error('values must be contiguous')
                        end

                        a0 = newa(1) - 0.5*DELTAa;
                        p0 = newp(1) - 0.5*DELTAp;
                        lexis = [a0 p0 DELTAa DELTAp];


                        U = rates(...
                            'Events', EVENTS, ...
                            'Offset', OFFSET, ...
                            'fullname', R.fullname, ...
                            'label', R.label, ...
                            'chromacode', R.chromacode, ...
                            'event_label', R.event_label, ...
                            'description', R.description, ...
                            'offset_units', R.offset_units, ...
                            'offset_tick', R.offset_tick, ...
                            'lexis', lexis);

                    case '{}'

                        % do nothing
                        U = R;

                end

            end

        end

        function U = subsasgn(R, S, V)
            % SUBSASGN Subscripted assignment for a rates object.

            U = R;
            a0 = R.ages(1);
            p0 = R.periods(1);
            DELTAa = R.ages(2) - R.ages(1);
            DELTAp = R.periods(2) - R.periods(1);
            lexis = [a0 p0 DELTAa DELTAp];

            if length(S) > 1

                DEPTH = numel(S);
                for d = 1:DEPTH
                    if d == 1
                        U = subsref(R, S(1));
                    else

                        U = subsref(U, S(d));
                    end
                end

            else

                switch S.type

                    case '.'

                        switch S.subs

                            case 'Events'
                                U = rates(...
                                    'Events', V, ...
                                    'Offset', R.Offset, ...
                                    'fullname', R.fullname, ...
                                    'label', R.label, ...
                                    'chromacode', R.chromacode, ...
                                    'event_label', R.event_label, ...
                                    'offset_units', R.offset_units, ...
                                    'offset_tick', R.offset_tick, ...
                                    'lexis', lexis);

                            case 'Offset'
                                U = rates(...
                                    'Events', R.Events, ...
                                    'Offset', V, ...
                                    'fullname', R.fullname, ...
                                    'label', R.label, ...
                                    'chromacode', R.chromacode, ...
                                    'event_label', R.event_label, ...
                                    'offset_units', R.offset_units, ...
                                    'offset_tick', R.offset_tick, ...
                                    'lexis', lexis);

                            case 'fullname'
                                U.fullname = V;

                            case 'label'
                                U.label = V;

                            case 'description'
                                U.description = V;

                            case 'chromacode'
                                U.chromacode = V;

                            case 'event_label'
                                U.event_label = V;

                            case 'offset_units'
                                U.offset_units = V;

                            case 'offset_tick'
                                U.offset_tick = V;

                            case 'ages'
                                U = rates(...
                                    'Events', R.Events, ...
                                    'Offset', R.Offset, ...
                                    'fullname', R.fullname, ...
                                    'label', R.label, ...
                                    'chromacode', R.chromacode, ...
                                    'event_label', R.event_label, ...
                                    'description', R.description, ...
                                    'offset_units', R.offset_units, ...
                                    'offset_tick', R.offset_tick, ...
                                    'ages', V, ...
                                    'periods', R.periods);

                            case 'periods'
                                U = rates(...
                                    'Events', R.Events, ...
                                    'Offset', R.Offset, ...
                                    'fullname', R.fullname, ...
                                    'label', R.label, ...
                                    'chromacode', R.chromacode, ...
                                    'event_label', R.event_label, ...
                                    'description', R.description, ...
                                    'offset_units', R.offset_units, ...
                                    'offset_tick', R.offset_tick, ...
                                    'ages', R.ages, ...
                                    'periods', V);

                            otherwise

                        end

                    case '()'
                        warning('parentheses indexing is undefined')

                    case '{}'
                        warning('brace indexing is undefined')



                end

            end

        end

        function rates2csv(R)
            % RATES2CSV Export a rates object to a csv file.
            %
            % RATES2CSV(R)
            %
            % * The filename is determined by the fullname.
            % * The csv file is compatible with the NCI Web Tool
            %   (https://analysistools.cancer.gov/apc/)
            %
            % See also csv2rates.

            RATES2CSV(R)
        end

        function varargout = geometry(R, varargin)
            % GEOMETRY Characteristics of the Lexis diagram of a rates object.
            %
            % GEOMETRY(R) or L = GEOMETRY(R)
            %
            % * GEOMETRY produces a version Appendix Figure 9 in
            %   https://pubmed.ncbi.nlm.nih.gov/30306829/
            %
            % * L contains a tbl interesting cells.
            %
            % See also: geode.

            L = GEOMETRY(R, varargin{:});

            if nargout >= 1
                varargout{1} = L;
            end

        end

        %%%
        % random samples
        %%%

        function W = randn(R, varargin)
            % RANDN Normal random sample with optional overdispersion s2.
            %
            % W = RANDN(R)
            % W = RANDN(R, 's2', scalar)
            %
            % Events ~ max(0, randn(Events, s2 * Events))
            %
            % See also poissrnd.

            PVP = struct('s2', 1);
            N = numel(varargin);
            lArgin = varargin;
            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};

                if ~ischar(propi)
                    error('A property must be specified using a string.')
                end

                switch lower(propi)

                    case 's2'
                        if ismatrix(vali) && isreal(vali)

                            if vali > 0
                                PVP.s2 = vali;
                            end
                        else
                            error('s2 must be >= 0')
                        end

                    otherwise

                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('The last property has no matching value.');
                end
            end

            W = R;

            W.Events = max(0, R.Events + sqrt(PVP.s2*R.Events).*randn(size(R)));
            W.fullname = [R.fullname ', Normal Random Sample (s2 = ' num2str(PVP.s2) ')'];

        end

        function W = poissrnd(R, varargin)
            % POISSRND Poisson random sample with optional overdispersion s2.
            %
            % W = POISSRND(R)
            % W = POISSRND(R, 's2', scalar)
            %
            % Events ~ poissrnd(Events/s2) with Offset = Offset/s2
            %
            % See also randn.

            PVP = struct('s2', 1);
            N = numel(varargin);
            lArgin = varargin;
            while N >= 2

                propi = lArgin{1};
                vali = lArgin{2};

                if ~ischar(propi)
                    error('A property must be specified using a string.')
                end

                switch lower(propi)

                    case 's2'
                        if ismatrix(vali) && isreal(vali)

                            if vali > 0
                                PVP.s2 = vali;
                            end
                        else
                            error('s2 must be >= 0')
                        end

                    otherwise

                end

                % setup for the next pair
                lArgin = lArgin(3:end);
                N = numel(lArgin);
                if eq(N, 1)
                    error('The last property has no matching value.');
                end
            end

            switch PVP.s2
                case 1

                    W = R;
                    W.Events = poissrnd(R.Events);
                    W.fullname = [R.fullname ', Poisson Random Sample'];

                otherwise

                    W = R;
                    W.Events = poissrnd(R.Events./PVP.s2);
                    W.Offset = W.Offset./PVP.s2;
                    W.fullname = [R.fullname ', Poisson Random Sample (s2 = ' num2str(PVP.s2) ')'];

            end

        end

        %%%
        % working with rates objects
        %%%

        function U = chunk(R, varargin)
            % CHUNK Aggregate cells in successive age groups and/or calendar periods.
            %
            % S = CHUNK(R, <property-value pairs>)
            %
            % Property-value pairs:
            %
            % 'AgeBlock'  - scalar, number of age groups to combine
            % 'PerBlock'  - scalar, number of calendar periods to combine
            % 'Direction' - 'LTF' (last-to-first, default) or 'FTL' (first-to-last)
            %
            % 'LTF' - CHUNK from most to least current period and oldest to youngest
            %         age group. If there are too few * early * periods or age groups to
            %         form a complete block, leftover cells are discarded.
            %
            % 'FTL' - CHUNK from earliest to latest period and youngest to oldest
            %         age group. If there are too few * late * periods or age groups to
            %         form a complete block, leftover cells are discarded.
            %
            % See also fill.

            U = CHUNK(R, varargin{:});

        end

        function P = pad(R, varargin)
            % PAD Border Events and Offset data with 0s or NaNs.
            %
            % P = PAD(R, varargin)
            %
            % See also matrix/pad.

            P = PAD(R, varargin{:});

        end

        function Ri5 = i5(R, varargin)
            % I5 Interpolate 5-year age groups to 1-year age groups.
            %
            % Ri5 = I5(R)
            % Ri5 = I5(R, 'Method', value)
            %
            % Property-value pairs:
            %
            % 'Method' - 'linear' (default) or 'cubic'.
            %
            % * cumulative Offset and Events are interpolated within periods.
            %
            %     'linear' - single-year values match within 5 year age groups
            %     'cubic'  - smoother values don't match

            Ri5 = I5(R, varargin{:});

        end

        function W = weights(R, varargin)
            % WEIGHTS Population weights for age standardization.
            %
            % W = WEIGHTS(R, 'Pop', value)
            %
            % 'Pop' - Standard Population:
            %
            %   1 - 2000 US Standard Population (Census P25-1130)
            %   2 - 2011 Canadian Standard Population
            %   3 - World (WHO 2000-2025 Std Million)
            %   4 - Uniform Million
            %   5 - CI5 100,000
            %
            % See also asr.

            W = WEIGHTS(R, varargin{:});

        end

        function S = asr(R, varargin)
            % ASR Age-Standardized Rates over calendar periods.
            %
            % S = ASR(R, ...
            %     'Pop', < 1 (default), 2, 3, 4, or 5 >, ...
            %     'Alpha', < 0.05 (default), value between 0 and 1 >)
            %
            % S is a structure array containing:
            %
            % asr - matrix object containing the ASRs
            %
            % pca - tbl with 3 estimates of Percent Change Annualized (PCA)
            %       a.k.a. EAPC
            %
            %  SEER    - trend, Poisson variance with dispersion parameter s2
            %  Poisson - trend, Poisson variance, s2 == 1
            %  2PT     - two-point estimator, Poisson-based variance
            %
            % * 'Alpha' - confidence level
            % * s2 value may be > 1 (over-dispersion) or < 1 (under-dispersion)
            %
            % See https://pubmed.ncbi.nlm.nih.gov/16984328/ for an overview
            % of the PCA estimators.
            %
            % see also weights.

            S = ASR(R, varargin{:});

        end

        function U = uni(varargin)
            % UNI Univariate statistics for rates objects.
            %
            % U = UNI(R1, R2, ..., RK)
            % U = UNI(R1, R2, ..., RK, <property-value pairs>)
            %
            % Property-value pairs:
            %
            % 'Pop'   - population <strong>weights</strong>, 1 (default), 2, 3, 4
            % 'Alpha' - confidence level, scalar between 0 and 1 (0.05 default)
            % 'pca'   - 'SEER' (default), 'Poisson' or '2PT'
            %
            % See also weights, asr.

            U = UNI(varargin{:});

        end

        function T = type(R, varargin)
            % TYPE Tabular summaries of a rates object.
            %
            % T = TYPE(R, <property-value pairs>)
            %
            % Property-value pairs:
            %
            %  'comp'  - quantity to output:
            %             'e' events
            %             'o' offset
            %             'r' rates (default)
            %             'r1' rates for a single offset unit
            %             'eo' events, offset
            %             'er' events, rates
            %             'eor' events, offset, rates
            %             'rci' rates, 95% confidence interval
            %             'v' variance of the rates
            %             'c' cohort scores
            %             'p' period scores
            %             'a' age scores
            %             'lr' rates on log scale
            %             'lr1' log rates for a single offset unit
            %             'l10r' rates on log10 scale
            %             'lv' variance of the log rates
            %             'lexis' [a0 p0 DELTAa DELTAp A P]
            %
            % 'ages'  - add a leading column of ages, 1 (true) or 0 (false, default)
            %
            % 'Alpha' - confidence level, scalar between 0 and 1 (default 0.05)
            %
            % T is a tbl, or a numeric array when 'comp' is 'v', 'lv', or 'lexis'
            %
            % See also rates2matrix.

            T = TYPE(R, varargin{:});

        end

        function M = rates2matrix(R, varargin)
            % RATES2MATRIX - Convert a rates object to a matrix object.
            %
            % M = rates2matrix(R, ...)
            %
            % Property-Value Pair:
            % 'scale' - 'r', 'r1', 'lr' (default), 'lr1'
            %
            % See also type, matrix.

            M = RATES2MATRIX(R, varargin{:});

        end

        function varargout = distribute(varargin)
            % DISTRIBUTE Distribute events from one rates object to others.
            %
            % [D2, D3, D4, ...] = DISTRIBUTE(R1, R2, R3, R4, ...)
            %
            % Events from R1 are distributed across R2, ... in proportion
            % to the numbers of Events in R2, ... by age and period.
            %
            % DISTRIBUTE is appropriate when:
            %
            % * R1, ... contain event rates for strata within the same population.
            % * R1 contains cases with missing or unknown strata.
            % * Missing data are missing at random given age and period.
            %
            % See also plus, union.

            varargout = DISTRIBUTE(varargin{:});

        end

        function D = vec(varargin)
            % VEC Convert rates objects to a table with one row per cell.
            %
            % D = vec(R)
            % D = vec(R1, R2, ..., RK)
            %
            % See also rates2tbl.

            D = VEC(varargin{:});

        end

        function T = rates2tbl(varargin)
            % RATES2TBL Convert rates objects to a tbl with one row per cell.
            %
            % D = RATES2TBL(R)
            % D = RATES2TBL(R1, R2, ..., RK)
            %
            % See also vec.

            T = RATES2TBL(varargin{:});

        end

        function G = geode(R)
            % GEODE Age-period-cohort design matrix.
            %
            % G = geode(R)
            %
            % See also apc.

            G = GEODE(R);

        end

        function F = fill(R, varargin)

            % FILL Fill missing data in a rates object.
            %
            % F = FILL(R, ...)
            %
            % * NaN offset data are filled using neighbor averages.
            % * NaN or zero event data are replaced with a value
            %   between 0 and the smallest event count.
            %
            % Property-value pairs:
            %
            % 'zero_fill' - string 'adp' (default) or scalar
            % 'offset'    - string 'neighbors' (default) or scalar
            %
            % See also chunk.

            F = FILL(R, varargin{:});

        end

        function P = plus(varargin)
            % PLUS Add Events across rates objects with the same Offset.
            %
            % P = PLUS(R1, R2, ..., RK)
            % P = PLUS(R1, R2, ..., RK, 'text')
            % P = R1 + R2 + ... + RK
            %
            % 'text' - alternative fullname, label, and chromacode for P
            %
            % See also union, distribute.

            P = PLUS(varargin{:});

        end

        function U = union(varargin)
            % UNION Add Events and Offset across rates objects with the same ages and periods.
            %
            % U = union(R1, R2, ..., RK)
            % U = union(R1, R2, ..., RK, 'text')
            %
            % 'text' - alternative fullname, label, and chromacode for U
            %
            % See also plus, distribute.

            U = UNION(varargin{:});

        end

        %%%
        % Visualization methods
        %%%

        function pcolor(R, varargin)
            % PCOLOR Heat map of a rates object.
            %
            % PCOLOR(R)
            % PCOLOR(R, go(...))
            %
            % * absolute rates are displayed
            %
            % See also surf, go.

            switch nargin
                case 1
                    PVP = ego('class', 'rates', 'method', 'pcolor');
                case 2
                    PVP = varargin{1};
                otherwise
                    error('too many inputs')
            end


            pcolor(type(R, 'comp', 'r'), PVP)

        end

        function surf(R, varargin)
            % SURF Surface plot of a rates object.
            %
            % surf(R)
            % surf(R, go(...))
            %
            % * log rates are plotted
            %
            % See also pcolor, go.

            switch nargin
                case 1
                    PVP = ego('class', 'rates', 'method', 'surf');
                case 2
                    PVP = varargin{1};
                otherwise
                    error('too many inputs')
            end

            T = type(R, 'comp', 'lr');
            surf(T, PVP)
            view(gca, [-210 +30])

        end

        function lexis(R, varargin)
            % LEXIS - Heat maps of rates by period and cohort versus age.
            %
            % LEXIS(R)
            % LEXIS(R, Style, go(...))
            %
            % Style - 'pcolor' (default) or 'hexmap'
            %
            % * log rates are plotted
            %
            % See also ftp.

            LEXIS(R, varargin{:})

        end

        function varargout = salsa(R, varargin)
            % SALSA StAndard pLotS of a rAtes object.
            %
            % SALSA(R)
            % SALSA(R, StandardPlot)
            % SALSA(R, StandardPlot, go(...))
            % T = SALSA(...)
            %
            % StandardPlot  - 'rpa' rates versus period by age (default)
            %                 'rap' rates versus age by period
            %                 'rca' rates versus cohort by age
            %                 'rac' rates versus age by cohort
            %
            % * 'rca' and 'rac' plots are undefined when the age and
            %   period intervals of R are unequal.
            %
            % * The y-axis scale is log with absolute-value labels
            %
            % See also ftp, go.

            warning off
            T = SALSA(R, varargin{:});
            warning on

            switch nargout
                case 1
                    varargout{1} = T;
                otherwise
            end

        end

        function varargout = ftp(R, varargin)
            % FTP Four sTandard Plots of a rates object.
            %
            % Two standard plots if the age and period intervals are
            % different.
            %
            % FTP(R)
            % FTP(R, go(...))
            % T = FTP(...)
            %
            % * The y-axis scales are log with absolute-value labels
            %
            % See also salsa, go.

            T = FTP(R, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = T;
                otherwise
                    error('too many outputs')
            end

        end

        function varargout = line(R, varargin)
            % LINE Summary curves of a rates object.
            %
            % LINE(R)
            % LINE(R, curve)
            % LINE(R, curve, go(...))
            % F = LINE(...)
            %
            % curve  descriptor                 standard plot
            % 'mpc'  marginal period curve *    'rpa'
            % 'mac'  marginal age curve         'rap'
            % 'mcc'  marginal cohort curve      'rca'
            % 'dac'  diagonal age curve         'rac'
            % 'lpa'  age-specific period slopes 'rpa' and 'rca'
            % 'lap'  period-specific age slopes 'rap'
            %
            % * default
            %
            % * summary curve in left axis
            % * gradient in right axis
            % * optional go values for the summary curve
            % * preset go values for the gradient
            % * y-axis scale for summary curves is log with absolute-value labels
            % * percent-change scale for slopes and gradients
            %
            % F contains a summary curve and its gradient as matrix objects,
            % F.mpc and F.dmpc, etc.
            %
            % See also sierra, go.

            Nl = numel(varargin);
            switch Nl
                case 0
                    curve = 'mpc';
                    PVP = [];
                case 1
                    curve = varargin{1};
                    PVP = [];
                case 2
                    curve = varargin{1};
                    PVP = varargin{2};
                otherwise
                    error('too many inputs')
            end

            F = paragon(R, curve, PVP);

            switch nargout
                case 1
                    varargout{1} = F;
                otherwise
            end

        end

        function varargout = sierra(R, varargin)
            % SIERRA Plot summary curves and gradients of a rates object.
            %
            % SIERRA(R)
            % F = SIERRA(R, 'Plot', <1 (default) or 0>)
            %
            % SIERRA generates a 2 x 3 array of graphs using preset go values:
            %
            %     (1,1) mpc/dmpc, (1,2) mcc/dmcc, (1,3) lpa
            %     (2,1) dac/ddac, (2,2) mac/dmac, (2,3) lap
            %
            % F is a cell array containing summary curves and gradients:
            %   * F{1}   mpc, dmpc
            %   * F{2}   mcc, dmcc
            %   * F{3}   lpa, dlpa
            %   * F{4}   dac, ddac
            %   * F{5}   mac, dmac
            %   * F{6}   lap, dlap
            %
            % See also line, scan.

            F = florence(R, varargin{:});

            switch nargout
                case 0
                case 1
                    varargout{1} = F;
                otherwise
                    error('too many outputs')
            end
        end

        function varargout = scan(R, varargin)
            % SCAN Plot Summary Curves and estimAble fuNctions of a rates object.
            %
            % SCAN(R, 'method', <value>, 'overdispersion', <value>)
            % [EF, F] = SCAN(R, ...)
            %
            % * The apc model is fitted to R after any zeros are filled.
            %
            % See also line, apc/scan, sage/scan.

            M = apc(fill(R), varargin{:});
            [EF, F] = kandinsky(M);

            switch nargout
                case 0
                case 1
                    varargout{1} = EF;
                case 2
                    varargout{1} = EF;
                    varargout{2} = F;
                otherwise
                    error('too many outputs')
            end

        end

        % end methods
    end
    % end classdef
end